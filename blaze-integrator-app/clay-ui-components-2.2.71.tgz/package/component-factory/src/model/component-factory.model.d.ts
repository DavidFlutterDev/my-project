import { Component } from "@angular/core";
export interface IClComponentFactoryModel {
    name: string;
    type: string;
    layout: string;
    component: Component;
    children?: any[];
}
