import { IClComponentFactoryModel } from "./model/component-factory.model";
export interface IClComponentFactory extends IClComponentFactoryModel {
    name: string;
    type: string;
    layout: string;
    component: any;
    children?: any[];
}
export declare const ClComponentFactoryList: IClComponentFactory[];
