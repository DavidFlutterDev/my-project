import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import { ClEmailProperties } from '@clay/ui-components/derived';
import { ClNestedLayoutProperties, ClTreeViewProperties, ClDatePickerProperties } from '@clay/ui-components/complex';
import { ClBaseComponentProperties, ClComponentTypes } from '@clay/ui-components/shared';
import { ClDynamicTreeViewProperties, ClTimelineActivityProperties, ClResizableGridProperties, ClCarouselProperties, ClDualSortListProperties, ClDragDropProperties, ClTableConfigProperties, ClWizardProperties, ClAccordionProperties, ClStepperProperties, ClCardProperties, ClTabsProperties, ClFormProperties } from '@clay/ui-components/containers';
import { ClNestedSelectProperties, ClFilePreviewProperties, ClMultiLevelSelectProperties, ClCodeViewProperties, ClNestedAutoCompleteProperties, ClSelectWithGroupProperties, ClContactInputProperties, ClTextBlockProperties, ClToggleButtonProperties, ClHyperLinkTextProperties, ClUploadTileProperties, ClToastProperties, ClSpinnerProperties, ClIconsListProperties, ClChipListProperties, ClImageProperties, ClProgressBarProperties, ClChipsInputProperties, ClTimerProperties, ClTimePickerProperties, ClSwitchProperties, ClRadioProperties, ClAutoCompleteProperties, ClButtonProperties, ClCheckboxProperties, ClMenuProperties, ClMultiAutoCompleteProperties, ClIconProperties, ClChipProperties, ClTextareaProperties, ClLabelProperties, ClMultiSelectProperties, ClSelectProperties, ClInputProperties } from '@clay/ui-components/basic';

class ClComponentPropertyFactory {
    constructor() {
        // Define a mapping between component types and property classes
        this._componentPropertyMap = {
            [ClComponentTypes.default]: ClBaseComponentProperties,
            [ClComponentTypes.input]: ClInputProperties,
            [ClComponentTypes.form]: ClFormProperties,
            [ClComponentTypes.tabs]: ClTabsProperties,
            [ClComponentTypes.card]: ClCardProperties,
            [ClComponentTypes.select]: ClSelectProperties,
            [ClComponentTypes.stepper]: ClStepperProperties,
            [ClComponentTypes.multiselect]: ClMultiSelectProperties,
            [ClComponentTypes.label]: ClLabelProperties,
            [ClComponentTypes.textarea]: ClTextareaProperties,
            [ClComponentTypes.chip]: ClChipProperties,
            [ClComponentTypes.icon]: ClIconProperties,
            [ClComponentTypes.multiAutocomplete]: ClMultiAutoCompleteProperties,
            [ClComponentTypes.menu]: ClMenuProperties,
            [ClComponentTypes.checkbox]: ClCheckboxProperties,
            [ClComponentTypes.button]: ClButtonProperties,
            [ClComponentTypes.autocomplete]: ClAutoCompleteProperties,
            [ClComponentTypes.accordion]: ClAccordionProperties,
            [ClComponentTypes.radio]: ClRadioProperties,
            [ClComponentTypes.switch]: ClSwitchProperties,
            [ClComponentTypes.timepicker]: ClTimePickerProperties,
            [ClComponentTypes.timer]: ClTimerProperties,
            [ClComponentTypes.chipInput]: ClChipsInputProperties,
            [ClComponentTypes.progressBar]: ClProgressBarProperties,
            [ClComponentTypes.image]: ClImageProperties,
            [ClComponentTypes.chipList]: ClChipListProperties,
            [ClComponentTypes.iconsList]: ClIconsListProperties,
            [ClComponentTypes.spinner]: ClSpinnerProperties,
            [ClComponentTypes.toast]: ClToastProperties,
            [ClComponentTypes.uploadTile]: ClUploadTileProperties,
            [ClComponentTypes.hyperLinkText]: ClHyperLinkTextProperties,
            [ClComponentTypes.datePicker]: ClDatePickerProperties,
            [ClComponentTypes.treeView]: ClTreeViewProperties,
            [ClComponentTypes.toggleButton]: ClToggleButtonProperties,
            [ClComponentTypes.textBlock]: ClTextBlockProperties,
            [ClComponentTypes.wizard]: ClWizardProperties,
            [ClComponentTypes.dataGrid]: ClTableConfigProperties,
            [ClComponentTypes.dragDropUpload]: ClDragDropProperties,
            [ClComponentTypes.dualSortList]: ClDualSortListProperties,
            [ClComponentTypes.carousel]: ClCarouselProperties,
            [ClComponentTypes.contactInput]: ClContactInputProperties,
            [ClComponentTypes.email]: ClEmailProperties,
            [ClComponentTypes.resizableGrid]: ClResizableGridProperties,
            [ClComponentTypes.selectWithGroup]: ClSelectWithGroupProperties,
            [ClComponentTypes.nestedAutoComplete]: ClNestedAutoCompleteProperties,
            [ClComponentTypes.nestedLayout]: ClNestedLayoutProperties,
            [ClComponentTypes.codeView]: ClCodeViewProperties,
            [ClComponentTypes.multiLevelSelect]: ClMultiLevelSelectProperties,
            [ClComponentTypes.timelineActivity]: ClTimelineActivityProperties,
            [ClComponentTypes.dynamicTreeView]: ClDynamicTreeViewProperties,
            [ClComponentTypes.filePreview]: ClFilePreviewProperties,
            [ClComponentTypes.nestedSelect]: ClNestedSelectProperties,
        };
    }
    generateProperty(componentType, options) {
        const PropertyClass = this._componentPropertyMap[componentType];
        if (PropertyClass) {
            return new PropertyClass();
        }
        return new ClBaseComponentProperties();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClComponentPropertyFactory, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClComponentPropertyFactory, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClComponentPropertyFactory, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { ClComponentPropertyFactory };
//# sourceMappingURL=clay-ui-components-property-factory.mjs.map
