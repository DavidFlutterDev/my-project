import { ClInputComponent } from '@clay/ui-components/basic';
import { ClAccordionComponent } from '@clay/ui-components/containers';

const ClComponentFactoryList = [
    {
        name: 'Input',
        layout: 'input',
        type: 'component',
        component: ClInputComponent,
    },
    {
        type: 'container',
        name: 'Accordion',
        layout: 'accordion',
        component: ClAccordionComponent,
    },
];

/**
 * Generated bundle index. Do not edit.
 */

export { ClComponentFactoryList };
//# sourceMappingURL=clay-ui-components-component-factory.mjs.map
