import * as i1 from '@angular/router';
import { RouterModule } from '@angular/router';
import * as i2$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { coerceBooleanProperty as coerceBooleanProperty$1 } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { HostBinding, Input, ViewEncapsulation, Component, EventEmitter, TemplateRef, ViewChild, Output, ContentChild, Injectable, ContentChildren, signal, input, ViewContainerRef, computed, Inject, forwardRef, inject, InjectionToken, Directive, ElementRef, ChangeDetectionStrategy, HostListener } from '@angular/core';
import { clAnimations, ClTruncatePipe } from '@clay/ui-commons/ancillary';
import { ClComponentTypes, ClBaseContainerComponent, ClComponentInjectorComponent, ClBaseComponent } from '@clay/ui-components/shared';
import * as i2 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i1$6 from '@clay/ui-components/basic';
import { ClIconComponent, ClInputComponent, ClCheckboxComponent, ClChipListComponent, ClChipsInputComponent, ClMultiAutocompleteComponent, ClMultiselectComponent, ClContactInputComponent, ClTextareaComponent, ClChipComponent, ClRadioComponent, ClSelectComponent, ClAutocompleteComponent, ClTimePickerComponent, ClButtonComponent, ClTextBlockProperties, ClTextBlockComponent, ClButtonProperties, ClButtonBehavior, ClLabelComponent, ClUploadService, ClToggleButtonComponent, ClTimerComponent, ClImageComponent, ClProgressBarComponent, ClSpinnerComponent, ClUploadTileComponent, ClIconsListComponent } from '@clay/ui-components/basic';
import { BehaviorSubject, timer, interval, debounceTime, iif, fromEvent, merge, Observable, Subject as Subject$1, NEVER, animationFrameScheduler, combineLatest, of } from 'rxjs';
import * as i1$1 from '@angular/common';
import { CommonModule, NgClass, NgStyle, NgTemplateOutlet } from '@angular/common';
import * as i9 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i1$2 from '@angular/forms';
import { FormsModule, FormControl, Validators, ReactiveFormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i3$1 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import { DynamicFormControlDirective, FormModelDirective, FormDirective } from '@clay/ui-components/form-validations';
import { ClEmailComponent } from '@clay/ui-components/derived';
import { Subject } from 'rxjs/internal/Subject';
import { TemplatePortal } from '@angular/cdk/portal';
import * as i4 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { takeUntil } from 'rxjs/internal/operators/takeUntil';
import * as i5 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import * as i13 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import * as i1$3 from '@angular/cdk/overlay';
import * as i2$2 from '@clay/app-shell/shared';
import * as i2$3 from '@angular/material/stepper';
import { MatStepperModule } from '@angular/material/stepper';
import { timer as timer$1 } from 'rxjs/internal/observable/timer';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as i3 from '@angular/material/expansion';
import { MatExpansionPanel, MatExpansionModule } from '@angular/material/expansion';
import { debounce, cloneDeep } from 'lodash';
import { CdkTableModule } from '@angular/cdk/table';
import * as i4$1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import * as i11 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import * as i14 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i15 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i17 from '@angular/material/progress-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import * as i1$4 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import * as i4$2 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i16 from '@angular/material/paginator';
import { MatPaginatorModule, MatPaginator } from '@angular/material/paginator';
import * as i6$1 from '@angular/material/sort';
import { MatSortModule, MatSort } from '@angular/material/sort';
import * as i10 from '@angular/material/table';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import * as i6 from '@angular/material/core';
import * as i1$5 from '@angular/material/bottom-sheet';
import { MAT_BOTTOM_SHEET_DATA, MatBottomSheet } from '@angular/material/bottom-sheet';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { filter, switchMap, startWith, exhaustMap, takeUntil as takeUntil$1, take, map, tap, distinctUntilChanged } from 'rxjs/operators';
import { ClTreeViewComponent } from '@clay/ui-components/complex';

class ClCardStyleProperties {
}
class ClCardProperties {
    constructor() {
        this.children = [];
        this.id = 'default0';
        this.type = ClComponentTypes.card;
        this.style = new ClCardStyleProperties;
        this.style.cssClasses = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.labelCssClasses = 'text-2xl md:text-3xl font-medium  ';
    }
}

class ClCardComponent extends ClBaseContainerComponent {
    /* eslint-enable @typescript-eslint/naming-convention */
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.expanded = false;
        this.face = 'front';
        this.flippable = false;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClCardProperties();
        super.ngOnInit();
    }
    /**
     * Host binding for component classes
     */
    get classList() {
        /* eslint-disable @typescript-eslint/naming-convention */
        return {
            'cl-card-expanded': this.expanded,
            'cl-card-face-back': this.flippable && this.face === 'back',
            'cl-card-face-front': this.flippable && this.face === 'front',
            'cl-card-flippable': this.flippable,
        };
        /* eslint-enable @typescript-eslint/naming-convention */
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------
    /**
     * On changes
     *
     * @param changes
     */
    ngOnChanges(changes) {
        // Expanded
        if ('expanded' in changes) {
            // Coerce the value to a boolean
            this.expanded = coerceBooleanProperty$1(changes['expanded'].currentValue);
        }
        // Flippable
        if ('flippable' in changes) {
            // Coerce the value to a boolean
            this.flippable = coerceBooleanProperty$1(changes['flippable'].currentValue);
        }
    }
    onCardClicked() {
        if (this.properties?.onCardClicked) {
            this.properties.onCardClicked();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClCardComponent, isStandalone: true, selector: "cl-card", inputs: { expanded: "expanded", face: "face", flippable: "flippable", properties: "properties" }, host: { properties: { "class": "this.classList" } }, exportAs: ["clCard"], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<!-- Flippable card -->\n@if (properties.flippable!) {\n  <!-- Title -->\n  <div class=\"{{properties.style?.labelCssClasses}} tracking-tight leading-7 sm:leading-10\">\n    <ng-content select=\"[clFlipCardTitle]\"></ng-content>\n  </div>\n  <!-- Title -->\n  <!-- Front -->\n  <div class=\"cl-card-front {{properties.style?.cssClasses}}\">\n    <ng-content select=\"[clCardFront]\"></ng-content>\n  </div>\n  <!-- Front -->\n  <!-- Back -->\n  <div class=\"cl-card-back {{properties.style?.cssClasses}}\">\n    <ng-content select=\"[clCardBack]\"></ng-content>\n  </div>\n  <!-- Back -->\n}\n<!-- Flippable card -->\n<!-- Normal card -->\n@if (!properties.flippable) {\n  <div id=\"properties?.id\" (click)=\"onCardClicked()\" [routerLink]=\"properties.routerLink!\"\n    class=\"p-4 flex flex-col w-full {{properties.routerLink ? 'cursor-pointer' : ''}} {{properties.style?.cssClasses}}\">\n    <!-- Title -->\n    <div class=\"{{properties.style?.labelCssClasses}} flex flex-row justify-between tracking-tight leading-7 sm:leading-10 \">\n      <ng-content select=\"[clCardTitle]\"></ng-content>\n      <ng-content select=\"[clCardActions]\"></ng-content>\n    </div>\n    <!-- Title -->\n    <!-- Content -->\n    <ng-content></ng-content>\n    <!-- Content -->\n  </div>\n  <!-- Content -->\n  <!-- Expansion -->\n  @if (expanded) {\n    <div [@expandCollapse] class=\"cl-card-expansion\">\n      <ng-content select=\"[clCardExpansion]\"></ng-content>\n    </div>\n  }\n  <!-- Expansion -->\n}\n<!-- Normal card -->\n", styles: ["cl-card{position:relative;display:flex;overflow:hidden;--tw-bg-opacity: 1;background-color:rgba(var(--cl-bg-card-rgb),var(--tw-bg-opacity));border-radius:1rem;--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable{border-radius:0;overflow:visible;transform-style:preserve-3d;transition:transform 1s;perspective:600px;background:transparent;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable.cl-card-face-back .cl-card-front{visibility:hidden;opacity:0;transform:rotateY(180deg)}cl-card.cl-card-flippable.cl-card-face-back .cl-card-back{visibility:visible;opacity:1;transform:rotateY(360deg)}cl-card.cl-card-flippable .cl-card-front,cl-card.cl-card-flippable .cl-card-back{display:flex;flex-direction:column;flex:1 1 auto;z-index:10;transition:transform .5s ease-out 0s,visibility 0s ease-in .2s,opacity 0s ease-in .2s;backface-visibility:hidden;--tw-bg-opacity: 1;background-color:rgba(var(--cl-bg-card-rgb),var(--tw-bg-opacity));border-radius:1rem;--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable .cl-card-front{position:relative;opacity:1;visibility:visible;transform:rotateY(0);overflow:hidden}cl-card.cl-card-flippable .cl-card-back{position:absolute;inset:0;opacity:0;visibility:hidden;transform:rotateY(180deg);overflow:hidden auto}\n"], dependencies: [{ kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "ngmodule", type: MatIconModule }], animations: clAnimations, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCardComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, exportAs: 'clCard', selector: 'cl-card', animations: clAnimations, encapsulation: ViewEncapsulation.None, imports: [RouterModule, MatIconModule], template: "<!-- Flippable card -->\n@if (properties.flippable!) {\n  <!-- Title -->\n  <div class=\"{{properties.style?.labelCssClasses}} tracking-tight leading-7 sm:leading-10\">\n    <ng-content select=\"[clFlipCardTitle]\"></ng-content>\n  </div>\n  <!-- Title -->\n  <!-- Front -->\n  <div class=\"cl-card-front {{properties.style?.cssClasses}}\">\n    <ng-content select=\"[clCardFront]\"></ng-content>\n  </div>\n  <!-- Front -->\n  <!-- Back -->\n  <div class=\"cl-card-back {{properties.style?.cssClasses}}\">\n    <ng-content select=\"[clCardBack]\"></ng-content>\n  </div>\n  <!-- Back -->\n}\n<!-- Flippable card -->\n<!-- Normal card -->\n@if (!properties.flippable) {\n  <div id=\"properties?.id\" (click)=\"onCardClicked()\" [routerLink]=\"properties.routerLink!\"\n    class=\"p-4 flex flex-col w-full {{properties.routerLink ? 'cursor-pointer' : ''}} {{properties.style?.cssClasses}}\">\n    <!-- Title -->\n    <div class=\"{{properties.style?.labelCssClasses}} flex flex-row justify-between tracking-tight leading-7 sm:leading-10 \">\n      <ng-content select=\"[clCardTitle]\"></ng-content>\n      <ng-content select=\"[clCardActions]\"></ng-content>\n    </div>\n    <!-- Title -->\n    <!-- Content -->\n    <ng-content></ng-content>\n    <!-- Content -->\n  </div>\n  <!-- Content -->\n  <!-- Expansion -->\n  @if (expanded) {\n    <div [@expandCollapse] class=\"cl-card-expansion\">\n      <ng-content select=\"[clCardExpansion]\"></ng-content>\n    </div>\n  }\n  <!-- Expansion -->\n}\n<!-- Normal card -->\n", styles: ["cl-card{position:relative;display:flex;overflow:hidden;--tw-bg-opacity: 1;background-color:rgba(var(--cl-bg-card-rgb),var(--tw-bg-opacity));border-radius:1rem;--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable{border-radius:0;overflow:visible;transform-style:preserve-3d;transition:transform 1s;perspective:600px;background:transparent;--tw-shadow: 0 0 #0000;--tw-shadow-colored: 0 0 #0000;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable.cl-card-face-back .cl-card-front{visibility:hidden;opacity:0;transform:rotateY(180deg)}cl-card.cl-card-flippable.cl-card-face-back .cl-card-back{visibility:visible;opacity:1;transform:rotateY(360deg)}cl-card.cl-card-flippable .cl-card-front,cl-card.cl-card-flippable .cl-card-back{display:flex;flex-direction:column;flex:1 1 auto;z-index:10;transition:transform .5s ease-out 0s,visibility 0s ease-in .2s,opacity 0s ease-in .2s;backface-visibility:hidden;--tw-bg-opacity: 1;background-color:rgba(var(--cl-bg-card-rgb),var(--tw-bg-opacity));border-radius:1rem;--tw-shadow: 0 1px 3px 0 rgb(0 0 0 / .1), 0 1px 2px -1px rgb(0 0 0 / .1);--tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}cl-card.cl-card-flippable .cl-card-front{position:relative;opacity:1;visibility:visible;transform:rotateY(0);overflow:hidden}cl-card.cl-card-flippable .cl-card-back{position:absolute;inset:0;opacity:0;visibility:hidden;transform:rotateY(180deg);overflow:hidden auto}\n"] }]
        }], ctorParameters: () => [], propDecorators: { expanded: [{
                type: Input
            }], face: [{
                type: Input
            }], flippable: [{
                type: Input
            }], properties: [{
                type: Input
            }], classList: [{
                type: HostBinding,
                args: ['class']
            }] } });

class ClTabHeaderComponent {
    constructor() {
        this.tabHeaderClicked = new EventEmitter();
    }
    onIconClicked(icon) {
        this.tabHeaderClicked.emit({ tabLabel: this.properties.label, actionIcon: icon.iconName });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTabHeaderComponent, isStandalone: true, selector: "cl-tab-header", inputs: { properties: "properties" }, outputs: { tabHeaderClicked: "tabHeaderClicked" }, viewQueries: [{ propertyName: "headerTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template mat-tab-label>\n  <span class=\"inline-flex items-center space-x-2\">\n\n    @if (properties.iconName) {\n      <mat-icon class=\"{{ properties.iconSize }}\" [svgIcon]=\"properties.iconName\"></mat-icon>\n    }\n    @if(properties.label) {\n     <span class=\"\">{{ properties.label }}</span>\n    }\n\n    @if (properties.count) {\n      <span class=\"px-2 py-1 text-sm rounded-full bg-primary-100 text-on-primary-100\">{{ properties.count }}</span>\n    }\n\n    @if (properties.actionIcons?.length) {\n      @for (icon of properties.actionIcons; track $index) {\n        <mat-icon (click)=\"$event.stopPropagation(); onIconClicked(icon)\" [svgIcon]=\"icon.iconName!\"\n          class=\"{{ icon.style?.cssClasses }} flex items-center justify-center {{ icon.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n        </mat-icon>\n      }\n    }\n\n    <div class=\"tab-seperator\"></div>\n  </span>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatTabsModule }, { kind: "directive", type: i2.MatTabLabel, selector: "[mat-tab-label], [matTabLabel]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabHeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tab-header', imports: [MatTabsModule, MatIconModule, ClIconComponent], template: "<ng-template mat-tab-label>\n  <span class=\"inline-flex items-center space-x-2\">\n\n    @if (properties.iconName) {\n      <mat-icon class=\"{{ properties.iconSize }}\" [svgIcon]=\"properties.iconName\"></mat-icon>\n    }\n    @if(properties.label) {\n     <span class=\"\">{{ properties.label }}</span>\n    }\n\n    @if (properties.count) {\n      <span class=\"px-2 py-1 text-sm rounded-full bg-primary-100 text-on-primary-100\">{{ properties.count }}</span>\n    }\n\n    @if (properties.actionIcons?.length) {\n      @for (icon of properties.actionIcons; track $index) {\n        <mat-icon (click)=\"$event.stopPropagation(); onIconClicked(icon)\" [svgIcon]=\"icon.iconName!\"\n          class=\"{{ icon.style?.cssClasses }} flex items-center justify-center {{ icon.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n        </mat-icon>\n      }\n    }\n\n    <div class=\"tab-seperator\"></div>\n  </span>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], tabHeaderClicked: [{
                type: Output
            }], headerTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClTabHeaderProperties {
    constructor() {
        this.actionIcons = [];
        this.iconSize = 'icon-size-4';
    }
}

class ClTabComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClTabComponent, isStandalone: true, selector: "cl-tab", queries: [{ propertyName: "tabHeader", first: true, predicate: ClTabHeaderComponent, descendants: true }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template>\n  <ng-content select=\"cl-tab-content\"></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tab', template: "<ng-template>\n  <ng-content select=\"cl-tab-content\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], tabHeader: [{
                type: ContentChild,
                args: [ClTabHeaderComponent]
            }] } });

class ClTabContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClTabContentComponent, isStandalone: true, selector: "cl-tab-content", ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tab-content', template: "<ng-content></ng-content>\n" }]
        }] });

class ClTabsService {
    constructor() {
        this.previousTab = 0;
        this.tabsData = new BehaviorSubject({});
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabsService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

var ClTabsAlignment;
(function (ClTabsAlignment) {
    ClTabsAlignment["end"] = "end";
    ClTabsAlignment["start"] = "start";
    ClTabsAlignment["center"] = "center";
})(ClTabsAlignment || (ClTabsAlignment = {}));
class ClTabsStyleProperties {
}
class ClTabsProperties {
    constructor() {
        this.id = 'default0';
        this.activeTab = 0;
        this.stretchTabs = false;
        this.animationDuration = 600;
        this.type = ClComponentTypes.tabs;
        this.style = new ClTabsStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.tabProperties = [
            {
                tabHeaderProperties: { label: 'Tab1', actionIcons: [] },
                tabContentProperties: []
            },
            {
                tabHeaderProperties: { label: 'Tab2', actionIcons: [] },
                tabContentProperties: []
            }
        ];
    }
}

class ClTabsComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(_changes) {
        this.activeTab ??= this.properties.activeTab;
    }
    ngOnInit() {
        this.properties ??= new ClTabsProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.tabs = this.contentItems;
        });
    }
    selectedTabChange(event) {
        if (this.properties.onSelectedTabChange) {
            this.properties.onSelectedTabChange(event.index);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTabsComponent, isStandalone: true, selector: "cl-tabs", inputs: { activeTab: "activeTab", properties: "properties" }, queries: [{ propertyName: "contentItems", predicate: ClTabComponent }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-tab-group [dynamicHeight]=\"true\" [preserveContent]=\"false\" class=\"flex h-full w-full\" [selectedIndex]=\"activeTab\"\n  [mat-stretch-tabs]=\"properties.stretchTabs\" [animationDuration]=\"properties.animationDuration!\"\n  [fitInkBarToContent]=\"properties.fitInkBarToContent\" (selectedTabChange)=\"selectedTabChange($any($event))\">\n\n  @for (tab of tabs; track tab) {\n    <mat-tab class=\"flex h-full w-full\">\n      <ng-template mat-tab-label>\n        <ng-container *ngTemplateOutlet=\"tab.tabHeader!.headerTemplate\"></ng-container>\n      </ng-template>\n\n      <ng-container *ngTemplateOutlet=\"tab.contentTemplate\"></ng-container>\n    </mat-tab>\n  }\n</mat-tab-group>\n", styles: [".dense-tab-container{width:100%}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container{margin:0!important;height:2.625rem!important;--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-bg-default-rgb),var(--tw-bg-opacity))!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels{height:2.313rem!important;margin-top:.313rem}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab{padding:0!important;height:2.313rem!important;z-index:99;min-width:0px!important;position:relative;--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-bg-default-rgb),var(--tw-bg-opacity))!important;border-top-left-radius:.5rem!important;border-top-right-radius:.5rem!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .tab-seperator{height:100%;position:absolute;right:1px;border-color:#c6c6c6;border-left-width:1px;border-style:solid}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .mdc-tab__text-label{padding:0 15px!important;color:#231e2f!important;font-weight:400!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .mdc-tab__content{background-color:#eee}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab:has(+.mdc-tab-indicator--active) .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab:last-child .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active{z-index:999!important;--tw-bg-opacity: 1 !important;background-color:rgb(255 255 255 / var(--tw-bg-opacity))!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mdc-tab__content{background-color:#fcfcfc}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mat-mdc-tab-ripple{border-width:1px!important;border-bottom-width:0px!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mat-ripple{z-index:999!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator__content--underline{width:100%!important}.dense-tab-container>mat-tab-group>.mat-mdc-tab-body-wrapper>mat-tab-body{--tw-bg-opacity: 1 !important;background-color:rgb(255 255 255 / var(--tw-bg-opacity))!important}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "directive", type: i2.MatTabLabel, selector: "[mat-tab-label], [matTabLabel]" }, { kind: "component", type: i2.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass"], exportAs: ["matTab"] }, { kind: "component", type: i2.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatFormFieldModule }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabsComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tabs', encapsulation: ViewEncapsulation.None, imports: [
                        CommonModule,
                        MatTabsModule,
                        MatIconModule,
                        MatFormFieldModule
                    ], template: "<mat-tab-group [dynamicHeight]=\"true\" [preserveContent]=\"false\" class=\"flex h-full w-full\" [selectedIndex]=\"activeTab\"\n  [mat-stretch-tabs]=\"properties.stretchTabs\" [animationDuration]=\"properties.animationDuration!\"\n  [fitInkBarToContent]=\"properties.fitInkBarToContent\" (selectedTabChange)=\"selectedTabChange($any($event))\">\n\n  @for (tab of tabs; track tab) {\n    <mat-tab class=\"flex h-full w-full\">\n      <ng-template mat-tab-label>\n        <ng-container *ngTemplateOutlet=\"tab.tabHeader!.headerTemplate\"></ng-container>\n      </ng-template>\n\n      <ng-container *ngTemplateOutlet=\"tab.contentTemplate\"></ng-container>\n    </mat-tab>\n  }\n</mat-tab-group>\n", styles: [".dense-tab-container{width:100%}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container{margin:0!important;height:2.625rem!important;--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-bg-default-rgb),var(--tw-bg-opacity))!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels{height:2.313rem!important;margin-top:.313rem}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab{padding:0!important;height:2.313rem!important;z-index:99;min-width:0px!important;position:relative;--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-bg-default-rgb),var(--tw-bg-opacity))!important;border-top-left-radius:.5rem!important;border-top-right-radius:.5rem!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .tab-seperator{height:100%;position:absolute;right:1px;border-color:#c6c6c6;border-left-width:1px;border-style:solid}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .mdc-tab__text-label{padding:0 15px!important;color:#231e2f!important;font-weight:400!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab .mdc-tab__content{background-color:#eee}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab:has(+.mdc-tab-indicator--active) .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab:last-child .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active{z-index:999!important;--tw-bg-opacity: 1 !important;background-color:rgb(255 255 255 / var(--tw-bg-opacity))!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mdc-tab__content{background-color:#fcfcfc}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mat-mdc-tab-ripple{border-width:1px!important;border-bottom-width:0px!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .mat-ripple{z-index:999!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator--active .tab-seperator{display:none!important}.dense-tab-container>mat-tab-group>mat-tab-header>.mat-mdc-tab-label-container .mat-mdc-tab-labels .mdc-tab-indicator__content--underline{width:100%!important}.dense-tab-container>mat-tab-group>.mat-mdc-tab-body-wrapper>mat-tab-body{--tw-bg-opacity: 1 !important;background-color:rgb(255 255 255 / var(--tw-bg-opacity))!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { activeTab: [{
                type: Input
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }], contentItems: [{
                type: ContentChildren,
                args: [ClTabComponent]
            }] } });

class ClFormComponent {
    ngOnChanges() {
        if (this.properties && this.properties.colsPerRow) {
            switch (this.properties.colsPerRow) {
                case 8:
                    this.gridClass = `xl:grid-cols-8 lg:grid-cols-8 md:grid-cols-8`;
                    break;
                case 5:
                    this.gridClass = `xl:grid-cols-5 lg:grid-cols-5 md:grid-cols-5`;
                    break;
                case 4:
                    this.gridClass = `xl:grid-cols-4 lg:grid-cols-4 md:grid-cols-3`;
                    break;
                case 3:
                    this.gridClass = `xl:grid-cols-3 lg:grid-cols-3 md:grid-cols-2`;
                    break;
                case 2:
                    this.gridClass = `xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2`;
                    break;
                case 1:
                    this.gridClass = `xl:grid-cols-1 lg:grid-cols-1 md:grid-cols-1`;
                    break;
                default:
                    this.gridClass = `xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2`;
                    break;
            }
        }
        else {
            this.gridClass = `xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2`;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFormComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClFormComponent, isStandalone: true, selector: "cl-form", inputs: { properties: "properties" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"grid w-full {{properties?.style?.alignItem || 'items-center'}} {{properties?.style?.gap || 'gap-4'}} {{properties.style?.cssClasses ?? gridClass }}\">\n  @for(child of properties!.children; track child) {\n    @switch (child.layout) {\n      @case ('checkbox') {\n        <cl-checkbox clDynamicFormControl  class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"\n        ></cl-checkbox>\n      }\n      @case ('chipList') {\n        <cl-chip-list clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  >\n        </cl-chip-list>\n      }\n      @case ('chipInput') {\n        <cl-chips-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-chips-input>\n      }\n\n      @case ('multiAutocomplete') {\n        <cl-multi-autocomplete clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\" ></cl-multi-autocomplete>\n      }\n      @case ('multiselect') {\n        <cl-multiselect clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\" ></cl-multiselect>\n      }\n      @case ('input') {\n        <cl-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-input>\n       }\n      @case ('email') {\n        <cl-email class=\"w-full\" [properties]=\"child!.properties\" ></cl-email>\n      }\n      @case ('contactInput') {\n        <cl-contact-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-contact-input>\n      }\n      @case ('textarea') {\n        <cl-textarea clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-textarea>\n      }\n      @case ('chip') {\n        <cl-chip  class=\"w-full\" [properties]=\"child!.properties\" ></cl-chip>\n      }\n      @case ('radio') {\n        <cl-radio clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-radio>\n      }\n      @case ('select') {\n        <cl-select clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-select>\n      }\n      @case ('autocomplete') {\n        <cl-autocomplete clDynamicFormControl  class=\"w-full\" [properties]='child!.properties' [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-autocomplete>\n      }\n      @case ('timepicker') {\n        <cl-time-picker clDynamicFormControl  class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-time-picker>\n      }\n      @case ('button')  {\n        <cl-button [properties]=\"child!.properties\">\n        </cl-button>\n      }\n    }\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClInputComponent, selector: "cl-input", inputs: ["properties"] }, { kind: "component", type: ClCheckboxComponent, selector: "cl-checkbox", inputs: ["properties"] }, { kind: "component", type: ClChipListComponent, selector: "cl-chip-list", inputs: ["properties"] }, { kind: "component", type: ClChipsInputComponent, selector: "cl-chips-input", inputs: ["properties"], outputs: ["optionsAdded"] }, { kind: "component", type: ClMultiAutocompleteComponent, selector: "cl-multi-autocomplete", inputs: ["properties"] }, { kind: "component", type: ClMultiselectComponent, selector: "cl-multiselect", inputs: ["properties"] }, { kind: "component", type: ClEmailComponent, selector: "cl-email", inputs: ["properties"] }, { kind: "component", type: ClContactInputComponent, selector: "cl-contact-input", inputs: ["properties"] }, { kind: "component", type: ClTextareaComponent, selector: "cl-textarea", inputs: ["properties"] }, { kind: "component", type: ClChipComponent, selector: "cl-chip", inputs: ["properties"] }, { kind: "component", type: ClRadioComponent, selector: "cl-radio", inputs: ["properties"] }, { kind: "component", type: ClSelectComponent, selector: "cl-select", inputs: ["properties"] }, { kind: "component", type: ClAutocompleteComponent, selector: "cl-autocomplete", inputs: ["properties"] }, { kind: "component", type: ClTimePickerComponent, selector: "cl-time-picker", inputs: ["properties"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "directive", type: DynamicFormControlDirective, selector: "[clDynamicFormControl]", inputs: ["dynamicFormControl", "formGroup", "validators"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFormComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-form', imports: [
                        MatIconModule,
                        MatInputModule,
                        FormsModule,
                        MatFormFieldModule,
                        ClInputComponent,
                        ClCheckboxComponent,
                        ClChipListComponent,
                        ClChipsInputComponent,
                        ClMultiAutocompleteComponent,
                        ClMultiselectComponent,
                        ClEmailComponent,
                        ClContactInputComponent,
                        ClTextareaComponent,
                        ClChipComponent,
                        ClRadioComponent,
                        ClSelectComponent,
                        ClAutocompleteComponent,
                        ClTimePickerComponent,
                        ClButtonComponent,
                        DynamicFormControlDirective,
                    ], template: "<div class=\"grid w-full {{properties?.style?.alignItem || 'items-center'}} {{properties?.style?.gap || 'gap-4'}} {{properties.style?.cssClasses ?? gridClass }}\">\n  @for(child of properties!.children; track child) {\n    @switch (child.layout) {\n      @case ('checkbox') {\n        <cl-checkbox clDynamicFormControl  class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"\n        ></cl-checkbox>\n      }\n      @case ('chipList') {\n        <cl-chip-list clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  >\n        </cl-chip-list>\n      }\n      @case ('chipInput') {\n        <cl-chips-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-chips-input>\n      }\n\n      @case ('multiAutocomplete') {\n        <cl-multi-autocomplete clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\" ></cl-multi-autocomplete>\n      }\n      @case ('multiselect') {\n        <cl-multiselect clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\" ></cl-multiselect>\n      }\n      @case ('input') {\n        <cl-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-input>\n       }\n      @case ('email') {\n        <cl-email class=\"w-full\" [properties]=\"child!.properties\" ></cl-email>\n      }\n      @case ('contactInput') {\n        <cl-contact-input clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-contact-input>\n      }\n      @case ('textarea') {\n        <cl-textarea clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-textarea>\n      }\n      @case ('chip') {\n        <cl-chip  class=\"w-full\" [properties]=\"child!.properties\" ></cl-chip>\n      }\n      @case ('radio') {\n        <cl-radio clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-radio>\n      }\n      @case ('select') {\n        <cl-select clDynamicFormControl class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-select>\n      }\n      @case ('autocomplete') {\n        <cl-autocomplete clDynamicFormControl  class=\"w-full\" [properties]='child!.properties' [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-autocomplete>\n      }\n      @case ('timepicker') {\n        <cl-time-picker clDynamicFormControl  class=\"w-full\" [properties]=\"child!.properties\" [dynamicFormControl]=\"child!.properties!.name\" [formGroup]=\"properties!.formGroup\" [validators]=\"child!.properties.validationsList\"  ></cl-time-picker>\n      }\n      @case ('button')  {\n        <cl-button [properties]=\"child!.properties\">\n        </cl-button>\n      }\n    }\n  }\n</div>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClFormStyleProperties {
}
class ClFormProperties {
    constructor() {
        this.type = ClComponentTypes.form;
        this.id = "default0";
        this.style = new ClFormStyleProperties();
        this.style.cssClasses = "";
    }
}

class ClWizardComponent extends ClBaseContainerComponent {
    constructor(_parentOverlay, _contentOverlay, _viewContainerRef, _changeDetectorRef, _clMediaWatcherService) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this._parentOverlay = _parentOverlay;
        this._contentOverlay = _contentOverlay;
        this._viewContainerRef = _viewContainerRef;
        this._changeDetectorRef = _changeDetectorRef;
        this._clMediaWatcherService = _clMediaWatcherService;
        this.onOptionChange = new EventEmitter();
        this.drawerOpened = true;
        // public drawerMode: 'over' | 'side' = 'side';
        this.drawerMode = 'side';
        this._unsubscribeAll = new Subject();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(_changes) {
        // setting first option as selected
        this.selectedOption ??= this.properties.selectedOption ?? this.properties.options[0];
        this.activeIndex = this.selectedOption != undefined ? this.properties.options?.findIndex((option) => option.id == this.selectedOption?.id) : -1;
    }
    ngOnInit() {
        // setting first option as selected
        this.selectedOption ??= this.properties.selectedOption ?? this.properties.options[0];
        // Subscribe to media changes
        this._clMediaWatcherService.onMediaChange$
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe(({ matchingAliases }) => {
            // Set the drawerMode and drawerOpened
            if (matchingAliases.includes('lg')) {
                this.drawerMode = 'side';
                this.drawerOpened = true;
            }
            else {
                this.drawerMode = 'over';
                this.drawerOpened = false;
            }
            // Mark for check
            this._changeDetectorRef.detectChanges();
        });
        super.ngOnInit();
    }
    /**
     * On destroy
     */
    ngOnDestroy() {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next(null);
        this._unsubscribeAll.complete();
        super.ngOnDestroy();
    }
    /**
     * Navigate to the panel
     *
     * @param option
     */
    goToComponent(option) {
        this.selectedOption = option;
        this.activeIndex = this.selectedOption != undefined ? this.properties.options?.findIndex((option) => option.id == this.selectedOption?.id) : -1;
        this.onOptionChange.emit(this.selectedOption);
        // Close the drawer on 'over' mode
        if (this.drawerMode === 'over') {
            this.drawer.close();
        }
    }
    /**
     * Get the details of the panel
     *
     * @param id
     */
    getOptionInfo(id) {
        return this.properties.options.find(option => option.id === id);
    }
    /**
     * Track by function for ngFor loops
     *
     * @param index
     * @param item
     */
    trackByFn(index, item) {
        return item.id || index;
    }
    onIconClick() {
        if (this.properties.actionIcons?.onClick) {
            this.properties.actionIcons?.onClick();
        }
        else {
            this.addActionIconOverlay();
        }
    }
    onContentIconClick() {
        if (this.selectedOption?.actionIcons?.onClick) {
            this.selectedOption?.actionIcons.onClick();
        }
        else {
            this.addContentActionIconOverlay();
        }
    }
    onParentOptionClick(selectedOption) {
        this._parentOverlayRef.detach();
        if (selectedOption.onOptionClick) {
            selectedOption.onOptionClick();
        }
    }
    onContentOptionClick(selectedOption) {
        this._contentOverlayRef.detach();
        if (selectedOption.onOptionClick) {
            selectedOption.onOptionClick();
        }
    }
    addActionIconOverlay() {
        if (this.properties.actionIcons?.options?.length == undefined) {
            return;
        }
        // Return if the messages panel or its origin is not defined
        if (!this.parentActionIconOverlay || !this.parentActionIconOrigin) {
            return;
        }
        // Create the overlay if it doesn't exist
        this._createParentOverlay();
        // Attach the portal to the overlay
        this._parentOverlayRef.attach(new TemplatePortal(this.parentActionIconOverlay, this._viewContainerRef));
    }
    addContentActionIconOverlay() {
        if (this.selectedOption?.actionIcons?.options?.length == undefined) {
            return;
        }
        // Return if the messages panel or its origin is not defined
        if (!this.contentActionIconOverlay || !this.contentActionIconOrigin) {
            return;
        }
        // Create the overlay if it doesn't exist
        if (!this._contentOverlayRef) {
            this._createContentOverlay();
        }
        // Attach the portal to the overlay
        this._contentOverlayRef.attach(new TemplatePortal(this.contentActionIconOverlay, this._viewContainerRef));
    }
    _createParentOverlay() {
        // Create the overlay
        this._parentOverlayRef = this._parentOverlay.create({
            hasBackdrop: true,
            backdropClass: 'cl-backdrop-on-mobile',
            scrollStrategy: this._parentOverlay.scrollStrategies.block(),
            positionStrategy: this._parentOverlay
                .position()
                .flexibleConnectedTo(this.parentActionIconOrigin._elementRef.nativeElement)
                .withLockedPosition(true)
                .withPush(true)
                .withPositions([
                {
                    originX: 'start',
                    originY: 'bottom',
                    overlayX: 'start',
                    overlayY: 'top',
                },
                {
                    originX: 'start',
                    originY: 'top',
                    overlayX: 'start',
                    overlayY: 'bottom',
                },
                {
                    originX: 'end',
                    originY: 'bottom',
                    overlayX: 'end',
                    overlayY: 'top',
                },
                {
                    originX: 'end',
                    originY: 'top',
                    overlayX: 'end',
                    overlayY: 'bottom',
                },
            ]),
        });
        // Detach the overlay from the portal on backdrop click
        this._parentOverlayRef.backdropClick()
            .subscribe(() => {
            this._parentOverlayRef.detach();
        });
    }
    _createContentOverlay() {
        // Create the overlay
        this._contentOverlayRef = this._contentOverlay.create({
            hasBackdrop: true,
            backdropClass: 'cl-backdrop-on-mobile',
            scrollStrategy: this._contentOverlay.scrollStrategies.block(),
            positionStrategy: this._contentOverlay
                .position()
                .flexibleConnectedTo(this.contentActionIconOrigin._elementRef.nativeElement)
                .withLockedPosition(true)
                .withPush(true)
                .withPositions([
                {
                    originX: 'start',
                    originY: 'bottom',
                    overlayX: 'start',
                    overlayY: 'top',
                },
                {
                    originX: 'start',
                    originY: 'top',
                    overlayX: 'start',
                    overlayY: 'bottom',
                },
                {
                    originX: 'end',
                    originY: 'bottom',
                    overlayX: 'end',
                    overlayY: 'top',
                },
                {
                    originX: 'end',
                    originY: 'top',
                    overlayX: 'end',
                    overlayY: 'bottom',
                },
            ]),
        });
        // Detach the overlay from the portal on backdrop click
        this._contentOverlayRef.backdropClick()
            .subscribe(() => {
            this._contentOverlayRef.detach();
        });
    }
    onSuffixIconClicked(option) {
        if (option.onSuffixIconClicked) {
            option.onSuffixIconClicked(option);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClWizardComponent, deps: [{ token: i1$3.Overlay }, { token: i1$3.Overlay }, { token: i0.ViewContainerRef }, { token: i0.ChangeDetectorRef }, { token: i2$2.ClMediaWatcherService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClWizardComponent, isStandalone: true, selector: "cl-wizard", inputs: { selectedOption: "selectedOption", properties: "properties" }, outputs: { onOptionChange: "onOptionChange" }, viewQueries: [{ propertyName: "drawer", first: true, predicate: ["drawer"], descendants: true }, { propertyName: "parentActionIconOrigin", first: true, predicate: ["parentActionIconOrigin"], descendants: true }, { propertyName: "contentActionIconOrigin", first: true, predicate: ["contentActionIconOrigin"], descendants: true }, { propertyName: "parentActionIconOverlay", first: true, predicate: ["parentActionIconOverlay"], descendants: true }, { propertyName: "contentActionIconOverlay", first: true, predicate: ["contentActionIconOverlay"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"flex flex-col w-full h-full min-w-0 sm:absolute sm:overflow-hidden {{ properties.style?.cssClasses }}\">\n  <mat-drawer-container class=\"flex-auto sm:h-full\">\n    <!-- Drawer -->\n    <mat-drawer #drawer [autoFocus]=\"false\" [mode]=\"drawerMode\" [(opened)]=\"drawerOpened\" (closed)=\"!drawerOpened\"\n      class=\"sm:w-80 dark:bg-gray-900 border-none\">\n      <!-- Header -->\n      <div class=\"flex items-center justify-between mx-4 my-8 sticky top-0\">\n        <!-- Title -->\n        <div class=\"flex justify-between items-center gap-3\">\n          <div class=\"text-3xl font-extrabold tracking-tight leading-none\">{{ properties.label }}</div>\n\n          @if (properties.actionIcons) {\n            <div class=\"flex gap-2 items-center\">\n              <mat-icon #parentActionIconOrigin (click)=\"onIconClick()\"\n                class=\"{{properties.actionIcons.classes}} cursor-pointer\" [svgIcon]=\"properties.actionIcons.icon!\">\n              </mat-icon>\n            </div>\n          }\n        </div>\n        <!-- Title -->\n\n        <!-- Close button -->\n        <div class=\"lg:hidden\">\n          <button mat-icon-button (click)=\"drawer.close()\">\n            <mat-icon [svgIcon]=\"'heroicons_outline:x-mark'\"></mat-icon>\n          </button>\n        </div>\n        <!-- Close button -->\n      </div>\n      <!-- Header -->\n\n      <!-- Options -->\n      <div class=\"flex flex-col divide-y border-t border-b overflow-y-auto wizard-options-container\">\n        @for (option of this.properties.options; track trackByFn($index, option)) {\n          <div (click)=\"goToComponent(option)\"\n            class=\"flex p-4 cursor-pointer {{ selectedOption && selectedOption.id === option.id ? 'bg-default dark:bg-hover' : 'hover:bg-gray-100 dark:hover:bg-hover' }}\">\n\n            <mat-icon [svgIcon]=\"option.icon!\"\n              class=\"{{ selectedOption && selectedOption.id === option.id ? 'text-primary dark:text-primary-500' : 'text-hint' }}\">\n            </mat-icon>\n\n            <div class=\"ml-3\">\n              <div\n                class=\"font-medium leading-6 {{ selectedOption && selectedOption.id === option.id ? 'text-primary dark:text-primary-500' : '' }}\">\n                {{ option.title }}\n              </div>\n\n              <div class=\"mt-0.5 text-secondary\">{{ option.description! }}</div>\n            </div>\n\n            @if (option.suffixIcon) {\n              <mat-icon [svgIcon]=\"option.suffixIcon!\" [tooltip]=\"option.suffixIconTooltip ?? ''\"\n                (click)=\"$event.stopPropagation(); onSuffixIconClicked(option)\" class=\"{{ option.style?.suffixIconCssClasses }}\">\n              </mat-icon>\n            }\n          </div>\n        }\n      </div>\n      <!-- Options -->\n    </mat-drawer>\n\n    <!-- Drawer content -->\n    <mat-drawer-content class=\"flex flex-col {{ drawerOpened ? 'ml-80' : ''}}\">\n      <!-- Main -->\n      <div class=\"py-6 flex-auto\">\n        <!-- Content header -->\n        <div class=\"px-6 flex gap-2 items-center\">\n          <!-- Drawer toggle -->\n          <button mat-icon-button class=\"-ml-2\" (click)=\"drawer.toggle()\">\n            <mat-icon [svgIcon]=\"'heroicons_outline:bars-3'\"></mat-icon>\n          </button>\n\n          <!-- Content title -->\n          @if (selectedOption) {\n            <div class=\"lg:ml-0 text-2xl font-bold tracking-tight leading-none\">\n              {{ selectedOption.contentTitle }}\n            </div>\n          }\n          <!-- Content title -->\n\n          @if (selectedOption?.actionIcons) {\n            <div class=\"flex gap-2 items-center\">\n              <mat-icon #contentActionIconOrigin (click)=\"onContentIconClick()\"\n                [svgIcon]=\"selectedOption?.actionIcons?.icon!\"\n                class=\"{{selectedOption?.actionIcons?.classes}}cursor-pointer\">\n              </mat-icon>\n            </div>\n          }\n        </div>\n        <!-- Content header -->\n\n        <!-- Load Content body -->\n        <div class=\"my-8 fixed inset-0 sm:static sm:inset-auto overflow-hidden\">\n          @if (selectedOption?.component) {\n            <div class=\"px-6\">\n              <cl-component-injector class=\"overflow-y-auto\" [component]=\"selectedOption!.component!\"\n                [properties]=\"selectedOption!.componentProperties\">\n              </cl-component-injector>\n            </div>\n          }\n\n          @if (activeIndex != -1 && properties.options![activeIndex].actionButtons?.length) {\n            <div class=\"fixed left-0 right-0 bottom-0 overflow-hidden z-99 border-t border-solid acrylic-light\">\n              <div class=\"p-2 flex w-full items-center justify-end\">\n                @for (button of properties.options![activeIndex].actionButtons; track $index) {\n                  <cl-button [properties]=\"button\"></cl-button>\n                }\n              </div>\n            </div>\n          }\n        </div>\n        <!-- Load Content body -->\n      </div>\n    </mat-drawer-content>\n  </mat-drawer-container>\n</div>\n\n<ng-template #parentActionIconOverlay>\n  <div\n    class=\"fixed inset-0 sm:static sm:inset-auto flex flex-col sm:min-w-72 sm:w-72 bg-white dark:bg-primary-800 rounded-lg overflow-hidden shadow-lg p-2 divide-y\">\n    @if (properties.actionIcons?.options?.length) {\n      @for (badgeDropdown of properties.actionIcons?.options; track badgeDropdown; let optionIndex = $index;) {\n        <div class=\"p-2 flex gap-2 w-full items-center cursor-pointer\" (click)=\"onParentOptionClick(badgeDropdown)\">\n          <mat-icon class=\"icon-size-5 {{ badgeDropdown.iconCssClasses }}cursor-pointer\" [svgIcon]=\"badgeDropdown.icon!\">\n          </mat-icon>\n\n          <div class=\"text-md text-neutral-900 {{ badgeDropdown.labelCssClasses }} cursor-pointer\">\n            {{ badgeDropdown.label }}\n          </div>\n        </div>\n      }\n    }\n  </div>\n</ng-template>\n\n<ng-template #contentActionIconOverlay>\n  <div\n    class=\"fixed inset-0 sm:static sm:inset-auto flex flex-col sm:min-w-72 sm:w-72 bg-white dark:bg-primary-800 rounded-lg overflow-hidden shadow-lg p-2 divide-y\">\n    @if (selectedOption && selectedOption.actionIcons?.options?.length) {\n      @for (badgeDropdown of selectedOption.actionIcons?.options; track badgeDropdown; let optionIndex = $index;) {\n        <div class=\"p-2 flex gap-2 w-full items-center cursor-pointer\" (click)=\"onContentOptionClick(badgeDropdown)\">\n          <mat-icon class=\"icon-size-5 {{ badgeDropdown.iconCssClasses }}cursor-pointer\" [svgIcon]=\"badgeDropdown.icon!\">\n          </mat-icon>\n\n          <div class=\"text-md text-neutral-900 {{ badgeDropdown.labelCssClasses }} cursor-pointer\">\n            {{ badgeDropdown.label }}\n          </div>\n        </div>\n      }\n    }\n  </div>\n</ng-template>\n", styles: [":host{display:flex!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatSidenavModule }, { kind: "component", type: i5.MatDrawer, selector: "mat-drawer", inputs: ["position", "mode", "disableClose", "autoFocus", "opened"], outputs: ["openedChange", "opened", "openedStart", "closed", "closedStart", "positionChanged"], exportAs: ["matDrawer"] }, { kind: "component", type: i5.MatDrawerContainer, selector: "mat-drawer-container", inputs: ["autosize", "hasBackdrop"], outputs: ["backdropClick"], exportAs: ["matDrawerContainer"] }, { kind: "component", type: i5.MatDrawerContent, selector: "mat-drawer-content" }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }, { kind: "component", type: ClComponentInjectorComponent, selector: "cl-component-injector", inputs: ["component", "properties"], outputs: ["changeEvent"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClWizardComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-wizard', imports: [
                        MatIconModule,
                        MatButtonModule,
                        MatSidenavModule,
                        MatTooltipModule,
                        ClButtonComponent,
                        ClTooltipDirective,
                        ClComponentInjectorComponent
                    ], template: "<div class=\"flex flex-col w-full h-full min-w-0 sm:absolute sm:overflow-hidden {{ properties.style?.cssClasses }}\">\n  <mat-drawer-container class=\"flex-auto sm:h-full\">\n    <!-- Drawer -->\n    <mat-drawer #drawer [autoFocus]=\"false\" [mode]=\"drawerMode\" [(opened)]=\"drawerOpened\" (closed)=\"!drawerOpened\"\n      class=\"sm:w-80 dark:bg-gray-900 border-none\">\n      <!-- Header -->\n      <div class=\"flex items-center justify-between mx-4 my-8 sticky top-0\">\n        <!-- Title -->\n        <div class=\"flex justify-between items-center gap-3\">\n          <div class=\"text-3xl font-extrabold tracking-tight leading-none\">{{ properties.label }}</div>\n\n          @if (properties.actionIcons) {\n            <div class=\"flex gap-2 items-center\">\n              <mat-icon #parentActionIconOrigin (click)=\"onIconClick()\"\n                class=\"{{properties.actionIcons.classes}} cursor-pointer\" [svgIcon]=\"properties.actionIcons.icon!\">\n              </mat-icon>\n            </div>\n          }\n        </div>\n        <!-- Title -->\n\n        <!-- Close button -->\n        <div class=\"lg:hidden\">\n          <button mat-icon-button (click)=\"drawer.close()\">\n            <mat-icon [svgIcon]=\"'heroicons_outline:x-mark'\"></mat-icon>\n          </button>\n        </div>\n        <!-- Close button -->\n      </div>\n      <!-- Header -->\n\n      <!-- Options -->\n      <div class=\"flex flex-col divide-y border-t border-b overflow-y-auto wizard-options-container\">\n        @for (option of this.properties.options; track trackByFn($index, option)) {\n          <div (click)=\"goToComponent(option)\"\n            class=\"flex p-4 cursor-pointer {{ selectedOption && selectedOption.id === option.id ? 'bg-default dark:bg-hover' : 'hover:bg-gray-100 dark:hover:bg-hover' }}\">\n\n            <mat-icon [svgIcon]=\"option.icon!\"\n              class=\"{{ selectedOption && selectedOption.id === option.id ? 'text-primary dark:text-primary-500' : 'text-hint' }}\">\n            </mat-icon>\n\n            <div class=\"ml-3\">\n              <div\n                class=\"font-medium leading-6 {{ selectedOption && selectedOption.id === option.id ? 'text-primary dark:text-primary-500' : '' }}\">\n                {{ option.title }}\n              </div>\n\n              <div class=\"mt-0.5 text-secondary\">{{ option.description! }}</div>\n            </div>\n\n            @if (option.suffixIcon) {\n              <mat-icon [svgIcon]=\"option.suffixIcon!\" [tooltip]=\"option.suffixIconTooltip ?? ''\"\n                (click)=\"$event.stopPropagation(); onSuffixIconClicked(option)\" class=\"{{ option.style?.suffixIconCssClasses }}\">\n              </mat-icon>\n            }\n          </div>\n        }\n      </div>\n      <!-- Options -->\n    </mat-drawer>\n\n    <!-- Drawer content -->\n    <mat-drawer-content class=\"flex flex-col {{ drawerOpened ? 'ml-80' : ''}}\">\n      <!-- Main -->\n      <div class=\"py-6 flex-auto\">\n        <!-- Content header -->\n        <div class=\"px-6 flex gap-2 items-center\">\n          <!-- Drawer toggle -->\n          <button mat-icon-button class=\"-ml-2\" (click)=\"drawer.toggle()\">\n            <mat-icon [svgIcon]=\"'heroicons_outline:bars-3'\"></mat-icon>\n          </button>\n\n          <!-- Content title -->\n          @if (selectedOption) {\n            <div class=\"lg:ml-0 text-2xl font-bold tracking-tight leading-none\">\n              {{ selectedOption.contentTitle }}\n            </div>\n          }\n          <!-- Content title -->\n\n          @if (selectedOption?.actionIcons) {\n            <div class=\"flex gap-2 items-center\">\n              <mat-icon #contentActionIconOrigin (click)=\"onContentIconClick()\"\n                [svgIcon]=\"selectedOption?.actionIcons?.icon!\"\n                class=\"{{selectedOption?.actionIcons?.classes}}cursor-pointer\">\n              </mat-icon>\n            </div>\n          }\n        </div>\n        <!-- Content header -->\n\n        <!-- Load Content body -->\n        <div class=\"my-8 fixed inset-0 sm:static sm:inset-auto overflow-hidden\">\n          @if (selectedOption?.component) {\n            <div class=\"px-6\">\n              <cl-component-injector class=\"overflow-y-auto\" [component]=\"selectedOption!.component!\"\n                [properties]=\"selectedOption!.componentProperties\">\n              </cl-component-injector>\n            </div>\n          }\n\n          @if (activeIndex != -1 && properties.options![activeIndex].actionButtons?.length) {\n            <div class=\"fixed left-0 right-0 bottom-0 overflow-hidden z-99 border-t border-solid acrylic-light\">\n              <div class=\"p-2 flex w-full items-center justify-end\">\n                @for (button of properties.options![activeIndex].actionButtons; track $index) {\n                  <cl-button [properties]=\"button\"></cl-button>\n                }\n              </div>\n            </div>\n          }\n        </div>\n        <!-- Load Content body -->\n      </div>\n    </mat-drawer-content>\n  </mat-drawer-container>\n</div>\n\n<ng-template #parentActionIconOverlay>\n  <div\n    class=\"fixed inset-0 sm:static sm:inset-auto flex flex-col sm:min-w-72 sm:w-72 bg-white dark:bg-primary-800 rounded-lg overflow-hidden shadow-lg p-2 divide-y\">\n    @if (properties.actionIcons?.options?.length) {\n      @for (badgeDropdown of properties.actionIcons?.options; track badgeDropdown; let optionIndex = $index;) {\n        <div class=\"p-2 flex gap-2 w-full items-center cursor-pointer\" (click)=\"onParentOptionClick(badgeDropdown)\">\n          <mat-icon class=\"icon-size-5 {{ badgeDropdown.iconCssClasses }}cursor-pointer\" [svgIcon]=\"badgeDropdown.icon!\">\n          </mat-icon>\n\n          <div class=\"text-md text-neutral-900 {{ badgeDropdown.labelCssClasses }} cursor-pointer\">\n            {{ badgeDropdown.label }}\n          </div>\n        </div>\n      }\n    }\n  </div>\n</ng-template>\n\n<ng-template #contentActionIconOverlay>\n  <div\n    class=\"fixed inset-0 sm:static sm:inset-auto flex flex-col sm:min-w-72 sm:w-72 bg-white dark:bg-primary-800 rounded-lg overflow-hidden shadow-lg p-2 divide-y\">\n    @if (selectedOption && selectedOption.actionIcons?.options?.length) {\n      @for (badgeDropdown of selectedOption.actionIcons?.options; track badgeDropdown; let optionIndex = $index;) {\n        <div class=\"p-2 flex gap-2 w-full items-center cursor-pointer\" (click)=\"onContentOptionClick(badgeDropdown)\">\n          <mat-icon class=\"icon-size-5 {{ badgeDropdown.iconCssClasses }}cursor-pointer\" [svgIcon]=\"badgeDropdown.icon!\">\n          </mat-icon>\n\n          <div class=\"text-md text-neutral-900 {{ badgeDropdown.labelCssClasses }} cursor-pointer\">\n            {{ badgeDropdown.label }}\n          </div>\n        </div>\n      }\n    }\n  </div>\n</ng-template>\n", styles: [":host{display:flex!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$3.Overlay }, { type: i1$3.Overlay }, { type: i0.ViewContainerRef }, { type: i0.ChangeDetectorRef }, { type: i2$2.ClMediaWatcherService }], propDecorators: { selectedOption: [{
                type: Input
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }], onOptionChange: [{
                type: Output
            }], drawer: [{
                type: ViewChild,
                args: ['drawer']
            }], parentActionIconOrigin: [{
                type: ViewChild,
                args: ['parentActionIconOrigin']
            }], contentActionIconOrigin: [{
                type: ViewChild,
                args: ['contentActionIconOrigin']
            }], parentActionIconOverlay: [{
                type: ViewChild,
                args: ['parentActionIconOverlay']
            }], contentActionIconOverlay: [{
                type: ViewChild,
                args: ['contentActionIconOverlay']
            }] } });

class ClWizardOptionsStyleProperties {
}
class ClWizardStyleProperties {
}
class ClWizardProperties {
    constructor() {
        this.options = [];
        this.id = 'default0';
        this.type = ClComponentTypes.wizard;
        this.style = new ClWizardStyleProperties();
        this.style.cssClasses = '';
        this.style.labelCssClasses = '';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClStepHeaderComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepHeaderComponent, isStandalone: true, selector: "cl-step-header", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "headerTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepLabel>{{ properties.label }}</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatStepperModule }, { kind: "directive", type: i2$3.MatStepLabel, selector: "[matStepLabel]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepHeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-header', imports: [MatIconModule, MatStepperModule], template: "<ng-template matStepLabel>{{ properties.label }}</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], headerTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClStepHeaderProperties {
    constructor() {
        this.label = 'Step';
        this.completed = signal(false);
        this.optional = signal(false);
    }
}

class ClStepComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepComponent, isStandalone: true, selector: "cl-step", queries: [{ propertyName: "stepHeader", first: true, predicate: ClStepHeaderComponent, descendants: true }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template>\n  <ng-content select=\"cl-step-content\"></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step', template: "<ng-template>\n  <ng-content select=\"cl-step-content\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], stepHeader: [{
                type: ContentChild,
                args: [ClStepHeaderComponent]
            }] } });

class ClStepNextComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepNextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepNextComponent, isStandalone: true, selector: "cl-step-next", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "nextTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepperNext>\n  <ng-content></ng-content>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatStepperModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepNextComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-next', imports: [MatStepperModule], template: "<ng-template matStepperNext>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], nextTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClStepNextProperties {
    constructor() {
        this.label = 'Next';
    }
}

class ClStepContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepContentComponent, isStandalone: true, selector: "cl-step-content", ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-content', template: "<ng-content></ng-content>\n" }]
        }] });

class StepPreviousComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: StepPreviousComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: StepPreviousComponent, isStandalone: true, selector: "cl-step-previous", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "previousTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepperPrevious>\n  <ng-content></ng-content>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatStepperModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: StepPreviousComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-previous', imports: [MatStepperModule], template: "<ng-template matStepperPrevious>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], previousTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClStepPreviousProperties {
    constructor() {
        this.label = 'Next';
    }
}

class ClStepperStyleProperties {
}
class ClStepperProperties {
    constructor() {
        this.id = 'default0';
        this.labelPosition = 'bottom';
        this.orientation = 'horizontal';
        this.type = ClComponentTypes.stepper;
        this.selectedStepIndex = signal(0);
        this.isLinear = false;
        this.style = new ClStepperStyleProperties();
        this.style.cssClasses = "w-full flex-auto";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.stepsProperties = [
            {
                stepHeaderProperties: { label: 'Step1' },
                stepContentProperties: [],
            },
            {
                stepHeaderProperties: { label: 'Step2' },
                stepContentProperties: [],
            },
        ];
    }
}

class ClStepperComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClStepperProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer$1(0).subscribe(() => {
            this.steppers = this.contentItems;
        });
    }
    selectionChange(event) {
        if (this.properties.onStepperSelected != undefined) {
            this.properties.onStepperSelected(event.selectedIndex);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClStepperComponent, isStandalone: true, selector: "cl-stepper", inputs: { properties: "properties" }, providers: [
            {
                provide: STEPPER_GLOBAL_OPTIONS,
                useValue: { displayDefaultIndicatorType: false },
            },
        ], queries: [{ propertyName: "contentItems", predicate: ClStepComponent }], usesInheritance: true, ngImport: i0, template: "<mat-stepper #stepper class=\"w-full\"\n  [linear]=\"properties.isLinear\"\n  [orientation]=\"properties.orientation!\"\n  [labelPosition]=\"properties.labelPosition!\"\n  [selectedIndex]=\"properties.selectedStepIndex!()\"\n  (selectionChange)=\"selectionChange($event)\">\n\n  @for (step of steppers; track step) {\n  <mat-step [completed]=\"step.stepHeader?.properties?.completed\" [optional]=\"step.stepHeader?.properties?.optional\"\n    [state]=\"step.stepHeader?.properties?.state!\">\n\n    <ng-template matStepLabel>\n      <ng-container *ngTemplateOutlet=\"step.stepHeader!.headerTemplate\"></ng-container>\n    </ng-template>\n\n    <ng-template matStepContent>\n      <ng-container *ngTemplateOutlet=\"step.contentTemplate\"></ng-container>\n    </ng-template>\n\n  </mat-step>\n  }\n</mat-stepper>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatStepperModule }, { kind: "component", type: i2$3.MatStep, selector: "mat-step", inputs: ["color"], exportAs: ["matStep"] }, { kind: "directive", type: i2$3.MatStepLabel, selector: "[matStepLabel]" }, { kind: "component", type: i2$3.MatStepper, selector: "mat-stepper, mat-vertical-stepper, mat-horizontal-stepper, [matStepper]", inputs: ["disableRipple", "color", "labelPosition", "headerPosition", "animationDuration"], outputs: ["animationDone"], exportAs: ["matStepper", "matVerticalStepper", "matHorizontalStepper"] }, { kind: "directive", type: i2$3.MatStepContent, selector: "ng-template[matStepContent]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepperComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-stepper', providers: [
                        {
                            provide: STEPPER_GLOBAL_OPTIONS,
                            useValue: { displayDefaultIndicatorType: false },
                        },
                    ], imports: [
                        CommonModule,
                        MatStepperModule,
                    ], template: "<mat-stepper #stepper class=\"w-full\"\n  [linear]=\"properties.isLinear\"\n  [orientation]=\"properties.orientation!\"\n  [labelPosition]=\"properties.labelPosition!\"\n  [selectedIndex]=\"properties.selectedStepIndex!()\"\n  (selectionChange)=\"selectionChange($event)\">\n\n  @for (step of steppers; track step) {\n  <mat-step [completed]=\"step.stepHeader?.properties?.completed\" [optional]=\"step.stepHeader?.properties?.optional\"\n    [state]=\"step.stepHeader?.properties?.state!\">\n\n    <ng-template matStepLabel>\n      <ng-container *ngTemplateOutlet=\"step.stepHeader!.headerTemplate\"></ng-container>\n    </ng-template>\n\n    <ng-template matStepContent>\n      <ng-container *ngTemplateOutlet=\"step.contentTemplate\"></ng-container>\n    </ng-template>\n\n  </mat-step>\n  }\n</mat-stepper>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], contentItems: [{
                type: ContentChildren,
                args: [ClStepComponent]
            }] } });

class ClCarouselContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClCarouselContentComponent, isStandalone: true, selector: "cl-carousel-content", viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clCarouselContent>\n  <ng-content></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-carousel-content', template: "<ng-template #clCarouselContent>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClCarouselStyleProperties {
}
class ClCarouselProperties {
    constructor() {
        this.id = 'default0';
        this.showIndicatorsInside = false;
        this.enableAnimationDuration = false;
        this.type = ClComponentTypes.carousel;
        this.animationDurationInMilliseconds = 5000;
        this.numberOfSlides = 0;
        this.children = [];
        this.style = new ClCarouselStyleProperties();
        this.style.cssClasses = '';
        this.style.sliderContentCss = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.activeNavigationColor = 'bg-gray-800';
        this.style.inActiveNavigationColor = 'bg-gray-300';
    }
}

class ClCarouselComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.currentIndex = 0;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClCarouselProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.carouselContents = this.carouselContentItems;
            this.startAutoSlide();
        });
    }
    ngOnDestroy() {
        this.autoSlideSubscription?.unsubscribe();
    }
    startAutoSlide() {
        this.autoSlideSubscription = interval(this.properties.animationDurationInMilliseconds)
            .subscribe(() => {
            this.nextSlide();
        });
    }
    prevSlide() {
        this.currentIndex = (this.currentIndex > 0) ? this.currentIndex - 1 : this.carouselContentItems.length - 1;
    }
    nextSlide() {
        this.currentIndex = (this.currentIndex < this.carouselContentItems.length - 1) ? this.currentIndex + 1 : 0;
    }
    goToSlide(index) {
        this.currentIndex = index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClCarouselComponent, isStandalone: true, selector: "cl-carousel", inputs: { properties: "properties" }, queries: [{ propertyName: "carouselContentItems", predicate: ClCarouselContentComponent }], usesInheritance: true, ngImport: i0, template: "<div class=\"relative\">\n  <!-- Carousel Close Icon-->\n  @if (properties.iconProperties){\n    <button class=\"cl-carousel-close-icon\">\n      <cl-icon class=\"flex self-center\" [properties]=\"properties.iconProperties\"></cl-icon>\n    </button>\n  }\n\n  <div class=\"relative w-full overflow-hidden {{properties.style?.cssClasses}}\">\n    <!-- Carousel Wrapper -->\n    <div class=\"flex\" [ngClass]=\"{'transition-transform duration-500 ease-in-out': properties.enableAnimationDuration}\"\n      [ngStyle]=\"{'transform': 'translateX(-' + currentIndex * 100 + '%)'}\">\n\n      @for (carouselContent of carouselContents; track carouselContent) {\n        <div class=\"w-full flex-shrink-0 {{properties.style?.sliderContentCss}}\">\n          <ng-container *ngTemplateOutlet=\"carouselContent.contentTemplate\"></ng-container>\n        </div>\n      }\n    </div>\n    <!-- Carousel Wrapper -->\n\n    <!-- internal indicators -->\n    @if (properties.showIndicatorsInside) {\n      <div class=\"absolute bottom-4 ml-10 transform -translate-x-1/2 flex space-x-2\">\n        <ng-container *ngTemplateOutlet=\"indicators\"></ng-container>\n      </div>\n    }\n    <!-- internal indicators -->\n  </div>\n\n  <!-- external indicators -->\n  @if (!properties.showIndicatorsInside) {\n    <div class=\"absolute bottom-[-1rem] left-1/2 transform -translate-x-1/2 mb-0 flex space-x-2\">\n      <ng-container *ngTemplateOutlet=\"indicators\"></ng-container>\n    </div>\n  }\n  <!-- external indicators -->\n</div>\n\n<ng-template #indicators>\n  @for (indicator of carouselContents; track indicator) {\n    <div (click)=\"goToSlide($index)\"\n      class=\"w-2 h-2 rounded-full cursor-pointer {{ $index == currentIndex ? properties.style?.activeNavigationColor : properties.style?.inActiveNavigationColor }}\">\n    </div>\n  }\n</ng-template>\n", styles: [".cl-carousel-close-icon{position:absolute;top:0;right:0;z-index:10;display:flex;--tw-translate-x: 50%;--tw-translate-y: -50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));align-items:center;justify-content:center;border-radius:9999px;--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.cl-carousel-close-icon:focus{outline:2px solid transparent;outline-offset:2px}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-carousel', imports: [
                        NgClass,
                        NgStyle,
                        CommonModule,
                        ClIconComponent,
                        ClCarouselContentComponent,
                    ], template: "<div class=\"relative\">\n  <!-- Carousel Close Icon-->\n  @if (properties.iconProperties){\n    <button class=\"cl-carousel-close-icon\">\n      <cl-icon class=\"flex self-center\" [properties]=\"properties.iconProperties\"></cl-icon>\n    </button>\n  }\n\n  <div class=\"relative w-full overflow-hidden {{properties.style?.cssClasses}}\">\n    <!-- Carousel Wrapper -->\n    <div class=\"flex\" [ngClass]=\"{'transition-transform duration-500 ease-in-out': properties.enableAnimationDuration}\"\n      [ngStyle]=\"{'transform': 'translateX(-' + currentIndex * 100 + '%)'}\">\n\n      @for (carouselContent of carouselContents; track carouselContent) {\n        <div class=\"w-full flex-shrink-0 {{properties.style?.sliderContentCss}}\">\n          <ng-container *ngTemplateOutlet=\"carouselContent.contentTemplate\"></ng-container>\n        </div>\n      }\n    </div>\n    <!-- Carousel Wrapper -->\n\n    <!-- internal indicators -->\n    @if (properties.showIndicatorsInside) {\n      <div class=\"absolute bottom-4 ml-10 transform -translate-x-1/2 flex space-x-2\">\n        <ng-container *ngTemplateOutlet=\"indicators\"></ng-container>\n      </div>\n    }\n    <!-- internal indicators -->\n  </div>\n\n  <!-- external indicators -->\n  @if (!properties.showIndicatorsInside) {\n    <div class=\"absolute bottom-[-1rem] left-1/2 transform -translate-x-1/2 mb-0 flex space-x-2\">\n      <ng-container *ngTemplateOutlet=\"indicators\"></ng-container>\n    </div>\n  }\n  <!-- external indicators -->\n</div>\n\n<ng-template #indicators>\n  @for (indicator of carouselContents; track indicator) {\n    <div (click)=\"goToSlide($index)\"\n      class=\"w-2 h-2 rounded-full cursor-pointer {{ $index == currentIndex ? properties.style?.activeNavigationColor : properties.style?.inActiveNavigationColor }}\">\n    </div>\n  }\n</ng-template>\n", styles: [".cl-carousel-close-icon{position:absolute;top:0;right:0;z-index:10;display:flex;--tw-translate-x: 50%;--tw-translate-y: -50%;transform:translate(var(--tw-translate-x),var(--tw-translate-y)) rotate(var(--tw-rotate)) skew(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));align-items:center;justify-content:center;border-radius:9999px;--tw-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1);--tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)}.cl-carousel-close-icon:focus{outline:2px solid transparent;outline-offset:2px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input
            }], carouselContentItems: [{
                type: ContentChildren,
                args: [ClCarouselContentComponent]
            }] } });

class ClExpansionPanelHeaderComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelHeaderComponent, isStandalone: true, selector: "cl-expansion-panel-header", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "headerTemplate", first: true, predicate: TemplateRef, descendants: true }], exportAs: ["clExpansionPanelHeader"], ngImport: i0, template: "<mat-expansion-panel-header>\n  <mat-panel-title>{{ properties.label }}</mat-panel-title>\n</mat-expansion-panel-header>\n", dependencies: [{ kind: "ngmodule", type: MatExpansionModule }, { kind: "component", type: i3.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i3.MatExpansionPanelTitle, selector: "mat-panel-title" }], viewProviders: [MatExpansionPanel] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelHeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, exportAs: 'clExpansionPanelHeader', selector: 'cl-expansion-panel-header', imports: [MatExpansionModule], viewProviders: [MatExpansionPanel], template: "<mat-expansion-panel-header>\n  <mat-panel-title>{{ properties.label }}</mat-panel-title>\n</mat-expansion-panel-header>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], headerTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClExpansionPanelDescriptionComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelDescriptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelDescriptionComponent, isStandalone: true, selector: "cl-expansion-panel-description", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "descriptionTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelDescriptionComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-expansion-panel-description', template: "<ng-content></ng-content>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], descriptionTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClExpansionPanelActionButtonsComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelActionButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelActionButtonsComponent, isStandalone: true, selector: "cl-expansion-panel-action-buttons", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "actionButtonsTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelActionButtonsComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-expansion-panel-action-buttons', imports: [], template: "<ng-content></ng-content>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], actionButtonsTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

class ClExpansionPanelComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelComponent, isStandalone: true, selector: "cl-expansion-panel", queries: [{ propertyName: "expansionPanelHeader", first: true, predicate: ClExpansionPanelHeaderComponent, descendants: true }, { propertyName: "expansionPanelDescription", first: true, predicate: ClExpansionPanelDescriptionComponent, descendants: true }, { propertyName: "expansionPanelActionButtons", first: true, predicate: ClExpansionPanelActionButtonsComponent, descendants: true }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template>\n  <ng-content select=\"cl-expansion-panel-content\"></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelComponent, decorators: [{
            type: Component,
            args: [{ imports: [], standalone: true, selector: 'cl-expansion-panel', template: "<ng-template>\n  <ng-content select=\"cl-expansion-panel-content\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], expansionPanelHeader: [{
                type: ContentChild,
                args: [ClExpansionPanelHeaderComponent]
            }], expansionPanelDescription: [{
                type: ContentChild,
                args: [ClExpansionPanelDescriptionComponent]
            }], expansionPanelActionButtons: [{
                type: ContentChild,
                args: [ClExpansionPanelActionButtonsComponent]
            }] } });

class ClAccordionStyleProperties {
}
class ClAccordionProperties {
    constructor() {
        this.id = 'default0';
        this.hideToggle = true;
        this.openMultiple = false;
        this.type = ClComponentTypes.accordion;
        this.style = new ClAccordionStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.iconCssClasses = 'icon-size-5';
        this.style.cssClasses = 'w-full flex-auto';
        this.style.titleCssClasses = 'text-xl font-normal text-primary-800';
        this.collapsedIcon = 'fss_icons:chevron-circle-down';
        this.expandedIcon = 'fss_icons:chevron-circle-up-filled';
        this.expansionPanelProperties = [
            {
                expansionPanelHeaderProperties: { label: 'Accordion1', panelOpenState: true, actionIcons: [], actionButtons: [] },
                expansionPanelContentProperties: [
                    {
                        "id": "column_999998",
                        "selector": "div",
                        "name": "Column",
                        "layout": "column",
                        "type": "container",
                        "hideDelete": true,
                        "import": "@clay/ui/components/container",
                        "properties": {
                            "cssClass": "flex w-full flex-col"
                        },
                        "defaultProperties": {
                            "cssClass": "flex w-full flex-col border border-dashed rounded-md border-purple-400"
                        },
                        "children": []
                    }
                ]
            },
            {
                expansionPanelHeaderProperties: { label: 'Accordion2', panelOpenState: false, actionIcons: [], actionButtons: [] },
                expansionPanelContentProperties: [
                    {
                        "id": "column_999999",
                        "selector": "div",
                        "name": "Column",
                        "layout": "column",
                        "type": "container",
                        "hideDelete": true,
                        "import": "@clay/ui/components/container",
                        "properties": {
                            "cssClass": "flex w-full flex-col"
                        },
                        "defaultProperties": {
                            "cssClass": "flex w-full flex-col border border-dashed rounded-md border-purple-400"
                        },
                        "children": []
                    }
                ]
            }
        ];
    }
}

class ClAccordionComponent extends ClBaseContainerComponent {
    constructor(cdr) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.cdr = cdr;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClAccordionProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer$1(0).subscribe(() => {
            this.expansionPanels = this.contentItems;
            this.cdr.detectChanges();
        });
    }
    onPanelStateChanged(expansionPanel, value) {
        expansionPanel.expansionPanelHeader.properties.panelOpenState = value;
        this.cdr.detectChanges();
    }
    onExpansionPanelSelected(index) {
        if (this.properties.onExpansionPanelSelected) {
            this.properties.onExpansionPanelSelected(index);
        }
    }
    onActionIconClicked(index, iconProperties) {
        if (iconProperties.onIconClicked) {
            iconProperties.onIconClicked(index);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAccordionComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClAccordionComponent, isStandalone: true, selector: "cl-accordion", inputs: { properties: "properties" }, queries: [{ propertyName: "contentItems", predicate: ClExpansionPanelComponent }], usesInheritance: true, ngImport: i0, template: "<mat-accordion [multi]=\"properties.openMultiple\" class=\"{{ properties.style?.cssClasses }}\">\n  @for (expansionPanel of expansionPanels; let panelIndex = $index; track expansionPanel) {\n  <!-- expansion panel -->\n  <mat-expansion-panel [hideToggle]=\"properties.hideToggle\" (opened)=\"onPanelStateChanged(expansionPanel, true)\"\n    (closed)=\"onPanelStateChanged(expansionPanel, false)\" class=\"{{ properties.style?.panelCssClasses }}\"\n    [expanded]=\"expansionPanel.expansionPanelHeader?.properties?.panelOpenState\">\n\n    <!-- expansion panel header -->\n    <mat-expansion-panel-header class=\"{{ properties.style?.headerCssClasses }}\"\n      (click)=\"onExpansionPanelSelected(panelIndex)\">\n      <!-- expansion panel title -->\n      <!-- {{ expansionPanel.expansionPanelHeader?.properties?.panelOpenState ? 'border-b' : '' }} -->\n      <mat-panel-title class=\"flex gap-2 items-center\">\n        @if(!expansionPanel.expansionPanelHeader?.properties?.hideDefaultHeader){\n        <div [tooltip]=\"expansionPanel.expansionPanelHeader?.properties?.label!\"\n          class=\"{{ properties.style?.titleCssClasses ?? 'text-xl leading-7 text-primary-800' }} \">\n          {{ expansionPanel.expansionPanelHeader?.properties?.label }}\n        </div>\n        }\n        @if(expansionPanel.expansionPanelHeader?.properties?.hideDefaultHeader &&\n        expansionPanel.expansionPanelHeader?.properties?.component) {\n        <cl-component-injector class=\"flex w-full\" [component]=\"expansionPanel.expansionPanelHeader?.properties?.component!\"\n          [properties]=\"expansionPanel.expansionPanelHeader?.properties?.componentProperties\">\n        </cl-component-injector>\n        }\n\n        @if(expansionPanel.expansionPanelDescription?.properties?.description){\n        <!-- expansion panel description -->\n        <div class=\"{{ properties.style?.descCssClasses }}\">\n          {{ expansionPanel.expansionPanelDescription?.properties?.description }}\n        </div>\n        }\n        <!-- expansion panel description -->\n      </mat-panel-title>\n      <!-- expansion panel title -->\n\n      <!-- action buttons -->\n      @if(expansionPanel.expansionPanelHeader?.properties?.actionButtons &&\n        expansionPanel.expansionPanelHeader!.properties!.actionButtons!.length > 0){\n      <div class=\"flex mr-4 gap-2 mt-0.5 items-center\">\n        @for (buttonProperties of expansionPanel.expansionPanelHeader!.properties!.actionButtons; track\n        buttonProperties) {\n        <cl-button class=\"{{ buttonProperties.style?.cssClasses }} cursor-pointer\" [properties]=\"buttonProperties\"\n          (click)=\"$event.stopPropagation()\">\n        </cl-button>\n        }\n      </div>\n      }\n      <!-- action buttons -->\n\n      <!-- action Icons -->\n      <div class=\"flex mr-4 gap-2 mt-0.5 items-center\">\n        @for (iconProperties of expansionPanel.expansionPanelHeader!.properties!.actionIcons; track iconProperties) {\n        <mat-icon [svgIcon]=\"iconProperties.iconName!\" class=\"{{ iconProperties.style?.cssClasses }} cursor-pointer\"\n          (click)=\"$event.stopPropagation(); onActionIconClicked(panelIndex, iconProperties)\">\n        </mat-icon>\n        }\n      </div>\n      <!-- action Icons -->\n\n      <!-- accordion toggle arrow icon -->\n      @if (properties.hideToggle) {\n      @if (expansionPanel.expansionPanelHeader?.properties?.panelOpenState) {\n      <mat-icon class=\"mt-1.5 {{ properties.style?.iconCssClasses }}\" [svgIcon]=\"properties.expandedIcon!\">\n      </mat-icon>\n      } @else if (!expansionPanel.expansionPanelHeader?.properties?.panelOpenState) {\n      <mat-icon class=\"mt-1.5 {{ properties.style?.iconCssClasses }}\" [svgIcon]=\"properties.collapsedIcon!\">\n      </mat-icon>\n      }\n      }\n      <!-- accordion toggle arrow icon -->\n    </mat-expansion-panel-header>\n    <!-- expansion panel header -->\n\n    <!-- expansion panel body -->\n    <div class=\"{{ properties.style?.bodyCssClasses }}\">\n      <ng-container *ngTemplateOutlet=\"expansionPanel.contentTemplate\"></ng-container>\n    </div>\n    <!-- expansion panel body -->\n  </mat-expansion-panel>\n  <!-- expansion panel -->\n  }\n</mat-accordion>\n", styles: [":host{display:flex!important}.mat-accordion .mat-expansion-panel{margin-bottom:1rem!important}.mat-accordion .mat-expansion-panel .mat-expansion-panel-content .mat-expansion-panel-body{padding:1rem 1.5rem!important}.dense-mat-accordion{width:100%!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel{margin:0!important;border-radius:0!important;--tw-shadow: 0 0 #0000 !important;--tw-shadow-colored: 0 0 #0000 !important;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel .mat-expansion-panel-header{padding-left:1rem!important;padding-right:1rem!important}.dense-mat-accordion .mat-expansion-panel-body{padding:1rem!important;padding-top:0!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel:not(:last-child){border-bottom-width:1px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i3.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i3.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i3.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i3.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }, { kind: "component", type: ClComponentInjectorComponent, selector: "cl-component-injector", inputs: ["component", "properties"], outputs: ["changeEvent"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAccordionComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-accordion', encapsulation: ViewEncapsulation.None, imports: [
                        CommonModule,
                        ClButtonComponent,
                        MatIconModule,
                        MatExpansionModule,
                        ClTooltipDirective,
                        ClComponentInjectorComponent
                    ], template: "<mat-accordion [multi]=\"properties.openMultiple\" class=\"{{ properties.style?.cssClasses }}\">\n  @for (expansionPanel of expansionPanels; let panelIndex = $index; track expansionPanel) {\n  <!-- expansion panel -->\n  <mat-expansion-panel [hideToggle]=\"properties.hideToggle\" (opened)=\"onPanelStateChanged(expansionPanel, true)\"\n    (closed)=\"onPanelStateChanged(expansionPanel, false)\" class=\"{{ properties.style?.panelCssClasses }}\"\n    [expanded]=\"expansionPanel.expansionPanelHeader?.properties?.panelOpenState\">\n\n    <!-- expansion panel header -->\n    <mat-expansion-panel-header class=\"{{ properties.style?.headerCssClasses }}\"\n      (click)=\"onExpansionPanelSelected(panelIndex)\">\n      <!-- expansion panel title -->\n      <!-- {{ expansionPanel.expansionPanelHeader?.properties?.panelOpenState ? 'border-b' : '' }} -->\n      <mat-panel-title class=\"flex gap-2 items-center\">\n        @if(!expansionPanel.expansionPanelHeader?.properties?.hideDefaultHeader){\n        <div [tooltip]=\"expansionPanel.expansionPanelHeader?.properties?.label!\"\n          class=\"{{ properties.style?.titleCssClasses ?? 'text-xl leading-7 text-primary-800' }} \">\n          {{ expansionPanel.expansionPanelHeader?.properties?.label }}\n        </div>\n        }\n        @if(expansionPanel.expansionPanelHeader?.properties?.hideDefaultHeader &&\n        expansionPanel.expansionPanelHeader?.properties?.component) {\n        <cl-component-injector class=\"flex w-full\" [component]=\"expansionPanel.expansionPanelHeader?.properties?.component!\"\n          [properties]=\"expansionPanel.expansionPanelHeader?.properties?.componentProperties\">\n        </cl-component-injector>\n        }\n\n        @if(expansionPanel.expansionPanelDescription?.properties?.description){\n        <!-- expansion panel description -->\n        <div class=\"{{ properties.style?.descCssClasses }}\">\n          {{ expansionPanel.expansionPanelDescription?.properties?.description }}\n        </div>\n        }\n        <!-- expansion panel description -->\n      </mat-panel-title>\n      <!-- expansion panel title -->\n\n      <!-- action buttons -->\n      @if(expansionPanel.expansionPanelHeader?.properties?.actionButtons &&\n        expansionPanel.expansionPanelHeader!.properties!.actionButtons!.length > 0){\n      <div class=\"flex mr-4 gap-2 mt-0.5 items-center\">\n        @for (buttonProperties of expansionPanel.expansionPanelHeader!.properties!.actionButtons; track\n        buttonProperties) {\n        <cl-button class=\"{{ buttonProperties.style?.cssClasses }} cursor-pointer\" [properties]=\"buttonProperties\"\n          (click)=\"$event.stopPropagation()\">\n        </cl-button>\n        }\n      </div>\n      }\n      <!-- action buttons -->\n\n      <!-- action Icons -->\n      <div class=\"flex mr-4 gap-2 mt-0.5 items-center\">\n        @for (iconProperties of expansionPanel.expansionPanelHeader!.properties!.actionIcons; track iconProperties) {\n        <mat-icon [svgIcon]=\"iconProperties.iconName!\" class=\"{{ iconProperties.style?.cssClasses }} cursor-pointer\"\n          (click)=\"$event.stopPropagation(); onActionIconClicked(panelIndex, iconProperties)\">\n        </mat-icon>\n        }\n      </div>\n      <!-- action Icons -->\n\n      <!-- accordion toggle arrow icon -->\n      @if (properties.hideToggle) {\n      @if (expansionPanel.expansionPanelHeader?.properties?.panelOpenState) {\n      <mat-icon class=\"mt-1.5 {{ properties.style?.iconCssClasses }}\" [svgIcon]=\"properties.expandedIcon!\">\n      </mat-icon>\n      } @else if (!expansionPanel.expansionPanelHeader?.properties?.panelOpenState) {\n      <mat-icon class=\"mt-1.5 {{ properties.style?.iconCssClasses }}\" [svgIcon]=\"properties.collapsedIcon!\">\n      </mat-icon>\n      }\n      }\n      <!-- accordion toggle arrow icon -->\n    </mat-expansion-panel-header>\n    <!-- expansion panel header -->\n\n    <!-- expansion panel body -->\n    <div class=\"{{ properties.style?.bodyCssClasses }}\">\n      <ng-container *ngTemplateOutlet=\"expansionPanel.contentTemplate\"></ng-container>\n    </div>\n    <!-- expansion panel body -->\n  </mat-expansion-panel>\n  <!-- expansion panel -->\n  }\n</mat-accordion>\n", styles: [":host{display:flex!important}.mat-accordion .mat-expansion-panel{margin-bottom:1rem!important}.mat-accordion .mat-expansion-panel .mat-expansion-panel-content .mat-expansion-panel-body{padding:1rem 1.5rem!important}.dense-mat-accordion{width:100%!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel{margin:0!important;border-radius:0!important;--tw-shadow: 0 0 #0000 !important;--tw-shadow-colored: 0 0 #0000 !important;box-shadow:var(--tw-ring-offset-shadow, 0 0 #0000),var(--tw-ring-shadow, 0 0 #0000),var(--tw-shadow)!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel .mat-expansion-panel-header{padding-left:1rem!important;padding-right:1rem!important}.dense-mat-accordion .mat-expansion-panel-body{padding:1rem!important;padding-top:0!important}.dense-mat-accordion>.mat-accordion .mat-expansion-panel:not(:last-child){border-bottom-width:1px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], contentItems: [{
                type: ContentChildren,
                args: [ClExpansionPanelComponent]
            }] } });

class ClExpansionPanelHeaderProperties {
    constructor() {
        this.label = 'Expansion Panel';
    }
}

class ClExpansionPanelContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelContentComponent, isStandalone: true, selector: "cl-expansion-panel-content", ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-expansion-panel-content', template: "<ng-content></ng-content>\n" }]
        }] });

class ClExpansionPanelDescriptionProperties {
    constructor() {
        this.description = 'Expansion Panel';
    }
}

class ClDataGridService {
    constructor() {
        this.clearSelection = new BehaviorSubject('');
    }
    clearDataGridSelection() {
        this.clearSelection.next('clear');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClPaginatorComponent {
    constructor(formBuilder) {
        this.formBuilder = formBuilder;
        this.currentPage = 1;
        this.noOfRecords = 0;
        this.showLoading = false;
        this.hideGoToPage = false;
        this.hideFirstLastPageBtn = false;
        this.pageSizeOptions = [10, 15, 20];
        this.pageIndex = new EventEmitter();
        this.onPageSizeChange = new EventEmitter();
        this.paginationPills = [];
        this.totalNoOfPages = 1;
        this.typedIndexNumber = '';
        this.selectedPageIndex = 1;
        this.callGoToPageNoFunc = false;
        this.paginatorForm = this.formBuilder.group({});
    }
    ngOnInit() {
        this.selectedPageIndex = this.currentPage;
        this.selectedPageSize = this.pageSize;
        // calling set default values function
        this.setDefaultValues();
        // calling calculate no of pages function
        this.calculateNoOfPages();
        // calling update current page function
        this.updateCurrentPage();
        // calling get pagination function
        this.getPagination();
    }
    ngOnChanges(changes) {
        // calling calculate no of pages function
        this.calculateNoOfPages();
        // calling update current page function
        this.updateCurrentPage();
        // calling get pagination function
        this.getPagination();
    }
    setDefaultValues() {
        this.paginatorForm.addControl('goToPage', new FormControl(null));
        this.paginatorForm.addControl('pageSizeControl', new FormControl(null, Validators.required));
        this.paginatorForm.get('pageSizeControl')?.patchValue(this.pageSize);
        // calling subscribe to go to page field function
        this.subscribeToGoToPageField();
    }
    subscribeToGoToPageField() {
        this.paginatorFormSubscription = this.paginatorForm.controls['goToPage'].valueChanges
            .pipe(debounceTime(600))
            .subscribe((value) => {
            if (this.callGoToPageNoFunc) {
                this.typedIndexNumber = value ?? '1';
                // calling on page no entered function
                this.onPageNoEntered();
            }
        });
    }
    /**
     * this function is trigged when the user changes the size of the page
     *
     * @param size - selected page size from dropdown
     */
    pageSizeChanged(size) {
        if (this.showLoading) {
            return;
        }
        this.selectedPageSize = size;
        this.onPageSizeChange.emit(size);
        // calling calculate no of pages function
        this.calculateNoOfPages();
        // calling go to page index function
        this.goToPageIndex(1);
        // calling update current page function
        this.updateCurrentPage();
        // calling get pagination function
        this.getPagination();
    }
    updateCurrentPage() {
        this.currentPage = this.selectedPageIndex;
    }
    calculateNoOfPages() {
        const total = Math.ceil(this.noOfRecords / this.selectedPageSize);
        this.totalNoOfPages = !isNaN(total) && total ? total : 1;
        if (this.totalNoOfPages < this.currentPage) {
            this.selectedPageIndex = this.totalNoOfPages;
            this.updateCurrentPage();
        }
    }
    goToNextPage() {
        if (this.selectedPageIndex < this.totalNoOfPages) {
            this.selectedPageIndex += 1;
            this.pageIndex.emit(this.selectedPageIndex);
        }
    }
    goToPreviousPage() {
        if (this.selectedPageIndex > 1) {
            this.selectedPageIndex -= 1;
            this.pageIndex.emit(this.selectedPageIndex);
        }
    }
    goToFirstPage() {
        if (this.selectedPageIndex > 1) {
            this.selectedPageIndex = 1;
            this.pageIndex.emit(this.selectedPageIndex);
        }
    }
    goToLastPage() {
        if (this.selectedPageIndex > 0) {
            this.selectedPageIndex = this.totalNoOfPages;
            this.pageIndex.emit(this.selectedPageIndex);
        }
    }
    /**
     * this function will be triggered when the user type a page no in go to field
     */
    onPageNoEntered() {
        const lastPage = Math.ceil(this.noOfRecords / this.pageSize);
        if (this.typedIndexNumber != null && (parseInt(this.typedIndexNumber) > lastPage || parseInt(this.typedIndexNumber) == this.currentPage)) {
            return;
        }
        let typedIndex = parseInt(this.typedIndexNumber) || parseInt('1');
        if (typedIndex > this.totalNoOfPages) {
            this.selectedPageIndex = this.totalNoOfPages;
        }
        else {
            this.selectedPageIndex = typedIndex;
        }
        this.pageIndex.emit(this.selectedPageIndex);
        // calling update current page function
        this.updateCurrentPage();
        // calling get pagination function
        this.getPagination();
    }
    allowOnlyNumbers(event) {
        const input = event.key;
        const isNumeric = /^[0-9]$/.test(input);
        if (!isNumeric) {
            event.preventDefault();
        }
    }
    /**
     * this function is called when the user clicks on
     * next button or previous button or any page no
     *
     * @param index - passing 'nxt' or 'prev' or actual page no
     */
    goToPageIndex(index) {
        if (this.showLoading) {
            return;
        }
        this.typedIndexNumber = '';
        this.callGoToPageNoFunc = false;
        this.paginatorForm.controls['goToPage'].reset();
        if (index === 'prev') {
            this.goToPreviousPage();
        }
        else if (index === 'nxt') {
            this.goToNextPage();
        }
        if (index === 'first') {
            this.goToFirstPage();
        }
        else if (index === 'last') {
            this.goToLastPage();
        }
        else if (typeof (index) === 'number') {
            this.selectedPageIndex = index;
            this.pageIndex.emit(this.selectedPageIndex);
        }
        // calling update current page function
        this.updateCurrentPage();
        // calling get pagination function
        this.getPagination();
    }
    managePaginationPills() {
        this.paginationPills = [];
        let start = 1, end = 3;
        if (this.currentPage > this.totalNoOfPages - 3) {
            start = this.totalNoOfPages - 2;
            end = this.totalNoOfPages;
        }
        else if (this.currentPage > 3) {
            start = this.currentPage - 1;
            end = this.currentPage + 1;
        }
        if (start > 1) {
            this.paginationPills.push('...');
        }
        for (let i = start; i <= end; i++) {
            this.paginationPills.push(i);
        }
        if (this.currentPage <= this.totalNoOfPages - 3) {
            this.paginationPills.push('...');
        }
    }
    getPagination() {
        if (this.totalNoOfPages <= 3) {
            this.paginationPills = [];
            for (let i = 1; i <= this.totalNoOfPages; i++) {
                this.paginationPills.push(i);
            }
        }
        else {
            this.managePaginationPills();
        }
    }
    ngOnDestroy() {
        this.paginatorFormSubscription?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClPaginatorComponent, deps: [{ token: i1$2.FormBuilder }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClPaginatorComponent, isStandalone: true, selector: "cl-paginator", inputs: { pageSize: "pageSize", currentPage: "currentPage", noOfRecords: "noOfRecords", showLoading: "showLoading", hideGoToPage: "hideGoToPage", hideFirstLastPageBtn: "hideFirstLastPageBtn", pageSizeOptions: "pageSizeOptions" }, outputs: { pageIndex: "pageIndex", onPageSizeChange: "onPageSizeChange" }, usesOnChanges: true, ngImport: i0, template: "<div [formGroup]=\"paginatorForm\"\n  class=\"flex flex-row items-center justify-between {{ totalNoOfPages <= 0 ? 'hidden' : '' }}\">\n\n  <!-- items per page selection dropdown -->\n  <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n    class=\"w-32 bg-neutral-50 dark:bg-primary-800 no-border-field h32-field padding-x8 cl-grid-paginator-dropdown\">\n\n    <mat-select type=\"text\" [disabled]=\"showLoading\" formControlName=\"pageSizeControl\"\n      [hideSingleSelectionIndicator]=\"true\" (valueChange)=\"pageSizeChanged($event)\">\n\n      @for (pageSize of pageSizeOptions; track pageSize) {\n      <mat-option [value]=\"pageSize\">\n        {{pageSize}} / page\n      </mat-option>\n      }\n\n    </mat-select>\n  </mat-form-field>\n  <!-- items per page selection dropdown -->\n\n  <div class=\"flex flex-row items-center\">\n    <!-- total items label -->\n    <mat-label class=\"total-items\">\n      <span> Total </span>\n      <span class=\"font-bold\"> {{ noOfRecords }} </span>\n      <span> items </span>\n    </mat-label>\n\n    <!-- page no list -->\n    <div class=\"flex flex-row items-center gap-2\">\n\n      <!-- first page button -->\n      @if(!hideFirstLastPageBtn) {\n      <div class=\"arrow\" (click)=\"goToPageIndex('first')\"\n        [ngClass]=\"{'active': selectedPageIndex > 1  && totalNoOfPages > 2}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-double-left'\"\n          [ngClass]=\"{'active': selectedPageIndex > 1  && totalNoOfPages > 2}\">\n        </mat-icon>\n      </div>\n      }\n      <!-- first page button -->\n\n      <!-- previous button -->\n      <div class=\"arrow\" (click)=\"goToPageIndex('prev')\" [ngClass]=\"{'active': selectedPageIndex > 1}\">\n        <mat-icon class=\"arrow-icon\" [ngClass]=\"{'active': selectedPageIndex > 1}\"\n          [svgIcon]=\"'heroicons_outline:chevron-left'\">\n        </mat-icon>\n      </div>\n      <!-- previous button -->\n\n      <!-- page number list -->\n      @for (pageNo of paginationPills; track pageNo) {\n      @if (pageNo != '...') {\n      <div class=\"page-no dark:text-primary-50\" [ngClass]=\"{'active': currentPage == pageNo}\"\n        (click)=\"currentPage == pageNo ? null : goToPageIndex(pageNo)\">\n        {{pageNo}}\n      </div>\n      }\n      @if (pageNo == '...') {\n      <div class=\"page-no dark:text-primary-50 {{pageNo == '...' ? 'cursor-default' : ''}}\">\n        {{pageNo}}\n      </div>\n      }\n      }\n      <!-- page number list -->\n\n      <!-- next button -->\n      <div class=\"arrow\" (click)=\"goToPageIndex('nxt')\" [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-right'\"\n          [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages}\">\n        </mat-icon>\n      </div>\n      <!-- next button -->\n\n      <!-- last page button -->\n      @if(!hideFirstLastPageBtn) {\n      <div class=\"arrow\" (click)=\"goToPageIndex('last')\"\n        [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages && totalNoOfPages > 2}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-double-right'\"\n          [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages  && totalNoOfPages > 2}\">\n        </mat-icon>\n      </div>\n      }\n      <!-- last page button -->\n    </div>\n\n    <!-- go to page no input -->\n    @if(!hideGoToPage) {\n    <mat-label class=\"ml-16 mr-8 font-normal text-gray-900 dark:text-primary-50\">Go to</mat-label>\n\n    <mat-form-field style=\"width: 50px;\" appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"bg-neutral-50 dark:bg-primary-800 no-border-field h32-field padding-x8 cl-grid-paginator-input\">\n\n      <input matInput [min]=\"1\" type=\"number\" autocomplete=\"off\" formControlName=\"goToPage\" style=\"text-align: center;\"\n        [attr.disabled]=\"showLoading ? '' : null\" (keypress)=\"callGoToPageNoFunc = true; allowOnlyNumbers($event)\" />\n\n    </mat-form-field>\n    }\n    <!-- go to page no input -->\n  </div>\n</div>\n", styles: [".total-items{margin-right:2.5rem;display:flex;gap:.125rem;font-size:.75rem;font-weight:400;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.total-items:is(.dark *){--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.arrow{display:flex;height:2rem;width:2rem;align-items:center;justify-content:center;border-radius:9999px;--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-50-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-800-rgb),var(--tw-text-opacity))}.arrow:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-800-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.arrow-icon{--tw-text-opacity: 1;color:rgb(82 82 82 / var(--tw-text-opacity));width:1rem;height:1rem;min-width:1rem;min-height:1rem;font-size:1rem;line-height:1rem}.arrow-icon svg{width:1rem;height:1rem}.arrow-icon.active{cursor:pointer;--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.page-no{display:flex;height:2rem;width:2rem;cursor:pointer;align-items:center;justify-content:center;border-radius:9999px;--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity));font-size:.875rem;line-height:1.25rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.page-no:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-800-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}.page-no.active{--tw-bg-opacity: 1;background-color:rgb(6 182 212 / var(--tw-bg-opacity));font-weight:700;--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity))}.page-no.active:is(.dark *){--tw-bg-opacity: 1;background-color:rgb(14 116 144 / var(--tw-bg-opacity))}::ng-deep .no-border-field.mat-mdc-form-field.mat-form-field-appearance-fill .mat-mdc-text-field-wrapper{padding:0!important;border-width:0px!important;background-color:transparent!important;--tw-shadow: none !important;--tw-shadow-colored: none !important;box-shadow:none!important}::ng-deep .h32-field .mat-mdc-form-field-infix{height:32px!important;min-height:32px!important}::ng-deep .padding-x8 .mat-mdc-form-field-flex{padding-left:.5rem!important;padding-right:.5rem!important}::ng-deep .cl-grid-paginator-dropdown .mdc-line-ripple:after{border-bottom:none!important}::ng-deep .cl-grid-paginator-dropdown .mdc-line-ripple:before{border-bottom:none!important}::ng-deep .cl-grid-paginator-dropdown .mat-mdc-form-field-infix{display:flex!important}::ng-deep .cl-grid-paginator-input{border-radius:.375rem;border-width:1px;--tw-border-opacity: 1;border-color:rgb(163 163 163 / var(--tw-border-opacity))}::ng-deep .cl-grid-paginator-input .mdc-line-ripple:after{border-bottom:none!important}::ng-deep .cl-grid-paginator-input .mdc-line-ripple:before{border-bottom:none!important}::ng-deep .cl-grid-paginator-input .mat-mdc-form-field-infix{display:flex!important;padding-top:4px!important;padding-bottom:4px!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NumberValueAccessor, selector: "input[type=number][formControlName],input[type=number][formControl],input[type=number][ngModel]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.MinValidator, selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]", inputs: ["min"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i9.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i9.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i11.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClPaginatorComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-paginator', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatSelectModule,
                        ReactiveFormsModule
                    ], template: "<div [formGroup]=\"paginatorForm\"\n  class=\"flex flex-row items-center justify-between {{ totalNoOfPages <= 0 ? 'hidden' : '' }}\">\n\n  <!-- items per page selection dropdown -->\n  <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n    class=\"w-32 bg-neutral-50 dark:bg-primary-800 no-border-field h32-field padding-x8 cl-grid-paginator-dropdown\">\n\n    <mat-select type=\"text\" [disabled]=\"showLoading\" formControlName=\"pageSizeControl\"\n      [hideSingleSelectionIndicator]=\"true\" (valueChange)=\"pageSizeChanged($event)\">\n\n      @for (pageSize of pageSizeOptions; track pageSize) {\n      <mat-option [value]=\"pageSize\">\n        {{pageSize}} / page\n      </mat-option>\n      }\n\n    </mat-select>\n  </mat-form-field>\n  <!-- items per page selection dropdown -->\n\n  <div class=\"flex flex-row items-center\">\n    <!-- total items label -->\n    <mat-label class=\"total-items\">\n      <span> Total </span>\n      <span class=\"font-bold\"> {{ noOfRecords }} </span>\n      <span> items </span>\n    </mat-label>\n\n    <!-- page no list -->\n    <div class=\"flex flex-row items-center gap-2\">\n\n      <!-- first page button -->\n      @if(!hideFirstLastPageBtn) {\n      <div class=\"arrow\" (click)=\"goToPageIndex('first')\"\n        [ngClass]=\"{'active': selectedPageIndex > 1  && totalNoOfPages > 2}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-double-left'\"\n          [ngClass]=\"{'active': selectedPageIndex > 1  && totalNoOfPages > 2}\">\n        </mat-icon>\n      </div>\n      }\n      <!-- first page button -->\n\n      <!-- previous button -->\n      <div class=\"arrow\" (click)=\"goToPageIndex('prev')\" [ngClass]=\"{'active': selectedPageIndex > 1}\">\n        <mat-icon class=\"arrow-icon\" [ngClass]=\"{'active': selectedPageIndex > 1}\"\n          [svgIcon]=\"'heroicons_outline:chevron-left'\">\n        </mat-icon>\n      </div>\n      <!-- previous button -->\n\n      <!-- page number list -->\n      @for (pageNo of paginationPills; track pageNo) {\n      @if (pageNo != '...') {\n      <div class=\"page-no dark:text-primary-50\" [ngClass]=\"{'active': currentPage == pageNo}\"\n        (click)=\"currentPage == pageNo ? null : goToPageIndex(pageNo)\">\n        {{pageNo}}\n      </div>\n      }\n      @if (pageNo == '...') {\n      <div class=\"page-no dark:text-primary-50 {{pageNo == '...' ? 'cursor-default' : ''}}\">\n        {{pageNo}}\n      </div>\n      }\n      }\n      <!-- page number list -->\n\n      <!-- next button -->\n      <div class=\"arrow\" (click)=\"goToPageIndex('nxt')\" [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-right'\"\n          [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages}\">\n        </mat-icon>\n      </div>\n      <!-- next button -->\n\n      <!-- last page button -->\n      @if(!hideFirstLastPageBtn) {\n      <div class=\"arrow\" (click)=\"goToPageIndex('last')\"\n        [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages && totalNoOfPages > 2}\">\n\n        <mat-icon class=\"arrow-icon\" [svgIcon]=\"'heroicons_outline:chevron-double-right'\"\n          [ngClass]=\"{'active': selectedPageIndex < totalNoOfPages  && totalNoOfPages > 2}\">\n        </mat-icon>\n      </div>\n      }\n      <!-- last page button -->\n    </div>\n\n    <!-- go to page no input -->\n    @if(!hideGoToPage) {\n    <mat-label class=\"ml-16 mr-8 font-normal text-gray-900 dark:text-primary-50\">Go to</mat-label>\n\n    <mat-form-field style=\"width: 50px;\" appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"bg-neutral-50 dark:bg-primary-800 no-border-field h32-field padding-x8 cl-grid-paginator-input\">\n\n      <input matInput [min]=\"1\" type=\"number\" autocomplete=\"off\" formControlName=\"goToPage\" style=\"text-align: center;\"\n        [attr.disabled]=\"showLoading ? '' : null\" (keypress)=\"callGoToPageNoFunc = true; allowOnlyNumbers($event)\" />\n\n    </mat-form-field>\n    }\n    <!-- go to page no input -->\n  </div>\n</div>\n", styles: [".total-items{margin-right:2.5rem;display:flex;gap:.125rem;font-size:.75rem;font-weight:400;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.total-items:is(.dark *){--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.arrow{display:flex;height:2rem;width:2rem;align-items:center;justify-content:center;border-radius:9999px;--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-50-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-800-rgb),var(--tw-text-opacity))}.arrow:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-800-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.arrow-icon{--tw-text-opacity: 1;color:rgb(82 82 82 / var(--tw-text-opacity));width:1rem;height:1rem;min-width:1rem;min-height:1rem;font-size:1rem;line-height:1rem}.arrow-icon svg{width:1rem;height:1rem}.arrow-icon.active{cursor:pointer;--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.page-no{display:flex;height:2rem;width:2rem;cursor:pointer;align-items:center;justify-content:center;border-radius:9999px;--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity));font-size:.875rem;line-height:1.25rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.page-no:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-800-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}.page-no.active{--tw-bg-opacity: 1;background-color:rgb(6 182 212 / var(--tw-bg-opacity));font-weight:700;--tw-text-opacity: 1;color:rgb(255 255 255 / var(--tw-text-opacity))}.page-no.active:is(.dark *){--tw-bg-opacity: 1;background-color:rgb(14 116 144 / var(--tw-bg-opacity))}::ng-deep .no-border-field.mat-mdc-form-field.mat-form-field-appearance-fill .mat-mdc-text-field-wrapper{padding:0!important;border-width:0px!important;background-color:transparent!important;--tw-shadow: none !important;--tw-shadow-colored: none !important;box-shadow:none!important}::ng-deep .h32-field .mat-mdc-form-field-infix{height:32px!important;min-height:32px!important}::ng-deep .padding-x8 .mat-mdc-form-field-flex{padding-left:.5rem!important;padding-right:.5rem!important}::ng-deep .cl-grid-paginator-dropdown .mdc-line-ripple:after{border-bottom:none!important}::ng-deep .cl-grid-paginator-dropdown .mdc-line-ripple:before{border-bottom:none!important}::ng-deep .cl-grid-paginator-dropdown .mat-mdc-form-field-infix{display:flex!important}::ng-deep .cl-grid-paginator-input{border-radius:.375rem;border-width:1px;--tw-border-opacity: 1;border-color:rgb(163 163 163 / var(--tw-border-opacity))}::ng-deep .cl-grid-paginator-input .mdc-line-ripple:after{border-bottom:none!important}::ng-deep .cl-grid-paginator-input .mdc-line-ripple:before{border-bottom:none!important}::ng-deep .cl-grid-paginator-input .mat-mdc-form-field-infix{display:flex!important;padding-top:4px!important;padding-bottom:4px!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormBuilder }], propDecorators: { pageSize: [{
                type: Input,
                args: [{ required: true }]
            }], currentPage: [{
                type: Input,
                args: [{ required: true }]
            }], noOfRecords: [{
                type: Input,
                args: [{ required: true }]
            }], showLoading: [{
                type: Input,
                args: [{ required: true }]
            }], hideGoToPage: [{
                type: Input,
                args: [{ required: false }]
            }], hideFirstLastPageBtn: [{
                type: Input,
                args: [{ required: false }]
            }], pageSizeOptions: [{
                type: Input,
                args: [{ required: true }]
            }], pageIndex: [{
                type: Output
            }], onPageSizeChange: [{
                type: Output
            }] } });

class ClDataGridInjectorComponent {
    constructor() {
        this.isComponentDragged = input(false);
        this.valueChange = new EventEmitter();
        this.textBlockProperties = new ClTextBlockProperties();
    }
    ngOnChanges() {
        this.createComponent();
    }
    createComponent() {
        if (!this.isComponentDragged()) {
            this.componentRef = this.viewContainer.createComponent(this.component ?? ClTextBlockComponent);
        }
        else {
            this.componentRef = this.viewContainer.createComponent(ClTextBlockComponent);
        }
        if (this.componentRef) {
            if (this.component && !this.isComponentDragged()) {
                this.componentRef.instance._value = this.value;
                this.componentRef.instance._rowValue = this.rowDetail;
                this.componentRef.instance.properties = this.properties;
                this.componentRef.instance.onChange = (value) => {
                    this.valueChange.emit(value);
                };
            }
            else {
                this.textBlockProperties.label = this.value;
                this.componentRef.instance.properties = this.textBlockProperties;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridInjectorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "18.2.8", type: ClDataGridInjectorComponent, isStandalone: true, selector: "cl-data-grid-injector", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: false, isRequired: false, transformFunction: null }, rowDetail: { classPropertyName: "rowDetail", publicName: "rowDetail", isSignal: false, isRequired: false, transformFunction: null }, component: { classPropertyName: "component", publicName: "component", isSignal: false, isRequired: false, transformFunction: null }, properties: { classPropertyName: "properties", publicName: "properties", isSignal: false, isRequired: false, transformFunction: null }, isComponentDragged: { classPropertyName: "isComponentDragged", publicName: "isComponentDragged", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, viewQueries: [{ propertyName: "viewContainer", first: true, predicate: ["viewContainerRef"], descendants: true, read: ViewContainerRef, static: true }], usesOnChanges: true, ngImport: i0, template: "<ng-container #viewContainerRef></ng-container>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridInjectorComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-data-grid-injector', template: "<ng-container #viewContainerRef></ng-container>\n" }]
        }], propDecorators: { value: [{
                type: Input
            }], rowDetail: [{
                type: Input
            }], component: [{
                type: Input
            }], properties: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], viewContainer: [{
                type: ViewChild,
                args: ['viewContainerRef', { read: ViewContainerRef, static: true }]
            }] } });

/**
 * this object is to set what type of cell it should render based on data
 * this determines the view template of the cell
 */
var ClColumnType;
(function (ClColumnType) {
    ClColumnType["text"] = "text";
    ClColumnType["time"] = "time";
    ClColumnType["date"] = "date";
    ClColumnType["input"] = "input";
    ClColumnType["image"] = "image";
    ClColumnType["number"] = "number";
    ClColumnType["status"] = "status";
    ClColumnType["select"] = "select";
    ClColumnType["button"] = "button";
    ClColumnType["amount"] = "amount";
    ClColumnType["primary"] = "primary";
    ClColumnType["percent"] = "percent";
    ClColumnType["actions"] = "actions";
    ClColumnType["checkbox"] = "checkbox";
    ClColumnType["criteria"] = "criteria";
    ClColumnType["progressBar"] = "progressBar";
    ClColumnType["reorderIndex"] = "reorderIndex";
})(ClColumnType || (ClColumnType = {}));
class ClDataGridStyleProperties {
}
/**
 * this config object is used for the entire data grid configuration
 * here the client application set the default configuration based on the use case
 */
class ClTableConfigProperties {
    constructor() {
        this.pageSize = 5;
        this.pageSize = 5;
        this.id = 'default0';
        this.editField = false;
        this.showFilter = true;
        this.isMultiple = true;
        this.rowDragEnable = false;
        this.customButtons = [];
        this.showLoading = false;
        this.showPaginator = true;
        this.showColumnFilter = false;
        this.isComponentDragged = false;
        this.columnCustomization = false;
        this.type = ClComponentTypes.dataGrid;
        this.pageSizeOptions = [5, 10, 15, 20];
        this.style = new ClDataGridStyleProperties();
        this.columns = [
            { key: 'column1', name: 'Column 1', columnType: ClColumnType.text },
            { key: 'column2', name: 'Column 2', columnType: ClColumnType.text },
            { key: 'column3', name: 'Column 3', columnType: ClColumnType.text },
            { key: 'column4', name: 'Column 4', columnType: ClColumnType.text },
            { key: 'column5', name: 'Column 5', columnType: ClColumnType.text },
        ];
        this.data = [
            { column1: 'data1', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data2', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data3', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data4', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data5', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data6', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data7', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data8', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data9', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' },
            { column1: 'data10', column2: 'data2', column3: 'data3', column4: 'data4', column5: 'data5' }
        ];
    }
}

class TableMultiFilterDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.selectedMultiFilter = [];
        this.defaultState = signal(true);
        this.isDisabled = computed(() => {
            return this.defaultState();
        });
        this.multiProperties = [];
        this.options = { value: '', options: [], indexValue: '' };
        this.chipProperties = {
            id: '',
            label: 'temp',
            multiple: true,
            disabled: false,
            direction: 'col',
            showOptionAll: true,
            optionsSelected: (selectedChips) => { },
            type: ClComponentTypes.chipList,
            options: [
                {
                    text: '',
                    value: '',
                    disabled: false,
                    isSelected: false,
                }
            ],
        };
        // Primary button properties
        this.primaryButtonProperties = {
            label: 'Apply',
            disabled: this.isDisabled,
            id: 'btnPrimarySubmit',
            type: ClComponentTypes.button,
            onSubmit: this.applyFilter.bind(this)
        };
        // Stroked primary button properties
        this.strokedButtonProperties = {
            label: 'Reset',
            disabled: this.isDisabled,
            id: 'btnPrimarySubmit',
            type: ClComponentTypes.button,
            onSubmit: this.resetToAll.bind(this)
        };
        this.propertiesData = data;
    }
    ngOnInit() {
        this.selectionForm();
        if (this.propertiesData) {
            for (let properties of this.propertiesData) {
                let index = this.propertiesData.indexOf(properties);
                if (properties.optionAllProperties?.isSelected == true) {
                    this.selectedMultiFilter.push({ ...this.options });
                    this.selectedMultiFilter[index].indexValue = index.toString();
                    this.selectedMultiFilter[index].value = properties.value;
                }
                if (properties.optionAllProperties?.isSelected == false) {
                    this.selectedMultiFilter.push({ ...this.options });
                    this.selectedMultiFilter[index].indexValue = index.toString();
                    this.selectedMultiFilter[index].value = properties.value;
                    // Filter the options based on the isSelected property
                    this.selectedMultiFilter[index].options = properties.options.filter((option) => option.isSelected === true);
                }
            }
        }
    }
    resetToAll() {
        for (let eachFilter of this.multiProperties) {
            const index = this.multiProperties.indexOf(eachFilter);
            eachFilter.optionAllProperties.isSelected = true;
            eachFilter.options = eachFilter.options;
            for (let option of eachFilter.options) {
                const subIndex = this.multiProperties[index].options.indexOf(option);
                option.isSelected = false;
            }
            this.selectedMultiFilter[index].options = [];
        }
    }
    selectionForm() {
        for (let eachFilter of this.propertiesData) {
            const index = this.propertiesData.indexOf(eachFilter);
            let data = { ...this.chipProperties };
            data.id = eachFilter.id;
            data.label = eachFilter.label;
            if (eachFilter.optionAllProperties) {
                data.showOptionAll = true,
                    data.optionAllProperties = eachFilter.optionAllProperties;
            }
            if (!eachFilter.optionAllProperties) {
                data.showOptionAll = false;
            }
            data.options = eachFilter.options;
            data.optionsSelected = this.selectedMultiFilterList.bind(this, index, 'option', eachFilter.value);
            this.multiProperties.push(data);
        }
    }
    selectedMultiFilterList(index, type, key, data) {
        this.defaultState.set(false);
        if (index >= 0 && index >= this.selectedMultiFilter.length) {
            for (let dataIndex = this.selectedMultiFilter.length; dataIndex <= index; dataIndex++) {
                this.selectedMultiFilter.push({ ...this.options });
                this.selectedMultiFilter[dataIndex].indexValue = dataIndex.toString();
                this.selectedMultiFilter[dataIndex].value = key;
            }
        }
        if (type == 'option') {
            this.selectedMultiFilter[index].options = data;
            if (this.selectedMultiFilter[index].options.length == this.multiProperties[index].options.length) {
                this.selectedMultiFilter[index].options = [];
                this.selectedMultiFilter[index].value = key;
            }
        }
        if (type == 'optionAll') {
            this.selectedMultiFilter[index].options = [];
            this.selectedMultiFilter[index].value = key;
        }
        if (this.selectedMultiFilter.length < this.multiProperties.length) {
            for (let list = this.selectedMultiFilter.length; list < this.multiProperties.length; list++) {
                this.selectedMultiFilter.push({ ...this.options });
                this.selectedMultiFilter[list].indexValue = list.toString();
                this.selectedMultiFilter[list].value = key;
            }
        }
    }
    applyFilter() {
        const modifiedData = this.selectedMultiFilter.map(item => {
            return {
                ...item,
                options: item.options.map((option) => option.value)
            };
        });
        let applyData = {
            selectedData: modifiedData,
            properties: this.propertiesData
        };
        this.dialogRef.close({ result: applyData });
    }
    filterClose() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: TableMultiFilterDialogComponent, deps: [{ token: i1$4.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: TableMultiFilterDialogComponent, isStandalone: true, selector: "cl-table-multi-filter-dialog", ngImport: i0, template: "<div class=\"row-auto border-b-2 w-full\">\n  <div class=\"flex items-center justify-between mx-4 my-1.5\">\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:filter-tuning'\"></mat-icon>\n      <span class=\"text-sky-900 text-2xl\">Filters</span>\n    </div>\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:close-icon'\" class=\"cursor-pointer\" (click)=\"filterClose()\"></mat-icon>\n    </div>\n  </div>\n</div>\n\n<div class=\"mx-6\">\n  @for (properties of multiProperties; track properties; let i = $index) {\n    <cl-chip-list class=\"mt-2 mb-2 ml-3 mr-3\" [properties]=\"properties\"></cl-chip-list>\n  }\n</div>\n\n<div class=\"row-auto border-t-2 w-full bg-gray-100\">\n  <div class=\"flex items-center justify-end px-4 py-3.5 gap-2\">\n    <cl-button [properties]=\"strokedButtonProperties\"></cl-button>\n    <cl-button [properties]=\"primaryButtonProperties\"></cl-button>\n  </div>\n</div>\n", styles: ["::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0rem!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClChipListComponent, selector: "cl-chip-list", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: TableMultiFilterDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-table-multi-filter-dialog', imports: [
                        MatIconModule,
                        ClButtonComponent,
                        ClChipListComponent,
                    ], template: "<div class=\"row-auto border-b-2 w-full\">\n  <div class=\"flex items-center justify-between mx-4 my-1.5\">\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:filter-tuning'\"></mat-icon>\n      <span class=\"text-sky-900 text-2xl\">Filters</span>\n    </div>\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:close-icon'\" class=\"cursor-pointer\" (click)=\"filterClose()\"></mat-icon>\n    </div>\n  </div>\n</div>\n\n<div class=\"mx-6\">\n  @for (properties of multiProperties; track properties; let i = $index) {\n    <cl-chip-list class=\"mt-2 mb-2 ml-3 mr-3\" [properties]=\"properties\"></cl-chip-list>\n  }\n</div>\n\n<div class=\"row-auto border-t-2 w-full bg-gray-100\">\n  <div class=\"flex items-center justify-end px-4 py-3.5 gap-2\">\n    <cl-button [properties]=\"strokedButtonProperties\"></cl-button>\n    <cl-button [properties]=\"primaryButtonProperties\"></cl-button>\n  </div>\n</div>\n", styles: ["::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0rem!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$4.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ClDataGridComponent extends ClBaseContainerComponent {
    //--------------------------------------------
    constructor(fb, cdr, dialog, dataGridService) {
        super();
        this.fb = fb;
        this.cdr = cdr;
        this.dialog = dialog;
        this.dataGridService = dataGridService;
        this.totalRecords = 0;
        this.showLoading = false;
        this.data = [];
        this.customData = null;
        this.editingColumn = null;
        this.editingRowIndex = null;
        this.editableFields = [];
        this.modifiedRow = [];
        this.currentPage = 1;
        this.isSortingSubscribed = false;
        this.columnFilters = [];
        this.dataSource = new MatTableDataSource([]);
        this.formControl = {};
        this.searchButtonDisable = signal(true);
        this.searchButtonProperties = new ClButtonProperties();
        this.editedRows = [];
        this.dragDisabled = false;
        this.tableFilter = [];
        this.tableFilterChip = [];
        this.customFilterData = null;
        this.disableSearchButton = true;
        this.globalSearchAppliedColumns = [];
        this.textBlockComponent = ClTextBlockComponent;
        this.previousIndex = null;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        /**
         * this function is the callback function on input field when user types
         *
         * @param column - column of the input field
         *
         * @param row - row of the input field
         */
        this.onInputChanged = debounce((event, row) => {
            if (this.properties.onInputChanged != undefined)
                this.properties.onInputChanged(row);
        }, 500);
        this.filterSearchQueryChange = debounce((searchQuery) => {
            if (this.properties.onFilterChange != undefined)
                this.properties.onFilterChange(searchQuery);
        }, 500);
        super.setProperties(this.properties);
        this.setSearchButtonProperties();
        this.formGroup = this.fb.group({});
        this._clearSelectionSubscription = this.dataGridService.clearSelection.subscribe((action) => {
            if (action === 'clear') {
                this.clearSelections();
            }
        });
    }
    ngOnChanges(changes) {
        if (changes['data']) {
            // calling set default values function
            this.setDefaultValues();
            // calling set data source function
            this.setDataToDataSource();
        }
        if (changes['customData'] && !changes['data']) {
            // Check if custom data filter from server side value change
            this.checkServerSideCustomData(changes['customData']?.currentValue);
        }
    }
    ngOnInit() {
        // calling set default table config function
        this.setDefaultTableConfig();
        // calling add global search control function
        this.addGlobalSearchControl();
        // calling initialize grid function
        this.addColumnLevelFilterControls();
        // calling create filter function
        this.createFilter();
        //initialize table filter variables
        this.initializeTableFilter();
        // this.setStatusProperties();
        super.ngOnInit();
    }
    setSearchButtonProperties() {
        this.searchButtonProperties.id = 'btnSubmit';
        this.searchButtonProperties.label = 'Search';
        this.searchButtonProperties.type = ClComponentTypes.button;
        this.searchButtonProperties.buttonBehavior = ClButtonBehavior.flat;
        this.searchButtonProperties.style.labelCssClasses = 'text-base text-white font-semibold';
        this.searchButtonProperties.disabled = this.searchButtonDisable;
        this.searchButtonProperties.onSubmit = this.onSearchBtnSubmit.bind(this);
    }
    // Check Custom Data Filter on Server Side
    checkServerSideCustomData(data) {
        if (data !== null) {
            this.customFilterData = data;
            // Apply the filter to the data source
            this.dataSource.filter = this.dataSource.filter;
        }
        if (data == null) {
            this.customFilterData = null;
            this.dataSource.filter = this.dataSource.filter;
        }
    }
    openDialogMultiFilter() {
        const dialogConfig = new MatDialogConfig();
        dialogConfig.width = '404px';
        dialogConfig.panelClass = 'cl-confirmation-dialog-panel';
        dialogConfig.data = cloneDeep(this.properties.setMultiFilter);
        this.dialog.open(TableMultiFilterDialogComponent, dialogConfig).afterClosed().subscribe((res) => {
            if (res && res.result) {
                this.selectedMultiFilter = res.result.selectedData;
                for (let eachFilter of this.selectedMultiFilter) {
                    if (eachFilter.options.length > 0) {
                        this.formGroup.controls[eachFilter.value]?.setValue(eachFilter.options);
                    }
                    if (eachFilter.options.length == 0) {
                        this.formGroup.controls[eachFilter.value]?.setValue('');
                    }
                }
                this.properties.setMultiFilter = cloneDeep(res.result.properties);
            }
            if (res && res.result && this.properties.onMultiFilterDialogApply) {
                this.properties.onMultiFilterDialogApply(res.result.selectedData);
            }
        });
    }
    onScroll(event) {
        const target = event.target;
        const table = this.tableContainer.nativeElement.querySelector('table');
        const cells = table.getElementsByClassName('mat-mdc-table-sticky-border-elem-left');
        for (const element of cells) {
            const cell = element;
            if (target.scrollLeft > 0) {
                cell.classList.add('scroll-right');
            }
            else {
                cell.classList.remove('scroll-right');
            }
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    handleValueChange(newValue) { }
    ngAfterViewInit() {
        // this paginator will only work when data grid is used via layout renderer
        // calling set paginator function
        this.setPaginator();
        // calling set data source function
        this.setDataToDataSource();
    }
    /**
     * This function will add global search control to the from group for global filter
     */
    addGlobalSearchControl() {
        // creating and adding form control for global filter
        this.formControl['globalSearch'] = new FormControl('');
        this.formGroup?.addControl('globalSearch', this.formControl['globalSearch']);
        this.formGroup.valueChanges.subscribe((searchQuery) => {
            this.tableFilterChip = searchQuery;
            // if all is selected in data grid filter then set that to ''
            if (this.properties?.enableServerSidePagination && this.properties.onFilterChange) {
                // emit the values to the client
                this.filterSearchQueryChange(searchQuery);
            }
            else {
                if (this.properties.showFilterDropdown && this.tableFilter.length) {
                    if (this.tableFilter.some((item) => item.filterFromServerSide && item.filterFromServerSide === true)) {
                        let searchQueryCopy = { ...searchQuery };
                        this.tableFilter.forEach((item) => {
                            if (item.filterFromServerSide) {
                                searchQueryCopy[item.key] = '';
                            }
                        });
                        this.tableFilter.forEach((item, index) => {
                            if (searchQuery[item.key].toLowerCase() == 'all') {
                                searchQueryCopy[item.key] = '';
                                this.dataSource.filter = JSON.stringify(searchQueryCopy);
                            }
                            if (item.filterFromServerSide) {
                                searchQueryCopy[item.key] = '';
                                this.dataSource.filter = JSON.stringify(searchQueryCopy);
                                this.filterSearchQueryChange(searchQuery);
                            }
                            else {
                                this.dataSource.filter = JSON.stringify(searchQueryCopy);
                            }
                        });
                    }
                    else {
                        this.tableFilter.forEach((item) => {
                            if (searchQuery[item.key].toLowerCase() == 'all') {
                                searchQuery[item.key] = '';
                                this.dataSource.filter = JSON.stringify(searchQuery);
                            }
                            this.dataSource.filter = JSON.stringify(searchQuery);
                        });
                    }
                }
                else {
                    this.dataSource.filter = JSON.stringify(searchQuery);
                }
            }
            this.disableSearchButton = true;
            for (let value of Object.values(searchQuery)) {
                if (typeof value === 'string' && value.length > 0 && value.toLowerCase() !== 'all') {
                    this.disableSearchButton = false;
                    break;
                }
            }
            if (this.disableSearchButton) {
                this.searchButtonDisable.set(true);
            }
            else {
                this.searchButtonDisable.set(false);
            }
        });
    }
    /**
     * This function will add column level filter controls to form group for column level filters
     */
    addColumnLevelFilterControls() {
        this.properties.searchPlaceholder ??= 'Search...';
        if (this.properties.columns && this.properties.columns.length > 0) {
            for (let column of this.properties.columns) {
                column.visible = true;
                // creating a column filter by using the key passed in header config
                // appending '_' to the key so that it becomes unique and the filter row is rendered
                this.columnFilters.push(`_${column.key}`);
                if (column.enableSearchOnColumn) {
                    this.globalSearchAppliedColumns.push(column.key);
                }
                // creating and adding form controls for all the column filters
                this.formControl[column.key] = new FormControl('');
                this.formGroup?.addControl(column.key, this.formControl[column.key]);
            }
        }
    }
    initializeTableFilter() {
        this.properties.showFilterDropdown = this.properties.showFilterDropdown ? this.properties.showFilterDropdown : false;
        if (this.properties.showFilterDropdown) {
            this.tableFilter = this.properties.filterConfig;
        }
        if (this.tableFilter.length > 0) {
            this.tableFilter.forEach((item, i) => {
                // check the options whether it contains all option or not
                // if the option is not there then add all option
                const hasAllOption = this.tableFilter[i].options.some((option) => option.value.toLowerCase() === 'all');
                if (!hasAllOption) {
                    this.tableFilter[i].options = [{ value: 'All', text: 'All' }].concat(this.tableFilter[i].options);
                }
                //setting the value to all initially
                if (this.tableFilter[i].selectedValue) {
                    this.formGroup.controls[item.key].setValue(this.tableFilter[i].selectedValue);
                    this.onFilterChange({ value: this.tableFilter[i].selectedValue }, i);
                }
                else {
                    this.formGroup.controls[item.key].setValue('All');
                    this.tableFilter[i].selectedValue = 'All';
                }
            });
        }
    }
    /**
     * this function will set the default values to the input fields
     * which is received from the client application
     */
    setDefaultValues() {
        this.totalRecords = this.properties.totalRecords ?? 0;
        this.matSortActive = this.properties.matSortActive;
        this.matSortDirection = this.properties.matSortDirection;
        this.showLoading = this.properties.showLoading ?? false;
        this.selection = new SelectionModel(this.properties.isMultiple, []);
    }
    /**
     * this function will set the default values to properties of table config
     */
    setDefaultTableConfig() {
        this.properties ??= new ClTableConfigProperties();
        this.properties.showFilter ??= true;
        this.properties.isMultiple ??= true;
        this.properties.showPaginator ??= true;
        this.properties.selectAllRecords ??= true;
        // this.properties.showColumnFilter ??= false;
        this.properties.pageSizeOptions ??= [10, 15, 20];
        this.properties.pageSize ??= this.properties.pageSizeOptions[0];
        this.selection = new SelectionModel(this.properties.isMultiple, []);
        this.properties.columns.forEach((column) => {
            column.disableDrag ??= false;
            column.enableSearchOnColumn ??= true;
            if (column.hasEditableRights && !this.editableFields.includes(column.key)) {
                this.editableFields.push(column.key);
            }
        });
    }
    /**
     * This function will initialize data source once data is sent from client
     */
    setDataToDataSource() {
        if (this.data && this.data.length > 0) {
            this.dataSource = new MatTableDataSource(this.data);
            this.dataSource.sort = this.sort;
            // calling set sorting subscription function
            this.setSortingSubscription();
            // this paginator will only when data grid is used directly
            // calling set paginator
            this.setPaginator();
            // calling create filter function
            this.createFilter();
            if (this.properties.enableServerSidePagination == undefined || this.properties.enableServerSidePagination == false) {
                // Below code is set to update initial set filters
                let searchQuery = this.formGroup.value;
                this.formGroup.setValue(searchQuery);
            }
        }
        else {
            this.dataSource = new MatTableDataSource(this.data);
        }
    }
    /**
     * this function subscribe to the sort change event of mat sort
     */
    setSortingSubscription() {
        if (!this.isSortingSubscribed) {
            // If the user changes the sort order, reset back to the first page.
            this.sort?.sortChange?.subscribe(() => {
                if (this.totalRecords && this.totalRecords > 0) {
                    this.currentPage = 0;
                    // calling go to page no function
                    if (this.properties.showPaginator) {
                        this.goToPageNo(this.currentPage);
                    }
                }
            });
            if (this.sort) {
                this.isSortingSubscribed = true;
            }
        }
    }
    /**
     * This function will set paginator for applying pagination to mat table
     */
    setPaginator() {
        if (this.paginator && this.properties.showPaginator) {
            this.properties.pageSize ??= this.properties.pageSizeOptions[0];
            this.dataSource.paginator = this.paginator;
        }
    }
    /**
     * This function is used directly inside the table to render the columns header
     * This function will only show the columns which are visible.
     *
     * This function also updates the column level filter row based on changes made by the user;
     * when the is hiding or showing the column
     */
    getDisplayColumns() {
        this.columnFilters = this.properties.columns.filter((column) => column.visible).map((column) => `_${column.key}`);
        return this.properties.columns.filter((column) => column.visible).map((column) => column.key);
    }
    /**
     * This function will change the order of the dropped column when the user is dragging and dropping the column.
     *
     * @param event - event of the column dropped
     */
    dropCol(event) {
        moveItemInArray(this.properties.columns, event.previousIndex, event.currentIndex);
    }
    dropRow(event) {
        // this.previousIndex = this.dataSource.data.indexOf(this.rowDetails);
        const differenceValue = Number(event.currentIndex) - Number(event.previousIndex);
        const currentIndex = Number(this.previousIndex) + Number(differenceValue);
        // Ensure data is not empty
        if (!this.dataSource.data || this.dataSource.data.length === 0 || currentIndex < 0 || this.previousIndex == null)
            return;
        // Get the current data from the table
        // const clonedDataSource = [...this.dataSource.data];
        // Move the dragged item in the array
        moveItemInArray(this.dataSource.data, this.previousIndex, currentIndex);
        // Update the dataSource with new order
        // this.dataSource.data = clonedDataSource;
        // Trigger change detection to reflect the changes in the UI and set previousIndex to null
        this.dataSource._updateChangeSubscription();
        this.cdr.detectChanges();
        this.previousIndex = null;
    }
    dragStarted(row) {
        this.previousIndex = this.dataSource.data.indexOf(row);
    }
    /**
     * This function is called when the page size is changed.
     *
     * @param pageSize - number of records per page
     */
    onPageSizeChange(pageSize) {
        this.paginator.pageSize = pageSize;
        this.dataSource.paginator = this.paginator;
    }
    /**
     * This function is called when the page is changed.
     *
     * @param index - page no or nxt or prev
     */
    goToPageNo(index) {
        this.paginator.pageIndex = index - 1;
        this.dataSource.paginator = this.paginator;
        if (this.properties.onPageNoChanged) {
            this.currentPage = index;
            this.properties.onPageNoChanged(this.currentPage, this.paginator.pageSize, this.sort.active, this.sort.direction);
        }
    }
    /**
     * This function will check if all the items in a row for that page is selected or not
     */
    isAllSelected() {
        const numSelected = this.selection.selected.length;
        const page = this.getDataLimit();
        return numSelected === page;
    }
    /**
     * Selects all rows in a page if they are not all selected; otherwise clear selection.
     * This function is also used to either select all items in the page or de-select.
     */
    masterToggle() {
        this.isAllSelected() ? this.clearSelections() : this.selectRows();
    }
    /**
     * This function will mark or select the row.
     */
    selectRows() {
        // calling get data limit function
        const limit = this.getDataLimit();
        for (let index = 0; index < limit; index++) {
            this.selection.select(this.dataSource.data[index]);
        }
        // calling on checkbox selection function
        this.onCheckboxSelection();
    }
    onRowValueChange(value, row, columnKey, index) {
        row[columnKey] = value;
        let obj = { row: row, index: index };
        this.onInputChanged({}, obj);
    }
    onRowValueChangeCheckbox(value, row, columnKey, index) {
        row[columnKey] = value.checked;
        let obj = { row: row, index: index };
        this.onInputChanged({}, obj);
    }
    /**
     * this function will return the records which are minimum
     *
     * @returns - entire records length if select all records is true
     *
     *          - page per records will be returned if records are greater than page size
     *
     *          - records length will be sent if records are lesser than page size
     */
    getDataLimit() {
        if (this.properties.pageSize && this.dataSource.data.length <= this.properties.pageSize) {
            return this.properties.pageSize;
        }
        return this.dataSource.data.length;
    }
    /**
     * This function will clear all the selections.
     */
    clearSelections() {
        if (this.selection) {
            this.selection.clear();
            // calling on checkbox selection function
            this.onCheckboxSelection();
        }
    }
    /**
     * This function will emit the selected row or rows.
     */
    onCheckboxSelection() {
        if (this.properties.onCheckboxSelection) {
            this.properties.onCheckboxSelection(this.selection.selected);
        }
    }
    /**
     * this function is the callback function of dropdown cell
     *
     * @param row - row of the dropdown
     */
    onDropdownValueChange(row, column, closePanel) {
        if (this.properties.onDropdownValueChange) {
            this.properties.onDropdownValueChange(row);
        }
        if (closePanel) {
            this.inputChanged(row, column, false);
        }
        else {
            this.stopEditingSelect(row, column);
        }
    }
    /**
     * This function will create and set filter predicate to data source;
     * and is used to filter out based on input at column level
     */
    createFilter() {
        this.dataSource.filterPredicate = (data, filter) => {
            let filters = JSON.parse(filter);
            let columnFilters = [];
            let columnFiltersChip = [];
            let customColumnFilter = true;
            if (this.properties.showFilterDropdown && this.tableFilter.length > 0) {
                this.tableFilter.forEach((item) => {
                    let obj = { key: item.key, value: filters[item.key] };
                    columnFilters.push(obj);
                });
            }
            if (Object.keys(this.tableFilterChip).length > 0) {
                for (let key in this.tableFilterChip) {
                    if (this.tableFilterChip.hasOwnProperty(key)) {
                        if (key !== 'globalSearch') {
                            let obj = { key: key, value: filters[key] };
                            columnFiltersChip.push(obj);
                        }
                    }
                }
            }
            if (this.properties.isCustomDataFilter && this.customFilterData !== null) {
                // Check if any row in customFilteredData matches the current data
                customColumnFilter = this.customFilterData.some((customRow) => {
                    // Implement your comparison logic here
                    let match = Object.keys(customRow).every((key) => {
                        // Convert undefined or null values to empty strings
                        const dataValue = data[key] !== undefined && data[key] !== null ? data[key].toString() : '';
                        const customRowValue = customRow[key] !== undefined && customRow[key] !== null ? customRow[key].toString() : '';
                        // Compare the values after conversion
                        return dataValue === customRowValue;
                    });
                    return match;
                });
            }
            if (this.properties.isCustomDataFilter && this.customFilterData == null) {
                customColumnFilter = true;
            }
            let matchesGlobalSearch = !filters.globalSearch || this.globalSearchAppliedColumns.some(col => data[col] && data[col].toString().toLowerCase().includes(filters.globalSearch.toString().toLowerCase()));
            let matchesColumnFilters = columnFiltersChip.every((filter) => {
                if (Array.isArray(filter.value)) {
                    return filter.value.some((value) => data[filter.key].includes(value));
                }
                else {
                    return !filter.value || data[filter.key].includes(filter.value);
                }
            });
            return matchesGlobalSearch && matchesColumnFilters && customColumnFilter;
        };
    }
    /**
     * This function will return all the rows where entered value in global or column level filter is found
     *
     * @param globalSearch - Send global search query
     *
     * @param filterObj - send filter object to identify which column needs to be kept
     *
     * @param filterObject - send filter object for column level search
     *
     * @returns - returns true or false based on search query is found or not
     */
    getSearchResult(globalSearch, filterObj, filterObject) {
        for (let [index, entry] of filterObject.entries()) {
            if (index === 0) {
                filterObj = entry;
            }
            else if (globalSearch) {
                filterObj = filterObj || entry;
            }
            else {
                filterObj = filterObj && entry;
            }
        }
        this.cdr.detectChanges();
        return filterObj;
    }
    // function will be triggered when the search button is clicked
    onSearchBtnSubmit() {
        if (this.properties.onSearchBtnSubmit) {
            this.properties.onSearchBtnSubmit(this.formControl['globalSearch'].value);
        }
    }
    /**
     * onPrimaryColumnClicked
     *
     * This function is the callback function on primary column
     * this function will be triggered when primary column is clicked
     *
     * @param row - row of the selected primary column
     */
    onPrimaryColumnClicked(row) {
        if (this.properties.onPrimaryColumnClick) {
            this.properties.onPrimaryColumnClick(row);
        }
    }
    /**
     * this function will check for validation and show error message
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     *
     * @returns - returns error message if there is any error or else returns null
     */
    getErrorMessage(column, row) {
        if (column.inputProperties?.optional) {
            return null;
        }
    }
    /**
     * this function will allow only numeric values in the input field
     *
     * @param event - event of the input field
     *
     * @param column - column of the input field
     */
    allowOnlyNumbers(event, column) {
        const input = event.key;
        const isNumeric = column.inputProperties.allowDecimal ? /^[0-9.]$/.test(input) : /^[0-9]$/.test(input);
        if (!isNumeric) {
            event.preventDefault();
        }
    }
    /**
     * this function will increment the value of the input field
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     */
    increment(column, row) {
        if (column.inputProperties?.max != undefined && row[column.key] == column.inputProperties.max) {
            return;
        }
        row[column.key]++;
        this.onInputChanged({}, row);
    }
    /**
     * this function will decrement the value of the input field
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     */
    decrement(column, row) {
        row[column.key]--;
        this.onInputChanged({}, row);
    }
    /**
     * Editing the particular cell based on below param
     * @param element Element to be edited
     * @param column column name
     * @param rowIndex  row Index
     */
    startEditing(element, column, rowIndex) {
        this.inputChanged(element, column, false);
        if (rowIndex !== undefined) {
            this.rowValidation(element);
        }
        if (this.editingRowIndex !== null && this.editingRowIndex !== rowIndex) {
            // If another cell is already in editing mode, stop editing it
            const previouslyEditingRow = this.data[this.editingRowIndex];
            previouslyEditingRow.editing = false;
            this.editingColumn = null;
            this.data[this.editingRowIndex] = previouslyEditingRow;
        }
        element.editing = true;
        this.editingColumn = column.name;
        this.editingRowIndex = rowIndex;
        let columnIndex = this.properties.columns.findIndex(data => data.key === column.key);
        setTimeout(() => {
            const focusElement = document.getElementById(`${element[this.properties.uniqueKey]}${columnIndex}`);
            // You can check if the element is found before trying to focus
            if (focusElement) {
                focusElement.focus();
            }
        });
    }
    /**
     * Stop editing the particular cell based on below param
     * @param element element to be stopped editing
     */
    stopEditing(element) {
        element.editing = false;
        this.editingColumn = null;
    }
    /**
     * Stop editing the particular cell based on below param
     * @param element element to be stopped editing
     */
    stopEditingSelect(element, column) {
        element.editing = false;
        this.inputChanged(element, column, false);
        this.editingColumn = null;
    }
    shouldHighlightCell(row, column) {
        if (column.validation?.validationFunction !== undefined) {
            let getValidation = column?.validation.validationFunction(row[column.key]);
            const errorItem = column?.validation.errorList.find((item) => item.key === getValidation);
            return errorItem ? errorItem.message : '';
        }
        else {
            return '';
        }
    }
    rowValidation(row) {
        if (this.properties.rowValidation !== undefined) {
            let getValidation = this.properties.rowValidation.validationFunction(row);
            const errorItem = this.properties.rowValidation.errorList.find((item) => item.key === getValidation);
            return errorItem ? errorItem.message : '';
        }
        else {
            return '';
        }
    }
    rowChanged(row) {
        let wholeObject = this.modifiedRow.find((data) => data[this.properties.uniqueKey] === row.key);
        if (wholeObject === null) {
            let obj = wholeObject;
            obj['editedRow'] = true;
            wholeObject = obj;
            this.modifiedRow.push();
        }
    }
    inputChanged(row, column, autoSuggest) {
        this.rowChanged(row);
        let existObj = this.isObjExist(row[this.properties.uniqueKey]);
        if (existObj !== null) {
            if (!this.hasKey(existObj, column.key)) {
                let obj = existObj;
                obj[column.key] = true;
                existObj = obj;
            }
        }
        else {
            let obj = {};
            obj[this.properties.uniqueKey] = row[this.properties.uniqueKey];
            obj[column.key] = true;
            this.editedRows.push(obj);
        }
        this.shouldHighlightCell(row, column);
        if (!autoSuggest) {
            this.stopEditing(row);
        }
        else {
            this.stopEditingCheck(row, column.inputProperties?.availableText, row[column.key]);
        }
    }
    isEdited(column, row) {
        let uniqueValue = row[this.properties.uniqueKey];
        let index = this.editedRows.findIndex((obj) => obj[this.properties.uniqueKey] == uniqueValue);
        if (index !== -1) {
            return this.editedRows[index][column.key];
        }
        else {
            return false;
        }
    }
    isRowEdited(row) {
        let index = this.editedRows.findIndex((obj) => obj[this.properties.uniqueKey] == row[this.properties.uniqueKey]);
        if (index !== -1) {
            return true;
        }
        else {
            return false;
        }
    }
    isObjExist(value) {
        const wholeObject = this.editedRows.find((data) => data[this.properties.uniqueKey] === value);
        return wholeObject || null;
    }
    hasKey(obj, key) {
        return obj.hasOwnProperty(key);
    }
    /**
     * Auto suggestion in input field stop editing on blur
     * @param element element which cell is edited
     * @param availableOptions array of strings which was passed as autosuggestion
     * @param value value what user enters in input field
     */
    stopEditingCheck(element, availableOptions, value) {
        if (value !== undefined) {
            let data = this.getFilteredText(availableOptions, value);
            if (data.length === 0 && data !== undefined) {
                this.stopEditing(element);
            }
        }
        this.stopEditing(element);
    }
    /**
     * Moving to next cell in the same row ad make it editable
     * @param event tab event
     * @param columnKey column name
     * @param rowIndex index of the editing row
     */
    tabToNextCell(event, columnKey, rowIndex) {
        let columnIndex = -1;
        let nextColumnIndex = -1;
        if (this.editingColumn !== null) {
            columnIndex = this.properties.columns.findIndex(column => column.name === this.editingColumn);
            nextColumnIndex = (columnIndex + 1) % this.properties.columns.length;
        }
        else {
            columnIndex = this.properties.columns.findIndex(column => column.key === columnKey);
            nextColumnIndex = (columnIndex + 1) % this.properties.columns.length;
        }
        if (this.editingRowIndex !== null) {
            let index = this.currentPage * (this.properties.pageSize ? this.properties.pageSize : 5);
            // Start editing the next cell in the same row
            if (this.formControl['globalSearch'].value !== "") {
                this.stopEditing(this.dataSource.filteredData[index]);
                this.startEditing(this.dataSource.filteredData[index], this.properties.columns[nextColumnIndex], rowIndex);
            }
            else {
                this.stopEditing(this.data[index]);
                this.startEditing(this.data[index], this.properties.columns[nextColumnIndex], rowIndex);
            }
        }
        // Prevent the default Tab behavior (e.g., moving to the next focusable element)
        event.preventDefault();
    }
    /**
     * Function to make first field as editable on clicking on Tab
     * @param event tab event
     * @param columnKey column name
     * @param rowIndex index of the editing row
     */
    tabChangeEditableField(event, columnKey, rowIndex) {
        const columnIndex = this.properties.columns.findIndex(column => column.key === columnKey);
        if (this.editingRowIndex !== null) {
            let index = this.editingRowIndex + (this.currentPage * (this.properties.pageSize ? this.properties.pageSize : 5));
            if (this.formControl['globalSearch'].value !== "") {
                this.startEditing(this.dataSource.filteredData[index], this.properties.columns[columnIndex], rowIndex);
            }
            else {
                this.startEditing(this.data[index], this.properties.columns[columnIndex], rowIndex);
            }
        }
        // Prevent the default Tab behavior (e.g., moving to the next focusable element)
        event.preventDefault();
    }
    /**
     * Filter data from the autosuggestion string
     * @param availableOptions Autosuggestion options array of string
     * @param value value entered in the input field
     * @returns array of filtered string based on the value entered
     */
    getFilteredText(availableOptions, value) {
        if (value !== undefined && value !== null) {
            const filterValue = value.toLowerCase();
            return availableOptions.filter((text) => text !== null && text !== undefined ? text.toLowerCase().includes(filterValue) : '');
        }
    }
    /**
     * Function call on clicking tab
     * @param event keyboard event
     * @param columnKey column key which is unique value
     * @param rowIndex row index where the user edits
     */
    handleKeyDown(event, columnKey, rowIndex) {
        if (event.key === 'Tab') {
            if (this.editableFields.length > 0) {
                const index = this.editableFields.indexOf(columnKey);
                if (index !== -1 && index < this.editableFields.length - 1) {
                    const nextString = this.editableFields[index + 1];
                    // Perform some action with the nextString
                    this.getElementRef(event, nextString, rowIndex);
                }
                else {
                    for (const column of this.properties.columns) {
                        if (column.hasEditableRights) {
                            let columnIndex1 = this.properties.columns.findIndex(data => data.key === column.key);
                            let columnIndex2 = this.properties.columns.findIndex(data => data.key === columnKey);
                            if (columnIndex1 > columnIndex2) {
                                this.getElementRef(event, column.key, rowIndex);
                                break;
                            }
                        }
                    }
                }
                event.preventDefault();
            }
        }
    }
    /**
     *
     * @param event keyboard event
     * @param columnKey column key unique parameter
     * @param rowIndex row index where the user edits
     */
    getElementRef(event, columnKey, rowIndex) {
        this.editingRowIndex = rowIndex;
        this.tabChangeEditableField(event, columnKey, rowIndex);
    }
    // This function checks whether the icon should be disabled or not.
    isDisabled(row, icons) {
        if (icons.disableOnCondition) {
            return icons.disableOnCondition(row);
        }
        return false;
    }
    // This function gets triggered when there is a change in the filter dropdown
    onFilterChange(event, index) {
        this.tableFilter[index].selectedValue = event.value;
    }
    /**
      * onCriteriaColumnClick
      *
      * This function is the callback function on criteria column
      * this function will be triggered when criteria column is clicked
      *
      * @param row - row of the selected criteria column
      * @param selectedValue - value of the selected criteria column
      */
    onCriteriaColumnClicked(row, selectedValue) {
        if (this.properties.onCriteriaColumnClick) {
            this.properties.onCriteriaColumnClick(row, selectedValue);
        }
    }
    getColumnStyle(column) {
        if (column.columnType === 'checkbox') {
            return '';
        }
        else {
            return column.columnStyle?.style || 'min-width: 120px';
        }
    }
    onActionIconClicked(row, actionIcon, index) {
        if (actionIcon.onIconClicked) {
            let globalIndex = index + (this.paginator.pageIndex * this.paginator.pageSize);
            actionIcon.onIconClicked(row, globalIndex);
        }
    }
    ngOnDestroy() {
        this._clearSelectionSubscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridComponent, deps: [{ token: i1$2.FormBuilder }, { token: i0.ChangeDetectorRef }, { token: i1$4.MatDialog }, { token: ClDataGridService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDataGridComponent, isStandalone: true, selector: "cl-data-grid", inputs: { matSortActive: "matSortActive", totalRecords: "totalRecords", showLoading: "showLoading", matSortDirection: "matSortDirection", data: "data", properties: "properties", customData: "customData" }, providers: [
            {
                multi: true,
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClDataGridComponent),
            }
        ], viewQueries: [{ propertyName: "sort", first: true, predicate: MatSort, descendants: true }, { propertyName: "table", first: true, predicate: ["table"], descendants: true }, { propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }, { propertyName: "tableContainer", first: true, predicate: ["tableContainer"], descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div class=\"flex flex-col w-full gap-4 data-grid-container\">\n  <!-- Filter and Column Customization -->\n  @if (properties.showFilter) {\n    <div class=\"flex flex-row gap-4 w-full items-center\">\n      <!-- Global filter -->\n      <mat-form-field appearance=\"outline\" [formGroup]=\"formGroup\" subscriptSizing=\"dynamic\"\n        class=\"w-full cl-grid-search-input dark:bg-primary-800\">\n\n        <input #input matInput autocomplete=\"off\" [placeholder]=\"properties.searchPlaceholder!\"\n          [formControl]=\"formControl['globalSearch']\" />\n\n        <mat-icon matPrefix class=\"cursor-pointer icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\">\n        </mat-icon>\n\n      </mat-form-field>\n      <!-- Global filter -->\n\n      <!-- Column filter -->\n      @if (properties.showFilterDropdown) {\n        @for (filter of tableFilter; track filter; let i = $index) {\n          <mat-form-field appearance=\"outline\" [formGroup]=\"formGroup\" subscriptSizing=\"dynamic\"\n            class=\"cl-grid-filter-dropdown {{filter?.widthFilterDropdown}}\"\n            [matTooltip]=\"!properties.isTooltipForFilterDropdown ? '' :  filter.label + ': ' + (filter.selectedValue?.text || '') \">\n\n            <mat-select [value]=\"filter.selectedValue\" (selectionChange)=\"onFilterChange($event, i)\"\n              [formControl]=\"formControl[filter.key]\" [hideSingleSelectionIndicator]=\"true\">\n\n              <mat-select-trigger class=\"text-base text-neutral-900\">\n                <span class=\"text-base text-neutral-700\">{{filter.label }}: </span>\n                <span class=\"font-bold\">{{filter.selectedValue}}</span>\n              </mat-select-trigger>\n\n              @for (option of filter.options; track option) {\n                <mat-option class=\"px-2\" [value]=\"option.value\">{{option.text}}</mat-option>\n              }\n            </mat-select>\n          </mat-form-field>\n        }\n      }\n      <!-- Column filter -->\n\n      <!-- Multi Filter Dialog -->\n      @if (properties.showMultiFilter) {\n        <!-- Dialog Filter -->\n        <div (click)=\"openDialogMultiFilter()\"\n          class=\"p-[0.7rem] flex border rounded-md justify-center cursor-pointer border-primary-600 dark:bg-primary-50\">\n\n          <mat-icon [svgIcon]=\"'fss_icons:filter-funnel'\" class=\"icon-size-4\">\n          </mat-icon>\n        </div>\n        <!-- Dialog Filter -->\n      }\n      <!-- Multi Filter Dialog -->\n\n      <cl-button [formGroup]=\"formGroup\" [properties]=\"searchButtonProperties\">\n      </cl-button>\n\n      <div class=\"flex gap-4 items-center pl-2\" [ngClass]=\"{'border-l': (properties.columnCustomization || properties.customButtons?.length), ' border-l-neutral-500': (properties.columnCustomization || properties.customButtons?.length)}\">\n        <!-- column customization -->\n        <!-- column customization icon -->\n         @if (properties.columnCustomization){\n          <div #matMenuTrigger #t=\"matMenuTrigger\" [matMenuTriggerFor]=\"menu\" [class.active-column]=\"t.menuOpen\"\n            class=\"p-[0.7rem] flex ml-4 border rounded-md justify-center cursor-pointer border-primary-600 dark:bg-primary-50\">\n\n            <mat-icon [svgIcon]=\"'fss_icons:columns'\" class=\"icon-size-4\">\n            </mat-icon>\n          </div>\n        }\n        <!-- column customization icon -->\n\n        <!-- column customization menu -->\n        <mat-menu #menu=\"matMenu\" class=\"w-80 lg:max-h-128 md:max-h-60\">\n\n          @for (column of properties.columns; track column; let i = $index) {\n            @if (!column.pinned && column.columnType != 'actions' && !column.hideFromCustomization) {\n              <mat-checkbox color=\"primary\" class=\"pl-2 pr-8 w-full\" [(ngModel)]=\"column.visible\"\n                (click)=\"$event.stopPropagation()\">\n                {{ column.name }}\n              </mat-checkbox>\n\n              @if (i < properties.columns!.length - 1) {\n                <mat-divider></mat-divider>\n              }\n            }\n          }\n        </mat-menu>\n        <!-- column customization menu -->\n        @if (properties.customButtons?.length) {\n          @for (buttonProperties of properties.customButtons; track buttonProperties; let buttonIndex = $index) {\n            <cl-button [properties]=\"buttonProperties\"></cl-button>\n          }\n        }\n        <!-- column customization -->\n      </div>\n      </div>\n  }\n  <!-- Filter and Column Customization -->\n\n  <!-- dynamic table column and row -->\n  <div class=\"max-w-full overflow-auto table-container\" #tableContainer (scroll)=\"onScroll($event)\">\n\n    <table #table matSort mat-table matSortDisableClear [dataSource]=\"dataSource\"\n    [matSortActive]=\"matSortActive\" [matSortDirection]=\"matSortDirection\"\n    cdkDropList\n    [cdkDropListData]=\"properties.rowDragEnable? dataSource: ''\"\n    [cdkDropListOrientation]=\"properties.rowDragEnable? 'vertical': 'horizontal'\"\n    (cdkDropListDropped)=\"properties.rowDragEnable? dropRow($event): dropCol($event)\">\n    <!-- <table #table matSort mat-table cdkDropList matSortDisableClear [dataSource]=\"dataSource\"\n    [matSortActive]=\"matSortActive\" [matSortDirection]=\"matSortDirection\" cdkDropListOrientation=\"horizontal\"\n    (cdkDropListDropped)=\"dropCol($event)\"> -->\n\n      <!-- data and header level rows -->\n      @for (column of properties.columns; track column; let columnIndex = $index) {\n        <ng-container [sticky]=\"column.pinned!\" [matColumnDef]=\"column.key\"\n          [stickyEnd]=\"column.columnType === 'actions' && column.pinned!\">\n          <!-- header -->\n          @if(column.columnType === 'reorderIndex'){\n            <th mat-header-cell *matHeaderCellDef\n            [style]=\"column.columnStyle?.style\"\n            class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n            <mat-label>{{ column.name }}</mat-label>\n            </th>\n          } @else if (column.columnType ==='checkbox') {\n          <!-- if the All rows has to be selected then header with a check all box  -->\n            @if (column.properties?.rowSelection) {\n              <th mat-header-cell *matHeaderCellDef>\n                <mat-checkbox class=\"table-checkbox\" (change)=\"$event ? masterToggle() : null\"\n                  [checked]=\"selection.hasValue() && isAllSelected()\"\n                  [indeterminate]=\"selection.hasValue() && !isAllSelected()\"\n                  style=\"min-width: '{{column.columnStyle?.minWidth}}';\">\n                </mat-checkbox>\n              </th>\n            }\n\n            <!-- if the cell is only a boolean value then header should be passed in column name property -->\n            @if (!column.properties?.rowSelection) {\n              <th cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\" mat-header-cell *matHeaderCellDef\n                class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\"\n                [style]=\"column.columnStyle?.style || (column.columnType === 'checkbox' ? '' : 'min-width: 120px')\">\n\n                <mat-label class=\"{{column.columnStyle?.alignment || 'text-start'}}\">\n                  {{ column.name }}\n                </mat-label>\n              </th>\n            }\n          } @else if (column.canSort) {\n            <th mat-sort-header cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\"\n              mat-header-cell *matHeaderCellDef\n              [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n              <mat-label>{{ column.name }}</mat-label>\n            </th>\n          } @else {\n            <th cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\" mat-header-cell *matHeaderCellDef\n              [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n              <mat-label>{{ column.name }}</mat-label>\n            </th>\n          }\n          <!-- header -->\n\n          <!-- data row based on style -->\n          @if(column.columnType === 'reorderIndex'){\n            <td mat-cell *matCellDef=\"let row; let i=index\" [style]=\"column.columnStyle?.style\"\n            class=\"{{column.columnStyle?.dataCellClasses}}\">\n            <div class=\"flex gap-2 flex-row\">\n               <mat-icon class=\"dragCursor\" (mousedown)=\"dragDisabled = false;\">reorder</mat-icon>\n            </div>\n            </td>\n          } @else if (column.columnType === 'checkbox') {\n            <td mat-cell *matCellDef=\"let row; let i=index\"\n              class=\"{{column.columnStyle?.dataCellClasses}}\"\n              (dblclick)=\"startEditing(row, column, i)\">\n\n              @if (!column.properties?.rowSelection) {\n                <mat-checkbox class=\"table-checkbox\" (click)=\"$event.stopPropagation()\" [(ngModel)]=\"row[column.key]\"\n                  [disabled]=\"column.properties?.disabled!\" (change)=\"onRowValueChangeCheckbox($event, row,column.key, i)\">\n                </mat-checkbox>\n              }\n\n              @if (column.properties?.rowSelection) {\n                <mat-checkbox class=\"table-checkbox\" (click)=\"$event.stopPropagation()\" [checked]=\"selection.isSelected(row)\"\n                  (change)=\"$event ? selection.toggle(row) : null; onCheckboxSelection()\">\n                </mat-checkbox>\n              }\n            </td>\n          } @else if (column.columnType === 'actions') {\n            <td mat-cell *matCellDef=\"let row; let i=index\" [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.dataCellClasses}}\">\n              <div class=\"flex gap-2 flex-row\">\n                @for (actionIcon of column.actionIcons; track $index) {\n                  <mat-icon class=\"{{column.hideActionIconOnKeyStatus? (row[column.hideActionIconOnKeyStatus]? 'hidden': actionIcon.style?.cssClasses) : actionIcon.style?.cssClasses}}\" [svgIcon]=\"actionIcon.iconName!\"\n                    (click)=\"onActionIconClicked(row, actionIcon, i); selection.setSelection(row)\">\n                  </mat-icon>\n                }\n              </div>\n            </td>\n          } @else {\n            @if (!properties.editField || column.displayAlways) {\n              <td mat-cell *matCellDef=\"let row; let i=index\"\n                [ngStyle]=\"column?.componentProperty?.label === '' ? {'text-align': 'center'} : {}\"\n                [style]=\"column.columnStyle?.style\" class=\"{{column.columnStyle?.dataCellClasses}} truncate\"\n                matTooltip=\"{{column.component ? '' : row[column.key]}}\">\n\n                @if (column.component) {\n                  <cl-data-grid-injector [component]=\"column.component\" [properties]=\"column?.componentProperty\"\n                    [value]=\"row[column.key]\" [isComponentDragged]=\"properties.isComponentDragged!\" [rowDetail]=\"row ?? ''\"\n                    (valueChange)=\"onRowValueChange($event, row,column.key, i)\" >\n                  </cl-data-grid-injector>\n                } @else {\n                  <span>{{ row[column.key] }}</span>\n                }\n              </td>\n            } @else {\n              <td mat-cell *matCellDef=\"let row; let i = index\" (keydown.enter)=\"startEditing(row, column, i)\"\n                (dblclick)=\"startEditing(row, column, i)\" (keydown)=\"handleKeyDown($event, column.key,i)\"\n                [ngClass]=\"{'highlight-cell': shouldHighlightCell(row,column) !== '' && isEdited(column, row)}\"\n                [style]=\"column.columnStyle?.style\"\n                class=\"{{column.columnStyle?.dataCellClasses}} {{properties.borderColor}}\n                {{column.columnStyle?.alignment || 'text-start'}} custom-cell\">\n\n                @if (row.editing && editingColumn === column.name && editingColumn !== null && column?.hasEditableRights) {\n                  @if (column.component) {\n                    <cl-data-grid-injector [component]=\"column.component\" [value]=\"row[column.key] ?? ''\" [rowDetail]=\"row ?? ''\" [isComponentDragged]=\"properties.isComponentDragged!\" [properties]=\"column?.componentProperty\"\n                      (valueChange)=\"onRowValueChange($event, row,column.key, i)\">\n                    </cl-data-grid-injector>\n                  } @else {\n                    <span>{{ row[column.key] }}</span>\n                  }\n                } @else {\n                  <div style=\"display: inline-grid\" class=\"w-full\">\n                    <span [matTooltip]=\"row[column.key]\" class=\"w-full truncate\"\n                      (keydown)=\"handleKeyDown($event, column.key, i)\" tabindex=\"0\">\n                      {{ row[column.key] }}\n                    </span>\n\n                    @if (shouldHighlightCell(row,column) !== '' && isEdited(column, row)) {\n                      <mat-hint class=\"truncate {{column.columnStyle?.maxWidth}} hint-style text-sm\"\n                        matTooltip=\"{{shouldHighlightCell(row,column) !== '' && isEdited(column, row) ? shouldHighlightCell(row,column) : ''}}\">\n                        {{shouldHighlightCell(row,column) !== '' && isEdited(column, row) ? shouldHighlightCell(row,column) : ''}}\n                      </mat-hint>\n                    }\n                  </div>\n                }\n              </td>\n            }\n          }\n          <!-- data row based on style -->\n        </ng-container>\n        }\n      <!-- } -->\n      <!-- data and header level rows -->\n\n      <!-- display column header -->\n      <tr mat-header-row *matHeaderRowDef=\"getDisplayColumns(); sticky:true\"></tr>\n      <!-- display column header -->\n\n      <!-- filter column header -->\n      <!-- @if (properties.showColumnFilter!) {\n        <tr mat-header-row *matHeaderRowDef=\"columnFilters; sticky:true\"></tr>\n      } -->\n      <!-- filter column header -->\n\n      <!-- data column row       cdkDrag cdkDragLockAxis=\"y\"  -->\n      @if(properties.rowDragEnable){\n        <tr cdkDrag [cdkDragData]=row (cdkDragStarted)=\"dragStarted(row)\"\n        mat-row *matRowDef=\"let row; columns: getDisplayColumns()\"\n        class=\"border-primary-900\"\n        [ngClass]=\"{'highlightTr': rowValidation(row) !== '' && isRowEdited(row),\n        'bg-primary-50': selection.isSelected(row)}\"\n        matTooltip=\"{{rowValidation(row) !== '' && isRowEdited(row) ? rowValidation(row) : ''}}\">\n        </tr>\n      } @else {\n        <tr\n        mat-row *matRowDef=\"let row; columns: getDisplayColumns()\"\n        class=\"border-primary-900\"\n        [ngClass]=\"{'highlightTr': rowValidation(row) !== '' && isRowEdited(row),\n        'bg-primary-50': selection.isSelected(row)}\"\n        matTooltip=\"{{rowValidation(row) !== '' && isRowEdited(row) ? rowValidation(row) : ''}}\">\n        </tr>\n      }\n\n      <!-- data column row -->\n    </table>\n  </div>\n  <!-- dynamic table column and row -->\n\n  @if (showLoading) {\n    <mat-progress-bar mode=\"indeterminate\" class=\"w-full rounded-full\">\n    </mat-progress-bar>\n  }\n\n  @if (properties.noDataLayout && dataSource.filteredData.length <= 0) {\n    <div class=\"flex w-full items-center justify-center flex-{{properties.noDataLayout.layoutType || 'col'}} {{properties.noDataLayout.gap}} py-12\">\n      @if (properties.noDataLayout.iconProperties) {\n        <cl-icon [properties]=\"properties.noDataLayout.iconProperties!\">\n        </cl-icon>\n      }\n\n      <cl-label [properties]=\"properties.noDataLayout.labelProperties\"></cl-label>\n    </div>\n  }\n\n  <!-- paginator -->\n  <mat-paginator #paginator style=\"display: none;\" [pageSize]=\"properties.pageSize!\"\n    [pageSizeOptions]=\"properties.pageSizeOptions!\"\n    [length]=\"properties.enableServerSidePagination ? totalRecords : dataSource.filteredData.length\">\n  </mat-paginator>\n\n  @if (properties.showPaginator!) {\n    <cl-paginator [currentPage]=\"currentPage\" [showLoading]=\"showLoading\" (pageIndex)=\"goToPageNo($event)\"\n      [pageSize]=\"properties.pageSize!\" (onPageSizeChange)=\"onPageSizeChange($event)\"\n      [pageSizeOptions]=\"properties.pageSizeOptions!\"\n      [noOfRecords]=\"properties.enableServerSidePagination ? totalRecords! : dataSource.filteredData.length\"\n      [hideGoToPage]=\"properties.hideGoToPage\"\n      [hideFirstLastPageBtn]=\"properties.hideFirstLastPageBtn\">\n    </cl-paginator>\n  }\n  <!-- paginator -->\n</div>\n", styles: [".mat-mdc-table thead,.mat-mdc-header-row,.mat-mdc-table .mat-mdc-header-cell,th{border-bottom-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgb(226 232 240 / var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity));padding:.75rem;font-size:.875rem;font-weight:700;line-height:1.25rem;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity))}.mat-mdc-table thead:is(.dark *),.mat-mdc-header-row:is(.dark *),.mat-mdc-table .mat-mdc-header-cell:is(.dark *),th:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}td:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity))}.mat-sort-header-content{display:flex;align-items:center;text-align:start}.mdc-data-table__cell,.mdc-data-table__header-cell{padding:0}.mat-mdc-table tbody,.mat-mdc-table .mat-mdc-cell{border-bottom-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgb(226 232 240 / var(--tw-border-opacity));padding:.75rem;font-size:.875rem;font-weight:400;line-height:1.5;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-mdc-table tbody:is(.dark *),.mat-mdc-table .mat-mdc-cell:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.green-color{--tw-text-opacity: 1;color:rgb(22 163 74 / var(--tw-text-opacity))}.mat-mdc-table-sticky-border-elem-right{filter:drop-shadow(0px 0px 8px rgba(0,0,0,.16))}.scroll-right{filter:drop-shadow(2px 0px 4px rgba(0,0,0,.16))}.progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}.compact-field ::ng-deep .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{height:2.5rem;min-height:2.5rem;padding:0;padding-top:.5rem}.compact-field ::ng-deep .mdc-text-field{padding-left:.5rem;padding-right:.5rem;text-align:center}.page-field input[type=number]{-moz-appearance:textfield!important}.page-field ::ng-deep .mat-form-field-infix{border-width:0px}.page-field ::ng-deep .mat-form-field-appearance-outline .mat-select-arrow-wrapper{transform:none;padding:0}::ng-deep .mat-input-element:is(.dark *)::placeholder{--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}::ng-deep .cl-grid-search-input .mat-mdc-form-field-infix{min-height:40px!important}::ng-deep .h-40-field .mat-mdc-form-field-infix{height:40px!important;min-height:40px!important}::ng-deep .cl-grid-search-input{height:40px!important;border-radius:.375rem}::ng-deep .cl-grid-search-input .mat-mdc-form-field-flex{height:40px!important}::ng-deep .cl-grid-search-input .mat-mdc-form-field-infix{padding-top:8px!important;padding-bottom:8px!important}::ng-deep .cl-grid-filter-dropdown{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-text-field-wrapper{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-form-field-flex{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-form-field-infix{padding-top:8px!important;padding-bottom:8px!important}::ng-deep .cl-grid-col-select{width:120px;border-style:none}::ng-deep .cl-grid-col-select .mat-mdc-form-field-infix{display:flex!important}::ng-deep .cl-grid-col-select .mdc-line-ripple{display:none!important}::ng-deep .highlight-cell{border:2px solid #dc2626!important}.highlightTr td:first-child{border-left:2px solid #dc2626!important}.highlightTr td:last-child{border-right:2px solid #dc2626!important}.highlightTr td{border-top:2px solid #dc2626!important;border-bottom:2px solid #dc2626!important}.hint-style{color:#dc2626!important;width:80%!important}::ng-deep .column-filter .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{padding-top:5px!important}::ng-deep .column-filter .mat-mdc-text-field-wrapper{padding-left:4px!important;padding-right:4px!important}.grid-action-dropdown:not(:last-child){border-bottom-width:1px;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity));border-bottom-style:solid}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i4$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatSortModule }, { kind: "directive", type: i6$1.MatSort, selector: "[matSort]", inputs: ["matSortActive", "matSortStart", "matSortDirection", "matSortDisableClear", "matSortDisabled"], outputs: ["matSortChange"], exportAs: ["matSort"] }, { kind: "component", type: i6$1.MatSortHeader, selector: "[mat-sort-header]", inputs: ["mat-sort-header", "arrowPosition", "start", "disabled", "sortActionDescription", "disableClear"], exportAs: ["matSortHeader"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$2.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i4$2.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3$1.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i9.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i9.MatLabel, selector: "mat-label" }, { kind: "directive", type: i9.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i9.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: CdkTableModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i10.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i10.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i10.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i10.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i10.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i10.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i10.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i10.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i10.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i10.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i11.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i11.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i13.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i14.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i15.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatPaginatorModule }, { kind: "component", type: i16.MatPaginator, selector: "mat-paginator", inputs: ["color", "pageIndex", "length", "pageSize", "pageSizeOptions", "hidePageSize", "showFirstLastButtons", "selectConfig", "disabled"], outputs: ["page"], exportAs: ["matPaginator"] }, { kind: "ngmodule", type: MatProgressBarModule }, { kind: "component", type: i17.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClPaginatorComponent, selector: "cl-paginator", inputs: ["pageSize", "currentPage", "noOfRecords", "showLoading", "hideGoToPage", "hideFirstLastPageBtn", "pageSizeOptions"], outputs: ["pageIndex", "onPageSizeChange"] }, { kind: "component", type: ClDataGridInjectorComponent, selector: "cl-data-grid-injector", inputs: ["value", "rowDetail", "component", "properties", "isComponentDragged"], outputs: ["valueChange"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-data-grid', providers: [
                        {
                            multi: true,
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClDataGridComponent),
                        }
                    ], imports: [
                        NgClass,
                        NgStyle,
                        FormsModule,
                        ReactiveFormsModule,
                        MatMenuModule,
                        MatIconModule,
                        MatSortModule,
                        DragDropModule,
                        MatInputModule,
                        CdkTableModule,
                        MatTableModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatDividerModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        MatPaginatorModule,
                        MatProgressBarModule,
                        MatAutocompleteModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClButtonComponent,
                        ClPaginatorComponent,
                        ClDataGridInjectorComponent
                    ], template: "<div class=\"flex flex-col w-full gap-4 data-grid-container\">\n  <!-- Filter and Column Customization -->\n  @if (properties.showFilter) {\n    <div class=\"flex flex-row gap-4 w-full items-center\">\n      <!-- Global filter -->\n      <mat-form-field appearance=\"outline\" [formGroup]=\"formGroup\" subscriptSizing=\"dynamic\"\n        class=\"w-full cl-grid-search-input dark:bg-primary-800\">\n\n        <input #input matInput autocomplete=\"off\" [placeholder]=\"properties.searchPlaceholder!\"\n          [formControl]=\"formControl['globalSearch']\" />\n\n        <mat-icon matPrefix class=\"cursor-pointer icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\">\n        </mat-icon>\n\n      </mat-form-field>\n      <!-- Global filter -->\n\n      <!-- Column filter -->\n      @if (properties.showFilterDropdown) {\n        @for (filter of tableFilter; track filter; let i = $index) {\n          <mat-form-field appearance=\"outline\" [formGroup]=\"formGroup\" subscriptSizing=\"dynamic\"\n            class=\"cl-grid-filter-dropdown {{filter?.widthFilterDropdown}}\"\n            [matTooltip]=\"!properties.isTooltipForFilterDropdown ? '' :  filter.label + ': ' + (filter.selectedValue?.text || '') \">\n\n            <mat-select [value]=\"filter.selectedValue\" (selectionChange)=\"onFilterChange($event, i)\"\n              [formControl]=\"formControl[filter.key]\" [hideSingleSelectionIndicator]=\"true\">\n\n              <mat-select-trigger class=\"text-base text-neutral-900\">\n                <span class=\"text-base text-neutral-700\">{{filter.label }}: </span>\n                <span class=\"font-bold\">{{filter.selectedValue}}</span>\n              </mat-select-trigger>\n\n              @for (option of filter.options; track option) {\n                <mat-option class=\"px-2\" [value]=\"option.value\">{{option.text}}</mat-option>\n              }\n            </mat-select>\n          </mat-form-field>\n        }\n      }\n      <!-- Column filter -->\n\n      <!-- Multi Filter Dialog -->\n      @if (properties.showMultiFilter) {\n        <!-- Dialog Filter -->\n        <div (click)=\"openDialogMultiFilter()\"\n          class=\"p-[0.7rem] flex border rounded-md justify-center cursor-pointer border-primary-600 dark:bg-primary-50\">\n\n          <mat-icon [svgIcon]=\"'fss_icons:filter-funnel'\" class=\"icon-size-4\">\n          </mat-icon>\n        </div>\n        <!-- Dialog Filter -->\n      }\n      <!-- Multi Filter Dialog -->\n\n      <cl-button [formGroup]=\"formGroup\" [properties]=\"searchButtonProperties\">\n      </cl-button>\n\n      <div class=\"flex gap-4 items-center pl-2\" [ngClass]=\"{'border-l': (properties.columnCustomization || properties.customButtons?.length), ' border-l-neutral-500': (properties.columnCustomization || properties.customButtons?.length)}\">\n        <!-- column customization -->\n        <!-- column customization icon -->\n         @if (properties.columnCustomization){\n          <div #matMenuTrigger #t=\"matMenuTrigger\" [matMenuTriggerFor]=\"menu\" [class.active-column]=\"t.menuOpen\"\n            class=\"p-[0.7rem] flex ml-4 border rounded-md justify-center cursor-pointer border-primary-600 dark:bg-primary-50\">\n\n            <mat-icon [svgIcon]=\"'fss_icons:columns'\" class=\"icon-size-4\">\n            </mat-icon>\n          </div>\n        }\n        <!-- column customization icon -->\n\n        <!-- column customization menu -->\n        <mat-menu #menu=\"matMenu\" class=\"w-80 lg:max-h-128 md:max-h-60\">\n\n          @for (column of properties.columns; track column; let i = $index) {\n            @if (!column.pinned && column.columnType != 'actions' && !column.hideFromCustomization) {\n              <mat-checkbox color=\"primary\" class=\"pl-2 pr-8 w-full\" [(ngModel)]=\"column.visible\"\n                (click)=\"$event.stopPropagation()\">\n                {{ column.name }}\n              </mat-checkbox>\n\n              @if (i < properties.columns!.length - 1) {\n                <mat-divider></mat-divider>\n              }\n            }\n          }\n        </mat-menu>\n        <!-- column customization menu -->\n        @if (properties.customButtons?.length) {\n          @for (buttonProperties of properties.customButtons; track buttonProperties; let buttonIndex = $index) {\n            <cl-button [properties]=\"buttonProperties\"></cl-button>\n          }\n        }\n        <!-- column customization -->\n      </div>\n      </div>\n  }\n  <!-- Filter and Column Customization -->\n\n  <!-- dynamic table column and row -->\n  <div class=\"max-w-full overflow-auto table-container\" #tableContainer (scroll)=\"onScroll($event)\">\n\n    <table #table matSort mat-table matSortDisableClear [dataSource]=\"dataSource\"\n    [matSortActive]=\"matSortActive\" [matSortDirection]=\"matSortDirection\"\n    cdkDropList\n    [cdkDropListData]=\"properties.rowDragEnable? dataSource: ''\"\n    [cdkDropListOrientation]=\"properties.rowDragEnable? 'vertical': 'horizontal'\"\n    (cdkDropListDropped)=\"properties.rowDragEnable? dropRow($event): dropCol($event)\">\n    <!-- <table #table matSort mat-table cdkDropList matSortDisableClear [dataSource]=\"dataSource\"\n    [matSortActive]=\"matSortActive\" [matSortDirection]=\"matSortDirection\" cdkDropListOrientation=\"horizontal\"\n    (cdkDropListDropped)=\"dropCol($event)\"> -->\n\n      <!-- data and header level rows -->\n      @for (column of properties.columns; track column; let columnIndex = $index) {\n        <ng-container [sticky]=\"column.pinned!\" [matColumnDef]=\"column.key\"\n          [stickyEnd]=\"column.columnType === 'actions' && column.pinned!\">\n          <!-- header -->\n          @if(column.columnType === 'reorderIndex'){\n            <th mat-header-cell *matHeaderCellDef\n            [style]=\"column.columnStyle?.style\"\n            class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n            <mat-label>{{ column.name }}</mat-label>\n            </th>\n          } @else if (column.columnType ==='checkbox') {\n          <!-- if the All rows has to be selected then header with a check all box  -->\n            @if (column.properties?.rowSelection) {\n              <th mat-header-cell *matHeaderCellDef>\n                <mat-checkbox class=\"table-checkbox\" (change)=\"$event ? masterToggle() : null\"\n                  [checked]=\"selection.hasValue() && isAllSelected()\"\n                  [indeterminate]=\"selection.hasValue() && !isAllSelected()\"\n                  style=\"min-width: '{{column.columnStyle?.minWidth}}';\">\n                </mat-checkbox>\n              </th>\n            }\n\n            <!-- if the cell is only a boolean value then header should be passed in column name property -->\n            @if (!column.properties?.rowSelection) {\n              <th cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\" mat-header-cell *matHeaderCellDef\n                class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\"\n                [style]=\"column.columnStyle?.style || (column.columnType === 'checkbox' ? '' : 'min-width: 120px')\">\n\n                <mat-label class=\"{{column.columnStyle?.alignment || 'text-start'}}\">\n                  {{ column.name }}\n                </mat-label>\n              </th>\n            }\n          } @else if (column.canSort) {\n            <th mat-sort-header cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\"\n              mat-header-cell *matHeaderCellDef\n              [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n              <mat-label>{{ column.name }}</mat-label>\n            </th>\n          } @else {\n            <th cdkDrag [cdkDragDisabled]=\"column?.disableDrag || properties.rowDragEnable\" mat-header-cell *matHeaderCellDef\n              [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.headerCellClasses}} truncate\" [matTooltip]=\"column.name\">\n              <mat-label>{{ column.name }}</mat-label>\n            </th>\n          }\n          <!-- header -->\n\n          <!-- data row based on style -->\n          @if(column.columnType === 'reorderIndex'){\n            <td mat-cell *matCellDef=\"let row; let i=index\" [style]=\"column.columnStyle?.style\"\n            class=\"{{column.columnStyle?.dataCellClasses}}\">\n            <div class=\"flex gap-2 flex-row\">\n               <mat-icon class=\"dragCursor\" (mousedown)=\"dragDisabled = false;\">reorder</mat-icon>\n            </div>\n            </td>\n          } @else if (column.columnType === 'checkbox') {\n            <td mat-cell *matCellDef=\"let row; let i=index\"\n              class=\"{{column.columnStyle?.dataCellClasses}}\"\n              (dblclick)=\"startEditing(row, column, i)\">\n\n              @if (!column.properties?.rowSelection) {\n                <mat-checkbox class=\"table-checkbox\" (click)=\"$event.stopPropagation()\" [(ngModel)]=\"row[column.key]\"\n                  [disabled]=\"column.properties?.disabled!\" (change)=\"onRowValueChangeCheckbox($event, row,column.key, i)\">\n                </mat-checkbox>\n              }\n\n              @if (column.properties?.rowSelection) {\n                <mat-checkbox class=\"table-checkbox\" (click)=\"$event.stopPropagation()\" [checked]=\"selection.isSelected(row)\"\n                  (change)=\"$event ? selection.toggle(row) : null; onCheckboxSelection()\">\n                </mat-checkbox>\n              }\n            </td>\n          } @else if (column.columnType === 'actions') {\n            <td mat-cell *matCellDef=\"let row; let i=index\" [style]=\"column.columnStyle?.style\"\n              class=\"{{column.columnStyle?.dataCellClasses}}\">\n              <div class=\"flex gap-2 flex-row\">\n                @for (actionIcon of column.actionIcons; track $index) {\n                  <mat-icon class=\"{{column.hideActionIconOnKeyStatus? (row[column.hideActionIconOnKeyStatus]? 'hidden': actionIcon.style?.cssClasses) : actionIcon.style?.cssClasses}}\" [svgIcon]=\"actionIcon.iconName!\"\n                    (click)=\"onActionIconClicked(row, actionIcon, i); selection.setSelection(row)\">\n                  </mat-icon>\n                }\n              </div>\n            </td>\n          } @else {\n            @if (!properties.editField || column.displayAlways) {\n              <td mat-cell *matCellDef=\"let row; let i=index\"\n                [ngStyle]=\"column?.componentProperty?.label === '' ? {'text-align': 'center'} : {}\"\n                [style]=\"column.columnStyle?.style\" class=\"{{column.columnStyle?.dataCellClasses}} truncate\"\n                matTooltip=\"{{column.component ? '' : row[column.key]}}\">\n\n                @if (column.component) {\n                  <cl-data-grid-injector [component]=\"column.component\" [properties]=\"column?.componentProperty\"\n                    [value]=\"row[column.key]\" [isComponentDragged]=\"properties.isComponentDragged!\" [rowDetail]=\"row ?? ''\"\n                    (valueChange)=\"onRowValueChange($event, row,column.key, i)\" >\n                  </cl-data-grid-injector>\n                } @else {\n                  <span>{{ row[column.key] }}</span>\n                }\n              </td>\n            } @else {\n              <td mat-cell *matCellDef=\"let row; let i = index\" (keydown.enter)=\"startEditing(row, column, i)\"\n                (dblclick)=\"startEditing(row, column, i)\" (keydown)=\"handleKeyDown($event, column.key,i)\"\n                [ngClass]=\"{'highlight-cell': shouldHighlightCell(row,column) !== '' && isEdited(column, row)}\"\n                [style]=\"column.columnStyle?.style\"\n                class=\"{{column.columnStyle?.dataCellClasses}} {{properties.borderColor}}\n                {{column.columnStyle?.alignment || 'text-start'}} custom-cell\">\n\n                @if (row.editing && editingColumn === column.name && editingColumn !== null && column?.hasEditableRights) {\n                  @if (column.component) {\n                    <cl-data-grid-injector [component]=\"column.component\" [value]=\"row[column.key] ?? ''\" [rowDetail]=\"row ?? ''\" [isComponentDragged]=\"properties.isComponentDragged!\" [properties]=\"column?.componentProperty\"\n                      (valueChange)=\"onRowValueChange($event, row,column.key, i)\">\n                    </cl-data-grid-injector>\n                  } @else {\n                    <span>{{ row[column.key] }}</span>\n                  }\n                } @else {\n                  <div style=\"display: inline-grid\" class=\"w-full\">\n                    <span [matTooltip]=\"row[column.key]\" class=\"w-full truncate\"\n                      (keydown)=\"handleKeyDown($event, column.key, i)\" tabindex=\"0\">\n                      {{ row[column.key] }}\n                    </span>\n\n                    @if (shouldHighlightCell(row,column) !== '' && isEdited(column, row)) {\n                      <mat-hint class=\"truncate {{column.columnStyle?.maxWidth}} hint-style text-sm\"\n                        matTooltip=\"{{shouldHighlightCell(row,column) !== '' && isEdited(column, row) ? shouldHighlightCell(row,column) : ''}}\">\n                        {{shouldHighlightCell(row,column) !== '' && isEdited(column, row) ? shouldHighlightCell(row,column) : ''}}\n                      </mat-hint>\n                    }\n                  </div>\n                }\n              </td>\n            }\n          }\n          <!-- data row based on style -->\n        </ng-container>\n        }\n      <!-- } -->\n      <!-- data and header level rows -->\n\n      <!-- display column header -->\n      <tr mat-header-row *matHeaderRowDef=\"getDisplayColumns(); sticky:true\"></tr>\n      <!-- display column header -->\n\n      <!-- filter column header -->\n      <!-- @if (properties.showColumnFilter!) {\n        <tr mat-header-row *matHeaderRowDef=\"columnFilters; sticky:true\"></tr>\n      } -->\n      <!-- filter column header -->\n\n      <!-- data column row       cdkDrag cdkDragLockAxis=\"y\"  -->\n      @if(properties.rowDragEnable){\n        <tr cdkDrag [cdkDragData]=row (cdkDragStarted)=\"dragStarted(row)\"\n        mat-row *matRowDef=\"let row; columns: getDisplayColumns()\"\n        class=\"border-primary-900\"\n        [ngClass]=\"{'highlightTr': rowValidation(row) !== '' && isRowEdited(row),\n        'bg-primary-50': selection.isSelected(row)}\"\n        matTooltip=\"{{rowValidation(row) !== '' && isRowEdited(row) ? rowValidation(row) : ''}}\">\n        </tr>\n      } @else {\n        <tr\n        mat-row *matRowDef=\"let row; columns: getDisplayColumns()\"\n        class=\"border-primary-900\"\n        [ngClass]=\"{'highlightTr': rowValidation(row) !== '' && isRowEdited(row),\n        'bg-primary-50': selection.isSelected(row)}\"\n        matTooltip=\"{{rowValidation(row) !== '' && isRowEdited(row) ? rowValidation(row) : ''}}\">\n        </tr>\n      }\n\n      <!-- data column row -->\n    </table>\n  </div>\n  <!-- dynamic table column and row -->\n\n  @if (showLoading) {\n    <mat-progress-bar mode=\"indeterminate\" class=\"w-full rounded-full\">\n    </mat-progress-bar>\n  }\n\n  @if (properties.noDataLayout && dataSource.filteredData.length <= 0) {\n    <div class=\"flex w-full items-center justify-center flex-{{properties.noDataLayout.layoutType || 'col'}} {{properties.noDataLayout.gap}} py-12\">\n      @if (properties.noDataLayout.iconProperties) {\n        <cl-icon [properties]=\"properties.noDataLayout.iconProperties!\">\n        </cl-icon>\n      }\n\n      <cl-label [properties]=\"properties.noDataLayout.labelProperties\"></cl-label>\n    </div>\n  }\n\n  <!-- paginator -->\n  <mat-paginator #paginator style=\"display: none;\" [pageSize]=\"properties.pageSize!\"\n    [pageSizeOptions]=\"properties.pageSizeOptions!\"\n    [length]=\"properties.enableServerSidePagination ? totalRecords : dataSource.filteredData.length\">\n  </mat-paginator>\n\n  @if (properties.showPaginator!) {\n    <cl-paginator [currentPage]=\"currentPage\" [showLoading]=\"showLoading\" (pageIndex)=\"goToPageNo($event)\"\n      [pageSize]=\"properties.pageSize!\" (onPageSizeChange)=\"onPageSizeChange($event)\"\n      [pageSizeOptions]=\"properties.pageSizeOptions!\"\n      [noOfRecords]=\"properties.enableServerSidePagination ? totalRecords! : dataSource.filteredData.length\"\n      [hideGoToPage]=\"properties.hideGoToPage\"\n      [hideFirstLastPageBtn]=\"properties.hideFirstLastPageBtn\">\n    </cl-paginator>\n  }\n  <!-- paginator -->\n</div>\n", styles: [".mat-mdc-table thead,.mat-mdc-header-row,.mat-mdc-table .mat-mdc-header-cell,th{border-bottom-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgb(226 232 240 / var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity));padding:.75rem;font-size:.875rem;font-weight:700;line-height:1.25rem;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity))}.mat-mdc-table thead:is(.dark *),.mat-mdc-header-row:is(.dark *),.mat-mdc-table .mat-mdc-header-cell:is(.dark *),th:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}td:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity))}.mat-sort-header-content{display:flex;align-items:center;text-align:start}.mdc-data-table__cell,.mdc-data-table__header-cell{padding:0}.mat-mdc-table tbody,.mat-mdc-table .mat-mdc-cell{border-bottom-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgb(226 232 240 / var(--tw-border-opacity));padding:.75rem;font-size:.875rem;font-weight:400;line-height:1.5;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-mdc-table tbody:is(.dark *),.mat-mdc-table .mat-mdc-cell:is(.dark *){--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-900-rgb),var(--tw-bg-opacity));--tw-text-opacity: 1;color:rgba(var(--cl-primary-50-rgb),var(--tw-text-opacity))}.green-color{--tw-text-opacity: 1;color:rgb(22 163 74 / var(--tw-text-opacity))}.mat-mdc-table-sticky-border-elem-right{filter:drop-shadow(0px 0px 8px rgba(0,0,0,.16))}.scroll-right{filter:drop-shadow(2px 0px 4px rgba(0,0,0,.16))}.progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}.compact-field ::ng-deep .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{height:2.5rem;min-height:2.5rem;padding:0;padding-top:.5rem}.compact-field ::ng-deep .mdc-text-field{padding-left:.5rem;padding-right:.5rem;text-align:center}.page-field input[type=number]{-moz-appearance:textfield!important}.page-field ::ng-deep .mat-form-field-infix{border-width:0px}.page-field ::ng-deep .mat-form-field-appearance-outline .mat-select-arrow-wrapper{transform:none;padding:0}::ng-deep .mat-input-element:is(.dark *)::placeholder{--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}::ng-deep .cl-grid-search-input .mat-mdc-form-field-infix{min-height:40px!important}::ng-deep .h-40-field .mat-mdc-form-field-infix{height:40px!important;min-height:40px!important}::ng-deep .cl-grid-search-input{height:40px!important;border-radius:.375rem}::ng-deep .cl-grid-search-input .mat-mdc-form-field-flex{height:40px!important}::ng-deep .cl-grid-search-input .mat-mdc-form-field-infix{padding-top:8px!important;padding-bottom:8px!important}::ng-deep .cl-grid-filter-dropdown{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-text-field-wrapper{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-form-field-flex{height:40px!important}::ng-deep .cl-grid-filter-dropdown .mat-mdc-form-field-infix{padding-top:8px!important;padding-bottom:8px!important}::ng-deep .cl-grid-col-select{width:120px;border-style:none}::ng-deep .cl-grid-col-select .mat-mdc-form-field-infix{display:flex!important}::ng-deep .cl-grid-col-select .mdc-line-ripple{display:none!important}::ng-deep .highlight-cell{border:2px solid #dc2626!important}.highlightTr td:first-child{border-left:2px solid #dc2626!important}.highlightTr td:last-child{border-right:2px solid #dc2626!important}.highlightTr td{border-top:2px solid #dc2626!important;border-bottom:2px solid #dc2626!important}.hint-style{color:#dc2626!important;width:80%!important}::ng-deep .column-filter .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix{padding-top:5px!important}::ng-deep .column-filter .mat-mdc-text-field-wrapper{padding-left:4px!important;padding-right:4px!important}.grid-action-dropdown:not(:last-child){border-bottom-width:1px;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity));border-bottom-style:solid}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.FormBuilder }, { type: i0.ChangeDetectorRef }, { type: i1$4.MatDialog }, { type: ClDataGridService }], propDecorators: { matSortActive: [{
                type: Input
            }], totalRecords: [{
                type: Input
            }], showLoading: [{
                type: Input
            }], matSortDirection: [{
                type: Input
            }], data: [{
                type: Input,
                args: [{ required: true }]
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }], customData: [{
                type: Input,
                args: [{ required: false }]
            }], sort: [{
                type: ViewChild,
                args: [MatSort]
            }], table: [{
                type: ViewChild,
                args: ['table']
            }], paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], tableContainer: [{
                type: ViewChild,
                args: ['tableContainer']
            }] } });

class ClModalWindowComponent {
    constructor(_dialogRef, data) {
        this._dialogRef = _dialogRef;
        this.data = data;
        this.properties = data;
    }
    ngOnInit() {
        this.setIconProperties();
        this.properties.title.style.cssClasses ??= 'text-2xl font-bold text-primary';
    }
    setIconProperties() {
        this.closeIconProperties = {
            id: 'default0',
            type: ClComponentTypes.icon,
            onIconClicked: this.close.bind(this),
            iconName: this.properties.closeIconName ?? 'heroicons_outline:x-mark',
            style: {
                cssClasses: this.properties.style?.closeIconCssClasses ?? 'icon-size-7 text-primary cursor-pointer'
            }
        };
    }
    close() {
        this._dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowComponent, deps: [{ token: i1$4.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClModalWindowComponent, isStandalone: true, selector: "cl-modal-window", ngImport: i0, template: "<div class=\"flex flex-col w-full h-full\">\n\n  @if(!properties.hideDefaultHeader) {\n    <!-- Sticky header -->\n    <div class=\"px-4 py-2 {{ properties.style?.cssClasses }} flex w-full justify-between sticky top-0 z-10\">\n      <div class=\"flex gap-2 items-center\">\n        @if (properties.titleIconName) {\n          @if (properties.titleIconName.includes(':')) {\n            <mat-icon [svgIcon]=\"properties.titleIconName\" [class]=\"properties.style!.iconCssClass\">\n            </mat-icon>\n          } @else {\n            <img [src]=\"properties.titleIconName\" [class]=\"properties.style!.iconCssClass\"/>\n          }\n        }\n\n        <cl-text-block [properties]=\"properties.title\"></cl-text-block>\n      </div>\n\n      <div class=\"flex gap-2 items-center\">\n        @if (properties.actionIcons) {\n          @for (icon of properties.actionIcons; track icon) {\n            <cl-icon [properties]=\"icon\"></cl-icon>\n          }\n        }\n\n        <cl-icon [properties]=\"closeIconProperties\"></cl-icon>\n      </div>\n    </div>\n  }\n\n\n  <!-- Content container -->\n  <div class=\"flex flex-col flex-grow overflow-y-auto\">\n    <cl-component-injector class=\"flex-grow\" [component]=\"properties.component\"\n      [properties]=\"properties.componentProperties\">\n    </cl-component-injector>\n  </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClTextBlockComponent, selector: "cl-text-block", inputs: ["properties"] }, { kind: "component", type: ClComponentInjectorComponent, selector: "cl-component-injector", inputs: ["component", "properties"], outputs: ["changeEvent"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-modal-window', imports: [
                        MatIconModule,
                        ClIconComponent,
                        ClTextBlockComponent,
                        ClComponentInjectorComponent
                    ], template: "<div class=\"flex flex-col w-full h-full\">\n\n  @if(!properties.hideDefaultHeader) {\n    <!-- Sticky header -->\n    <div class=\"px-4 py-2 {{ properties.style?.cssClasses }} flex w-full justify-between sticky top-0 z-10\">\n      <div class=\"flex gap-2 items-center\">\n        @if (properties.titleIconName) {\n          @if (properties.titleIconName.includes(':')) {\n            <mat-icon [svgIcon]=\"properties.titleIconName\" [class]=\"properties.style!.iconCssClass\">\n            </mat-icon>\n          } @else {\n            <img [src]=\"properties.titleIconName\" [class]=\"properties.style!.iconCssClass\"/>\n          }\n        }\n\n        <cl-text-block [properties]=\"properties.title\"></cl-text-block>\n      </div>\n\n      <div class=\"flex gap-2 items-center\">\n        @if (properties.actionIcons) {\n          @for (icon of properties.actionIcons; track icon) {\n            <cl-icon [properties]=\"icon\"></cl-icon>\n          }\n        }\n\n        <cl-icon [properties]=\"closeIconProperties\"></cl-icon>\n      </div>\n    </div>\n  }\n\n\n  <!-- Content container -->\n  <div class=\"flex flex-col flex-grow overflow-y-auto\">\n    <cl-component-injector class=\"flex-grow\" [component]=\"properties.component\"\n      [properties]=\"properties.componentProperties\">\n    </cl-component-injector>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1$4.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

class ClModalWindowService {
    constructor() {
        this._dialog = inject(MatDialog);
    }
    open(config) {
        // Open the dialog
        return this._dialog.open(ClModalWindowComponent, {
            data: config,
            closeOnNavigation: true,
            position: config.position,
            width: config.style?.width,
            height: config.style?.height,
            minWidth: config.style?.minWidth,
            maxWidth: config.style?.maxWidth,
            disableClose: !config.dismissible,
            minHeight: config.style?.minHeight,
            maxHeight: config.style?.maxHeight,
            autoFocus: config.autoFocus ?? false,
            panelClass: config.style?.panelClass,
            hasBackdrop: config.hasBackdrop ?? true,
            backdropClass: 'cl-modal-window-backdrop'
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClBottomSheetComponent {
    constructor(data, _bottomSheetRef) {
        this.data = data;
        this._bottomSheetRef = _bottomSheetRef;
        this.properties = data;
    }
    ngOnInit() {
        this.setIconProperties();
    }
    setIconProperties() {
        this.closeIconProperties = {
            id: 'default0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:x-mark',
            onIconClicked: this.closeBottomSheet.bind(this),
            style: {
                cssClasses: this.properties.style?.closeIconCssClasses ?? 'icon-size-6 text-white cursor-pointer',
            },
        };
    }
    closeBottomSheet() {
        this._bottomSheetRef.dismiss();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetComponent, deps: [{ token: MAT_BOTTOM_SHEET_DATA }, { token: i1$5.MatBottomSheetRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClBottomSheetComponent, isStandalone: true, selector: "cl-bottom-sheet", ngImport: i0, template: "<div class=\"flex flex-col w-full h-full\">\n  <div class=\"bg-primary px-4 py-2 sticky top-0 z-10 {{ properties.style?.cssClasses }} flex w-full justify-between\">\n    <cl-text-block [properties]=\"properties.title\"></cl-text-block>\n\n    <div class=\"flex gap-2 items-center\">\n      @if (properties.actionIcons) {\n        @for (icon of properties.actionIcons; track icon) {\n          <cl-icon [properties]=\"icon\"></cl-icon>\n        }\n      }\n\n      <cl-icon [properties]=\"closeIconProperties\"></cl-icon>\n    </div>\n  </div>\n\n  <cl-component-injector class=\"size-full\" [component]=\"properties.component\"\n    [properties]=\"properties.componentProperties\">\n  </cl-component-injector>\n</div>\n", dependencies: [{ kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClTextBlockComponent, selector: "cl-text-block", inputs: ["properties"] }, { kind: "component", type: ClComponentInjectorComponent, selector: "cl-component-injector", inputs: ["component", "properties"], outputs: ["changeEvent"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-bottom-sheet', imports: [
                        ClIconComponent,
                        ClTextBlockComponent,
                        ClComponentInjectorComponent,
                    ], template: "<div class=\"flex flex-col w-full h-full\">\n  <div class=\"bg-primary px-4 py-2 sticky top-0 z-10 {{ properties.style?.cssClasses }} flex w-full justify-between\">\n    <cl-text-block [properties]=\"properties.title\"></cl-text-block>\n\n    <div class=\"flex gap-2 items-center\">\n      @if (properties.actionIcons) {\n        @for (icon of properties.actionIcons; track icon) {\n          <cl-icon [properties]=\"icon\"></cl-icon>\n        }\n      }\n\n      <cl-icon [properties]=\"closeIconProperties\"></cl-icon>\n    </div>\n  </div>\n\n  <cl-component-injector class=\"size-full\" [component]=\"properties.component\"\n    [properties]=\"properties.componentProperties\">\n  </cl-component-injector>\n</div>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_BOTTOM_SHEET_DATA]
                }] }, { type: i1$5.MatBottomSheetRef }] });

class ClBottomSheetService {
    constructor() {
        this._bottomSheet = inject(MatBottomSheet);
    }
    open(config) {
        // Open the dialog
        return this._bottomSheet.open(ClBottomSheetComponent, {
            data: config,
            disableClose: !config.dismissible,
            autoFocus: config.autoFocus ?? false,
            panelClass: config.style?.panelClass,
            hasBackdrop: config.hasBackdrop ?? false,
            backdropClass: config.style?.backdropClass,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClDualSortListStyleProperties {
}
class ClDualSortListProperties {
    constructor() {
        this.id = 'default0';
        this.leftListTitle = 'Left List';
        this.rightListTitle = 'Right List';
        this.rightListTooltipContent = ['Priority of Selected HSMs'];
        this.leftListTooltipContent = ['Line 1', 'Select Priority of Available HSMs'];
        this.type = ClComponentTypes.dualSortList;
        this.style = new ClDualSortListStyleProperties();
        this.style.cssClasses = 'p-4 bg-primary-50';
        this.style.titleIconSizeCssClasses = 'icon-size-5 text-primary';
        this.style.titleCssClasses = 'text-lg font-bold text-primary leading-6';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.options = [
            { name: 'Option 1', value: 'option1', selected: false },
            { name: 'Option 2', value: 'option2', selected: false },
            { name: 'Option 3', value: 'option3', selected: false },
            { name: 'Option 4', value: 'option4', selected: false },
            { name: 'Option 5', value: 'option5', selected: false },
        ];
    }
}

class ClDualSortListComponent extends ClBaseContainerComponent {
    constructor(cdr) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        super(); // Call the superclass constructor from ClBaseContainerComponent
        this.cdr = cdr;
        // Arrays to hold items for dual sort functionality
        this.selectedItems = [];
        this.availableItems = [];
        this.selectedItemsForCheck = [];
        super.setProperties(this.properties); // Initialize properties using the superclass method
    }
    // Lifecycle hook: called after Angular initializes the component's views and child views
    ngAfterViewInit() {
        // After view is initialized, check if there are pre-selected available items
        if (this.properties.options) {
            const selected = this.properties.options.filter((item) => item.selected);
            this.selectedItems.push(...selected);
            // Reset selected flag for each selected item
            this.selectedItems.forEach(item => item.selected = false);
        }
    }
    // Angular lifecycle hook: called after Angular initializes the component
    ngOnInit() {
        this.properties ??= new ClDualSortListProperties(); // Initialize properties if not provided
        this.setIconProperties();
        // Initialize availableItems based on properties
        if (this.properties.options) {
            this.availableItems = this.properties.options
                .map((item) => ({ ...item, selected: item.selected ?? false }))
                .filter(item => !item.selected);
        }
        super.ngOnInit(); // Call superclass ngOnInit
    }
    setIconProperties() {
        this.leftInfoIconProperties = {
            id: 'iIcon',
            tooltipPosition: 'right',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:information-circle',
            style: { cssClasses: `flex items-center text-primary justify-center` },
            tooltip: this.properties.leftListTooltipContent.join('\r\n\n'),
        };
        this.rightInfoIconProperties = {
            id: 'iIcon',
            tooltipPosition: 'right',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:information-circle',
            style: { cssClasses: `flex items-center text-primary justify-center` },
            tooltip: this.properties.rightListTooltipContent.join('\r\n\n'),
        };
    }
    // Move selected items from availableItems to selectedItems
    moveToSelected() {
        const selected = this.availableItems.filter(item => item.selected);
        this.selectedItems.push(...selected);
        this.availableItems = this.availableItems.filter(item => !item.selected);
        selected.forEach(item => item.selected = false);
        this.cdr.detectChanges(); // Detect changes after modification
        if (this.properties.onSelected) {
            this.properties.onSelected(this.selectedItems);
        }
    }
    // Move selected items from selectedItems to availableItems
    moveToAvailable() {
        const available = this.selectedItems.filter(item => item.selected);
        this.availableItems.push(...available);
        this.selectedItems = this.selectedItems.filter(item => !item.selected);
        available.forEach(item => item.selected = false);
        this.cdr.detectChanges(); // Detect changes after modification
        if (this.properties.onSelected) {
            this.properties.onSelected(this.selectedItems);
        }
    }
    // Check if selected items can be moved up in the list
    canMoveSelectedUp() {
        const selectedCount = this.selectedItems.filter(item => item.selected).length;
        if (selectedCount == 0) {
            return true;
        }
        if (selectedCount > 1 && this.selectedItems[0].selected) {
            return true;
        }
        else {
            return selectedCount === 1 && this.selectedItems[0].selected;
        }
    }
    // Check if selected items can be moved down in the list
    canMoveSelectedDown() {
        const selectedCount = this.selectedItems.filter(item => item.selected).length;
        if (selectedCount == 0) {
            return true;
        }
        if (selectedCount > 1 && this.selectedItems[this.selectedItems.length - 1].selected) {
            return true;
        }
        else {
            return selectedCount === 1 && this.selectedItems[this.selectedItems.length - 1].selected;
        }
    }
    // Move selected items up in the list
    moveSelectedUp() {
        const selectedIndices = [];
        this.selectedItems.forEach((item, index) => {
            if (item.selected)
                selectedIndices.push(index);
        });
        selectedIndices.forEach((selectedIndex) => {
            if (selectedIndex > 0) {
                const temp = this.selectedItems[selectedIndex];
                this.selectedItems[selectedIndex] = this.selectedItems[selectedIndex - 1];
                this.selectedItems[selectedIndex - 1] = temp;
            }
        });
        if (this.properties.onSelected) {
            this.properties.onSelected(this.selectedItems);
        }
    }
    // Move selected items down in the list
    moveSelectedDown() {
        const selectedIndices = [];
        this.selectedItems.forEach((item, index) => {
            if (item.selected)
                selectedIndices.push(index);
        });
        selectedIndices.reverse().forEach((selectedIndex) => {
            if (selectedIndex < this.selectedItems.length - 1) {
                const temp = this.selectedItems[selectedIndex];
                this.selectedItems[selectedIndex] = this.selectedItems[selectedIndex + 1];
                this.selectedItems[selectedIndex + 1] = temp;
            }
        });
        if (this.properties.onSelected) {
            this.properties.onSelected(this.selectedItems);
        }
    }
    // Handle drop event for reordering items
    drop(event) {
        moveItemInArray(this.selectedItems, event.previousIndex, event.currentIndex);
        if (this.properties.onSelected) {
            this.properties.onSelected(this.selectedItems);
        }
    }
    // Check if there are selected items to move to the selected list
    canMoveToSelected() {
        return this.availableItems.some(item => item.selected);
    }
    // Check if there are selected items to move to the available list
    canMoveToAvailable() {
        return this.selectedItems.some(item => item.selected);
    }
    // Handle mouse enter event for an item
    onMouseEnter(item) {
        item.hovered = true;
    }
    // Handle mouse leave event for an item
    onMouseLeave(item) {
        item.hovered = false;
    }
    // Handle checkbox change event
    checkboxChanged(item) {
        // Update selected items for checkbox change
        this.selectedItemsForCheck.forEach((x) => {
            if (!x.selected) {
                const index = this.selectedItemsForCheck.findIndex(selectedItem => selectedItem.name === x.name);
                if (index !== -1) {
                    this.selectedItemsForCheck.splice(index, 1);
                }
            }
        });
        if (item.selected) {
            this.selectedItemsForCheck.push(item);
        }
        else {
            const index = this.selectedItemsForCheck.findIndex(selectedItem => selectedItem.name === item.name);
            if (index !== -1) {
                this.selectedItemsForCheck.splice(index, 1);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDualSortListComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDualSortListComponent, isStandalone: true, selector: "cl-dual-sort-list", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<!-- Root Container Card -->\n<div class=\"{{ properties.style?.cssClasses }} flex gap-4 w-full items-center\">\n  <!-- Div container consist of header, Left List Box and Arrow -->\n  <div class=\"flex gap-4 w-full flex-col\">\n    <!-- Left List Box Header -->\n    <div class=\"flex gap-2 w-full items-center\">\n      <div class=\"{{ properties.style?.titleCssClasses }}\">{{ properties.leftListTitle }}</div>\n\n      @if (properties.leftListTooltipContent) {\n        <cl-icon [properties]=\"leftInfoIconProperties\" class=\"flex items-center justify-center\"></cl-icon>\n      }\n    </div>\n\n    <!-- Left List Box Body and Arrow contained inside this block -->\n    <div class=\"flex gap-4 w-full items-center justify-between\">\n      <!-- Left List Box -->\n      <div class=\"h-64 w-full bg-white shadow-md rounded-md overflow-y-auto\">\n        <div class=\"flex flex-col\">\n          @for (item of availableItems; let i = $index; track item){\n            <mat-checkbox [(ngModel)]=\"item.selected\" (change)=\"checkboxChanged(item)\" (mouseenter)=\"onMouseEnter(item)\"\n              (mouseleave)=\"onMouseLeave(item)\">\n              <div class=\"flex w-full text-md\">{{ item.name }}</div>\n            </mat-checkbox>\n\n            @if (i !== availableItems.length - 1) {\n              <mat-divider></mat-divider>\n            }\n          }\n        </div>\n      </div>\n      <!-- Left List Box End -->\n\n      <!-- Arrow to move list -->\n      <div class=\"flex gap-4 flex-col items-center\">\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveToSelected()\"\n          [disabled]=\"!canMoveToSelected()\">\n          <mat-icon>arrow_forward</mat-icon>\n        </button>\n\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveToAvailable()\"\n          [disabled]=\"!canMoveToAvailable()\">\n          <mat-icon>arrow_back</mat-icon>\n        </button>\n      </div>\n      <!-- Arrow Div End-->\n    </div>\n  </div>\n\n  <!-- Div container consist of header, Right List Box and Right hand Arrow -->\n  <div class=\"flex gap-4 w-full flex-col\">\n    <!-- Right List Box Header -->\n    <div class=\"flex gap-2 w-full items-center\">\n      <div class=\"{{ properties.style?.titleCssClasses }}\">{{ properties.rightListTitle }}</div>\n\n      @if (properties.rightListTooltipContent) {\n        <cl-icon [properties]=\"rightInfoIconProperties\" class=\"flex items-center justify-center\"></cl-icon>\n      }\n    </div>\n\n    <!-- Right List Box and Right hand Arrow -->\n    <div class=\"flex gap-4 w-full items-center\">\n      <!-- Right List Box -->\n      <div class=\"h-64 w-full bg-white rounded-md overflow-y-auto shadow-md\">\n        <div cdkDropList class=\"drag-container\" (cdkDropListDropped)=\"drop($event)\">\n          @for (item of selectedItems; let i = $index; track item){\n            <div cdkDrag class=\"list\" (mouseenter)=\"onMouseEnter(item)\" (mouseleave)=\"onMouseLeave(item)\">\n              <div class=\"flex items-center\">\n                <mat-checkbox class=\"w-full\" [(ngModel)]=\"item.selected\">{{ item.name }}</mat-checkbox>\n\n                <mat-icon cdkDragHandle [svgIcon]=\"'heroicons_outline:bars-3'\" class=\"ml-auto mr-4 cursor-pointer text-neutral-600\">\n                </mat-icon>\n              </div>\n\n              @if (i !== selectedItems.length - 1 && selectedItems.length) {\n                <mat-divider></mat-divider>\n              }\n            </div>\n          }\n        </div>\n      </div>\n      <!-- Right List Box End -->\n\n      <!-- Right hand Arrow -->\n      <div class=\"flex gap-4 flex-col items-center\">\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveSelectedUp()\"\n          [disabled]=\"canMoveSelectedUp()\">\n          <mat-icon>arrow_upward</mat-icon>\n        </button>\n\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveSelectedDown()\"\n          [disabled]=\"canMoveSelectedDown()\">\n          <mat-icon>arrow_downward</mat-icon>\n        </button>\n      </div>\n      <!-- Right hand Arrow End -->\n    </div>\n  </div>\n</div>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatListModule }, { kind: "component", type: i14.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$2.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i4$2.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$2.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i15.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDualSortListComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-dual-sort-list', imports: [
                        FormsModule,
                        MatCardModule,
                        MatIconModule,
                        MatListModule,
                        DragDropModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                    ], template: "<!-- Root Container Card -->\n<div class=\"{{ properties.style?.cssClasses }} flex gap-4 w-full items-center\">\n  <!-- Div container consist of header, Left List Box and Arrow -->\n  <div class=\"flex gap-4 w-full flex-col\">\n    <!-- Left List Box Header -->\n    <div class=\"flex gap-2 w-full items-center\">\n      <div class=\"{{ properties.style?.titleCssClasses }}\">{{ properties.leftListTitle }}</div>\n\n      @if (properties.leftListTooltipContent) {\n        <cl-icon [properties]=\"leftInfoIconProperties\" class=\"flex items-center justify-center\"></cl-icon>\n      }\n    </div>\n\n    <!-- Left List Box Body and Arrow contained inside this block -->\n    <div class=\"flex gap-4 w-full items-center justify-between\">\n      <!-- Left List Box -->\n      <div class=\"h-64 w-full bg-white shadow-md rounded-md overflow-y-auto\">\n        <div class=\"flex flex-col\">\n          @for (item of availableItems; let i = $index; track item){\n            <mat-checkbox [(ngModel)]=\"item.selected\" (change)=\"checkboxChanged(item)\" (mouseenter)=\"onMouseEnter(item)\"\n              (mouseleave)=\"onMouseLeave(item)\">\n              <div class=\"flex w-full text-md\">{{ item.name }}</div>\n            </mat-checkbox>\n\n            @if (i !== availableItems.length - 1) {\n              <mat-divider></mat-divider>\n            }\n          }\n        </div>\n      </div>\n      <!-- Left List Box End -->\n\n      <!-- Arrow to move list -->\n      <div class=\"flex gap-4 flex-col items-center\">\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveToSelected()\"\n          [disabled]=\"!canMoveToSelected()\">\n          <mat-icon>arrow_forward</mat-icon>\n        </button>\n\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveToAvailable()\"\n          [disabled]=\"!canMoveToAvailable()\">\n          <mat-icon>arrow_back</mat-icon>\n        </button>\n      </div>\n      <!-- Arrow Div End-->\n    </div>\n  </div>\n\n  <!-- Div container consist of header, Right List Box and Right hand Arrow -->\n  <div class=\"flex gap-4 w-full flex-col\">\n    <!-- Right List Box Header -->\n    <div class=\"flex gap-2 w-full items-center\">\n      <div class=\"{{ properties.style?.titleCssClasses }}\">{{ properties.rightListTitle }}</div>\n\n      @if (properties.rightListTooltipContent) {\n        <cl-icon [properties]=\"rightInfoIconProperties\" class=\"flex items-center justify-center\"></cl-icon>\n      }\n    </div>\n\n    <!-- Right List Box and Right hand Arrow -->\n    <div class=\"flex gap-4 w-full items-center\">\n      <!-- Right List Box -->\n      <div class=\"h-64 w-full bg-white rounded-md overflow-y-auto shadow-md\">\n        <div cdkDropList class=\"drag-container\" (cdkDropListDropped)=\"drop($event)\">\n          @for (item of selectedItems; let i = $index; track item){\n            <div cdkDrag class=\"list\" (mouseenter)=\"onMouseEnter(item)\" (mouseleave)=\"onMouseLeave(item)\">\n              <div class=\"flex items-center\">\n                <mat-checkbox class=\"w-full\" [(ngModel)]=\"item.selected\">{{ item.name }}</mat-checkbox>\n\n                <mat-icon cdkDragHandle [svgIcon]=\"'heroicons_outline:bars-3'\" class=\"ml-auto mr-4 cursor-pointer text-neutral-600\">\n                </mat-icon>\n              </div>\n\n              @if (i !== selectedItems.length - 1 && selectedItems.length) {\n                <mat-divider></mat-divider>\n              }\n            </div>\n          }\n        </div>\n      </div>\n      <!-- Right List Box End -->\n\n      <!-- Right hand Arrow -->\n      <div class=\"flex gap-4 flex-col items-center\">\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveSelectedUp()\"\n          [disabled]=\"canMoveSelectedUp()\">\n          <mat-icon>arrow_upward</mat-icon>\n        </button>\n\n        <button class=\"border-2 border-solid border-gray-300\" mat-icon-button (click)=\"moveSelectedDown()\"\n          [disabled]=\"canMoveSelectedDown()\">\n          <mat-icon>arrow_downward</mat-icon>\n        </button>\n      </div>\n      <!-- Right hand Arrow End -->\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { properties: [{
                type: Input
            }] } });

class ClResizableGridItemComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClResizableGridItemComponent, isStandalone: true, selector: "cl-resizable-grid-item", inputs: { id: "id" }, viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clResizableGrid>\n  <ng-content></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridItemComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-resizable-grid-item', template: "<ng-template #clResizableGrid>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { id: [{
                type: Input,
                args: [{ required: true }]
            }], contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });

/** Cached result of whether the user's browser supports passive event listeners. */
let supportsPassiveEvents;
/**
 * Checks whether the user's browser supports passive event listeners.
 * See: https://github.com/WICG/EventListenerOptions/blob/gh-pages/explainer.md
 */
function clSupportsPassiveEventListeners() {
    if (supportsPassiveEvents == null && typeof window !== 'undefined') {
        try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
                get: () => supportsPassiveEvents = true
            }));
        }
        finally {
            supportsPassiveEvents = supportsPassiveEvents || false;
        }
    }
    return supportsPassiveEvents;
}
/**
 * Normalizes an `AddEventListener` object to something that can be passed
 * to `addEventListener` on any browser, no matter whether it supports the
 * `options` parameter.
 * @param options Object to be normalized.
 */
function clNormalizePassiveListenerOptions(options) {
    return clSupportsPassiveEventListeners() ? options : !!options.capture;
}

/** Options that can be used to bind a passive event listener. */
const passiveEventListenerOptions = clNormalizePassiveListenerOptions({ passive: true });
/** Options that can be used to bind an active event listener. */
const activeEventListenerOptions = clNormalizePassiveListenerOptions({ passive: false });
let isMobile = null;
function clIsMobileOrTablet() {
    if (isMobile != null) {
        return isMobile;
    }
    // Generic match pattern to identify mobile or tablet devices
    const isMobileDevice = /Android|webOS|BlackBerry|Windows Phone|iPad|iPhone|iPod/i.test(navigator.userAgent);
    // Since IOS 13 is not safe to just check for the generic solution. See: https://stackoverflow.com/questions/58019463/how-to-detect-device-name-in-safari-on-ios-13-while-it-doesnt-show-the-correct
    const isIOSMobileDevice = /iPad|iPhone|iPod/.test(navigator.platform) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    isMobile = isMobileDevice || isIOSMobileDevice;
    return isMobile;
}
function clIsMouseEvent(event) {
    return event.clientX != null;
}
function clIsTouchEvent(event) {
    return event.touches != null && event.touches.length != null;
}
function clPointerClientX(event) {
    return clIsMouseEvent(event) ? event.clientX : event.touches[0].clientX;
}
function clPointerClientY(event) {
    return clIsMouseEvent(event) ? event.clientY : event.touches[0].clientY;
}
function clPointerClient(event) {
    return {
        clientX: clIsMouseEvent(event) ? event.clientX : event.touches[0].clientX,
        clientY: clIsMouseEvent(event) ? event.clientY : event.touches[0].clientY
    };
}
function clIsMouseEventOrMousePointerEvent(event) {
    return event.type === 'mousedown'
        || (event.type === 'pointerdown' && event.pointerType === 'mouse');
}
/** Returns true if browser supports pointer events */
function clSupportsPointerEvents() {
    return !!window.PointerEvent;
}
/**
 * Emits when a mousedown or touchstart emits. Avoids conflicts between both events.
 * @param element, html element where to  listen the events.
 * @param touchNumber number of the touch to track the event, default to the first one.
 */
function clMouseOrTouchDown(element, touchNumber = 1) {
    return iif(() => clIsMobileOrTablet(), fromEvent(element, 'touchstart', passiveEventListenerOptions).pipe(filter((touchEvent) => touchEvent.touches.length === touchNumber)), fromEvent(element, 'mousedown', activeEventListenerOptions).pipe(filter((mouseEvent) => {
        /**
         * 0 : Left mouse button
         * 1 : Wheel button or middle button (if present)
         * 2 : Right mouse button
         */
        return mouseEvent.button === 0; // Mouse down to be only fired if is left click
    })));
}
/**
 * Emits when a 'mousemove' or a 'touchmove' event gets fired.
 * @param element, html element where to  listen the events.
 * @param touchNumber number of the touch to track the event, default to the first one.
 */
function clMouseOrTouchMove(element, touchNumber = 1) {
    return iif(() => clIsMobileOrTablet(), fromEvent(element, 'touchmove', activeEventListenerOptions).pipe(filter((touchEvent) => touchEvent.touches.length === touchNumber)), fromEvent(element, 'mousemove', activeEventListenerOptions));
}
function clTouchEnd(element, touchNumber = 1) {
    return merge(fromEvent(element, 'touchend').pipe(filter((touchEvent) => touchEvent.touches.length === touchNumber - 1)), fromEvent(element, 'touchcancel').pipe(filter((touchEvent) => touchEvent.touches.length === touchNumber - 1)));
}
/**
 * Emits when a there is a 'mouseup' or the touch ends.
 * @param element, html element where to  listen the events.
 * @param touchNumber number of the touch to track the event, default to the first one.
 */
function clMouserOrTouchEnd(element, touchNumber = 1) {
    return iif(() => clIsMobileOrTablet(), clTouchEnd(element, touchNumber), fromEvent(element, 'mouseup'));
}
/**
 * Emits when a 'pointerdown' event occurs (only for the primary pointer). Fallbacks to 'mousemove' or a 'touchmove' if pointer events are not supported.
 * @param element, html element where to listen the events.
 */
function clPointerDown(element) {
    if (!clSupportsPointerEvents()) {
        return clMouseOrTouchDown(element);
    }
    return fromEvent(element, 'pointerdown', activeEventListenerOptions).pipe(filter((pointerEvent) => pointerEvent.isPrimary));
}
/**
 * Emits when a 'pointermove' event occurs (only for the primary pointer). Fallbacks to 'mousemove' or a 'touchmove' if pointer events are not supported.
 * @param element, html element where to listen the events.
 */
function clPointerMove(element) {
    if (!clSupportsPointerEvents()) {
        return clMouseOrTouchMove(element);
    }
    return fromEvent(element, 'pointermove', activeEventListenerOptions).pipe(filter((pointerEvent) => pointerEvent.isPrimary));
}
/**
 * Emits when a 'pointerup' event occurs (only for the primary pointer). Fallbacks to 'mousemove' or a 'touchmove' if pointer events are not supported.
 * @param element, html element where to listen the events.
 */
function clPointerUp(element) {
    if (!clSupportsPointerEvents()) {
        return clMouserOrTouchEnd(element);
    }
    return fromEvent(element, 'pointerup').pipe(filter(pointerEvent => pointerEvent.isPrimary));
}

/**
 * IMPORTANT:
 * This utils are taken from the project: https://github.com/STRML/react-grid-layout.
 * The code should be as less modified as possible for easy maintenance.
 */
const DEBUG = false;
/**
 * Return the bottom coordinate of the layout.
 *
 * @param  {Array} layout Layout array.
 * @return {Number}       Bottom coordinate.
 */
function bottom(layout) {
    let max = 0, bottomY;
    for (let i = 0, len = layout.length; i < len; i++) {
        bottomY = layout[i].y + layout[i].h;
        if (bottomY > max) {
            max = bottomY;
        }
    }
    return max;
}
function cloneLayout(layout) {
    const newLayout = Array(layout.length);
    for (let i = 0, len = layout.length; i < len; i++) {
        newLayout[i] = cloneLayoutItem(layout[i]);
    }
    return newLayout;
}
// Fast path to cloning, since this is monomorphic
/** NOTE: This code has been modified from the original source */
function cloneLayoutItem(layoutItem) {
    const clonedLayoutItem = {
        w: layoutItem.w,
        h: layoutItem.h,
        x: layoutItem.x,
        y: layoutItem.y,
        id: layoutItem.id,
        moved: !!layoutItem.moved,
        static: !!layoutItem.static,
        children: layoutItem.children,
    };
    if (layoutItem.minW !== undefined) {
        clonedLayoutItem.minW = layoutItem.minW;
    }
    if (layoutItem.maxW !== undefined) {
        clonedLayoutItem.maxW = layoutItem.maxW;
    }
    if (layoutItem.minH !== undefined) {
        clonedLayoutItem.minH = layoutItem.minH;
    }
    if (layoutItem.maxH !== undefined) {
        clonedLayoutItem.maxH = layoutItem.maxH;
    }
    // These can be null
    if (layoutItem.isDraggable !== undefined) {
        clonedLayoutItem.isDraggable = layoutItem.isDraggable;
    }
    if (layoutItem.isResizable !== undefined) {
        clonedLayoutItem.isResizable = layoutItem.isResizable;
    }
    return clonedLayoutItem;
}
/**
 * Given two layoutitems, check if they collide.
 */
function collides(l1, l2) {
    if (l1.id === l2.id) {
        return false;
    } // same element
    if (l1.x + l1.w <= l2.x) {
        return false;
    } // l1 is left of l2
    if (l1.x >= l2.x + l2.w) {
        return false;
    } // l1 is right of l2
    if (l1.y + l1.h <= l2.y) {
        return false;
    } // l1 is above l2
    if (l1.y >= l2.y + l2.h) {
        return false;
    } // l1 is below l2
    return true; // boxes overlap
}
/**
 * Given a layout, compact it. This involves going down each y coordinate and removing gaps
 * between items.
 *
 * @param  {Array} layout Layout.
 * @param  {Boolean} verticalCompact Whether or not to compact the layout
 *   vertically.
 * @return {Array}       Compacted Layout.
 */
function compact(layout, compactType, cols) {
    // Statics go in the compareWith array right away so items flow around them.
    const compareWith = getStatics(layout);
    // We go through the items by row and column.
    const sorted = sortLayoutItems(layout, compactType);
    // Holding for new items.
    const out = Array(layout.length);
    for (let i = 0, len = sorted.length; i < len; i++) {
        let l = cloneLayoutItem(sorted[i]);
        // Don't move static elements
        if (!l.static) {
            l = compactItem(compareWith, l, compactType, cols, sorted);
            // Add to comparison array. We only collide with items before this one.
            // Statics are already in this array.
            compareWith.push(l);
        }
        // Add to output array to make sure they still come out in the right order.
        out[layout.indexOf(sorted[i])] = l;
        // Clear moved flag, if it exists.
        l.moved = false;
    }
    return out;
}
const heightWidth = { x: 'w', y: 'h' };
/**
 * Before moving item down, it will check if the movement will cause collisions and move those items down before.
 */
function resolveCompactionCollision(layout, item, moveToCoord, axis) {
    const sizeProp = heightWidth[axis];
    item[axis] += 1;
    const itemIndex = layout
        .map((layoutItem) => {
        return layoutItem.id;
    })
        .indexOf(item.id);
    // Go through each item we collide with.
    for (let i = itemIndex + 1; i < layout.length; i++) {
        const otherItem = layout[i];
        // Ignore static items
        if (otherItem.static) {
            continue;
        }
        // Optimization: we can break early if we know we're past this el
        // We can do this b/c it's a sorted layout
        if (otherItem.y > item.y + item.h) {
            break;
        }
        if (collides(item, otherItem)) {
            resolveCompactionCollision(layout, otherItem, moveToCoord + item[sizeProp], axis);
        }
    }
    item[axis] = moveToCoord;
}
/**
 * Compact an item in the layout.
 */
function compactItem(compareWith, l, compactType, cols, fullLayout) {
    const compactV = compactType === 'vertical';
    const compactH = compactType === 'horizontal';
    if (compactV) {
        // Bottom 'y' possible is the bottom of the layout.
        // This allows you to do nice stuff like specify {y: Infinity}
        // This is here because the layout must be sorted in order to get the correct bottom `y`.
        l.y = Math.min(bottom(compareWith), l.y);
        // Move the element up as far as it can go without colliding.
        while (l.y > 0 && !getFirstCollision(compareWith, l)) {
            l.y--;
        }
    }
    else if (compactH) {
        // Move the element left as far as it can go without colliding.
        while (l.x > 0 && !getFirstCollision(compareWith, l)) {
            l.x--;
        }
    }
    // Move it down, and keep moving it down if it's colliding.
    let collides;
    while ((collides = getFirstCollision(compareWith, l))) {
        if (compactH) {
            resolveCompactionCollision(fullLayout, l, collides.x + collides.w, 'x');
        }
        else {
            resolveCompactionCollision(fullLayout, l, collides.y + collides.h, 'y');
        }
        // Since we can't grow without bounds horizontally, if we've overflown, let's move it down and try again.
        if (compactH && l.x + l.w > cols) {
            l.x = cols - l.w;
            l.y++;
            // ALso move element as left as much as we can (cl-custom-change)
            while (l.x > 0 && !getFirstCollision(compareWith, l)) {
                l.x--;
            }
        }
    }
    // Ensure that there are no negative positions
    l.y = Math.max(l.y, 0);
    l.x = Math.max(l.x, 0);
    return l;
}
/**
 * Given a layout, make sure all elements fit within its bounds.
 *
 * @param  {Array} layout Layout array.
 * @param  {Number} bounds Number of columns.
 */
function correctBounds(layout, bounds) {
    const collidesWith = getStatics(layout);
    for (let i = 0, len = layout.length; i < len; i++) {
        const l = layout[i];
        // Overflows right
        if (l.x + l.w > bounds.cols) {
            l.x = bounds.cols - l.w;
        }
        // Overflows left
        if (l.x < 0) {
            l.x = 0;
            l.w = bounds.cols;
        }
        if (!l.static) {
            collidesWith.push(l);
        }
        else {
            // If this is static and collides with other statics, we must move it down.
            // We have to do something nicer than just letting them overlap.
            while (getFirstCollision(collidesWith, l)) {
                l.y++;
            }
        }
    }
    return layout;
}
/**
 * Get a layout item by ID. Used so we can override later on if necessary.
 *
 * @param  {Array}  layout Layout array.
 * @param  {String} id     ID
 * @return {LayoutItem}    Item at ID.
 */
function getLayoutItem(layout, id) {
    for (let i = 0, len = layout.length; i < len; i++) {
        if (layout[i].id === id) {
            return layout[i];
        }
    }
    return null;
}
/**
 * Returns the first item this layout collides with.
 * It doesn't appear to matter which order we approach this from, although
 * perhaps that is the wrong thing to do.
 *
 * @param  {Object} layoutItem Layout item.
 * @return {Object|undefined}  A colliding layout item, or undefined.
 */
function getFirstCollision(layout, layoutItem) {
    for (let i = 0, len = layout.length; i < len; i++) {
        if (collides(layout[i], layoutItem)) {
            return layout[i];
        }
    }
    return null;
}
function getAllCollisions(layout, layoutItem) {
    return layout.filter(l => collides(l, layoutItem));
}
/**
 * Get all static elements.
 * @param  {Array} layout Array of layout objects.
 * @return {Array}        Array of static layout items..
 */
function getStatics(layout) {
    return layout.filter(l => l.static);
}
/**
 * Move an element. Responsible for doing cascading movements of other elements.
 *
 * @param  {Array}      layout            Full layout to modify.
 * @param  {LayoutItem} l                 element to move.
 * @param  {Number}     [x]               X position in grid units.
 * @param  {Number}     [y]               Y position in grid units.
 */
function moveElement(layout, l, x, y, isUserAction, preventCollision, compactType, cols) {
    // If this is static and not explicitly enabled as draggable,
    // no move is possible, so we can short-circuit this immediately.
    if (l.static && l.isDraggable !== true) {
        return layout;
    }
    // Short-circuit if nothing to do.
    if (l.y === y && l.x === x) {
        return layout;
    }
    log(`Moving element ${l.id} to [${String(x)},${String(y)}] from [${l.x},${l.y}]`);
    const oldX = l.x;
    const oldY = l.y;
    // This is quite a bit faster than extending the object
    if (typeof x === 'number') {
        l.x = x;
    }
    if (typeof y === 'number') {
        l.y = y;
    }
    l.moved = true;
    // If this collides with anything, move it.
    // When doing this comparison, we have to sort the items we compare with
    // to ensure, in the case of multiple collisions, that we're getting the
    // nearest collision.
    let sorted = sortLayoutItems(layout, compactType);
    const movingUp = compactType === 'vertical' && typeof y === 'number'
        ? oldY >= y
        : compactType === 'horizontal' && typeof x === 'number'
            ? oldX >= x
            : false;
    if (movingUp) {
        sorted = sorted.reverse();
    }
    const collisions = getAllCollisions(sorted, l);
    // There was a collision; abort
    if (preventCollision && collisions.length) {
        log(`Collision prevented on ${l.id}, reverting.`);
        l.x = oldX;
        l.y = oldY;
        l.moved = false;
        return layout;
    }
    // Move each item that collides away from this element.
    for (let i = 0, len = collisions.length; i < len; i++) {
        const collision = collisions[i];
        log(`Resolving collision between ${l.id} at [${l.x},${l.y}] and ${collision.id} at [${collision.x},${collision.y}]`);
        // Short circuit so we can't infinite loop
        if (collision.moved) {
            continue;
        }
        // Don't move static items - we have to move *this* element away
        if (collision.static) {
            layout = moveElementAwayFromCollision(layout, collision, l, isUserAction, compactType, cols);
        }
        else {
            layout = moveElementAwayFromCollision(layout, l, collision, isUserAction, compactType, cols);
        }
    }
    return layout;
}
/**
 * This is where the magic needs to happen - given a collision, move an element away from the collision.
 * We attempt to move it up if there's room, otherwise it goes below.
 *
 * @param  {Array} layout            Full layout to modify.
 * @param  {LayoutItem} collidesWith Layout item we're colliding with.
 * @param  {LayoutItem} itemToMove   Layout item we're moving.
 */
function moveElementAwayFromCollision(layout, collidesWith, itemToMove, isUserAction, compactType, cols) {
    const compactH = compactType === 'horizontal';
    // Compact vertically if not set to horizontal
    const compactV = compactType !== 'horizontal';
    const preventCollision = collidesWith.static; // we're already colliding (not for static items)
    // If there is enough space above the collision to put this element, move it there.
    // We only do this on the main collision as this can get funky in cascades and cause
    // unwanted swapping behavior.
    if (isUserAction) {
        // Reset isUserAction flag because we're not in the main collision anymore.
        isUserAction = false;
        // Make a mock item so we don't modify the item here, only modify in moveElement.
        const fakeItem = {
            x: compactH
                ? Math.max(collidesWith.x - itemToMove.w, 0)
                : itemToMove.x,
            y: compactV
                ? Math.max(collidesWith.y - itemToMove.h, 0)
                : itemToMove.y,
            w: itemToMove.w,
            h: itemToMove.h,
            id: '-1',
            children: itemToMove.children,
        };
        // No collision? If so, we can go up there; otherwise, we'll end up moving down as normal
        if (!getFirstCollision(layout, fakeItem)) {
            log(`Doing reverse collision on ${itemToMove.id} up to [${fakeItem.x},${fakeItem.y}].`);
            return moveElement(layout, itemToMove, compactH ? fakeItem.x : undefined, compactV ? fakeItem.y : undefined, isUserAction, preventCollision, compactType, cols);
        }
    }
    return moveElement(layout, itemToMove, compactH ? itemToMove.x + 1 : undefined, compactV ? itemToMove.y + 1 : undefined, isUserAction, preventCollision, compactType, cols);
}
/**
 * Helper to convert a number to a percentage string.
 *
 * @param  {Number} num Any number
 * @return {String}     That number as a percentage.
 */
function perc(num) {
    return num * 100 + '%';
}
function setTransform({ top, left, width, height }) {
    // Replace unit less items with px
    const translate = `translate(${left}px,${top}px)`;
    return {
        transform: translate,
        WebkitTransform: translate,
        MozTransform: translate,
        msTransform: translate,
        OTransform: translate,
        width: `${width}px`,
        height: `${height}px`,
        position: 'absolute',
    };
}
function setTopLeft({ top, left, width, height }) {
    return {
        top: `${top}px`,
        left: `${left}px`,
        width: `${width}px`,
        height: `${height}px`,
        position: 'absolute',
    };
}
/**
 * Get layout items sorted from top left to right and down.
 *
 * @return {Array} Array of layout objects.
 * @return {Array}        Layout, sorted static items first.
 */
function sortLayoutItems(layout, compactType) {
    if (compactType === 'horizontal') {
        return sortLayoutItemsByColRow(layout);
    }
    else {
        return sortLayoutItemsByRowCol(layout);
    }
}
function sortLayoutItemsByRowCol(layout) {
    return [].concat(layout).sort(function (a, b) {
        if (a.y > b.y || (a.y === b.y && a.x > b.x)) {
            return 1;
        }
        else if (a.y === b.y && a.x === b.x) {
            // Without this, we can get different sort results in IE vs. Chrome/FF
            return 0;
        }
        return -1;
    });
}
function sortLayoutItemsByColRow(layout) {
    return [].concat(layout).sort(function (a, b) {
        if (a.x > b.x || (a.x === b.x && a.y > b.y)) {
            return 1;
        }
        return -1;
    });
}
/**
 * Validate a layout. Throws errors.
 *
 * @param  {Array}  layout        Array of layout items.
 * @param  {String} [contextName] Context name for errors.
 * @throw  {Error}                Validation error.
 */
function validateLayout(layout, contextName = 'Layout') {
    const subProps = ['x', 'y', 'w', 'h'];
    if (!Array.isArray(layout)) {
        throw new Error(contextName + ' must be an array!');
    }
    for (let i = 0, len = layout.length; i < len; i++) {
        const item = layout[i];
        for (let j = 0; j < subProps.length; j++) {
            if (typeof item[subProps[j]] !== 'number') {
                throw new Error('ReactGridLayout: ' +
                    contextName +
                    '[' +
                    i +
                    '].' +
                    subProps[j] +
                    ' must be a number!');
            }
        }
        if (item.id && typeof item.id !== 'string') {
            throw new Error('ReactGridLayout: ' +
                contextName +
                '[' +
                i +
                '].i must be a string!');
        }
        if (item.static !== undefined && typeof item.static !== 'boolean') {
            throw new Error('ReactGridLayout: ' +
                contextName +
                '[' +
                i +
                '].static must be a boolean!');
        }
    }
}
// Flow can't really figure this out, so we just use Object
function autoBindHandlers(el, fns) {
    fns.forEach(key => (el[key] = el[key].bind(el)));
}
function log(...args) {
    if (!DEBUG) {
        return;
    }
}
const noop = () => { };

/** Tracks items by id. This function is mean to be used in conjunction with the ngFor that renders the 'cl-grid-items' */
function clTrackById(index, item) {
    return item.id;
}
/** Given a layout, the gridHeight and the gap return the resulting rowHeight */
function clGetGridItemRowHeight(layout, gridHeight, gap) {
    const numberOfRows = layout.reduce((acc, cur) => Math.max(acc, Math.max(cur.y + cur.h, 0)), 0);
    const gapTotalHeight = (numberOfRows - 1) * gap;
    const gridHeightMinusGap = gridHeight - gapTotalHeight;
    return gridHeightMinusGap / numberOfRows;
}
/**
 * Call react-grid-layout utils 'compact()' function and return the compacted layout.
 * @param layout to be compacted.
 * @param compactType, type of compaction.
 * @param cols, number of columns of the grid.
 */
function clGridCompact(layout, compactType, cols) {
    return compact(layout, compactType, cols)
        // Prune react-grid-layout compact extra properties.
        .map(item => ({ id: item.id, x: item.x, y: item.y, w: item.w, h: item.h, minW: item.minW, minH: item.minH, maxW: item.maxW, maxH: item.maxH, children: item.children }));
}
function screenXToGridX(screenXPos, cols, width, gap) {
    const widthMinusGaps = width - (gap * (cols - 1));
    const itemWidth = widthMinusGaps / cols;
    const widthMinusOneItem = width - itemWidth;
    const colWidthWithGap = widthMinusOneItem / (cols - 1);
    return Math.round(screenXPos / colWidthWithGap);
}
function screenYToGridY(screenYPos, rowHeight, height, gap) {
    return Math.round(screenYPos / (rowHeight + gap));
}
function screenWidthToGridWidth(gridScreenWidth, cols, width, gap) {
    const widthMinusGaps = width - (gap * (cols - 1));
    const itemWidth = widthMinusGaps / cols;
    const gridScreenWidthMinusFirst = gridScreenWidth - itemWidth;
    return Math.round(gridScreenWidthMinusFirst / (itemWidth + gap)) + 1;
}
function screenHeightToGridHeight(gridScreenHeight, rowHeight, height, gap) {
    const gridScreenHeightMinusFirst = gridScreenHeight - rowHeight;
    return Math.round(gridScreenHeightMinusFirst / (rowHeight + gap)) + 1;
}
/** Returns a Dictionary where the key is the id and the value is the change applied to that item. If no changes Dictionary is empty. */
function clGetGridLayoutDiff(gridLayoutA, gridLayoutB) {
    const diff = {};
    gridLayoutA.forEach(itemA => {
        const itemB = gridLayoutB.find(_itemB => _itemB.id === itemA.id);
        if (itemB != null) {
            const posChanged = itemA.x !== itemB.x || itemA.y !== itemB.y;
            const sizeChanged = itemA.w !== itemB.w || itemA.h !== itemB.h;
            const change = posChanged && sizeChanged ? 'moveresize' : posChanged ? 'move' : sizeChanged ? 'resize' : null;
            if (change) {
                diff[itemB.id] = { change };
            }
        }
    });
    return diff;
}
/**
 * Given the grid config & layout data and the current drag position & information, returns the corresponding layout and drag item position
 * @param gridItem grid item that is been dragged
 * @param config current grid configuration
 * @param compactionType type of compaction that will be performed
 * @param draggingData contains all the information about the drag
 */
function clGridItemDragging(gridItem, config, compactionType, draggingData) {
    const { pointerDownEvent, pointerDragEvent, gridElemClientRect, dragElemClientRect, scrollDifference } = draggingData;
    const gridItemId = gridItem.id;
    const draggingElemPrevItem = config.layout.find(item => item.id === gridItemId);
    const clientStartX = clPointerClientX(pointerDownEvent);
    const clientStartY = clPointerClientY(pointerDownEvent);
    const clientX = clPointerClientX(pointerDragEvent);
    const clientY = clPointerClientY(pointerDragEvent);
    const offsetX = clientStartX - dragElemClientRect.left;
    const offsetY = clientStartY - dragElemClientRect.top;
    // Grid element positions taking into account the possible scroll total difference from the beginning.
    const gridElementLeftPosition = gridElemClientRect.left + scrollDifference.left;
    const gridElementTopPosition = gridElemClientRect.top + scrollDifference.top;
    // Calculate position relative to the grid element.
    const gridRelXPos = clientX - gridElementLeftPosition - offsetX;
    const gridRelYPos = clientY - gridElementTopPosition - offsetY;
    const rowHeightInPixels = config.rowHeight === 'fit'
        ? clGetGridItemRowHeight(config.layout, config.height ?? gridElemClientRect.height, config.gap)
        : config.rowHeight;
    // Get layout item position
    const layoutItem = {
        ...draggingElemPrevItem,
        x: screenXToGridX(gridRelXPos, config.cols, gridElemClientRect.width, config.gap),
        y: screenYToGridY(gridRelYPos, rowHeightInPixels, gridElemClientRect.height, config.gap)
    };
    // Correct the values if they overflow, since 'moveElement' function doesn't do it
    layoutItem.x = Math.max(0, layoutItem.x);
    layoutItem.y = Math.max(0, layoutItem.y);
    if (layoutItem.x + layoutItem.w > config.cols) {
        layoutItem.x = Math.max(0, config.cols - layoutItem.w);
    }
    // Parse to LayoutItem array data in order to use 'react.grid-layout' utils
    const layoutItems = config.layout;
    const draggedLayoutItem = layoutItems.find(item => item.id === gridItemId);
    let newLayoutItems = moveElement(layoutItems, draggedLayoutItem, layoutItem.x, layoutItem.y, true, config.preventCollision, compactionType, config.cols);
    newLayoutItems = compact(newLayoutItems, compactionType, config.cols);
    return {
        layout: newLayoutItems,
        draggedItemPos: {
            top: gridRelYPos,
            left: gridRelXPos,
            width: dragElemClientRect.width,
            height: dragElemClientRect.height
        }
    };
}
/**
 * Given the grid config & layout data and the current drag position & information, returns the corresponding layout and drag item position
 * @param gridItem grid item that is been dragged
 * @param config current grid configuration
 * @param compactionType type of compaction that will be performed
 * @param draggingData contains all the information about the drag
 */
function clGridItemResizing(gridItem, config, compactionType, draggingData) {
    const { pointerDownEvent, pointerDragEvent, gridElemClientRect, dragElemClientRect, scrollDifference } = draggingData;
    const gridItemId = gridItem.id;
    const clientStartX = clPointerClientX(pointerDownEvent);
    const clientStartY = clPointerClientY(pointerDownEvent);
    const clientX = clPointerClientX(pointerDragEvent);
    const clientY = clPointerClientY(pointerDragEvent);
    // Get the difference between the mouseDown and the position 'right' of the resize element.
    const resizeElemOffsetX = dragElemClientRect.width - (clientStartX - dragElemClientRect.left);
    const resizeElemOffsetY = dragElemClientRect.height - (clientStartY - dragElemClientRect.top);
    const draggingElemPrevItem = config.layout.find(item => item.id === gridItemId);
    const width = clientX + resizeElemOffsetX - (dragElemClientRect.left + scrollDifference.left);
    const height = clientY + resizeElemOffsetY - (dragElemClientRect.top + scrollDifference.top);
    const rowHeightInPixels = config.rowHeight === 'fit'
        ? clGetGridItemRowHeight(config.layout, config.height ?? gridElemClientRect.height, config.gap)
        : config.rowHeight;
    // Get layout item grid position
    const layoutItem = {
        ...draggingElemPrevItem,
        w: screenWidthToGridWidth(width, config.cols, gridElemClientRect.width, config.gap),
        h: screenHeightToGridHeight(height, rowHeightInPixels, gridElemClientRect.height, config.gap)
    };
    layoutItem.w = limitNumberWithinRange(layoutItem.w, gridItem.minW ?? layoutItem.minW, gridItem.maxW ?? layoutItem.maxW);
    layoutItem.h = limitNumberWithinRange(layoutItem.h, gridItem.minH ?? layoutItem.minH, gridItem.maxH ?? layoutItem.maxH);
    if (layoutItem.x + layoutItem.w > config.cols) {
        layoutItem.w = Math.max(1, config.cols - layoutItem.x);
    }
    if (config.preventCollision) {
        const maxW = layoutItem.w;
        const maxH = layoutItem.h;
        let colliding = hasCollision(config.layout, layoutItem);
        let shrunkDimension;
        while (colliding) {
            shrunkDimension = getDimensionToShrink(layoutItem, shrunkDimension);
            layoutItem[shrunkDimension]--;
            colliding = hasCollision(config.layout, layoutItem);
        }
        if (shrunkDimension === 'w') {
            layoutItem.h = maxH;
            colliding = hasCollision(config.layout, layoutItem);
            while (colliding) {
                layoutItem.h--;
                colliding = hasCollision(config.layout, layoutItem);
            }
        }
        if (shrunkDimension === 'h') {
            layoutItem.w = maxW;
            colliding = hasCollision(config.layout, layoutItem);
            while (colliding) {
                layoutItem.w--;
                colliding = hasCollision(config.layout, layoutItem);
            }
        }
    }
    const newLayoutItems = config.layout.map((item) => {
        return item.id === gridItemId ? layoutItem : item;
    });
    return {
        layout: compact(newLayoutItems, compactionType, config.cols),
        draggedItemPos: {
            top: dragElemClientRect.top - gridElemClientRect.top,
            left: dragElemClientRect.left - gridElemClientRect.left,
            width,
            height,
        }
    };
}
function hasCollision(layout, layoutItem) {
    return !!getFirstCollision(layout, layoutItem);
}
function getDimensionToShrink(layoutItem, lastShrunk) {
    if (layoutItem.h <= 1) {
        return 'w';
    }
    if (layoutItem.w <= 1) {
        return 'h';
    }
    return lastShrunk === 'w' ? 'h' : 'w';
}
/**
 * Given the current number and min/max values, returns the number within the range
 * @param number can be any numeric value
 * @param min minimum value of range
 * @param max maximum value of range
 */
function limitNumberWithinRange(num, min = 1, max = Infinity) {
    return Math.min(Math.max(num, min < 1 ? 1 : min), max);
}
/** Returns true if both item1 and item2 ClGridLayoutItems are equivalent. */
function clGridItemLayoutItemAreEqual(item1, item2) {
    return item1.id === item2.id
        && item1.x === item2.x
        && item1.y === item2.y
        && item1.w === item2.w
        && item1.h === item2.h;
}

/**
 * Injection token that can be used to reference instances of `ClGridDragHandle`. It serves as
 * alternative token to the actual `ClGridDragHandle` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CL_GRID_DRAG_HANDLE = new InjectionToken('ClGridDragHandle');
/** Handle that can be used to drag a ClGridItem instance. */
class ClGridDragHandle {
    constructor(element) {
        this.element = element;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridDragHandle, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: ClGridDragHandle, isStandalone: true, selector: "[clGridDragHandle]", host: { classAttribute: "cl-grid-drag-handle" }, providers: [{ provide: CL_GRID_DRAG_HANDLE, useExisting: ClGridDragHandle }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridDragHandle, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[clGridDragHandle]',
                    // eslint-disable-next-line @angular-eslint/no-host-metadata-property
                    host: {
                        class: 'cl-grid-drag-handle'
                    },
                    providers: [{ provide: CL_GRID_DRAG_HANDLE, useExisting: ClGridDragHandle }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

/**
 * Injection token that can be used to reference instances of `ClGridResizeHandle`. It serves as
 * alternative token to the actual `ClGridResizeHandle` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CL_GRID_RESIZE_HANDLE = new InjectionToken('ClGridResizeHandle');
/** Handle that can be used to drag a ClGridItem instance. */
// eslint-disable-next-line @angular-eslint/directive-class-suffix
class ClGridResizeHandle {
    constructor(element) {
        this.element = element;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridResizeHandle, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: ClGridResizeHandle, isStandalone: true, selector: "[clGridResizeHandle]", host: { classAttribute: "cl-grid-resize-handle" }, providers: [{ provide: CL_GRID_RESIZE_HANDLE, useExisting: ClGridResizeHandle }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridResizeHandle, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[clGridResizeHandle]',
                    // eslint-disable-next-line @angular-eslint/no-host-metadata-property
                    host: {
                        class: 'cl-grid-resize-handle'
                    },
                    providers: [{ provide: CL_GRID_RESIZE_HANDLE, useExisting: ClGridResizeHandle }],
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

/**
 * Injection token that can be used to reference instances of `ClGridItemPlaceholder`. It serves as
 * alternative token to the actual `ClGridItemPlaceholder` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
const CL_GRID_ITEM_PLACEHOLDER = new InjectionToken('ClGridItemPlaceholder');
/** Directive that can be used to create a custom placeholder for a ClGridItem instance. */
class ClGridItemPlaceholder {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridItemPlaceholder, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: ClGridItemPlaceholder, isStandalone: true, selector: "ng-template[clGridItemPlaceholder]", inputs: { data: "data" }, host: { classAttribute: "cl-grid-item-placeholder-content" }, providers: [{ provide: CL_GRID_ITEM_PLACEHOLDER, useExisting: ClGridItemPlaceholder }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridItemPlaceholder, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: 'ng-template[clGridItemPlaceholder]',
                    // eslint-disable-next-line @angular-eslint/no-host-metadata-property
                    host: {
                        class: 'cl-grid-item-placeholder-content'
                    },
                    providers: [{ provide: CL_GRID_ITEM_PLACEHOLDER, useExisting: ClGridItemPlaceholder }],
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { data: [{
                type: Input
            }] } });

/** Coerces a data-bound value (typically a string) to a boolean. */
function coerceBooleanProperty(value) {
    return value != null && `${value}` !== 'false';
}

function coerceNumberProperty(value, fallbackValue = 0) {
    return _isNumberValue(value) ? Number(value) : fallbackValue;
}
/**
 * Whether the provided value is considered a number.
 * @docs-private
 */
function _isNumberValue(value) {
    // parseFloat(value) handles most of the cases we're interested in (it treats null, empty string,
    // and other non-number values as NaN, where Number just uses 0) but it considers the string
    // '123hello' to be a valid number. Therefore we also check if Number(value) is NaN.
    return !isNaN(parseFloat(value)) && !isNaN(Number(value));
}

const GRID_ITEM_GET_RENDER_DATA_TOKEN = new InjectionToken('GRID_ITEM_GET_RENDER_DATA_TOKEN');

/** Runs source observable outside the zone */
function clOutsideZone(zone) {
    return (source) => {
        return new Observable(observer => {
            return zone.runOutsideAngular(() => source.subscribe(observer));
        });
    };
}
/** Rxjs operator that makes source observable to no emit any data */
function clNoEmit() {
    return (source$) => {
        return source$.pipe(filter(() => false));
    };
}

/** Event options that can be used to bind an active, capturing event. */
const activeCapturingEventOptions = clNormalizePassiveListenerOptions({
    passive: false,
    capture: true
});
class ClGridService {
    constructor(ngZone) {
        this.ngZone = ngZone;
        this.touchMoveSubject = new Subject$1();
        this.touchMove$ = this.touchMoveSubject.asObservable();
        this.registerTouchMoveSubscription();
    }
    ngOnDestroy() {
        this.touchMoveSubscription?.unsubscribe();
    }
    mouseOrTouchMove$(element) {
        if (!clSupportsPointerEvents()) {
            return iif(() => clIsMobileOrTablet(), this.touchMove$, fromEvent(element, 'mousemove', activeCapturingEventOptions) // TODO: Fix rxjs typings, boolean should be a good param too.
            );
        }
        return fromEvent(element, 'pointermove', activeCapturingEventOptions);
    }
    registerTouchMoveSubscription() {
        // The `touchmove` event gets bound once, ahead of time, because WebKit
        // won't preventDefault on a dynamically-added `touchmove` listener.
        // See https://bugs.webkit.org/show_bug.cgi?id=184250.
        this.touchMoveSubscription = this.ngZone.runOutsideAngular(() => 
        // The event handler has to be explicitly active,
        // because newer browsers make it passive by default.
        fromEvent(document, 'touchmove', activeCapturingEventOptions) // TODO: Fix rxjs typings, boolean should be a good param too.
            // .pipe(filter((touchEvent: TouchEvent) => touchEvent.touches.length === 1))
            .pipe(filter((touchEvent) => touchEvent.touches.length === 1))
            .subscribe((touchEvent) => this.touchMoveSubject.next(touchEvent)));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridService, deps: [{ token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i0.NgZone }] });

class ClGridItemComponent {
    /** Id of the grid item. This property is strictly compulsory. */
    get id() {
        return this._id;
    }
    set id(val) {
        this._id = val;
    }
    /** Minimum amount of pixels that the user should move before it starts the drag sequence. */
    get dragStartThreshold() { return this._dragStartThreshold; }
    set dragStartThreshold(val) {
        this._dragStartThreshold = coerceNumberProperty(val);
    }
    /** Whether the item is draggable or not. Defaults to true. Does not affect manual dragging using the startDragManually method. */
    get draggable() {
        return this._draggable;
    }
    set draggable(val) {
        this._draggable = coerceBooleanProperty(val);
        this._draggable$.next(this._draggable);
    }
    /** Whether the item is resizable or not. Defaults to true. */
    get resizable() {
        return this._resizable;
    }
    set resizable(val) {
        this._resizable = coerceBooleanProperty(val);
        this._resizable$.next(this._resizable);
    }
    constructor(elementRef, gridService, renderer, ngZone, getItemRenderData) {
        this.elementRef = elementRef;
        this.gridService = gridService;
        this.renderer = renderer;
        this.ngZone = ngZone;
        this.getItemRenderData = getItemRenderData;
        /** CSS transition style. Note that for more performance is preferable only make transition on transform property. */
        this.transition = 'transform 500ms ease, width 500ms ease, height 500ms ease';
        this._dragStartThreshold = 0;
        this._draggable = true;
        this._draggable$ = new BehaviorSubject(this._draggable);
        this._manualDragEvents$ = new Subject$1();
        this._resizable = true;
        this._resizable$ = new BehaviorSubject(this._resizable);
        this.dragStartSubject = new Subject$1();
        this.resizeStartSubject = new Subject$1();
        this.subscriptions = [];
        this.dragStart$ = this.dragStartSubject.asObservable();
        this.resizeStart$ = this.resizeStartSubject.asObservable();
    }
    ngOnInit() {
        const gridItemRenderData = this.getItemRenderData(this.id);
        this.setStyles(gridItemRenderData);
    }
    ngAfterContentInit() {
        this.subscriptions.push(this._dragStart$().subscribe(this.dragStartSubject), this._resizeStart$().subscribe(this.resizeStartSubject));
    }
    ngOnDestroy() {
        this.subscriptions.forEach(sub => sub.unsubscribe());
    }
    /**
     * To manually start dragging, route the desired pointer events to this method.
     * Dragging initiated by this method will work regardless of the value of the draggable Input.
     * It is the caller's responsibility to call this method with only the events that are desired to cause a drag.
     * For example, if you only want left clicks to cause a drag, it is your responsibility to filter out other mouse button events.
     * @param startEvent The pointer event that should initiate the drag.
     */
    startDragManually(startEvent) {
        this._manualDragEvents$.next(startEvent);
    }
    setStyles({ top, left, width, height }) {
        // transform is 6x times faster than top/left
        this.renderer.setStyle(this.elementRef.nativeElement, 'transform', `translateX(${left}) translateY(${top})`);
        this.renderer.setStyle(this.elementRef.nativeElement, 'display', `block`);
        this.renderer.setStyle(this.elementRef.nativeElement, 'transition', this.transition);
        if (width != null) {
            this.renderer.setStyle(this.elementRef.nativeElement, 'width', width);
        }
        if (height != null) {
            this.renderer.setStyle(this.elementRef.nativeElement, 'height', height);
        }
    }
    _dragStart$() {
        return merge(this._manualDragEvents$, this._draggable$.pipe(switchMap((draggable) => {
            if (!draggable) {
                return NEVER;
            }
            return this._dragHandles.changes.pipe(startWith(this._dragHandles), switchMap((dragHandles) => {
                return iif(() => dragHandles.length > 0, merge(...dragHandles.toArray().map(dragHandle => clPointerDown(dragHandle.element.nativeElement))), clPointerDown(this.elementRef.nativeElement));
            }));
        }))).pipe(exhaustMap(startEvent => {
            // If the event started from an element with the native HTML drag&drop, it'll interfere
            // with our own dragging (e.g. `img` tags do it by default). Prevent the default action
            // to stop it from happening. Note that preventing on `dragstart` also seems to work, but
            // it's flaky and it fails if the user drags it away quickly. Also note that we only want
            // to do this for `mousedown` and `pointerdown` since doing the same for `touchstart` will
            // stop any `click` events from firing on touch devices.
            if (clIsMouseEventOrMousePointerEvent(startEvent)) {
                startEvent.preventDefault();
            }
            const startPointer = clPointerClient(startEvent);
            return this.gridService.mouseOrTouchMove$(document).pipe(takeUntil$1(clPointerUp(document)), clOutsideZone(this.ngZone), filter((moveEvent) => {
                moveEvent.preventDefault();
                const movePointer = clPointerClient(moveEvent);
                const distanceX = Math.abs(startPointer.clientX - movePointer.clientX);
                const distanceY = Math.abs(startPointer.clientY - movePointer.clientY);
                // When this conditions returns true mean that we are over threshold.
                return distanceX + distanceY >= this.dragStartThreshold;
            }), take(1), 
            // Return the original start event
            map(() => startEvent));
        }));
    }
    _resizeStart$() {
        return this._resizable$.pipe(switchMap((resizable) => {
            if (!resizable) {
                // Side effect to hide the resizeElem if resize is disabled.
                this.renderer.setStyle(this.resizeElem.nativeElement, 'display', 'none');
                return NEVER;
            }
            else {
                return this._resizeHandles.changes.pipe(startWith(this._resizeHandles), switchMap((resizeHandles) => {
                    if (resizeHandles.length > 0) {
                        // Side effect to hide the resizeElem if there are resize handles.
                        this.renderer.setStyle(this.resizeElem.nativeElement, 'display', 'none');
                        return merge(...resizeHandles.toArray().map(resizeHandle => clPointerDown(resizeHandle.element.nativeElement)));
                    }
                    else {
                        this.renderer.setStyle(this.resizeElem.nativeElement, 'display', 'block');
                        return clPointerDown(this.resizeElem.nativeElement);
                    }
                }), tap((startEvent) => {
                    if (clIsMouseEventOrMousePointerEvent(startEvent)) {
                        startEvent.preventDefault();
                    }
                }));
            }
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridItemComponent, deps: [{ token: i0.ElementRef }, { token: ClGridService }, { token: i0.Renderer2 }, { token: i0.NgZone }, { token: GRID_ITEM_GET_RENDER_DATA_TOKEN }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClGridItemComponent, isStandalone: true, selector: "cl-grid-item", inputs: { minW: "minW", minH: "minH", maxW: "maxW", maxH: "maxH", transition: "transition", id: "id", dragStartThreshold: "dragStartThreshold", draggable: "draggable", resizable: "resizable" }, queries: [{ propertyName: "placeholder", first: true, predicate: CL_GRID_ITEM_PLACEHOLDER, descendants: true }, { propertyName: "_dragHandles", predicate: CL_GRID_DRAG_HANDLE, descendants: true }, { propertyName: "_resizeHandles", predicate: CL_GRID_RESIZE_HANDLE, descendants: true }], viewQueries: [{ propertyName: "resizeElem", first: true, predicate: ["resizeElem"], descendants: true, read: ElementRef, static: true }], ngImport: i0, template: "<ng-content></ng-content>\n<div #resizeElem class=\"grid-item-resize-icon\"></div>", styles: [":host{display:none;position:absolute;z-index:1;overflow:hidden;touch-action:none}:host div{position:absolute;-webkit-user-select:none;user-select:none;z-index:10}:host div.grid-item-resize-icon{cursor:se-resize;width:20px;height:20px;bottom:0;right:0;color:inherit}:host div.grid-item-resize-icon:after{content:\"\";position:absolute;right:3px;bottom:3px;width:5px;height:5px;border-right:2px solid;border-bottom:2px solid}.display-none{display:none!important}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridItemComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-grid-item', changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-content></ng-content>\n<div #resizeElem class=\"grid-item-resize-icon\"></div>", styles: [":host{display:none;position:absolute;z-index:1;overflow:hidden;touch-action:none}:host div{position:absolute;-webkit-user-select:none;user-select:none;z-index:10}:host div.grid-item-resize-icon{cursor:se-resize;width:20px;height:20px;bottom:0;right:0;color:inherit}:host div.grid-item-resize-icon:after{content:\"\";position:absolute;right:3px;bottom:3px;width:5px;height:5px;border-right:2px solid;border-bottom:2px solid}.display-none{display:none!important}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: ClGridService }, { type: i0.Renderer2 }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [GRID_ITEM_GET_RENDER_DATA_TOKEN]
                }] }], propDecorators: { _dragHandles: [{
                type: ContentChildren,
                args: [CL_GRID_DRAG_HANDLE, { descendants: true }]
            }], _resizeHandles: [{
                type: ContentChildren,
                args: [CL_GRID_RESIZE_HANDLE, { descendants: true }]
            }], resizeElem: [{
                type: ViewChild,
                args: ['resizeElem', { static: true, read: ElementRef }]
            }], placeholder: [{
                type: ContentChild,
                args: [CL_GRID_ITEM_PLACEHOLDER]
            }], minW: [{
                type: Input
            }], minH: [{
                type: Input
            }], maxW: [{
                type: Input
            }], maxH: [{
                type: Input
            }], transition: [{
                type: Input
            }], id: [{
                type: Input
            }], dragStartThreshold: [{
                type: Input
            }], draggable: [{
                type: Input
            }], resizable: [{
                type: Input
            }] } });

/**
 * Client rect utilities.
 * This file is taken from Angular Material repository.
 */
/** Gets a mutable version of an element's bounding `ClientRect`. */
function getMutableClientRect(element) {
    const clientRect = element.getBoundingClientRect();
    // We need to clone the `clientRect` here, because all the values on it are readonly
    // and we need to be able to update them. Also we can't use a spread here, because
    // the values on a `ClientRect` aren't own properties. See:
    // https://developer.mozilla.org/en-US/docs/Web/API/Element/getBoundingClientRect#Notes
    return {
        top: clientRect.top,
        right: clientRect.right,
        bottom: clientRect.bottom,
        left: clientRect.left,
        width: clientRect.width,
        height: clientRect.height
    };
}
/**
 * Checks whether some coordinates are within a `ClientRect`.
 * @param clientRect ClientRect that is being checked.
 * @param x Coordinates along the X axis.
 * @param y Coordinates along the Y axis.
 */
function isInsideClientRect(clientRect, x, y) {
    const { top, bottom, left, right } = clientRect;
    return y >= top && y <= bottom && x >= left && x <= right;
}
/**
 * Updates the top/left positions of a `ClientRect`, as well as their bottom/right counterparts.
 * @param clientRect `ClientRect` that should be updated.
 * @param top Amount to add to the `top` position.
 * @param left Amount to add to the `left` position.
 */
function adjustClientRect(clientRect, top, left) {
    clientRect.top += top;
    clientRect.bottom = clientRect.top + clientRect.height;
    clientRect.left += left;
    clientRect.right = clientRect.left + clientRect.width;
}
/**
 * Checks whether the pointer coordinates are close to a ClientRect.
 * @param rect ClientRect to check against.
 * @param threshold Threshold around the ClientRect.
 * @param pointerX Coordinates along the X axis.
 * @param pointerY Coordinates along the Y axis.
 */
function isPointerNearClientRect(rect, threshold, pointerX, pointerY) {
    const { top, right, bottom, left, width, height } = rect;
    const xThreshold = width * threshold;
    const yThreshold = height * threshold;
    return pointerY > top - yThreshold && pointerY < bottom + yThreshold &&
        pointerX > left - xThreshold && pointerX < right + xThreshold;
}

/**
 * Proximity, as a ratio to width/height at which to start auto-scrolling.
 * The value comes from trying it out manually until it feels right.
 */
const SCROLL_PROXIMITY_THRESHOLD = 0.05;
/**
 * Increments the vertical scroll position of a node.
 * @param node Node whose scroll position should change.
 * @param amount Amount of pixels that the `node` should be scrolled.
 */
function incrementVerticalScroll(node, amount) {
    if (node === window) {
        node.scrollBy(0, amount);
    }
    else {
        // Ideally we could use `Element.scrollBy` here as well, but IE and Edge don't support it.
        node.scrollTop += amount;
    }
}
/**
 * Increments the horizontal scroll position of a node.
 * @param node Node whose scroll position should change.
 * @param amount Amount of pixels that the `node` should be scrolled.
 */
function incrementHorizontalScroll(node, amount) {
    if (node === window) {
        node.scrollBy(amount, 0);
    }
    else {
        // Ideally we could use `Element.scrollBy` here as well, but IE and Edge don't support it.
        node.scrollLeft += amount;
    }
}
/**
 * Gets whether the vertical auto-scroll direction of a node.
 * @param clientRect Dimensions of the node.
 * @param pointerY Position of the user's pointer along the y axis.
 */
function getVerticalScrollDirection(clientRect, pointerY) {
    const { top, bottom, height } = clientRect;
    const yThreshold = height * SCROLL_PROXIMITY_THRESHOLD;
    if (pointerY >= top - yThreshold && pointerY <= top + yThreshold) {
        return 1 /* AutoScrollVerticalDirection.UP */;
    }
    else if (pointerY >= bottom - yThreshold && pointerY <= bottom + yThreshold) {
        return 2 /* AutoScrollVerticalDirection.DOWN */;
    }
    return 0 /* AutoScrollVerticalDirection.NONE */;
}
/**
 * Gets whether the horizontal auto-scroll direction of a node.
 * @param clientRect Dimensions of the node.
 * @param pointerX Position of the user's pointer along the x axis.
 */
function getHorizontalScrollDirection(clientRect, pointerX) {
    const { left, right, width } = clientRect;
    const xThreshold = width * SCROLL_PROXIMITY_THRESHOLD;
    if (pointerX >= left - xThreshold && pointerX <= left + xThreshold) {
        return 1 /* AutoScrollHorizontalDirection.LEFT */;
    }
    else if (pointerX >= right - xThreshold && pointerX <= right + xThreshold) {
        return 2 /* AutoScrollHorizontalDirection.RIGHT */;
    }
    return 0 /* AutoScrollHorizontalDirection.NONE */;
}
/**
 * Returns an observable that schedules a loop and apply scroll on the scrollNode into the specified direction/s.
 * This observable doesn't emit, it just performs the 'scroll' side effect.
 * @param scrollNode, node where the scroll would be applied.
 * @param verticalScrollDirection, vertical direction of the scroll.
 * @param horizontalScrollDirection, horizontal direction of the scroll.
 * @param scrollStep, scroll step in CSS pixels that would be applied in every loop.
 */
function scrollToDirectionInterval$(scrollNode, verticalScrollDirection, horizontalScrollDirection, scrollStep = 2) {
    return interval(0, animationFrameScheduler)
        .pipe(tap(() => {
        if (verticalScrollDirection === 1 /* AutoScrollVerticalDirection.UP */) {
            incrementVerticalScroll(scrollNode, -scrollStep);
        }
        else if (verticalScrollDirection === 2 /* AutoScrollVerticalDirection.DOWN */) {
            incrementVerticalScroll(scrollNode, scrollStep);
        }
        if (horizontalScrollDirection === 1 /* AutoScrollHorizontalDirection.LEFT */) {
            incrementHorizontalScroll(scrollNode, -scrollStep);
        }
        else if (horizontalScrollDirection === 2 /* AutoScrollHorizontalDirection.RIGHT */) {
            incrementHorizontalScroll(scrollNode, scrollStep);
        }
    }), clNoEmit());
}
/**
 * Given a source$ observable with pointer location, scroll the scrollNode if the pointer is near to it.
 * This observable doesn't emit, it just performs a 'scroll' side effect.
 * @param scrollableParent, parent node in which the scroll would be performed.
 * @param options, configuration options.
 */
function clScrollIfNearElementClientRect$(scrollableParent, options) {
    let scrollNode;
    let scrollableParentClientRect;
    let scrollableParentScrollWidth;
    if (scrollableParent === document) {
        scrollNode = document.defaultView;
        const { width, height } = getViewportSize();
        scrollableParentClientRect = { width, height, top: 0, right: width, bottom: height, left: 0 };
        scrollableParentScrollWidth = getDocumentScrollWidth();
    }
    else {
        scrollNode = scrollableParent;
        scrollableParentClientRect = getMutableClientRect(scrollableParent);
        scrollableParentScrollWidth = scrollableParent.scrollWidth;
    }
    /**
     * IMPORTANT: By design, only let scroll horizontal if the scrollable parent has explicitly an scroll horizontal.
     * This layout solution is not designed in mind to have any scroll horizontal, but exceptionally we allow it in this
     * specific use case.
     */
    options = options || {};
    if (options.disableHorizontal == null && scrollableParentScrollWidth <= scrollableParentClientRect.width) {
        options.disableHorizontal = true;
    }
    return (source$) => source$.pipe(map(({ pointerX, pointerY }) => {
        let verticalScrollDirection = getVerticalScrollDirection(scrollableParentClientRect, pointerY);
        let horizontalScrollDirection = getHorizontalScrollDirection(scrollableParentClientRect, pointerX);
        // Check if scroll directions are disabled.
        if (options?.disableVertical) {
            verticalScrollDirection = 0 /* AutoScrollVerticalDirection.NONE */;
        }
        if (options?.disableHorizontal) {
            horizontalScrollDirection = 0 /* AutoScrollHorizontalDirection.NONE */;
        }
        return { verticalScrollDirection, horizontalScrollDirection };
    }), distinctUntilChanged((prev, actual) => {
        return prev.verticalScrollDirection === actual.verticalScrollDirection
            && prev.horizontalScrollDirection === actual.horizontalScrollDirection;
    }), switchMap(({ verticalScrollDirection, horizontalScrollDirection }) => {
        if (verticalScrollDirection || horizontalScrollDirection) {
            return scrollToDirectionInterval$(scrollNode, verticalScrollDirection, horizontalScrollDirection, options?.scrollStep);
        }
        else {
            return NEVER;
        }
    }));
}
/**
 * Emits on EVERY scroll event and returns the accumulated scroll offset relative to the initial scroll position.
 * @param scrollableParent, node in which scroll events would be listened.
 */
function clGetScrollTotalRelativeDifference$(scrollableParent) {
    let scrollInitialPosition;
    // Calculate initial scroll position
    if (scrollableParent === document) {
        scrollInitialPosition = getViewportScrollPosition();
    }
    else {
        scrollInitialPosition = {
            top: scrollableParent.scrollTop,
            left: scrollableParent.scrollLeft
        };
    }
    return fromEvent(scrollableParent, 'scroll', clNormalizePassiveListenerOptions({ capture: true })).pipe(map(() => {
        let newTop;
        let newLeft;
        if (scrollableParent === document) {
            const viewportScrollPosition = getViewportScrollPosition();
            newTop = viewportScrollPosition.top;
            newLeft = viewportScrollPosition.left;
        }
        else {
            newTop = scrollableParent.scrollTop;
            newLeft = scrollableParent.scrollLeft;
        }
        const topDifference = scrollInitialPosition.top - newTop;
        const leftDifference = scrollInitialPosition.left - newLeft;
        return { top: topDifference, left: leftDifference };
    }));
}
/** Returns the viewport's width and height. */
function getViewportSize() {
    const _window = document.defaultView ?? window;
    return {
        width: _window.innerWidth,
        height: _window.innerHeight
    };
}
/** Gets a ClientRect for the viewport's bounds. */
function getViewportRect() {
    // Use the document element's bounding rect rather than the window scroll properties
    // (e.g. pageYOffset, scrollY) due to in issue in Chrome and IE where window scroll
    // properties and client coordinates (boundingClientRect, clientX/Y, etc.) are in different
    // conceptual viewports. Under most circumstances these viewports are equivalent, but they
    // can disagree when the page is pinch-zoomed (on devices that support touch).
    // See https://bugs.chromium.org/p/chromium/issues/detail?id=489206#c4
    // We use the documentElement instead of the body because, by default (without a css reset)
    // browsers typically give the document body an 8px margin, which is not included in
    // getBoundingClientRect().
    const scrollPosition = getViewportScrollPosition();
    const { width, height } = getViewportSize();
    return {
        top: scrollPosition.top,
        left: scrollPosition.left,
        bottom: scrollPosition.top + height,
        right: scrollPosition.left + width,
        height,
        width,
    };
}
/** Gets the (top, left) scroll position of the viewport. */
function getViewportScrollPosition() {
    // The top-left-corner of the viewport is determined by the scroll position of the document
    // body, normally just (scrollLeft, scrollTop). However, Chrome and Firefox disagree about
    // whether `document.body` or `document.documentElement` is the scrolled element, so reading
    // `scrollTop` and `scrollLeft` is inconsistent. However, using the bounding rect of
    // `document.documentElement` works consistently, where the `top` and `left` values will
    // equal negative the scroll position.
    const windowRef = document.defaultView ?? window;
    const documentElement = document.documentElement;
    const documentRect = documentElement.getBoundingClientRect();
    const top = -documentRect.top || document.body.scrollTop || windowRef.scrollY ||
        documentElement.scrollTop || 0;
    const left = -documentRect.left || document.body.scrollLeft || windowRef.scrollX ||
        documentElement.scrollLeft || 0;
    return { top, left };
}
/** Returns the document scroll width */
function getDocumentScrollWidth() {
    return Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);
}

/**
 * Transition duration utilities.
 * This file is taken from Angular Material repository.
 */
/* eslint-disable @katoid/prefix-exported-code */
/** Parses a CSS time value to milliseconds. */
function parseCssTimeUnitsToMs(value) {
    // Some browsers will return it in seconds, whereas others will return milliseconds.
    const multiplier = value.toLowerCase().indexOf('ms') > -1 ? 1 : 1000;
    return parseFloat(value) * multiplier;
}
/** Gets the transform transition duration, including the delay, of an element in milliseconds. */
function getTransformTransitionDurationInMs(element) {
    const computedStyle = getComputedStyle(element);
    const transitionedProperties = parseCssPropertyValue(computedStyle, 'transition-property');
    const property = transitionedProperties.find(prop => prop === 'transform' || prop === 'all');
    // If there's no transition for `all` or `transform`, we shouldn't do anything.
    if (!property) {
        return 0;
    }
    // Get the index of the property that we're interested in and match
    // it up to the same index in `transition-delay` and `transition-duration`.
    const propertyIndex = transitionedProperties.indexOf(property);
    const rawDurations = parseCssPropertyValue(computedStyle, 'transition-duration');
    const rawDelays = parseCssPropertyValue(computedStyle, 'transition-delay');
    return parseCssTimeUnitsToMs(rawDurations[propertyIndex]) +
        parseCssTimeUnitsToMs(rawDelays[propertyIndex]);
}
/** Parses out multiple values from a computed style into an array. */
function parseCssPropertyValue(computedStyle, name) {
    const value = computedStyle.getPropertyValue(name);
    return value.split(',').map(part => part.trim());
}

function getDragResizeEventData(gridItem, layout) {
    return {
        layout,
        layoutItem: layout.find((item) => item.id === gridItem.id),
        gridItemRef: gridItem
    };
}
function getColumnWidth(config, width) {
    const { cols, gap } = config;
    const widthExcludingGap = width - Math.max((gap * (cols - 1)), 0);
    return (widthExcludingGap / cols);
}
function getRowHeightInPixels(config, height) {
    const { rowHeight, layout, gap } = config;
    return rowHeight === 'fit' ? clGetGridItemRowHeight(layout, height, gap) : rowHeight;
}
function layoutToRenderItems(config, width, height) {
    const { layout, gap } = config;
    const rowHeightInPixels = getRowHeightInPixels(config, height);
    const itemWidthPerColumn = getColumnWidth(config, width);
    const renderItems = {};
    for (const item of layout) {
        renderItems[item.id] = {
            id: item.id,
            top: item.y * rowHeightInPixels + gap * item.y,
            left: item.x * itemWidthPerColumn + gap * item.x,
            width: item.w * itemWidthPerColumn + gap * Math.max(item.w - 1, 0),
            height: item.h * rowHeightInPixels + gap * Math.max(item.h - 1, 0),
        };
    }
    return renderItems;
}
function getGridHeight(layout, rowHeight, gap) {
    return layout.reduce((acc, cur) => Math.max(acc, (cur.y + cur.h) * rowHeight + Math.max(cur.y + cur.h - 1, 0) * gap), 0);
}
// eslint-disable-next-line @katoid/prefix-exported-code
function parseRenderItemToPixels(renderItem) {
    return {
        id: renderItem.id,
        top: `${renderItem.top}px`,
        left: `${renderItem.left}px`,
        width: `${renderItem.width}px`,
        height: `${renderItem.height}px`
    };
}
// eslint-disable-next-line @katoid/prefix-exported-code
function __gridItemGetRenderDataFactoryFunc(gridCmp) {
    return function (id) {
        return parseRenderItemToPixels(gridCmp.getItemRenderData(id));
    };
}
function clGridItemGetRenderDataFactoryFunc(gridCmp) {
    // Workaround explained: https://github.com/ng-packagr/ng-packagr/issues/696#issuecomment-387114613
    const resultFunc = __gridItemGetRenderDataFactoryFunc(gridCmp);
    return resultFunc;
}
const defaultBackgroundConfig = {
    borderColor: '#ffa72678',
    gapColor: 'transparent',
    rowColor: 'transparent',
    columnColor: 'transparent',
    borderWidth: 1,
};
class ClGridComponent {
    /** Whether or not to update the internal layout when some dependent property change. */
    get compactOnPropsChange() { return this._compactOnPropsChange; }
    set compactOnPropsChange(value) {
        this._compactOnPropsChange = coerceBooleanProperty(value);
    }
    /** If true, grid items won't change position when being dragged over. Handy when using no compaction */
    get preventCollision() { return this._preventCollision; }
    set preventCollision(value) {
        this._preventCollision = coerceBooleanProperty(value);
    }
    /** Number of CSS pixels that would be scrolled on each 'tick' when auto scroll is performed. */
    get scrollSpeed() { return this._scrollSpeed; }
    set scrollSpeed(value) {
        this._scrollSpeed = coerceNumberProperty(value, 2);
    }
    /** Type of compaction that will be applied to the layout (vertical, horizontal or free). Defaults to 'vertical' */
    get compactType() {
        return this._compactType;
    }
    set compactType(val) {
        this._compactType = val;
    }
    /**
     * Row height as number or as 'fit'.
     * If rowHeight is a number value, it means that each row would have those css pixels in height.
     * if rowHeight is 'fit', it means that rows will fit in the height available. If 'fit' value is set, a 'height' should be also provided.
     */
    get rowHeight() { return this._rowHeight; }
    set rowHeight(val) {
        this._rowHeight = val === 'fit' ? val : Math.max(1, Math.round(coerceNumberProperty(val)));
    }
    /** Number of columns  */
    get cols() { return this._cols; }
    set cols(val) {
        this._cols = Math.max(1, Math.round(coerceNumberProperty(val)));
    }
    /** Layout of the grid. Array of all the grid items with its 'id' and position on the grid. */
    get layout() { return this._layout; }
    set layout(layout) {
        /**
         * Enhancement:
         * Only set layout if it's reference has changed and use a boolean to track whenever recalculate the layout on ngOnChanges.
         *
         * Why:
         * The normal use of this lib is having the variable layout in the outer component or in a store, assigning it whenever it changes and
         * binded in the component with it's input [layout]. In this scenario, we would always calculate one unnecessary change on the layout when
         * it is re-binded on the input.
         */
        this._layout = layout;
    }
    /** Grid gap in css pixels */
    get gap() {
        return this._gap;
    }
    set gap(val) {
        this._gap = Math.max(coerceNumberProperty(val), 0);
    }
    /**
     * If height is a number, fixes the height of the grid to it, recommended when rowHeight = 'fit' is used.
     * If height is null, height will be automatically set according to its inner grid items.
     * Defaults to null.
     * */
    get height() {
        return this._height;
    }
    set height(val) {
        this._height = typeof val === 'number' ? Math.max(val, 0) : null;
    }
    get backgroundConfig() {
        return this._backgroundConfig;
    }
    set backgroundConfig(val) {
        this._backgroundConfig = val;
        // If there is background configuration, add main grid background class. Grid background class comes with opacity 0.
        // It is done this way for adding opacity animation and to don't add any styles when grid background is null.
        const classList = this.elementRef.nativeElement.classList;
        this._backgroundConfig !== null ? classList.add('cl-grid-background') : classList.remove('cl-grid-background');
        // Set background visibility
        this.setGridBackgroundVisible(this._backgroundConfig?.show === 'always');
    }
    get config() {
        return {
            cols: this.cols,
            rowHeight: this.rowHeight,
            height: this.height,
            layout: this.layout,
            preventCollision: this.preventCollision,
            gap: this.gap,
        };
    }
    constructor(gridService, elementRef, viewContainerRef, renderer, ngZone) {
        this.gridService = gridService;
        this.elementRef = elementRef;
        this.viewContainerRef = viewContainerRef;
        this.renderer = renderer;
        this.ngZone = ngZone;
        /** Emits when layout change */
        this.layoutUpdated = new EventEmitter();
        /** Emits when drag starts */
        this.dragStarted = new EventEmitter();
        /** Emits when resize starts */
        this.resizeStarted = new EventEmitter();
        /** Emits when drag ends */
        this.dragEnded = new EventEmitter();
        /** Emits when resize ends */
        this.resizeEnded = new EventEmitter();
        /** Emits when a grid item is being resized and its bounds have changed */
        this.gridItemResize = new EventEmitter();
        /**
         * Parent element that contains the scroll. If an string is provided it would search that element by id on the dom.
         * If no data provided or null auto scroll is not performed.
         */
        this.scrollableParent = null;
        this._compactOnPropsChange = true;
        this._preventCollision = false;
        this._scrollSpeed = 2;
        this._compactType = 'vertical';
        this._rowHeight = 100;
        this._cols = 6;
        this._gap = 0;
        this._height = null;
        this._backgroundConfig = null;
        this.subscriptions = [];
    }
    ngOnChanges(changes) {
        if (this.rowHeight === 'fit' && this.height == null) {
            console.warn(`ClGridComponent: The @Input() height should not be null when using rowHeight 'fit'`);
        }
        let needsCompactLayout = false;
        let needsRecalculateRenderData = false;
        // TODO: Does fist change need to be compacted by default?
        // Compact layout whenever some dependent prop changes.
        if (changes['compactType'] || changes['cols'] || changes['layout']) {
            needsCompactLayout = true;
        }
        // Check if wee need to recalculate rendering data.
        if (needsCompactLayout || changes['rowHeight'] || changes['height'] || changes['gap'] || changes['backgroundConfig']) {
            needsRecalculateRenderData = true;
        }
        // Only compact layout if lib user has provided it. Lib users that want to save/store always the same layout  as it is represented (compacted)
        // can use CLCompactGrid utility and pre-compact the layout. This is the recommended behavior for always having a the same layout on this component
        // and the ones that uses it.
        if (needsCompactLayout && this.compactOnPropsChange) {
            this.compactLayout();
        }
        if (needsRecalculateRenderData) {
            this.calculateRenderData();
        }
    }
    ngAfterContentInit() {
        this.initSubscriptions();
    }
    ngAfterContentChecked() {
        this.render();
    }
    resize() {
        this.calculateRenderData();
        this.render();
    }
    ngOnDestroy() {
        this.subscriptions.forEach(sub => sub.unsubscribe());
    }
    compactLayout() {
        this.layout = compact(this.layout, this.compactType, this.cols);
    }
    getItemsRenderData() {
        return { ...this._gridItemsRenderData };
    }
    getItemRenderData(itemId) {
        return this._gridItemsRenderData[itemId];
    }
    calculateRenderData() {
        const clientRect = this.elementRef.nativeElement.getBoundingClientRect();
        this.gridCurrentHeight = this.height ?? (this.rowHeight === 'fit' ? clientRect.height : getGridHeight(this.layout, this.rowHeight, this.gap));
        this._gridItemsRenderData = layoutToRenderItems(this.config, clientRect.width, this.gridCurrentHeight);
        // Set Background CSS variables
        this.setBackgroundCssVariables(getRowHeightInPixels(this.config, this.gridCurrentHeight));
    }
    render() {
        this.renderer.setStyle(this.elementRef.nativeElement, 'height', `${this.gridCurrentHeight}px`);
        this.updateGridItemsStyles();
    }
    setBackgroundCssVariables(rowHeight) {
        const style = this.elementRef.nativeElement.style;
        if (this._backgroundConfig) {
            // structure
            style.setProperty('--gap', this.gap + 'px');
            style.setProperty('--row-height', rowHeight + 'px');
            style.setProperty('--columns', `${this.cols}`);
            style.setProperty('--border-width', (this._backgroundConfig.borderWidth ?? defaultBackgroundConfig.borderWidth) + 'px');
            // colors
            style.setProperty('--border-color', this._backgroundConfig.borderColor ?? defaultBackgroundConfig.borderColor);
            style.setProperty('--gap-color', this._backgroundConfig.gapColor ?? defaultBackgroundConfig.gapColor);
            style.setProperty('--row-color', this._backgroundConfig.rowColor ?? defaultBackgroundConfig.rowColor);
            style.setProperty('--column-color', this._backgroundConfig.columnColor ?? defaultBackgroundConfig.columnColor);
        }
        else {
            style.removeProperty('--gap');
            style.removeProperty('--row-height');
            style.removeProperty('--columns');
            style.removeProperty('--border-width');
            style.removeProperty('--border-color');
            style.removeProperty('--gap-color');
            style.removeProperty('--row-color');
            style.removeProperty('--column-color');
        }
    }
    updateGridItemsStyles() {
        this._gridItems.forEach(item => {
            const gridItemRenderData = this._gridItemsRenderData[item.id];
            if (gridItemRenderData == null) {
                console.error(`Couldn't find the specified grid item for the id: ${item.id}`);
            }
            else {
                item.setStyles(parseRenderItemToPixels(gridItemRenderData));
            }
        });
    }
    setGridBackgroundVisible(visible) {
        const classList = this.elementRef.nativeElement.classList;
        visible ? classList.add('cl-grid-background-visible') : classList.remove('cl-grid-background-visible');
    }
    initSubscriptions() {
        this.subscriptions = [
            this._gridItems.changes.pipe(startWith(this._gridItems), switchMap((gridItems) => {
                return merge(...gridItems.map((gridItem) => gridItem.dragStart$.pipe(map((event) => ({ event, gridItem, type: 'drag' })))), ...gridItems.map((gridItem) => gridItem.resizeStart$.pipe(map((event) => ({
                    event,
                    gridItem,
                    type: 'resize'
                }))))).pipe(exhaustMap(({ event, gridItem, type }) => {
                    // Emit drag or resize start events. Ensure that is start event is inside the zone.
                    this.ngZone.run(() => (type === 'drag' ? this.dragStarted : this.resizeStarted).emit(getDragResizeEventData(gridItem, this.layout)));
                    this.setGridBackgroundVisible(this._backgroundConfig?.show === 'whenDragging' || this._backgroundConfig?.show === 'always');
                    // Perform drag sequence
                    return this.performDragSequence$(gridItem, event, type).pipe(map((layout) => ({ layout, gridItem, type })));
                }));
            })).subscribe(({ layout, gridItem, type }) => {
                this.layout = layout;
                // Calculate new rendering data given the new layout.
                this.calculateRenderData();
                // Emit drag or resize end events.
                (type === 'drag' ? this.dragEnded : this.resizeEnded).emit(getDragResizeEventData(gridItem, layout));
                // Notify that the layout has been updated.
                this.layoutUpdated.emit(layout);
                this.setGridBackgroundVisible(this._backgroundConfig?.show === 'always');
            })
        ];
    }
    /**
     * Perform a general grid drag action, from start to end. A general grid drag action basically includes creating the placeholder element and adding
     * some class animations. calcNewStateFunc needs to be provided in order to calculate the new state of the layout.
     * @param gridItem that is been dragged
     * @param pointerDownEvent event (mousedown or touchdown) where the user initiated the drag
     * @param calcNewStateFunc function that return the new layout state and the drag element position
     */
    performDragSequence$(gridItem, pointerDownEvent, type) {
        return new Observable((observer) => {
            // Retrieve grid (parent) and gridItem (draggedElem) client rects.
            const gridElemClientRect = getMutableClientRect(this.elementRef.nativeElement);
            const dragElemClientRect = getMutableClientRect(gridItem.elementRef.nativeElement);
            const scrollableParent = typeof this.scrollableParent === 'string' ? document.getElementById(this.scrollableParent) : this.scrollableParent;
            this.renderer.addClass(gridItem.elementRef.nativeElement, 'no-transitions');
            this.renderer.addClass(gridItem.elementRef.nativeElement, 'cl-grid-item-dragging');
            const placeholderClientRect = {
                ...dragElemClientRect,
                left: dragElemClientRect.left - gridElemClientRect.left,
                top: dragElemClientRect.top - gridElemClientRect.top
            };
            this.createPlaceholderElement(placeholderClientRect, gridItem.placeholder);
            let newLayout;
            // TODO (enhancement): consider move this 'side effect' observable inside the main drag loop.
            //  - Pros are that we would not repeat subscriptions and takeUntil would shut down observables at the same time.
            //  - Cons are that moving this functionality as a side effect inside the main drag loop would be confusing.
            const scrollSubscription = this.ngZone.runOutsideAngular(() => (!scrollableParent ? NEVER : this.gridService.mouseOrTouchMove$(document).pipe(map((event) => ({
                pointerX: clPointerClientX(event),
                pointerY: clPointerClientY(event)
            })), clScrollIfNearElementClientRect$(scrollableParent, { scrollStep: this.scrollSpeed }))).pipe(takeUntil$1(clPointerUp(document))).subscribe());
            /**
             * Main subscription, it listens for 'pointer move' and 'scroll' events and recalculates the layout on each emission
             */
            const subscription = this.ngZone.runOutsideAngular(() => merge(combineLatest([
                this.gridService.mouseOrTouchMove$(document),
                ...(!scrollableParent ? [of({ top: 0, left: 0 })] : [
                    clGetScrollTotalRelativeDifference$(scrollableParent).pipe(startWith({ top: 0, left: 0 }) // Force first emission to allow CombineLatest to emit even no scroll event has occurred
                    )
                ])
            ])).pipe(takeUntil$1(clPointerUp(document))).subscribe((value) => {
                const [pointerDragEvent, scrollDifference] = value;
                pointerDragEvent.preventDefault();
                /**
                 * Set the new layout to be the layout in which the calcNewStateFunc would be executed.
                 * NOTE: using the mutated layout is the way to go by 'react-grid-layout' utils. If we don't use the previous layout,
                 * some utilities from 'react-grid-layout' would not work as expected.
                 */
                const currentLayout = newLayout || this.layout;
                // Get the correct newStateFunc depending on if we are dragging or resizing
                const calcNewStateFunc = type === 'drag' ? clGridItemDragging : clGridItemResizing;
                const { layout, draggedItemPos } = calcNewStateFunc(gridItem, {
                    layout: currentLayout,
                    rowHeight: this.rowHeight,
                    height: this.height,
                    cols: this.cols,
                    preventCollision: this.preventCollision,
                    gap: this.gap,
                }, this.compactType, {
                    pointerDownEvent,
                    pointerDragEvent,
                    gridElemClientRect,
                    dragElemClientRect,
                    scrollDifference
                });
                newLayout = layout;
                this.gridCurrentHeight = this.height ?? (this.rowHeight === 'fit' ? gridElemClientRect.height : getGridHeight(newLayout, this.rowHeight, this.gap));
                this._gridItemsRenderData = layoutToRenderItems({
                    cols: this.cols,
                    rowHeight: this.rowHeight,
                    height: this.height,
                    layout: newLayout,
                    preventCollision: this.preventCollision,
                    gap: this.gap,
                }, gridElemClientRect.width, gridElemClientRect.height);
                const newGridItemRenderData = { ...this._gridItemsRenderData[gridItem.id] };
                const placeholderStyles = parseRenderItemToPixels(newGridItemRenderData);
                // Put the real final position to the placeholder element
                this.placeholder.style.width = placeholderStyles.width;
                this.placeholder.style.height = placeholderStyles.height;
                this.placeholder.style.transform = `translateX(${placeholderStyles.left}) translateY(${placeholderStyles.top})`;
                // modify the position of the dragged item to be the once we want (for example the mouse position or whatever)
                this._gridItemsRenderData[gridItem.id] = {
                    ...draggedItemPos,
                    id: this._gridItemsRenderData[gridItem.id].id
                };
                this.setBackgroundCssVariables(this.rowHeight === 'fit' ? clGetGridItemRowHeight(newLayout, gridElemClientRect.height, this.gap) : this.rowHeight);
                this.render();
                // If we are performing a resize, and bounds have changed, emit event.
                // NOTE: Only emit on resize for now. Use case for normal drag is not justified for now. Emitting on resize is, since we may want to re-render the grid item or the placeholder in order to fit the new bounds.
                if (type === 'resize') {
                    const prevGridItem = currentLayout.find(item => item.id === gridItem.id);
                    const newGridItem = newLayout.find(item => item.id === gridItem.id);
                    // Check if item resized has changed, if so, emit resize change event
                    if (!clGridItemLayoutItemAreEqual(prevGridItem, newGridItem)) {
                        this.gridItemResize.emit({
                            width: newGridItemRenderData.width,
                            height: newGridItemRenderData.height,
                            gridItemRef: getDragResizeEventData(gridItem, newLayout).gridItemRef
                        });
                    }
                }
            }, (error) => observer.error(error), () => {
                this.ngZone.run(() => {
                    // Remove drag classes
                    this.renderer.removeClass(gridItem.elementRef.nativeElement, 'no-transitions');
                    this.renderer.removeClass(gridItem.elementRef.nativeElement, 'cl-grid-item-dragging');
                    this.addGridItemAnimatingClass(gridItem).subscribe();
                    // Consider destroying the placeholder after the animation has finished.
                    this.destroyPlaceholder();
                    if (newLayout) {
                        // TODO: newLayout should already be pruned. If not, it should have type Layout, not ClGridLayout as it is now.
                        // Prune react-grid-layout compact extra properties.
                        observer.next(newLayout.map(item => ({
                            id: item.id,
                            x: item.x,
                            y: item.y,
                            w: item.w,
                            h: item.h,
                            minW: item.minW,
                            minH: item.minH,
                            maxW: item.maxW,
                            maxH: item.maxH,
                            children: item.children,
                        })));
                    }
                    else {
                        // TODO: Need we really to emit if there is no layout change but drag started and ended?
                        observer.next(this.layout);
                    }
                    observer.complete();
                });
            }));
            return () => {
                scrollSubscription.unsubscribe();
                subscription.unsubscribe();
            };
        });
    }
    /**
     * It adds the `cl-grid-item-animating` class and removes it when the animated transition is complete.
     * This function is meant to be executed when the drag has ended.
     * @param gridItem that has been dragged
     */
    addGridItemAnimatingClass(gridItem) {
        return new Observable((observer) => {
            const duration = getTransformTransitionDurationInMs(gridItem.elementRef.nativeElement);
            if (duration === 0) {
                observer.next('');
                observer.complete();
                return;
            }
            this.renderer.addClass(gridItem.elementRef.nativeElement, 'cl-grid-item-animating');
            const handler = ((event) => {
                if (!event || (event.target === gridItem.elementRef.nativeElement && event.propertyName === 'transform')) {
                    this.renderer.removeClass(gridItem.elementRef.nativeElement, 'cl-grid-item-animating');
                    removeEventListener();
                    clearTimeout(timeout);
                    observer.next('');
                    observer.complete();
                }
            });
            // If a transition is short enough, the browser might not fire the `transitionend` event.
            // Since we know how long it's supposed to take, add a timeout with a 50% buffer that'll
            // fire if the transition hasn't completed when it was supposed to.
            const timeout = setTimeout(handler, duration * 1.5);
            const removeEventListener = this.renderer.listen(gridItem.elementRef.nativeElement, 'transitionend', handler);
        });
    }
    /** Creates placeholder element */
    createPlaceholderElement(clientRect, gridItemPlaceholder) {
        this.placeholder = this.renderer.createElement('div');
        this.placeholder.style.width = `${clientRect.width}px`;
        this.placeholder.style.height = `${clientRect.height}px`;
        this.placeholder.style.transform = `translateX(${clientRect.left}px) translateY(${clientRect.top}px)`;
        this.placeholder.classList.add('cl-grid-item-placeholder');
        this.renderer.appendChild(this.elementRef.nativeElement, this.placeholder);
        // Create and append custom placeholder if provided.
        // Important: Append it after creating & appending the container placeholder. This way we ensure parent bounds are set when creating the embeddedView.
        if (gridItemPlaceholder) {
            this.placeholderRef = this.viewContainerRef.createEmbeddedView(gridItemPlaceholder.templateRef, gridItemPlaceholder.data);
            this.placeholderRef.rootNodes.forEach(node => this.placeholder.appendChild(node));
            this.placeholderRef.detectChanges();
        }
        else {
            this.placeholder.classList.add('cl-grid-item-placeholder-default');
        }
    }
    /** Destroys the placeholder element and its ViewRef. */
    destroyPlaceholder() {
        this.placeholder?.remove();
        this.placeholderRef?.destroy();
        this.placeholder = this.placeholderRef = null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridComponent, deps: [{ token: ClGridService }, { token: i0.ElementRef }, { token: i0.ViewContainerRef }, { token: i0.Renderer2 }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClGridComponent, isStandalone: true, selector: "cl-grid", inputs: { scrollableParent: "scrollableParent", compactOnPropsChange: "compactOnPropsChange", preventCollision: "preventCollision", scrollSpeed: "scrollSpeed", compactType: "compactType", rowHeight: "rowHeight", cols: "cols", layout: "layout", gap: "gap", height: "height", backgroundConfig: "backgroundConfig" }, outputs: { layoutUpdated: "layoutUpdated", dragStarted: "dragStarted", resizeStarted: "resizeStarted", dragEnded: "dragEnded", resizeEnded: "resizeEnded", gridItemResize: "gridItemResize" }, providers: [
            {
                provide: GRID_ITEM_GET_RENDER_DATA_TOKEN,
                useFactory: clGridItemGetRenderDataFactoryFunc,
                deps: [ClGridComponent]
            }
        ], queries: [{ propertyName: "_gridItems", predicate: ClGridItemComponent, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<ng-content></ng-content>", styles: ["cl-grid{width:100%;display:block;position:relative}cl-grid.cl-grid-background:before{content:\"\";border:none;position:absolute;inset:0;z-index:0;transition:opacity .2s;opacity:0;background-image:repeating-linear-gradient(var(--border-color) 0 var(--border-width),var(--row-color) var(--border-width) calc(var(--row-height) - var(--border-width)),var(--border-color) calc(var(--row-height) - var(--border-width)) calc(var(--row-height)),var(--gap-color) calc(var(--row-height)) calc(var(--row-height) + var(--gap))),repeating-linear-gradient(90deg,var(--border-color) 0 var(--border-width),var(--column-color) var(--border-width) calc(100% - (var(--border-width) + var(--gap))),var(--border-color) calc(100% - (var(--border-width) + var(--gap))) calc(100% - var(--gap)),var(--gap-color) calc(100% - var(--gap)) 100%);background-size:calc((100% + var(--gap)) / var(--columns)) calc(var(--row-height) + var(--gap));background-position:0 0}cl-grid.cl-grid-background.cl-grid-background-visible:before{opacity:1}cl-grid cl-grid-item.cl-grid-item-dragging,cl-grid cl-grid-item.cl-grid-item-animating{z-index:1000}cl-grid cl-grid-item.no-transitions{transition:none!important}cl-grid .cl-grid-item-placeholder{z-index:0;position:absolute;transition:all .15s ease;transition-property:transform}cl-grid .cl-grid-item-placeholder-default{background-color:var(--cl-neutral-300);opacity:.6}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClGridComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-grid', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: GRID_ITEM_GET_RENDER_DATA_TOKEN,
                            useFactory: clGridItemGetRenderDataFactoryFunc,
                            deps: [ClGridComponent]
                        }
                    ], template: "<ng-content></ng-content>", styles: ["cl-grid{width:100%;display:block;position:relative}cl-grid.cl-grid-background:before{content:\"\";border:none;position:absolute;inset:0;z-index:0;transition:opacity .2s;opacity:0;background-image:repeating-linear-gradient(var(--border-color) 0 var(--border-width),var(--row-color) var(--border-width) calc(var(--row-height) - var(--border-width)),var(--border-color) calc(var(--row-height) - var(--border-width)) calc(var(--row-height)),var(--gap-color) calc(var(--row-height)) calc(var(--row-height) + var(--gap))),repeating-linear-gradient(90deg,var(--border-color) 0 var(--border-width),var(--column-color) var(--border-width) calc(100% - (var(--border-width) + var(--gap))),var(--border-color) calc(100% - (var(--border-width) + var(--gap))) calc(100% - var(--gap)),var(--gap-color) calc(100% - var(--gap)) 100%);background-size:calc((100% + var(--gap)) / var(--columns)) calc(var(--row-height) + var(--gap));background-position:0 0}cl-grid.cl-grid-background.cl-grid-background-visible:before{opacity:1}cl-grid cl-grid-item.cl-grid-item-dragging,cl-grid cl-grid-item.cl-grid-item-animating{z-index:1000}cl-grid cl-grid-item.no-transitions{transition:none!important}cl-grid .cl-grid-item-placeholder{z-index:0;position:absolute;transition:all .15s ease;transition-property:transform}cl-grid .cl-grid-item-placeholder-default{background-color:var(--cl-neutral-300);opacity:.6}\n"] }]
        }], ctorParameters: () => [{ type: ClGridService }, { type: i0.ElementRef }, { type: i0.ViewContainerRef }, { type: i0.Renderer2 }, { type: i0.NgZone }], propDecorators: { _gridItems: [{
                type: ContentChildren,
                args: [ClGridItemComponent, { descendants: true }]
            }], layoutUpdated: [{
                type: Output
            }], dragStarted: [{
                type: Output
            }], resizeStarted: [{
                type: Output
            }], dragEnded: [{
                type: Output
            }], resizeEnded: [{
                type: Output
            }], gridItemResize: [{
                type: Output
            }], scrollableParent: [{
                type: Input
            }], compactOnPropsChange: [{
                type: Input
            }], preventCollision: [{
                type: Input
            }], scrollSpeed: [{
                type: Input
            }], compactType: [{
                type: Input
            }], rowHeight: [{
                type: Input
            }], cols: [{
                type: Input
            }], layout: [{
                type: Input
            }], gap: [{
                type: Input
            }], height: [{
                type: Input
            }], backgroundConfig: [{
                type: Input
            }] } });

/**
 * Removes and item from an array. Returns a new array instance (it doesn't mutate the source array).
 * @param array source array to be returned without the element to remove
 * @param condition function that will return true for the item that we want to remove
 */
function clArrayRemoveItem(array, condition) {
    const arrayCopy = [...array];
    const index = array.findIndex((item) => condition(item));
    if (index > -1) {
        arrayCopy.splice(index, 1);
    }
    return arrayCopy;
}

/*
 * Public API Surface of grid
 */

class ClResizableGridProperties {
    constructor() {
        this.gap = 8;
        this.cols = 4;
        this.rowHeight = 80;
        this.id = 'default0';
        this.disableDrag = false;
        this.disableResize = false;
        this.disableRemove = false;
        this.preventCollision = false;
        this.compactType = 'vertical';
        this.type = ClComponentTypes.resizableGrid;
        this.transition = 'transform 500ms ease, width 500ms ease, height 500ms ease';
        this.backgroundConfig = {
            show: 'always',
            borderWidth: 1,
            gapColor: 'transparent',
            rowColor: 'rgba(110, 122, 146, 0.01)',
            borderColor: 'rgba(110, 122, 146, 0.25)',
            columnColor: 'rgba(110, 122, 146, 0.01)'
        };
        this.layout = [
            { id: '0', x: 0, y: 0, w: 1, h: 1, children: [] },
            { id: '1', x: 1, y: 1, w: 1, h: 1, children: [] },
            { id: '2', x: 2, y: 2, w: 1, h: 1, children: [] },
            { id: '3', x: 3, y: 3, w: 1, h: 1, children: [] },
            { id: '4', x: 0, y: 4, w: 1, h: 1, children: [] },
            { id: '5', x: 1, y: 5, w: 1, h: 1, children: [] },
            { id: '6', x: 2, y: 6, w: 1, h: 1, children: [] },
            { id: '7', x: 3, y: 7, w: 1, h: 1, children: [] },
            { id: '8', x: 0, y: 8, w: 1, h: 1, children: [] },
            { id: '9', x: 1, y: 9, w: 1, h: 1, children: [] },
            { id: '10', x: 2, y: 10, w: 1, h: 1, children: [] },
            { id: '11', x: 3, y: 11, w: 1, h: 1, children: [] }
        ];
    }
}

class ClResizableGridComponent extends ClBaseContainerComponent {
    constructor(cdr) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.cdr = cdr;
        /** Emits when layout change */
        this.layoutUpdated = new EventEmitter();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClResizableGridProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        this.properties.layout = clGridCompact(this.properties.layout, this.properties.compactType, this.properties.cols);
        this.cdr.detectChanges();
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.gridItemContents = this.gridContentItems;
        });
    }
    onLayoutUpdated(layout) {
        this.properties.layout = layout;
        if (this.properties.onLayoutUpdated) {
            this.properties.onLayoutUpdated(layout);
        }
    }
    /**
     * Fired when a mousedown happens on the remove grid item button.
     * Stops the event from propagating an causing the drag to start.
     * We don't want to drag when mousedown is fired on remove icon button.
     */
    stopEventPropagation(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    /** Removes the item from the layout */
    removeItem(id) {
        // Important: Don't mutate the array. Let Angular know that the layout has changed creating a new reference.
        this.properties.layout = clArrayRemoveItem(this.properties.layout, (item) => item.id === id);
    }
    onResizeEnded(event) {
        if (this.properties.onResizeEnded) {
            this.properties.onResizeEnded(event);
        }
    }
    onResizeStarted(event) {
        if (this.properties.onResizeStarted) {
            this.properties.onResizeStarted(event);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClResizableGridComponent, isStandalone: true, selector: "cl-resizable-grid", inputs: { properties: "properties" }, outputs: { layoutUpdated: "layoutUpdated" }, queries: [{ propertyName: "gridContentItems", predicate: ClResizableGridItemComponent }], usesInheritance: true, ngImport: i0, template: "<cl-grid [gap]=\"properties.gap!\" [cols]=\"properties.cols\" [layout]=\"properties.layout!\"\n  [rowHeight]=\"properties.rowHeight\" (resizeEnded)=\"onResizeEnded($event)\" [compactType]=\"properties.compactType\"\n  (layoutUpdated)=\"onLayoutUpdated($event)\" (resizeStarted)=\"onResizeStarted($event)\"\n  [preventCollision]=\"properties.preventCollision\" [backgroundConfig]=\"properties.backgroundConfig!\">\n\n  <!-- @for (component of properties.layout; let componentIndex = $index; track component) { -->\n  @for (component of gridItemContents; track component) {\n    <cl-grid-item [id]=\"component.id\" [transition]=\"properties.transition!\" [draggable]=\"!properties.disableDrag\"\n      [resizable]=\"!properties.disableResize!\">\n\n      <div class=\"grid-item-content\">\n        <!-- @for (gridItem of gridItemContents; track gridItem) { -->\n          <ng-container *ngTemplateOutlet=\"component.contentTemplate\"></ng-container>\n        <!-- } -->\n      </div>\n\n      @if (properties.disableRemove) {\n        <div class=\"grid-item-remove-handle\" (click)=\"removeItem(component.id)\" (mousedown)=\"stopEventPropagation($event)\">\n        </div>\n      }\n    </cl-grid-item>\n  }\n</cl-grid>\n", styles: [".grid-item-content{box-sizing:border-box;display:flex;width:100%;height:100%;cursor:grab;-webkit-user-select:none;user-select:none;align-items:center;justify-content:center;border-width:1px;border-style:dashed;--tw-border-opacity: 1;border-color:rgb(115 115 115 / var(--tw-border-opacity));background-color:rgb(229 229 229 / var(--tw-bg-opacity));--tw-bg-opacity: .4}.grid-item-remove-handle{position:absolute;top:0;right:0;display:flex;cursor:pointer;justify-content:center;--tw-text-opacity: 1;color:rgba(var(--cl-warn-rgb),var(--tw-text-opacity));width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.grid-item-remove-handle svg{width:1.25rem;height:1.25rem}.grid-item-remove-handle:after{content:\"x\";font-size:1rem;font-weight:400;--tw-text-opacity: 1;color:rgba(var(--cl-warn-rgb),var(--tw-text-opacity))}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ClGridComponent, selector: "cl-grid", inputs: ["scrollableParent", "compactOnPropsChange", "preventCollision", "scrollSpeed", "compactType", "rowHeight", "cols", "layout", "gap", "height", "backgroundConfig"], outputs: ["layoutUpdated", "dragStarted", "resizeStarted", "dragEnded", "resizeEnded", "gridItemResize"] }, { kind: "component", type: ClGridItemComponent, selector: "cl-grid-item", inputs: ["minW", "minH", "maxW", "maxH", "transition", "id", "dragStartThreshold", "draggable", "resizable"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-resizable-grid', imports: [
                        CommonModule,
                        ClGridComponent,
                        ClGridItemComponent,
                    ], template: "<cl-grid [gap]=\"properties.gap!\" [cols]=\"properties.cols\" [layout]=\"properties.layout!\"\n  [rowHeight]=\"properties.rowHeight\" (resizeEnded)=\"onResizeEnded($event)\" [compactType]=\"properties.compactType\"\n  (layoutUpdated)=\"onLayoutUpdated($event)\" (resizeStarted)=\"onResizeStarted($event)\"\n  [preventCollision]=\"properties.preventCollision\" [backgroundConfig]=\"properties.backgroundConfig!\">\n\n  <!-- @for (component of properties.layout; let componentIndex = $index; track component) { -->\n  @for (component of gridItemContents; track component) {\n    <cl-grid-item [id]=\"component.id\" [transition]=\"properties.transition!\" [draggable]=\"!properties.disableDrag\"\n      [resizable]=\"!properties.disableResize!\">\n\n      <div class=\"grid-item-content\">\n        <!-- @for (gridItem of gridItemContents; track gridItem) { -->\n          <ng-container *ngTemplateOutlet=\"component.contentTemplate\"></ng-container>\n        <!-- } -->\n      </div>\n\n      @if (properties.disableRemove) {\n        <div class=\"grid-item-remove-handle\" (click)=\"removeItem(component.id)\" (mousedown)=\"stopEventPropagation($event)\">\n        </div>\n      }\n    </cl-grid-item>\n  }\n</cl-grid>\n", styles: [".grid-item-content{box-sizing:border-box;display:flex;width:100%;height:100%;cursor:grab;-webkit-user-select:none;user-select:none;align-items:center;justify-content:center;border-width:1px;border-style:dashed;--tw-border-opacity: 1;border-color:rgb(115 115 115 / var(--tw-border-opacity));background-color:rgb(229 229 229 / var(--tw-bg-opacity));--tw-bg-opacity: .4}.grid-item-remove-handle{position:absolute;top:0;right:0;display:flex;cursor:pointer;justify-content:center;--tw-text-opacity: 1;color:rgba(var(--cl-warn-rgb),var(--tw-text-opacity));width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.grid-item-remove-handle svg{width:1.25rem;height:1.25rem}.grid-item-remove-handle:after{content:\"x\";font-size:1rem;font-weight:400;--tw-text-opacity: 1;color:rgba(var(--cl-warn-rgb),var(--tw-text-opacity))}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], layoutUpdated: [{
                type: Output
            }], gridContentItems: [{
                type: ContentChildren,
                args: [ClResizableGridItemComponent]
            }] } });

class ClDragDropDirective {
    constructor() {
        this.selectedFiles = new EventEmitter();
        this._background = '';
    }
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        this._background = "#E7E9EA";
    }
    onDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this._background = "";
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        const files = event.dataTransfer?.files;
        this.selectedFiles.emit(files);
        this._background = "";
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: ClDragDropDirective, isStandalone: true, selector: "[clDragDropUpload]", outputs: { selectedFiles: "selectedFiles" }, host: { listeners: { "dragover": "onDragOver($event)", "dragleave": "onDragLeave($event)", "drop": "onDrop($event)" }, properties: { "style.background": "this._background" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[clDragDropUpload]',
                }]
        }], propDecorators: { selectedFiles: [{
                type: Output
            }], _background: [{
                type: HostBinding,
                args: ["style.background"]
            }], onDragOver: [{
                type: HostListener,
                args: ["dragover", ["$event"]]
            }], onDragLeave: [{
                type: HostListener,
                args: ["dragleave", ["$event"]]
            }], onDrop: [{
                type: HostListener,
                args: ["drop", ["$event"]]
            }] } });

class ClDragDropUploadComponent extends ClBaseComponent {
    getImageUrl() {
        if (this.stackLayoutProperties !== undefined && this.stackLayoutProperties.isBackgroundImage !== undefined) {
            return `url(${this.stackLayoutProperties?.backgroundImageUrl})`;
        }
        else {
            return 'none';
        }
    }
    constructor(uploadService) {
        super();
        this.uploadService = uploadService;
        this.accept = '';
        this.localUrl = [];
        this.selectedFiles = [];
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        //--------------------------------------------
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
        this.errorTextProperties = {
            label: '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm text-failed justify-center' },
            id: 'dragDropUploadErrorText',
        };
        this.duplicateErrorTextProperties = {
            label: '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm text-failed justify-start' },
            id: 'dragDropUploadDuplicateErrorText',
        };
        this.deleteIconProperties = {
            id: 'dragDropDeleteIcon',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5 text-red-400' },
            iconName: 'heroicons_outline:trash',
        };
        this.dragDropTextProperties = {
            label: 'Drag and drop files here',
            type: ClComponentTypes.label,
            style: { cssClasses: 'mt-2 text-base leading-6 font-semibold text-neutral-600' },
            id: 'labelDragDropText',
        };
        this.orTextProperties = {
            label: 'or',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-md leading-6 font-semibold text-neutral-600' },
            id: 'labelOrText',
        };
        this.browseFileTextProperties = {
            label: 'Browse file',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-base leading-6 font-normal text-primary-300' },
            id: 'labelBrowseText',
        };
        this.fileUploadIconProperties = {
            id: 'uploadTileIcon',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-6 text-primary' },
            iconName: 'fss_icons:file-upload',
        };
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnChanges(changes) {
        if (this.preLoadImageProperties != undefined) {
            // calling set preview image properties method
            this.setPreviewImageProperties(this.preLoadImageProperties.imageUrl);
        }
        if (this.preLoadMultiFileProperties != undefined && this.properties.isMultiple) {
            let listUpdate = this.preLoadMultiFileProperties.map((file) => file = { name: file.fileName, base64: `data:${file.base64DataType};base64,${file.base64val}` });
            this.pushBase64Files(listUpdate);
        }
    }
    ngOnInit() {
        // calling set default property value function
        this.setDefaultPropertyValue();
        this.properties.uploadIcon ??= 'fss_icons:cloud-upload';
        if (this.properties.preLoadImageProperties) {
            this.setPreviewImageProperties(this.properties.preLoadImageProperties.imageUrl);
        }
        this.dimensionTitleProperties = {
            label: this.properties.dimensionTitle ?? 'Supported dimensions:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelDimensionsTitleText',
        };
        this.dimensionDescProperties = {
            label: this.properties.dimension ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelDimensionsDescText',
        };
        this.supportedTitleProperties = {
            label: this.properties.supportedFileTitle ?? 'Supported formats:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelSupportedTitleText',
        };
        this.supportedDescProperties = {
            label: this.properties.supportedFile ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelDimensionsDescText',
        };
        this.maxLimitTitleProperties = {
            label: this.properties.maxLimitTitle ?? 'Dimension',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelMaxLimitTitleText',
        };
        this.maxLimitDescProperties = {
            label: this.properties.maxLimit ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelMaxLimitDescText',
        };
        this.maxAllowedFileTitleTextProperties = {
            label: this.properties.maxAllowedFileHintTitleText ?? 'Max Allowed File:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelAllowedFileTitleText',
        };
        this.maxAllowedFileDescTextProperties = {
            label: this.properties.maxAllowedFileHintDescText,
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelAllowedFileDescText',
        };
        this.fileDisplayGridProperties = {
            colsPerRow: 2,
        };
        if (this.properties.allowedFileTypes !== undefined) {
            this.accept = this.properties.allowedFileTypes.join(',');
        }
    }
    /**
     * onFileUpload
     *
     * This function will call the service to upload the file
     *
     * @param event
     */
    onFileUpload(event) {
        // calling upload file method
        const result = this.uploadService.uploadFile(event, this.accept, this.properties.maxLimitInKb ? this.properties.maxLimitInKb : 0, this.properties.uploadError, this.properties.fileGridView);
        if (this.properties.maxAllowedFiles && ((Number(result().length) + Number(this.selectedFiles.length)) > this.properties.maxAllowedFiles)) {
            this.fileResult[0].errorMessage = this.properties.uploadError?.maxFileAllowedErrorMsg ?? 'File count exceeds allowed limit';
            this.errorTextProperties.label = this.fileResult[0].errorMessage;
            return;
        }
        // .pipe(take(1))
        // .subscribe((result: File[]) => {
        // calling reset view method
        if (result.length == 0 && this.selectedFiles.length == 0) {
            this.resetView();
        }
        result().forEach((x) => {
            if (x.extension == undefined) {
                const fileNameParts = x.name.split('.');
                const fileExtension = fileNameParts[fileNameParts.length - 1].toLowerCase();
                x.extension = fileExtension;
            }
        });
        this.selectedFiles = [...this.selectedFiles, ...result()];
        // this.selectedFiles = result;
        // calling get file size method
        // this.fileResult = this.uploadService.getFileSize(this.selectedFiles[0]);
        // this.fileResult = this.uploadService.fileResult.length>0 ?this.uploadService.fileResult : this.fileResult.push( { fileSize: 0, fileSizeDesc: '', errorMessage: undefined }) ;
        if (this.uploadService.fileResult.length > 0) {
            this.fileResult = this.uploadService.fileResult;
        }
        else {
            this.fileResult.push({ fileSize: 0, fileSizeDesc: '', errorMessage: undefined });
        }
        if (this.fileResult != undefined && this.fileResult.length > 0) {
            this.errorTextProperties.label = this.fileResult[0].errorMessage;
        }
        // calling show preview image method
        // this.showPreviewImage();
        // calling push selected files method
        this.pushSelectedFiles();
        // });
    }
    /**
     * resetView
     *
     * This function will reset the entire view
     */
    resetView() {
        this.localUrl = [];
        this.selectedFiles = [];
        this.preLoadImageProperties = undefined;
        this.properties.preLoadImageProperties = undefined;
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
    }
    /**
     * show preview image
     *
     * This method will generate the url of the selected file for preview
     *
     * @param files - array of files
     */
    showPreviewImage() {
        for (const file of this.selectedFiles) {
            const reader = new FileReader();
            reader.onload = (e) => {
                // calling set preview image properties method
                this.setPreviewImageProperties(e.target.result);
            };
            reader.readAsDataURL(file);
        }
    }
    setPreviewImageProperties(value) {
        this.localUrl.push(value);
        this.stackLayoutProperties = {
            isBackgroundImage: true,
            id: 'stackLayoutDragDrop',
            backgroundImageUrl: this.localUrl[0],
            styleProperties: {
                cornerRadius: 'rounded-md',
                width: this.properties.width,
                height: this.properties.height,
                bgColor: this.properties.afterUploadBgColor,
            },
            child: {
                layout: 'button',
            },
        };
    }
    /**
     * files dropped
     *
     * This function is called when the file is dropped in the UI
     *
     * @param selectedFiles - selected Files array which were dropped
     */
    filesDropped(selectedFiles) {
        this.selectedFiles = selectedFiles;
        // calling show preview image method
        // this.showPreviewImage(this.selectedFiles);
        // calling push selected files method
        this.pushSelectedFiles();
    }
    /**
     * on delete file
     *
     * this function will delete the selected file
     */
    onDeleteFile() {
        // calling reset view method
        this.resetView();
        // calling push selected files method
        this.pushSelectedFiles();
    }
    pushBase64Files(base64Files) {
        if (!Array.isArray(base64Files) || base64Files.length === 0) {
            return;
        }
        const processedFiles = base64Files.map(file => {
            const byteString = atob(file.base64.split(',')[1]); // Decode Base64
            const mimeString = file.base64.split(',')[0].split(':')[1].split(';')[0]; // Extract MIME type
            const arrayBuffer = new ArrayBuffer(byteString.length);
            const uintArray = new Uint8Array(arrayBuffer);
            for (let i = 0; i < byteString.length; i++) {
                uintArray[i] = byteString.charCodeAt(i);
            }
            const blob = new Blob([uintArray], { type: mimeString });
            const newFile = new File([blob], file.name, { type: mimeString });
            // Add extension manually if it's not already set
            if (!newFile.extension) {
                const fileNameParts = newFile.name.split('.');
                const fileExtension = fileNameParts[fileNameParts.length - 1].toLowerCase();
                newFile.extension = fileExtension;
            }
            return newFile;
        });
        // Push to selectedFiles
        this.selectedFiles.push(...processedFiles);
        // Call existing method to handle further processing
        this.pushSelectedFiles();
    }
    /**
     * push selected files
     *
     * this function will call the callback function
     */
    pushSelectedFiles() {
        // calling show preview image method
        this.showPreviewImage();
        // calling on file upload method
        if (this.properties.onFileUpload) {
            this.properties.onFileUpload(this.selectedFiles);
        }
        const uniqueFileNames = new Set();
        if (Array.isArray(this.selectedFiles)) {
            this.selectedFiles.forEach((selectedFile) => {
                const fileName = selectedFile.name;
                selectedFile.error = undefined;
                // Check if the file name is already in the set
                if (uniqueFileNames.has(fileName)) {
                    selectedFile.error = 'duplicate';
                    // File name is a duplicate
                    this.fileResult.push({
                        fileSize: 0,
                        fileSizeDesc: fileName,
                        errorMessage: 'Duplicate file',
                    });
                }
                else {
                    // File name is unique, add it to the set
                    uniqueFileNames.add(fileName);
                }
            });
        }
        if (this.fileResult != undefined && this.fileResult.length > 0) {
            this.duplicateErrorTextProperties.label = this.fileResult[this.fileResult.length - 1].errorMessage;
        }
    }
    setDefaultPropertyValue() {
        this.properties.isMultiple ??= true;
    }
    onDeleteEachFile(index) {
        if (index >= 0 && index < this.selectedFiles.length) {
            // Remove the element at the specified index
            const deletedFile = this.selectedFiles.splice(index, 1)[0];
            // Find the first occurrence of the file with the same name in the selectedFiles array
            const matchingFileIndex = this.selectedFiles.findIndex(file => file.name === deletedFile.name);
            // If found, remove the 'duplicate' error
            if (matchingFileIndex !== -1) {
                this.selectedFiles[matchingFileIndex].error = undefined;
            }
            if (this.selectedFiles.length == 1) {
                this.localUrl = [];
                this.showPreviewImage();
            }
            if (this.properties.onFileUpload) {
                this.properties.onFileUpload(this.selectedFiles);
            }
        }
    }
    onFileClicked(fileName) {
        if (this.properties.onFileClicked) {
            this.properties.onFileClicked(fileName);
        }
    }
    displaySize(sizeInBytes) {
        const sizeInKB = this.convertBytesToKB(sizeInBytes);
        const sizeInMB = this.convertBytesToMB(sizeInBytes);
        if (sizeInMB >= 1) {
            return `${sizeInMB.toFixed(2)} MB`;
        }
        else {
            return `${sizeInKB.toFixed(2)} KB`;
        }
    }
    convertBytesToMB(bytes) {
        return bytes / (1024 * 1024);
    }
    convertBytesToKB(bytes) {
        return bytes / 1024;
    }
    createIconProperties(id, iconName) {
        return {
            id: `${id}TileIcon`,
            type: ClComponentTypes.icon,
            iconName: `fss_icons:${iconName}`,
        };
    }
    getFileIconProperties(file) {
        const error = file.error !== undefined;
        const extension = error ? undefined : file.extension;
        const iconPropertiesMap = {
            'csv': this.createIconProperties('csv', 'csv-file'),
            'txt': this.createIconProperties('txt', 'txt-file'),
            'docx': this.createIconProperties('docx', 'doc-file'),
            'xlsx': this.createIconProperties('xlsx', 'xlx-file'),
            'xls': this.createIconProperties('xls', 'xls-file'),
            'pdf': this.createIconProperties('pdf', 'pdf-file'),
            'png': this.createIconProperties('png', 'png-file'),
            'jpg': this.createIconProperties('jpg', 'jpg-file'),
            'jfif': this.createIconProperties('jfif', 'gif-file'),
            'svg': this.createIconProperties('svg', 'svg-file'),
            'json': this.createIconProperties('json', 'json-file'),
            'html': this.createIconProperties('html', 'html-file'),
        };
        return iconPropertiesMap[extension] || this.fileUploadIconProperties;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropUploadComponent, deps: [{ token: i1$6.ClUploadService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDragDropUploadComponent, isStandalone: true, selector: "cl-drag-drop-upload", inputs: { properties: "properties", updatedUploadIconProperties: "updatedUploadIconProperties", preLoadImageProperties: "preLoadImageProperties", preLoadMultiFileProperties: "preLoadMultiFileProperties" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClDragDropUploadComponent),
                multi: true
            },
            ClUploadService
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "  @if ((properties.preLoadImageProperties == undefined && selectedFiles.length <=0) && (properties.fileGridView == undefined || properties.fileGridView == false)){\n  <div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if (fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flex-col mt-1 gap-1 justify-center\">\n     @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n  </div>\n  }\n<!-- Image preview -->\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==undefined || properties.fileGridView==false)){\n<div>\n  <div id=\"stackLayoutProperties.id\" class=\"stack-layout-container {{stackLayoutProperties?.styleProperties?.bgColor}} {{stackLayoutProperties?.styleProperties?.height}} {{stackLayoutProperties?.styleProperties?.width}} {{stackLayoutProperties?.styleProperties?.cornerRadius}}\" [ngStyle]=\"{'background-image': getImageUrl()}\">\n      <div class=\"flex flex-row justify-end\">\n\n      <button mat-raised-button type=\"button\"\n        (click)=\"fileUpload.value = ''; stackLayoutProperties.backgroundImageUrl = ''; onDeleteFile()\"\n        class=\"py-2 px-3 mt-4 mr-4 bg-white rounded-xl items-center justify-center\">\n\n        <cl-icon [properties]=\"deleteIconProperties\"></cl-icon>\n      </button>\n    </div>\n  </div>\n</div>\n}\n\n@if((properties.preLoadImageProperties == undefined && selectedFiles.length >=0) &&  (properties.fileGridView==true)){\n<div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if(fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flow-row mt-1 gap-1 justify-center\">\n\n    @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n</div>\n}\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==true)){\n<div\n  class=\"mt-8\">\n  <div class=\"grid w-full items-center sm:grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 {{fileDisplayGridProperties?.styleProperties?.gap || 'gap-4'}}\">\n    @for (file of selectedFiles; track file; let fileIndex = $index;) {\n    <div>\n      <div\n        class=\" {{ (fileResult[fileResult.length-1].errorMessage != undefined && file?.error=='duplicate' ) ? 'dashed-border-failed rounded-lg margin-top-error' : 'custom-background rounded-lg' }}\">\n\n        <div class=\"flex flex-row gap-4 justify-between\">\n          <!-- <div> -->\n          <div class=\"flex flex-row gap-1 justify-center mouse-pointer\" (click)=\"onFileClicked(file.name)\">\n            <ng-container>\n              <cl-icon [properties]=\"getFileIconProperties(file)\"\n                class=\" ml-1 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </ng-container>\n            <div class=\"flex flex-col gap-1 w-fit mt-2\">\n              <label class=\"text-primary font-normal text-[16px]\">{{ file.name }}</label>\n              <label class=\"text-xs text-neutral\">Size: {{ displaySize(file.size) }}</label>\n            </div>\n          </div>\n          <!-- </div> -->\n          <div>\n            <button mat-raised-button type=\"button\" (click)=\"fileUpload.value = ''; onDeleteEachFile(fileIndex)\"\n              class=\"rounded-xl items-center justify-center\">\n              <cl-icon [properties]=\"deleteIconProperties\"\n                class=\" ml-2 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </button>\n          </div>\n        </div>\n      </div>\n      <!-- Error message -->\n      @if((fileResult.length > 0 && fileResult[fileResult.length-1] != undefined) && file?.error=='duplicate'){\n      <ng-container>\n        <cl-label [properties]=\"duplicateErrorTextProperties\"></cl-label>\n      </ng-container>\n      }\n      <!-- Error message -->\n    </div>\n    }\n  </div>\n</div>\n}\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"properties.isMultiple\" (change)=\"onFileUpload($event)\" class=\"hidden pointer-events-none\" />\n", styles: [".container{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='%23333' stroke-width='1' stroke-dasharray='6' stroke-dashoffset='0' stroke-linecap='round'/%3e%3c/svg%3e\")!important}.custom-background{background-color:#f3f8ff}.margin-top-error{margin-top:16px}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "directive", type: ClDragDropDirective, selector: "[clDragDropUpload]", outputs: ["selectedFiles"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropUploadComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-drag-drop-upload', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClDragDropUploadComponent),
                            multi: true
                        },
                        ClUploadService
                    ], imports: [
                        NgStyle,
                        MatIconModule,
                        ClIconComponent,
                        ClCardComponent,
                        ClLabelComponent,
                        ClDragDropDirective,
                    ], template: "  @if ((properties.preLoadImageProperties == undefined && selectedFiles.length <=0) && (properties.fileGridView == undefined || properties.fileGridView == false)){\n  <div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if (fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flex-col mt-1 gap-1 justify-center\">\n     @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n  </div>\n  }\n<!-- Image preview -->\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==undefined || properties.fileGridView==false)){\n<div>\n  <div id=\"stackLayoutProperties.id\" class=\"stack-layout-container {{stackLayoutProperties?.styleProperties?.bgColor}} {{stackLayoutProperties?.styleProperties?.height}} {{stackLayoutProperties?.styleProperties?.width}} {{stackLayoutProperties?.styleProperties?.cornerRadius}}\" [ngStyle]=\"{'background-image': getImageUrl()}\">\n      <div class=\"flex flex-row justify-end\">\n\n      <button mat-raised-button type=\"button\"\n        (click)=\"fileUpload.value = ''; stackLayoutProperties.backgroundImageUrl = ''; onDeleteFile()\"\n        class=\"py-2 px-3 mt-4 mr-4 bg-white rounded-xl items-center justify-center\">\n\n        <cl-icon [properties]=\"deleteIconProperties\"></cl-icon>\n      </button>\n    </div>\n  </div>\n</div>\n}\n\n@if((properties.preLoadImageProperties == undefined && selectedFiles.length >=0) &&  (properties.fileGridView==true)){\n<div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if(fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flow-row mt-1 gap-1 justify-center\">\n\n    @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n</div>\n}\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==true)){\n<div\n  class=\"mt-8\">\n  <div class=\"grid w-full items-center sm:grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 {{fileDisplayGridProperties?.styleProperties?.gap || 'gap-4'}}\">\n    @for (file of selectedFiles; track file; let fileIndex = $index;) {\n    <div>\n      <div\n        class=\" {{ (fileResult[fileResult.length-1].errorMessage != undefined && file?.error=='duplicate' ) ? 'dashed-border-failed rounded-lg margin-top-error' : 'custom-background rounded-lg' }}\">\n\n        <div class=\"flex flex-row gap-4 justify-between\">\n          <!-- <div> -->\n          <div class=\"flex flex-row gap-1 justify-center mouse-pointer\" (click)=\"onFileClicked(file.name)\">\n            <ng-container>\n              <cl-icon [properties]=\"getFileIconProperties(file)\"\n                class=\" ml-1 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </ng-container>\n            <div class=\"flex flex-col gap-1 w-fit mt-2\">\n              <label class=\"text-primary font-normal text-[16px]\">{{ file.name }}</label>\n              <label class=\"text-xs text-neutral\">Size: {{ displaySize(file.size) }}</label>\n            </div>\n          </div>\n          <!-- </div> -->\n          <div>\n            <button mat-raised-button type=\"button\" (click)=\"fileUpload.value = ''; onDeleteEachFile(fileIndex)\"\n              class=\"rounded-xl items-center justify-center\">\n              <cl-icon [properties]=\"deleteIconProperties\"\n                class=\" ml-2 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </button>\n          </div>\n        </div>\n      </div>\n      <!-- Error message -->\n      @if((fileResult.length > 0 && fileResult[fileResult.length-1] != undefined) && file?.error=='duplicate'){\n      <ng-container>\n        <cl-label [properties]=\"duplicateErrorTextProperties\"></cl-label>\n      </ng-container>\n      }\n      <!-- Error message -->\n    </div>\n    }\n  </div>\n</div>\n}\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"properties.isMultiple\" (change)=\"onFileUpload($event)\" class=\"hidden pointer-events-none\" />\n", styles: [".container{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='%23333' stroke-width='1' stroke-dasharray='6' stroke-dashoffset='0' stroke-linecap='round'/%3e%3c/svg%3e\")!important}.custom-background{background-color:#f3f8ff}.margin-top-error{margin-top:16px}\n"] }]
        }], ctorParameters: () => [{ type: i1$6.ClUploadService }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], updatedUploadIconProperties: [{
                type: Input
            }], preLoadImageProperties: [{
                type: Input
            }], preLoadMultiFileProperties: [{
                type: Input
            }] } });

var ClFileType;
(function (ClFileType) {
    ClFileType["csv"] = "text/csv";
    ClFileType["png"] = "image/png";
    ClFileType["txt"] = "text/plain";
    ClFileType["html"] = "text/html";
    ClFileType["jpg"] = "image/jpeg";
    ClFileType["svg"] = "image/svg+xml";
    ClFileType["pdf"] = "application/pdf";
    ClFileType["json"] = "application/json";
    ClFileType["image"] = "image/jpeg,image/png,image/svg+xml";
    ClFileType["xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    ClFileType["docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
})(ClFileType || (ClFileType = {}));
class ClDragDropStyleProperties {
}
class ClDragDropProperties {
    constructor() {
        this.id = 'default0';
        this.isMultiple = false;
        this.label = 'Drag and Drop Upload';
        this.type = ClComponentTypes.dragDropUpload;
        this.style = new ClDragDropStyleProperties();
    }
}

class ClDynamicComponent {
    constructor() {
        this.isDynamicTree = false;
        this.dynamicTreeOptions = {};
        this.dynamicTreeValidation = false;
        this.validationOptions = { debounceTime: 300 };
        this.dynamicForm = {};
        this.dynamicValidationOptions = {};
    }
    ngOnChanges(changes) {
        this.dynamicValidationOptions = {
            dynamicControlName: this.properties?.properties?.name ?? '',
            dynamicTree: true,
            dynamicTreeId: this.dynamicTreeOptions.dynamicTreeId,
            parentNodes: this.dynamicTreeOptions.parentNodeIds,
            nodeId: this.dynamicTreeOptions.nodeId,
            deletedNodeIds: this.dynamicTreeOptions.deletedNodeIds
        };
    }
    ngOnInit() {
    }
    onValueChange(event) {
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDynamicComponent, isStandalone: true, selector: "cl-dynamic-renderer", inputs: { properties: "properties", ngForm: "ngForm", isDynamicTree: "isDynamicTree", dynamicTreeOptions: "dynamicTreeOptions", dynamicTreeValidation: "dynamicTreeValidation" }, usesOnChanges: true, ngImport: i0, template: "<!-- Switch case with recursive call -->\n@switch (properties && properties?.layout) {\n  @case ('page') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"dynamicTreeValidation\" ></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('button')  {\n    <cl-button [properties]=\"properties!.properties\">\n    </cl-button>\n  }\n  @case ('toggleButton') {\n    <cl-toggle-button class=\"w-full\" [properties]=\"properties!.properties\"></cl-toggle-button>\n  }\n  @case ('checkbox') {\n    @if(dynamicTreeValidation) {\n      <cl-checkbox [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\" [properties]=\"properties!.properties\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-checkbox>\n    } @else {\n      <cl-checkbox class=\"w-full\" [properties]=\"properties!.properties\" ></cl-checkbox>\n    }\n\n  }\n  @case ('chipList') {\n  @if(dynamicTreeValidation) {\n  <cl-chip-list class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\"\n    [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\" [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\">\n  </cl-chip-list>\n  } @else {\n  <cl-chip-list class=\"w-full\" [properties]=\"properties!.properties\"></cl-chip-list>\n  }\n\n  }\n  @case ('chipInput') {\n    @if(dynamicTreeValidation) {\n      <cl-chips-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-chips-input>\n    } @else {\n      <cl-chips-input class=\"w-full\" [properties]=\"properties!.properties\" ></cl-chips-input>\n    }\n\n  }\n  @case ('image') {\n    <cl-image class=\"w-full\" [properties]=\"properties!.properties\" ></cl-image>\n  }\n  @case ('multiAutocomplete') {\n    @if(dynamicTreeValidation) {\n      <cl-multi-autocomplete class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-multi-autocomplete>\n    } @else {\n      <cl-multi-autocomplete class=\"w-full\" [properties]=\"properties!.properties\" ></cl-multi-autocomplete>\n    }\n\n  }\n  @case ('multiselect') {\n    @if(dynamicTreeValidation) {\n      <cl-multiselect class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-multiselect>\n    } @else {\n      <cl-multiselect class=\"w-full\" [properties]=\"properties!.properties\" ></cl-multiselect>\n    }\n\n  }\n  @case ('input') {\n    @if(dynamicTreeValidation) {\n      <cl-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-input>\n    } @else {\n      <cl-input class=\"w-full\" [properties]=\"properties!.properties\"></cl-input>\n    }\n\n   }\n  @case ('email') {\n    @if(dynamicTreeValidation) {\n    <cl-email class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-email>\n    } @else {\n      <cl-email class=\"w-full\" [properties]=\"properties!.properties\" ></cl-email>\n    }\n  }\n  @case ('contactInput') {\n    @if(dynamicTreeValidation) {\n    <cl-contact-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-contact-input>\n    } @else {\n      <cl-contact-input class=\"w-full\" [properties]=\"properties!.properties\" ></cl-contact-input>\n    }\n  }\n  @case ('textarea') {\n    @if(dynamicTreeValidation) {\n    <cl-textarea class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-textarea>\n    } @else {\n      <cl-textarea class=\"w-full\" [properties]=\"properties!.properties\" ></cl-textarea>\n    }\n  }\n  @case ('chip') {\n    @if(dynamicTreeValidation) {\n    <cl-chip [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-chip>\n    } @else {\n      <cl-chip [properties]=\"properties!.properties\" class=\"w-full\"></cl-chip>\n    }\n  }\n  @case ('radio') {\n    @if(dynamicTreeValidation) {\n    <cl-radio [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-radio>\n    } @else {\n      <cl-radio [properties]=\"properties!.properties\"  class=\"w-full\"></cl-radio>\n    }\n  }\n  @case ('select') {\n    @if(dynamicTreeValidation) {\n    <cl-select class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\"\n     [validationOptions]=\"validationOptions\"\n     [dynamicControlOptions]=\"dynamicValidationOptions\" ></cl-select>\n    } @else {\n      <cl-select class=\"w-full\" [properties]=\"properties!.properties\" ></cl-select>\n    }\n  }\n  @case ('autocomplete') {\n    @if(dynamicTreeValidation) {\n    <cl-autocomplete [properties]='properties!.properties' [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-autocomplete>\n    } @else {\n      <cl-autocomplete [properties]='properties!.properties' class=\"w-full\"></cl-autocomplete>\n    }\n  }\n  @case ('timer') {\n    <cl-timer class=\"w-full\" [properties]=\"properties!.properties\" ></cl-timer>\n  }\n  @case ('timepicker') {\n    @if(dynamicTreeValidation) {\n    <cl-time-picker [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-time-picker>\n    } @else {\n      <cl-time-picker [properties]=\"properties!.properties\" class=\"w-full\"></cl-time-picker>\n    }\n  }\n  @case ('progressBar') {\n    <cl-progress-bar class=\"w-full\" [properties]=\"properties!.properties\" ></cl-progress-bar>\n  }\n  @case ('spinner') {\n    <cl-spinner class=\"w-full\" [properties]=\"properties!.properties\"></cl-spinner>\n  }\n  @case ('uploadTile') {\n    <cl-upload-tile class=\"w-full\" [properties]=\"properties!.properties\"></cl-upload-tile>\n  }\n  @case ('label') {\n    <cl-label [properties]=\"properties!.properties\"></cl-label>\n  }\n  @case ('icon') {\n    <cl-icon [properties]=\"properties!.properties\"></cl-icon>\n  }\n  @case ('icon-list') {\n    <cl-icons-list [properties]=\"properties!.properties\"></cl-icons-list>\n  }\n  @case ('tabs') {\n      <!-- Tabs Layout -->\n      <cl-tabs [properties]=\"properties!.properties\" class=\"dense-tab-container\">\n        @for (tab of properties!.properties; let tabIndex = $index; track tab) {\n          <cl-tab>\n            <cl-tab-header [properties]=\"tab.tabHeaderProperties\"></cl-tab-header>\n\n            <cl-tab-content>\n              @for (content of tab.tabContentProperties; track content) {\n              <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n              </cl-dynamic-renderer>\n              }\n            </cl-tab-content>\n          </cl-tab>\n        }\n      </cl-tabs>\n      <!-- Tabs Layout -->\n  }\n  @case ('accordion') {\n  <cl-accordion [properties]=\"properties!.properties\">\n    @for(accordion of properties!.properties.expansionPanelProperties; track accordion){\n    <cl-expansion-panel>\n      <cl-expansion-panel-header [properties]=\"accordion.expansionPanelHeaderProperties\">\n      </cl-expansion-panel-header>\n\n      <cl-expansion-panel-content>\n        @for (content of accordion.expansionPanelContentProperties; track content){\n          <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n          </cl-dynamic-renderer>\n        }\n      </cl-expansion-panel-content>\n    </cl-expansion-panel>\n    }\n  </cl-accordion>\n  }\n  @case ('card') {\n    <cl-card class=\"m-4 w-full\" [properties]=\"properties!.properties\">\n      @for (content of properties!.properties.children; track content){\n      <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n      </cl-dynamic-renderer>\n      }\n    </cl-card>\n  }\n  @case ('dualSortList') {\n    <cl-dual-sort-list [properties]=\"properties!.properties\"></cl-dual-sort-list>\n  }\n  @case ('stepper') {\n    <cl-card class=\"m-4 flex-auto\">\n      <cl-stepper class=\"max-w-3/4 min-w-3/4 self-center\" [properties]=\"properties!.properties\">\n        @for (step of properties!.properties.stepsProperties; track step) {\n        <cl-step>\n          <cl-step-header [properties]=\"step.stepHeaderProperties\"></cl-step-header>\n\n          <cl-step-content>\n            @for(content of step.stepContentProperties; track content){\n            <cl-dynamic-renderer [properties]=\"content\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n            }\n          </cl-step-content>\n        </cl-step>\n        }\n      </cl-stepper>\n    </cl-card>\n  }\n  @case ('dataGrid') {\n    <cl-data-grid\n    [data]=\"properties!.properties.data!\"\n    class=\"overflow-auto\"\n    [properties]=\"properties!.properties\"\n    [showLoading]=\"properties!.properties.showLoading!\"\n    [totalRecords]=\"properties!.properties.totalRecords\"\n    (onSelectionChange)=\"onValueChange($event)\"\n    [matSortActive]=\"properties!.properties.matSortActive!\"\n    [customData]=\"(properties!.properties && properties!.properties.customDataFilter)? properties!.properties.customDataFilter: null\"\n    [matSortDirection]=\"properties!.properties.matSortDirection!\"\n    >\n  </cl-data-grid>\n  }\n  @case ('carousel') {\n    <div class=\"flex flex-col p-8\">\n      <cl-carousel [properties]=\"properties!.properties\">\n        <!--Looping approach-->\n        @for (content of properties!.properties.children; track content){\n          <cl-carousel-content>\n            <cl-dynamic-renderer [properties]=\"content\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n          </cl-carousel-content>\n        }\n      </cl-carousel>\n    </div>\n  }\n  @case ('dragDropUpload') {\n    <cl-drag-drop-upload [properties]=\"properties!.properties\" [updatedUploadIconProperties]=\"properties!.properties.uploadIcon\" [preLoadImageProperties]=\"properties!.properties.preLoadImageProperties\">\n    </cl-drag-drop-upload>\n  }\n  @case ('treeView') {\n    <cl-tree-view class=\"flex-auto\" [properties]=\"properties!.properties\"></cl-tree-view>\n  }\n  @case ('grid') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('row') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer class=\"{{content.properties.style.contentWidth}}\" [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('column') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <!-- <form [formGroup]=\"ngForm.form\"> -->\n          <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n        <!-- </form> -->\n      }\n    </div>\n  }\n  @case ('form') {\n    <form class=\"w-full\" [formGroup]=\"properties!.formGroup\">\n      <cl-form class=\"w-full\" [properties]=\"properties!\"></cl-form>\n    </form>\n  }\n}\n<!-- End of Switch case with recursive call -->\n", styles: [""], dependencies: [{ kind: "component", type: ClDynamicComponent, selector: "cl-dynamic-renderer", inputs: ["properties", "ngForm", "isDynamicTree", "dynamicTreeOptions", "dynamicTreeValidation"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i1$2.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "component", type: ClInputComponent, selector: "cl-input", inputs: ["properties"] }, { kind: "component", type: ClEmailComponent, selector: "cl-email", inputs: ["properties"] }, { kind: "component", type: ClContactInputComponent, selector: "cl-contact-input", inputs: ["properties"] }, { kind: "component", type: ClTextareaComponent, selector: "cl-textarea", inputs: ["properties"] }, { kind: "component", type: ClRadioComponent, selector: "cl-radio", inputs: ["properties"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClSelectComponent, selector: "cl-select", inputs: ["properties"] }, { kind: "component", type: ClCheckboxComponent, selector: "cl-checkbox", inputs: ["properties"] }, { kind: "component", type: ClChipComponent, selector: "cl-chip", inputs: ["properties"] }, { kind: "component", type: ClChipListComponent, selector: "cl-chip-list", inputs: ["properties"] }, { kind: "component", type: ClToggleButtonComponent, selector: "cl-toggle-button", inputs: ["properties"] }, { kind: "component", type: ClTimerComponent, selector: "cl-timer", inputs: ["properties"] }, { kind: "component", type: ClImageComponent, selector: "cl-image", inputs: ["properties"] }, { kind: "component", type: ClMultiselectComponent, selector: "cl-multiselect", inputs: ["properties"] }, { kind: "component", type: ClMultiAutocompleteComponent, selector: "cl-multi-autocomplete", inputs: ["properties"] }, { kind: "component", type: ClProgressBarComponent, selector: "cl-progress-bar", inputs: ["properties"] }, { kind: "component", type: ClSpinnerComponent, selector: "cl-spinner", inputs: ["properties"] }, { kind: "component", type: ClChipsInputComponent, selector: "cl-chips-input", inputs: ["properties"], outputs: ["optionsAdded"] }, { kind: "component", type: ClUploadTileComponent, selector: "cl-upload-tile", inputs: ["properties", "preLoadImageProperties"] }, { kind: "component", type: ClTabComponent, selector: "cl-tab" }, { kind: "component", type: ClCardComponent, selector: "cl-card", inputs: ["expanded", "face", "flippable", "properties"], exportAs: ["clCard"] }, { kind: "component", type: ClTabsComponent, selector: "cl-tabs", inputs: ["activeTab", "properties"] }, { kind: "component", type: ClTabHeaderComponent, selector: "cl-tab-header", inputs: ["properties"], outputs: ["tabHeaderClicked"] }, { kind: "component", type: ClTabContentComponent, selector: "cl-tab-content" }, { kind: "component", type: ClDualSortListComponent, selector: "cl-dual-sort-list", inputs: ["properties"] }, { kind: "component", type: ClStepperComponent, selector: "cl-stepper", inputs: ["properties"] }, { kind: "component", type: ClStepComponent, selector: "cl-step" }, { kind: "component", type: ClStepHeaderComponent, selector: "cl-step-header", inputs: ["properties"] }, { kind: "component", type: ClStepContentComponent, selector: "cl-step-content" }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "component", type: ClDataGridComponent, selector: "cl-data-grid", inputs: ["matSortActive", "totalRecords", "showLoading", "matSortDirection", "data", "properties", "customData"] }, { kind: "component", type: ClCarouselComponent, selector: "cl-carousel", inputs: ["properties"] }, { kind: "component", type: ClCarouselContentComponent, selector: "cl-carousel-content" }, { kind: "component", type: ClDragDropUploadComponent, selector: "cl-drag-drop-upload", inputs: ["properties", "updatedUploadIconProperties", "preLoadImageProperties", "preLoadMultiFileProperties"] }, { kind: "component", type: ClIconsListComponent, selector: "cl-icons-list", inputs: ["properties"] }, { kind: "component", type: ClAutocompleteComponent, selector: "cl-autocomplete", inputs: ["properties"] }, { kind: "component", type: ClTimePickerComponent, selector: "cl-time-picker", inputs: ["properties"] }, { kind: "component", type: ClTreeViewComponent, selector: "cl-tree-view", inputs: ["properties"] }, { kind: "component", type: ClAccordionComponent, selector: "cl-accordion", inputs: ["properties"] }, { kind: "component", type: ClFormComponent, selector: "cl-form", inputs: ["properties"] }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClExpansionPanelComponent, selector: "cl-expansion-panel" }, { kind: "component", type: ClExpansionPanelHeaderComponent, selector: "cl-expansion-panel-header", inputs: ["properties"], exportAs: ["clExpansionPanelHeader"] }, { kind: "component", type: ClExpansionPanelContentComponent, selector: "cl-expansion-panel-content" }, { kind: "directive", type: FormModelDirective, selector: "[ngModel]", inputs: ["validationOptions", "dynamicControlOptions"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-dynamic-renderer', imports: [
                        CommonModule,
                        FormsModule,
                        ClInputComponent,
                        ClEmailComponent,
                        ClContactInputComponent,
                        ClTextareaComponent,
                        ClRadioComponent,
                        ClButtonComponent,
                        ClSelectComponent,
                        ClCheckboxComponent,
                        ClChipComponent,
                        ClChipListComponent,
                        ClToggleButtonComponent,
                        ClTimerComponent,
                        ClImageComponent,
                        ClMultiselectComponent,
                        ClMultiAutocompleteComponent,
                        ClProgressBarComponent,
                        ClSpinnerComponent,
                        ClChipsInputComponent,
                        ClUploadTileComponent,
                        ClTabComponent,
                        ClCardComponent,
                        ClTabsComponent,
                        ClTabHeaderComponent,
                        ClTabContentComponent,
                        ClDualSortListComponent,
                        ClStepperComponent,
                        ClStepComponent,
                        ClCardComponent,
                        ClStepHeaderComponent,
                        ClStepContentComponent,
                        ClLabelComponent,
                        ClDataGridComponent,
                        ClCarouselComponent,
                        ClCarouselContentComponent,
                        ClDragDropUploadComponent,
                        ClIconsListComponent,
                        ClAutocompleteComponent,
                        ClTimePickerComponent,
                        ClTreeViewComponent,
                        ClAccordionComponent,
                        ClFormComponent,
                        ClIconComponent,
                        ClExpansionPanelComponent,
                        ClExpansionPanelHeaderComponent,
                        ClExpansionPanelContentComponent,
                        FormModelDirective,
                        FormDirective,
                        ReactiveFormsModule
                    ], template: "<!-- Switch case with recursive call -->\n@switch (properties && properties?.layout) {\n  @case ('page') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"dynamicTreeValidation\" ></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('button')  {\n    <cl-button [properties]=\"properties!.properties\">\n    </cl-button>\n  }\n  @case ('toggleButton') {\n    <cl-toggle-button class=\"w-full\" [properties]=\"properties!.properties\"></cl-toggle-button>\n  }\n  @case ('checkbox') {\n    @if(dynamicTreeValidation) {\n      <cl-checkbox [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\" [properties]=\"properties!.properties\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-checkbox>\n    } @else {\n      <cl-checkbox class=\"w-full\" [properties]=\"properties!.properties\" ></cl-checkbox>\n    }\n\n  }\n  @case ('chipList') {\n  @if(dynamicTreeValidation) {\n  <cl-chip-list class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\"\n    [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\" [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\">\n  </cl-chip-list>\n  } @else {\n  <cl-chip-list class=\"w-full\" [properties]=\"properties!.properties\"></cl-chip-list>\n  }\n\n  }\n  @case ('chipInput') {\n    @if(dynamicTreeValidation) {\n      <cl-chips-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-chips-input>\n    } @else {\n      <cl-chips-input class=\"w-full\" [properties]=\"properties!.properties\" ></cl-chips-input>\n    }\n\n  }\n  @case ('image') {\n    <cl-image class=\"w-full\" [properties]=\"properties!.properties\" ></cl-image>\n  }\n  @case ('multiAutocomplete') {\n    @if(dynamicTreeValidation) {\n      <cl-multi-autocomplete class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-multi-autocomplete>\n    } @else {\n      <cl-multi-autocomplete class=\"w-full\" [properties]=\"properties!.properties\" ></cl-multi-autocomplete>\n    }\n\n  }\n  @case ('multiselect') {\n    @if(dynamicTreeValidation) {\n      <cl-multiselect class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-multiselect>\n    } @else {\n      <cl-multiselect class=\"w-full\" [properties]=\"properties!.properties\" ></cl-multiselect>\n    }\n\n  }\n  @case ('input') {\n    @if(dynamicTreeValidation) {\n      <cl-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\"\n      [validationOptions]=\"validationOptions\"\n      [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-input>\n    } @else {\n      <cl-input class=\"w-full\" [properties]=\"properties!.properties\"></cl-input>\n    }\n\n   }\n  @case ('email') {\n    @if(dynamicTreeValidation) {\n    <cl-email class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-email>\n    } @else {\n      <cl-email class=\"w-full\" [properties]=\"properties!.properties\" ></cl-email>\n    }\n  }\n  @case ('contactInput') {\n    @if(dynamicTreeValidation) {\n    <cl-contact-input class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-contact-input>\n    } @else {\n      <cl-contact-input class=\"w-full\" [properties]=\"properties!.properties\" ></cl-contact-input>\n    }\n  }\n  @case ('textarea') {\n    @if(dynamicTreeValidation) {\n    <cl-textarea class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-textarea>\n    } @else {\n      <cl-textarea class=\"w-full\" [properties]=\"properties!.properties\" ></cl-textarea>\n    }\n  }\n  @case ('chip') {\n    @if(dynamicTreeValidation) {\n    <cl-chip [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-chip>\n    } @else {\n      <cl-chip [properties]=\"properties!.properties\" class=\"w-full\"></cl-chip>\n    }\n  }\n  @case ('radio') {\n    @if(dynamicTreeValidation) {\n    <cl-radio [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-radio>\n    } @else {\n      <cl-radio [properties]=\"properties!.properties\"  class=\"w-full\"></cl-radio>\n    }\n  }\n  @case ('select') {\n    @if(dynamicTreeValidation) {\n    <cl-select class=\"w-full\" [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\"\n     [validationOptions]=\"validationOptions\"\n     [dynamicControlOptions]=\"dynamicValidationOptions\" ></cl-select>\n    } @else {\n      <cl-select class=\"w-full\" [properties]=\"properties!.properties\" ></cl-select>\n    }\n  }\n  @case ('autocomplete') {\n    @if(dynamicTreeValidation) {\n    <cl-autocomplete [properties]='properties!.properties' [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-autocomplete>\n    } @else {\n      <cl-autocomplete [properties]='properties!.properties' class=\"w-full\"></cl-autocomplete>\n    }\n  }\n  @case ('timer') {\n    <cl-timer class=\"w-full\" [properties]=\"properties!.properties\" ></cl-timer>\n  }\n  @case ('timepicker') {\n    @if(dynamicTreeValidation) {\n    <cl-time-picker [properties]=\"properties!.properties\" [name]=\"properties!.properties.name\" [ngModel]=\"dynamicForm[properties!.properties.name]\" class=\"w-full\"\n    [validationOptions]=\"validationOptions\"\n    [dynamicControlOptions]=\"dynamicValidationOptions\"></cl-time-picker>\n    } @else {\n      <cl-time-picker [properties]=\"properties!.properties\" class=\"w-full\"></cl-time-picker>\n    }\n  }\n  @case ('progressBar') {\n    <cl-progress-bar class=\"w-full\" [properties]=\"properties!.properties\" ></cl-progress-bar>\n  }\n  @case ('spinner') {\n    <cl-spinner class=\"w-full\" [properties]=\"properties!.properties\"></cl-spinner>\n  }\n  @case ('uploadTile') {\n    <cl-upload-tile class=\"w-full\" [properties]=\"properties!.properties\"></cl-upload-tile>\n  }\n  @case ('label') {\n    <cl-label [properties]=\"properties!.properties\"></cl-label>\n  }\n  @case ('icon') {\n    <cl-icon [properties]=\"properties!.properties\"></cl-icon>\n  }\n  @case ('icon-list') {\n    <cl-icons-list [properties]=\"properties!.properties\"></cl-icons-list>\n  }\n  @case ('tabs') {\n      <!-- Tabs Layout -->\n      <cl-tabs [properties]=\"properties!.properties\" class=\"dense-tab-container\">\n        @for (tab of properties!.properties; let tabIndex = $index; track tab) {\n          <cl-tab>\n            <cl-tab-header [properties]=\"tab.tabHeaderProperties\"></cl-tab-header>\n\n            <cl-tab-content>\n              @for (content of tab.tabContentProperties; track content) {\n              <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n              </cl-dynamic-renderer>\n              }\n            </cl-tab-content>\n          </cl-tab>\n        }\n      </cl-tabs>\n      <!-- Tabs Layout -->\n  }\n  @case ('accordion') {\n  <cl-accordion [properties]=\"properties!.properties\">\n    @for(accordion of properties!.properties.expansionPanelProperties; track accordion){\n    <cl-expansion-panel>\n      <cl-expansion-panel-header [properties]=\"accordion.expansionPanelHeaderProperties\">\n      </cl-expansion-panel-header>\n\n      <cl-expansion-panel-content>\n        @for (content of accordion.expansionPanelContentProperties; track content){\n          <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n          </cl-dynamic-renderer>\n        }\n      </cl-expansion-panel-content>\n    </cl-expansion-panel>\n    }\n  </cl-accordion>\n  }\n  @case ('card') {\n    <cl-card class=\"m-4 w-full\" [properties]=\"properties!.properties\">\n      @for (content of properties!.properties.children; track content){\n      <cl-dynamic-renderer [properties]=\"content\" class=\"w-full\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\">\n      </cl-dynamic-renderer>\n      }\n    </cl-card>\n  }\n  @case ('dualSortList') {\n    <cl-dual-sort-list [properties]=\"properties!.properties\"></cl-dual-sort-list>\n  }\n  @case ('stepper') {\n    <cl-card class=\"m-4 flex-auto\">\n      <cl-stepper class=\"max-w-3/4 min-w-3/4 self-center\" [properties]=\"properties!.properties\">\n        @for (step of properties!.properties.stepsProperties; track step) {\n        <cl-step>\n          <cl-step-header [properties]=\"step.stepHeaderProperties\"></cl-step-header>\n\n          <cl-step-content>\n            @for(content of step.stepContentProperties; track content){\n            <cl-dynamic-renderer [properties]=\"content\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n            }\n          </cl-step-content>\n        </cl-step>\n        }\n      </cl-stepper>\n    </cl-card>\n  }\n  @case ('dataGrid') {\n    <cl-data-grid\n    [data]=\"properties!.properties.data!\"\n    class=\"overflow-auto\"\n    [properties]=\"properties!.properties\"\n    [showLoading]=\"properties!.properties.showLoading!\"\n    [totalRecords]=\"properties!.properties.totalRecords\"\n    (onSelectionChange)=\"onValueChange($event)\"\n    [matSortActive]=\"properties!.properties.matSortActive!\"\n    [customData]=\"(properties!.properties && properties!.properties.customDataFilter)? properties!.properties.customDataFilter: null\"\n    [matSortDirection]=\"properties!.properties.matSortDirection!\"\n    >\n  </cl-data-grid>\n  }\n  @case ('carousel') {\n    <div class=\"flex flex-col p-8\">\n      <cl-carousel [properties]=\"properties!.properties\">\n        <!--Looping approach-->\n        @for (content of properties!.properties.children; track content){\n          <cl-carousel-content>\n            <cl-dynamic-renderer [properties]=\"content\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n          </cl-carousel-content>\n        }\n      </cl-carousel>\n    </div>\n  }\n  @case ('dragDropUpload') {\n    <cl-drag-drop-upload [properties]=\"properties!.properties\" [updatedUploadIconProperties]=\"properties!.properties.uploadIcon\" [preLoadImageProperties]=\"properties!.properties.preLoadImageProperties\">\n    </cl-drag-drop-upload>\n  }\n  @case ('treeView') {\n    <cl-tree-view class=\"flex-auto\" [properties]=\"properties!.properties\"></cl-tree-view>\n  }\n  @case ('grid') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('row') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <cl-dynamic-renderer class=\"{{content.properties.style.contentWidth}}\" [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n      }\n    </div>\n  }\n  @case ('column') {\n    <div class=\"{{properties!.properties.cssClass}}\">\n      @for (content of properties!.children; track content) {\n        <!-- <form [formGroup]=\"ngForm.form\"> -->\n          <cl-dynamic-renderer [properties]=\"content\" [ngForm]=\"ngForm\" [isDynamicTree]=\"isDynamicTree\" [dynamicTreeValidation]=\"dynamicTreeValidation\" [dynamicTreeOptions]=\"dynamicTreeOptions\"></cl-dynamic-renderer>\n        <!-- </form> -->\n      }\n    </div>\n  }\n  @case ('form') {\n    <form class=\"w-full\" [formGroup]=\"properties!.formGroup\">\n      <cl-form class=\"w-full\" [properties]=\"properties!\"></cl-form>\n    </form>\n  }\n}\n<!-- End of Switch case with recursive call -->\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input
            }], ngForm: [{
                type: Input
            }], isDynamicTree: [{
                type: Input
            }], dynamicTreeOptions: [{
                type: Input
            }], dynamicTreeValidation: [{
                type: Input
            }] } });

class ClDynamicTreeViewProperties {
    constructor() {
        this.id = 'default0';
        this.type = ClComponentTypes.dynamicTreeView;
        this.addButtonProperties = new ClButtonProperties();
        this.addButtonProperties.label = 'Add New Parent';
        this.addButtonProperties.style.cssClasses = 'p-0 bg-white';
        this.addButtonProperties.icon = 'heroicons_outline:plus-circle';
        this.addButtonProperties.buttonBehavior = ClButtonBehavior.flat;
        this.addButtonProperties.style.iconCssClasses = 'p-0 text-primary';
        this.addButtonProperties.style.labelCssClasses = 'p-0 text-primary';
        this.nodes = [
            {
                id: 1,
                showAddChildrenButton: false
            }
        ];
    }
}

class DynamicTreeViewService {
    constructor() {
        this.addChildNode = new Subject$1();
        this.deletedNodeIds = [];
    }
    getAllParentIds(nodeId) {
        let parentIds = [];
        if (this.properties.nodes.length) {
            parentIds = this.getParentIds(this.properties.nodes, nodeId);
        }
        return parentIds;
    }
    getParentIds(tree, targetId, path = []) {
        for (const node of tree) {
            // Check if the current node is the target
            if (node.id === targetId) {
                return path; // Return the path of parent IDs
            }
            // If the current node has children, recursively search them
            if (node.nodes) {
                const result = this.getParentIds(node.nodes, targetId, [...path, node.id]);
                if (result.length > 0) {
                    return result; // If the target is found in a subtree, return the result
                }
            }
        }
        return []; // Return an empty array if the target is not found
    }
    // deleteNodeFormGroup(id: string, parentNodeIds: string[]) {
    //   // delete the formGroup which has the id as a control
    //   let formArr = this.ngForm.form.get('nodes').controls;
    //   // let parentNodeIds = this.getAllParentIds(id);
    //  if(parentNodeIds.length) {
    //   let parentFormArr = formArr;
    //   let obj: any;
    //   parentNodeIds.forEach((parentId:string) => {
    //     obj = this.findFormGroup(parentFormArr, parentId);
    //     parentFormArr =  obj?.formGroup.get('nodes').controls;
    //   });
    //   let nodeObj = this.findFormGroup(parentFormArr, id);
    //   parentFormArr.splice(nodeObj?.index, 1);
    //  } else {
    //   //find the formGroup and delete it from the formArray
    //   let obj = this.findFormGroup(formArr, id);
    //   formArr.splice(obj!.index, 1);
    //  }
    //  this.ngForm.form.updateValueAndValidity();
    //  console.log(61, this.ngForm.form);
    // }
    // findFormGroup(formArr: any[], id :string) {
    //   if(formArr.length) {
    //     for(let i=0; i < formArr.length; i++) {
    //       let fmGroup = formArr[i];
    //       if(fmGroup.controls.hasOwnProperty(id)) {
    //         return { index: i, formGroup: fmGroup};
    //       }
    //     }
    //   }
    //   return null;
    // }
    deleteNodeFormGroup(id, parentNodeIds) {
        const formArr = this.ngForm.form.get('nodes');
        // const parentNodeIds = this.getAllParentIds(id);
        if (parentNodeIds.length) {
            let parentFormArr = formArr;
            let obj;
            parentNodeIds.forEach((parentId) => {
                obj = this.findFormGroup(parentFormArr.controls, parentId);
                parentFormArr = obj?.formGroup.get('nodes');
            });
            const nodeObj = this.findFormGroup(parentFormArr.controls, id);
            if (nodeObj) {
                // parentFormArr.removeAt(nodeObj.index);
                parentFormArr.controls.splice(nodeObj.index, 1);
            }
        }
        else {
            // Find the formGroup and delete it from the formArray
            const obj = this.findFormGroup(formArr.controls, id);
            if (obj) {
                formArr.removeAt(obj.index);
            }
        }
        this.ngForm.form.updateValueAndValidity();
    }
    findFormGroup(formArr, id) {
        for (let i = 0; i < formArr.length; i++) {
            const fmGroup = formArr[i];
            if (fmGroup.get(id.toString())) {
                return { index: i, formGroup: fmGroup };
            }
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class ClDynamicTreeViewChildComponent {
    constructor() {
        this.dynamicTreeService = inject(DynamicTreeViewService);
        this.dynamicTreeOptions = {};
        this.parentNodeIds = [];
    }
    /**
     * this function will calculate the width for tree nodes
     *
     * @param depth - depth of the tree node
     *
     * @returns - style with width properties calculated
     */
    getTreeNodeWidth(depth) {
        return { 'width': `calc(100% - ${4}px)` };
        // return { 'width': `calc(100% - ${ 4 + depth }px)` };
    }
    ngOnInit() {
        this.parentNodeIds = this.dynamicTreeService.getAllParentIds(this.node.id);
        this.setDynamicTreeOptions();
    }
    setDynamicTreeOptions() {
        this.dynamicTreeOptions = {
            "dynamicTreeId": this.dynamicTreeId,
            "parentNodeIds": this.parentNodeIds,
            "nodeId": this.node.id,
            "dynamicTree": true,
            "deletedNodeIds": this.dynamicTreeService.deletedNodeIds
        };
    }
    ngAfterViewInit() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = () => {
                this.addChildNode();
            };
        }
    }
    ngOnChanges() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = this.addChildNode.bind(this);
        }
    }
    ngDoCheck() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = this.addChildNode.bind(this);
        }
    }
    addChildNode() {
        // if(this.addChildFunction) {
        //   this.addChildFunction({ index: this.index , node: this.node});
        // }
        this.dynamicTreeService.addChildNode.next({ index: this.index, node: this.node });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewChildComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDynamicTreeViewChildComponent, isStandalone: true, selector: "cl-dynamic-tree-view-child", inputs: { index: "index", node: "node", childAddButtonProperties: "childAddButtonProperties", dynamicTreeId: "dynamicTreeId" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"flex w-full flex-col\">\n  <cl-dynamic-renderer class=\"w-full\" [properties]=\"node.properties\" [isDynamicTree]=\"true\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"true\"></cl-dynamic-renderer>\n\n  <!-- Render child nodes recursively -->\n  @if (node.nodes?.length) {\n    @for (childNode of node.nodes; track node; let index = $index) {\n      <div class=\"flex connector\" [ngStyle]=\"{'--connector-height': index == node.nodes!.length - 1 ? '0px' : '100%'}\">\n        <div class=\"z-10 size-2 mt-[17px] rotate-45 bg-primary text-primary\"></div>\n\n        <cl-dynamic-tree-view-child [node]=\"childNode\" [index]=\"index\" class=\"flex -m-1\"\n          [ngStyle]=\"getTreeNodeWidth(childNode.depth!)\" [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"dynamicTreeId\">\n        </cl-dynamic-tree-view-child>\n      </div>\n    }\n  }\n\n  @if (node.showAddChildrenButton) {\n    <cl-button class=\"mt-4 ml-8 mb-4\" [properties]=\"node.childAddButtonProperties!\"></cl-button>\n  }\n</div>\n", dependencies: [{ kind: "component", type: ClDynamicTreeViewChildComponent, selector: "cl-dynamic-tree-view-child", inputs: ["index", "node", "childAddButtonProperties", "dynamicTreeId"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClDynamicComponent, selector: "cl-dynamic-renderer", inputs: ["properties", "ngForm", "isDynamicTree", "dynamicTreeOptions", "dynamicTreeValidation"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewChildComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, encapsulation: ViewEncapsulation.None, selector: 'cl-dynamic-tree-view-child', imports: [
                        NgStyle,
                        NgTemplateOutlet,
                        ClButtonComponent,
                        ClDynamicComponent
                    ], template: "<div class=\"flex w-full flex-col\">\n  <cl-dynamic-renderer class=\"w-full\" [properties]=\"node.properties\" [isDynamicTree]=\"true\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"true\"></cl-dynamic-renderer>\n\n  <!-- Render child nodes recursively -->\n  @if (node.nodes?.length) {\n    @for (childNode of node.nodes; track node; let index = $index) {\n      <div class=\"flex connector\" [ngStyle]=\"{'--connector-height': index == node.nodes!.length - 1 ? '0px' : '100%'}\">\n        <div class=\"z-10 size-2 mt-[17px] rotate-45 bg-primary text-primary\"></div>\n\n        <cl-dynamic-tree-view-child [node]=\"childNode\" [index]=\"index\" class=\"flex -m-1\"\n          [ngStyle]=\"getTreeNodeWidth(childNode.depth!)\" [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"dynamicTreeId\">\n        </cl-dynamic-tree-view-child>\n      </div>\n    }\n  }\n\n  @if (node.showAddChildrenButton) {\n    <cl-button class=\"mt-4 ml-8 mb-4\" [properties]=\"node.childAddButtonProperties!\"></cl-button>\n  }\n</div>\n" }]
        }], propDecorators: { index: [{
                type: Input,
                args: [{ required: true }]
            }], node: [{
                type: Input,
                args: [{ required: true }]
            }], childAddButtonProperties: [{
                type: Input
            }], dynamicTreeId: [{
                type: Input
            }] } });

class ClDynamicTreeViewComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.afterContentCheckedCalled = false;
        this.dynamicTreeService = inject(DynamicTreeViewService);
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        // calling set default properties function
        this.properties ??= new ClDynamicTreeViewProperties();
        this.setButtonProperties();
        super.ngOnInit();
    }
    ngAfterContentChecked() {
        if (this.properties.nodes?.length && !this.afterContentCheckedCalled) {
            this.afterContentCheckedCalled = true;
            this.addDepth(this.properties.nodes);
        }
    }
    ngDoCheck() {
        this.dynamicTreeService.properties = this.properties;
        this.dynamicTreeService.ngForm = this.ngForm;
    }
    /**
     * this function is used to add depth to the tree view for managing the width of the children
     *
     * @param treeNode - array of objects
     *
     * @param depth - depth of the tree node
     */
    addDepth(treeNode, depth = 0) {
        treeNode.forEach((childTreeNode) => {
            childTreeNode.depth = depth;
            if (childTreeNode.nodes && childTreeNode.nodes.length > 0) {
                // calling add depth function
                this.addDepth(childTreeNode.nodes, depth + 1);
            }
        });
    }
    setButtonProperties() {
        if (this.properties.addButtonProperties === undefined) {
            this.properties.addButtonProperties = new ClButtonProperties();
            this.properties.addButtonProperties.label = 'Add New Parent';
            this.properties.addButtonProperties.style.cssClasses = 'p-0 bg-white';
            this.properties.addButtonProperties.icon = 'heroicons_outline:plus-circle';
            this.properties.addButtonProperties.buttonBehavior = ClButtonBehavior.flat;
            this.properties.addButtonProperties.style.iconCssClasses = 'p-0 text-primary';
            this.properties.addButtonProperties.style.labelCssClasses = 'p-0 text-primary';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDynamicTreeViewComponent, isStandalone: true, selector: "cl-dynamic-tree-view", inputs: { properties: "properties", ngForm: "ngForm" }, usesInheritance: true, ngImport: i0, template: "<div class=\"flex w-full flex-col\">\n  @for (node of properties.nodes!; track node; let index = $index) {\n    <cl-dynamic-tree-view-child [node]=\"node\" [index]=\"index\" class=\"flex w-full\"\n      [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"properties.id\">\n    </cl-dynamic-tree-view-child>\n  }\n\n  @if (properties.addButtonProperties) {\n    <cl-button class=\"mt-4\" [properties]=\"properties.addButtonProperties\"></cl-button>\n  }\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:38px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:not(:last-child):after{top:10px;left:-28px;content:\"\";height:var(--connector-height);position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}\n"], dependencies: [{ kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClDynamicTreeViewChildComponent, selector: "cl-dynamic-tree-view-child", inputs: ["index", "node", "childAddButtonProperties", "dynamicTreeId"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-dynamic-tree-view', encapsulation: ViewEncapsulation.None, imports: [
                        ClButtonComponent,
                        ClDynamicTreeViewChildComponent
                    ], template: "<div class=\"flex w-full flex-col\">\n  @for (node of properties.nodes!; track node; let index = $index) {\n    <cl-dynamic-tree-view-child [node]=\"node\" [index]=\"index\" class=\"flex w-full\"\n      [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"properties.id\">\n    </cl-dynamic-tree-view-child>\n  }\n\n  @if (properties.addButtonProperties) {\n    <cl-button class=\"mt-4\" [properties]=\"properties.addButtonProperties\"></cl-button>\n  }\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:38px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:not(:last-child):after{top:10px;left:-28px;content:\"\";height:var(--connector-height);position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], ngForm: [{
                type: Input
            }] } });

var ClTimelineActivityStatus;
(function (ClTimelineActivityStatus) {
    ClTimelineActivityStatus["pending"] = "pending";
    ClTimelineActivityStatus["approved"] = "approved";
    ClTimelineActivityStatus["rejected"] = "rejected";
    ClTimelineActivityStatus["cancelled"] = "cancelled";
    ClTimelineActivityStatus["completed"] = "completed";
    ClTimelineActivityStatus["notStarted"] = "Not Started";
})(ClTimelineActivityStatus || (ClTimelineActivityStatus = {}));
class ClTimelineActivityStyleProperties {
}
class ClTimelineActivityProperties {
    constructor() {
        this.id = 'default0';
        this.itemsPerRow = 5;
        this.type = ClComponentTypes.timelineActivity;
        this.style = new ClTimelineActivityStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.activities = [
            {
                id: '493190c9-5b61-4912-afe5-78c21f1044d7',
                icon: 'heroicons_solid:arrow-top-right-on-square',
                title: 'Transfer Request',
                date: 'Jan 4th 2023 05:00pm',
                status: ClTimelineActivityStatus.completed,
                description: 'by Arjun Das',
                stepStatus: {
                    id: '',
                    label: '',
                    hidden: true,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: '',
                        labelCssClasses: ''
                    }
                }
            },
            {
                id: '6e3e97e5-effc-4fb7-b730-52a151f0b641',
                icon: 'heroicons_solid:star',
                title: 'Approve / Reject',
                date: 'Jan 4th 2023 05:00pm',
                status: 'pending',
                stepStatus: {
                    id: 'chip',
                    label: "test",
                    hidden: false,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: 'mt-3 mb-4 color-orange-chip shadow-md',
                        labelCssClasses: ''
                    }
                }
            },
            {
                id: 'b91ccb58-b06c-413b-b389-87010e03a120',
                icon: 'heroicons_solid:envelope',
                title: 'Card Process',
                date: 'Jan 4th 2023 05:00pm',
                status: 'rejected',
                stepStatus: {
                    id: '',
                    label: '',
                    hidden: true,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: '',
                        labelCssClasses: ''
                    }
                }
            }
        ];
    }
}

class ClTimelineActivityComponent extends ClBaseContainerComponent {
    constructor() {
        super();
        this.activitiesLength = 0;
        this.heightOfDashedLine = 0;
        super.setProperties(this.properties);
    }
    ngOnInit() {
        // Get the activities
        // this.getWidth()
        this.activities = this.splitDataIntoArrays(this.properties.activities, Number(this.properties.itemsPerRow));
        super.ngOnInit();
    }
    ngDoCheck() {
        if (this.activitiesLength !== this.properties.activities.length) {
            this.activities = this.splitDataIntoArrays(this.properties.activities, Number(this.properties.itemsPerRow));
        }
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------
    /**
     * Split array based on length
     * @param data activity array
     * @param count length on each row
     * @returns splitted array
     */
    splitDataIntoArrays(data, count) {
        const result = [];
        this.activitiesLength = data.length;
        for (let i = 0; i < data.length; i += count) {
            const chunk = data.slice(i, i + count);
            result.push(chunk);
        }
        result.forEach((chunk, index) => {
            if (index % 2 === 1) {
                const paddingCount = count - chunk.length;
                const defaultObject = {
                    id: `padding-${index}`,
                    date: "",
                    description: "",
                    icon: "",
                    status: "",
                };
                // Create an array of default objects for padding
                // result[index] = [...padding, ...chunk];
                chunk.reverse();
                if (paddingCount) {
                    for (let i = 0; i < paddingCount; i++) {
                        chunk.unshift({ ...defaultObject, id: `padding-${index}-${i}` });
                    }
                }
            }
        });
        return result;
    }
    getWidth() {
        let widthClass = "w-full";
        if (this.properties.itemsPerRow && this.properties.itemsPerRow < 7) {
            widthClass = 'w-1/' + this.properties.itemsPerRow;
        }
        else {
            widthClass = 'min-w-12 w-auto;';
        }
        return widthClass;
    }
    /**
    * Calculate length of vertical line
    */
    calculateHeight(index = 0) {
        const rowElement = document.getElementById(`row-${index}`);
        if (rowElement) {
            const height = rowElement.clientHeight;
            if (index == 0) {
                this.heightOfDashedLine = height + 33;
            }
            else {
                this.heightOfDashedLine = height + 1;
            }
        }
        else {
            console.warn(`Element with id 'row-${index}' not found.`);
            this.heightOfDashedLine = 0; // Fallback value
        }
    }
    /**
     * @returns height in px
     */
    getHeight(index) {
        this.calculateHeight(index);
        return this.heightOfDashedLine.toString() + 'px';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimelineActivityComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTimelineActivityComponent, isStandalone: true, selector: "cl-timeline-activity", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<!-- <div class=\"flex w-full\"> -->\n@for (activity of activities; track activity; let i = $index; let first = $first; let last = $last){\n<div id=\"row-{{i}}\" [style.grid-template-columns]=\"'repeat(' + properties.itemsPerRow + ', minmax(0, 1fr))'\"\n  class=\"grid\">\n  @for (step of activity; track step; let j = $index; let end = $last; let start = $first;){\n  <div class=\"\" [ngClass]=\"[i >= 1 ? 'mt-8' : '']\">\n    <div class=\"w-full z-10\">\n      <div class=\"relative flex flex-col items-center\">\n        <div class=\"flex flex-col items-center relative w-full\" [ngClass]=\"{'per-row-two': properties.itemsPerRow === 2,'per-row-three': properties.itemsPerRow === 3}\">\n          @if(i % 2 === 1 && start && !last ){\n          <div class=\"absolute inset-y-0 below-left-line mt-5\" [style]=\"{'height': getHeight(i)}\"></div>\n          }\n          @if(i % 2 === 0 && end && !last){\n          <div class=\"absolute inset-y-0 below-line mt-5\" [style]=\"{'height': getHeight(i)}\"></div>\n          }\n\n          @if(step.status !== ''){\n          @if(i%2==0 && !end){\n          <div class=\"absolute left-1/2 top-0 h-0.5 border-t border-dashed border-blue-600 w-full z-0 mt-5 mr-4 ml-3\"></div>\n          }\n          <!-- <div>{{j}} {{start}} {{end}} {{i%2==1}}</div> -->\n          @if(i%2==1 && (start || !end)){\n          <div class=\"absolute left-1/2 top-0 h-0.5 border-t border-dashed border-blue-600 w-full z-0 mt-5 mr-4 ml-3\"></div>\n          }\n          }\n\n          <!-- Icon -->\n          @if(step.icon && !step.image){\n\n          <div class=\"flex-shrink-0 items-center justify-center size-10 mr-4 rounded-full z-11\" [ngClass]=\"step.status === 'completed' ? 'color-green' : step.status === 'pending' ?\n                      'color-orange' : step.status === 'rejected'? 'color-red' : 'color-disabled'\">\n            <mat-icon [ngClass]=\"step.status === 'Not started'? 'icon-color-gray': ''\"\n              class=\"icon-size-custom text-white\" [svgIcon]=\"step.icon\"></mat-icon>\n          </div>\n\n          }\n\n          <!-- Image -->\n          @if(step.image){\n\n          <img class=\"shrink-0 size-10 mr-4 rounded-full overflow-hidden object-cover object-center z-11\"\n            [src]=\"step.image\" [alt]=\"'Activity image'\">\n\n          }\n          @if(i%2==0){\n          @if(end && !last){\n          <div class=\"absolute right-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 12px) !important;\"></div>\n          }\n          @else if(i!==0 && j==0){\n          @if(step.status !== ''){\n          <div class=\"absolute left-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 28px) !important;\"></div>\n          }\n          }\n          }\n          @if(i%2==1){\n          @if(end){\n          <div class=\"absolute right-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 12px) !important;\"></div>\n\n          }\n          @else if(j==0){\n          @if(step.status !== ''){\n            @if(!(last && activity.length==properties.itemsPerRow)){\n              <div class=\"absolute left-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 28px) !important;\"></div>\n            }\n          }\n          }\n          }\n        </div>\n\n\n        <!-- Content -->\n        <div class=\"flex flex-col flex-auto items-center\">\n          <!-- Description -->\n          @if(step.title){\n\n          <div class=\"font-family-title\" [ngClass]=\"step.status !== 'completed' ? 'disabled-font' : 'completed-font' \">\n            {{step.title}}</div>\n\n          }\n\n          @if(step.stepStatus){\n\n          @if(!step.stepStatus.hidden){\n          <div class=\"rounded-full {{ step.stepStatus.style?.cssClasses }} py-0.5 px-2 custom-chip-border\">\n            <mat-label class=\"flex w-full\n                      {{ step.stepStatus.style?.labelCssClasses }}\">\n\n              @if(step.stepStatus.label.textTrimLength == undefined){\n              <span>{{step.stepStatus.label}}</span>\n              }\n              @if(step.stepStatus.label.textTrimLength != undefined && step.stepStatus.label.textTrimLength\n              > 0){\n              <span>\n                {{step.stepStatus.label | truncate:[step.stepStatus.label.textTrimLength]}}\n              </span>\n              }\n              @if(step.stepStatus.label.optional){\n              <span class=\"optional-text\">(Optional)</span>\n              }\n\n            </mat-label>\n          </div>\n          }\n\n          }\n\n          @if(step.description){\n\n          <div class=\"font-family-extracontent\">\n            {{step.description}}\n          </div>\n\n          }\n          <div class=\"flex flex-row items-center mt-2 space-x-2 text-md leading-5\">\n            <!-- Date -->\n            @if(step.status === 'completed' || step.status === 'rejected'){\n            <div class=\"font-family-description\">\n              {{step.date}}\n            </div>\n            }\n          </div>\n        </div>\n      </div>\n    </div>\n\n\n  </div>\n  }\n</div>\n}\n<!-- </div> -->", styles: [".icon-size-custom{width:1.5rem!important;height:2.5rem!important;min-width:1.25rem!important;min-height:1.25rem!important;font-size:1.25rem!important;line-height:1.25rem!important;margin-left:8px}.divider{border-top:1px dashed #2D78E8;width:calc(100% - 8px);margin:8px 0}.font-family-title{font-family:Nunito;font-size:16px;font-weight:700;line-height:24px;letter-spacing:0em}.completed-font{color:#002660}.disabled-font{color:#a0a2a5}.font-family-description{font-family:Nunito;font-size:12px;font-weight:400;line-height:16px;letter-spacing:0em;color:#636467}.font-family-extracontent{font-family:Nunito;font-size:12px;font-weight:700;line-height:16px;letter-spacing:0em;color:#38393a}.dotted-line{position:absolute;top:16%;left:43%;width:50%;height:1px;border-bottom:1px dashed #2D78E8}.below-line{border:1px dashed rgb(37,99,235);width:13px;left:98%;border-left:none;border-bottom:none;border-top:none;border-radius:16px;top:16%}.below-left-line{border:1px dashed rgb(37,99,235);width:13px;left:0;border-right:none;border-bottom:none;border-top:none;border-radius:16px;top:16%}.color-green{background-color:#22c53c}.color-orange{background:#f7b501}.color-red{background:#ef4444}.color-disabled{background-color:#e7e8eb}.color-pending-font{color:#6f5100}.icon-color-gray{color:#b9bbbf!important}.color-orange-chip{background-color:#fff7e0}.custom-chip-border{border:2px solid white}.horizontal-dotted{background-image:linear-gradient(to right,gray 33%,transparent 0%);background-size:8px 2px;border-style:dotted}.bg-dotted{background-image:linear-gradient(to bottom,transparent 50%,currentColor 50%);background-size:1px 8px;background-repeat:repeat-y;color:#00f}.bg-right-dotted{background-image:linear-gradient(to right,transparent 50%,currentColor 50%);background-size:1px 8px;background-repeat:repeat-y}@media screen and (min-width: 1025px){.below-left-line{left:-2%}.below-line{left:97%}}@media screen and (max-width: 1025px){.below-left-line{left:-3%}.below-line{left:97%}}@media screen and (min-width: 1750px){.below-line{left:99%}}.per-row-two .below-left-line{left:-.5%}.per-row-two .below-line{left:98%}@media screen and (min-width: 1272px){.per-row-two .below-line{left:99%}}@media screen and (min-width: 1017px) and (max-width: 1907px){.per-row-three .below-line{left:98%}.per-row-three .below-left-line{left:-1%}}@media screen and (min-width: 1908px){.per-row-three .below-line{left:99%}.per-row-three .below-left-line{left:-1%}}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i9.MatLabel, selector: "mat-label" }, { kind: "pipe", type: ClTruncatePipe, name: "truncate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimelineActivityComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-timeline-activity', encapsulation: ViewEncapsulation.None, standalone: true, imports: [
                        NgClass,
                        MatIconModule,
                        MatFormFieldModule,
                        ClTruncatePipe,
                    ], template: "<!-- <div class=\"flex w-full\"> -->\n@for (activity of activities; track activity; let i = $index; let first = $first; let last = $last){\n<div id=\"row-{{i}}\" [style.grid-template-columns]=\"'repeat(' + properties.itemsPerRow + ', minmax(0, 1fr))'\"\n  class=\"grid\">\n  @for (step of activity; track step; let j = $index; let end = $last; let start = $first;){\n  <div class=\"\" [ngClass]=\"[i >= 1 ? 'mt-8' : '']\">\n    <div class=\"w-full z-10\">\n      <div class=\"relative flex flex-col items-center\">\n        <div class=\"flex flex-col items-center relative w-full\" [ngClass]=\"{'per-row-two': properties.itemsPerRow === 2,'per-row-three': properties.itemsPerRow === 3}\">\n          @if(i % 2 === 1 && start && !last ){\n          <div class=\"absolute inset-y-0 below-left-line mt-5\" [style]=\"{'height': getHeight(i)}\"></div>\n          }\n          @if(i % 2 === 0 && end && !last){\n          <div class=\"absolute inset-y-0 below-line mt-5\" [style]=\"{'height': getHeight(i)}\"></div>\n          }\n\n          @if(step.status !== ''){\n          @if(i%2==0 && !end){\n          <div class=\"absolute left-1/2 top-0 h-0.5 border-t border-dashed border-blue-600 w-full z-0 mt-5 mr-4 ml-3\"></div>\n          }\n          <!-- <div>{{j}} {{start}} {{end}} {{i%2==1}}</div> -->\n          @if(i%2==1 && (start || !end)){\n          <div class=\"absolute left-1/2 top-0 h-0.5 border-t border-dashed border-blue-600 w-full z-0 mt-5 mr-4 ml-3\"></div>\n          }\n          }\n\n          <!-- Icon -->\n          @if(step.icon && !step.image){\n\n          <div class=\"flex-shrink-0 items-center justify-center size-10 mr-4 rounded-full z-11\" [ngClass]=\"step.status === 'completed' ? 'color-green' : step.status === 'pending' ?\n                      'color-orange' : step.status === 'rejected'? 'color-red' : 'color-disabled'\">\n            <mat-icon [ngClass]=\"step.status === 'Not started'? 'icon-color-gray': ''\"\n              class=\"icon-size-custom text-white\" [svgIcon]=\"step.icon\"></mat-icon>\n          </div>\n\n          }\n\n          <!-- Image -->\n          @if(step.image){\n\n          <img class=\"shrink-0 size-10 mr-4 rounded-full overflow-hidden object-cover object-center z-11\"\n            [src]=\"step.image\" [alt]=\"'Activity image'\">\n\n          }\n          @if(i%2==0){\n          @if(end && !last){\n          <div class=\"absolute right-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 12px) !important;\"></div>\n          }\n          @else if(i!==0 && j==0){\n          @if(step.status !== ''){\n          <div class=\"absolute left-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 28px) !important;\"></div>\n          }\n          }\n          }\n          @if(i%2==1){\n          @if(end){\n          <div class=\"absolute right-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 12px) !important;\"></div>\n\n          }\n          @else if(j==0){\n          @if(step.status !== ''){\n            @if(!(last && activity.length==properties.itemsPerRow)){\n              <div class=\"absolute left-0 top-0 h-0.5 border-t border-dashed border-blue-600 z-0 mt-5\" style=\"width: calc(50% - 28px) !important;\"></div>\n            }\n          }\n          }\n          }\n        </div>\n\n\n        <!-- Content -->\n        <div class=\"flex flex-col flex-auto items-center\">\n          <!-- Description -->\n          @if(step.title){\n\n          <div class=\"font-family-title\" [ngClass]=\"step.status !== 'completed' ? 'disabled-font' : 'completed-font' \">\n            {{step.title}}</div>\n\n          }\n\n          @if(step.stepStatus){\n\n          @if(!step.stepStatus.hidden){\n          <div class=\"rounded-full {{ step.stepStatus.style?.cssClasses }} py-0.5 px-2 custom-chip-border\">\n            <mat-label class=\"flex w-full\n                      {{ step.stepStatus.style?.labelCssClasses }}\">\n\n              @if(step.stepStatus.label.textTrimLength == undefined){\n              <span>{{step.stepStatus.label}}</span>\n              }\n              @if(step.stepStatus.label.textTrimLength != undefined && step.stepStatus.label.textTrimLength\n              > 0){\n              <span>\n                {{step.stepStatus.label | truncate:[step.stepStatus.label.textTrimLength]}}\n              </span>\n              }\n              @if(step.stepStatus.label.optional){\n              <span class=\"optional-text\">(Optional)</span>\n              }\n\n            </mat-label>\n          </div>\n          }\n\n          }\n\n          @if(step.description){\n\n          <div class=\"font-family-extracontent\">\n            {{step.description}}\n          </div>\n\n          }\n          <div class=\"flex flex-row items-center mt-2 space-x-2 text-md leading-5\">\n            <!-- Date -->\n            @if(step.status === 'completed' || step.status === 'rejected'){\n            <div class=\"font-family-description\">\n              {{step.date}}\n            </div>\n            }\n          </div>\n        </div>\n      </div>\n    </div>\n\n\n  </div>\n  }\n</div>\n}\n<!-- </div> -->", styles: [".icon-size-custom{width:1.5rem!important;height:2.5rem!important;min-width:1.25rem!important;min-height:1.25rem!important;font-size:1.25rem!important;line-height:1.25rem!important;margin-left:8px}.divider{border-top:1px dashed #2D78E8;width:calc(100% - 8px);margin:8px 0}.font-family-title{font-family:Nunito;font-size:16px;font-weight:700;line-height:24px;letter-spacing:0em}.completed-font{color:#002660}.disabled-font{color:#a0a2a5}.font-family-description{font-family:Nunito;font-size:12px;font-weight:400;line-height:16px;letter-spacing:0em;color:#636467}.font-family-extracontent{font-family:Nunito;font-size:12px;font-weight:700;line-height:16px;letter-spacing:0em;color:#38393a}.dotted-line{position:absolute;top:16%;left:43%;width:50%;height:1px;border-bottom:1px dashed #2D78E8}.below-line{border:1px dashed rgb(37,99,235);width:13px;left:98%;border-left:none;border-bottom:none;border-top:none;border-radius:16px;top:16%}.below-left-line{border:1px dashed rgb(37,99,235);width:13px;left:0;border-right:none;border-bottom:none;border-top:none;border-radius:16px;top:16%}.color-green{background-color:#22c53c}.color-orange{background:#f7b501}.color-red{background:#ef4444}.color-disabled{background-color:#e7e8eb}.color-pending-font{color:#6f5100}.icon-color-gray{color:#b9bbbf!important}.color-orange-chip{background-color:#fff7e0}.custom-chip-border{border:2px solid white}.horizontal-dotted{background-image:linear-gradient(to right,gray 33%,transparent 0%);background-size:8px 2px;border-style:dotted}.bg-dotted{background-image:linear-gradient(to bottom,transparent 50%,currentColor 50%);background-size:1px 8px;background-repeat:repeat-y;color:#00f}.bg-right-dotted{background-image:linear-gradient(to right,transparent 50%,currentColor 50%);background-size:1px 8px;background-repeat:repeat-y}@media screen and (min-width: 1025px){.below-left-line{left:-2%}.below-line{left:97%}}@media screen and (max-width: 1025px){.below-left-line{left:-3%}.below-line{left:97%}}@media screen and (min-width: 1750px){.below-line{left:99%}}.per-row-two .below-left-line{left:-.5%}.per-row-two .below-line{left:98%}@media screen and (min-width: 1272px){.per-row-two .below-line{left:99%}}@media screen and (min-width: 1017px) and (max-width: 1907px){.per-row-three .below-line{left:98%}.per-row-three .below-left-line{left:-1%}}@media screen and (min-width: 1908px){.per-row-three .below-line{left:99%}.per-row-three .below-left-line{left:-1%}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { CL_GRID_DRAG_HANDLE, CL_GRID_ITEM_PLACEHOLDER, CL_GRID_RESIZE_HANDLE, ClAccordionComponent, ClAccordionProperties, ClAccordionStyleProperties, ClBottomSheetComponent, ClBottomSheetService, ClCardComponent, ClCardProperties, ClCardStyleProperties, ClCarouselComponent, ClCarouselContentComponent, ClCarouselProperties, ClCarouselStyleProperties, ClColumnType, ClDataGridComponent, ClDataGridService, ClDataGridStyleProperties, ClDragDropProperties, ClDragDropStyleProperties, ClDragDropUploadComponent, ClDualSortListComponent, ClDualSortListProperties, ClDualSortListStyleProperties, ClDynamicComponent, ClDynamicTreeViewComponent, ClDynamicTreeViewProperties, ClExpansionPanelComponent, ClExpansionPanelContentComponent, ClExpansionPanelDescriptionComponent, ClExpansionPanelDescriptionProperties, ClExpansionPanelHeaderComponent, ClExpansionPanelHeaderProperties, ClFileType, ClFormComponent, ClFormProperties, ClFormStyleProperties, ClGridComponent, ClGridDragHandle, ClGridItemComponent, ClGridItemPlaceholder, ClGridResizeHandle, ClModalWindowComponent, ClModalWindowService, ClResizableGridComponent, ClResizableGridItemComponent, ClResizableGridProperties, ClStepComponent, ClStepContentComponent, ClStepHeaderComponent, ClStepHeaderProperties, ClStepNextComponent, ClStepNextProperties, ClStepPreviousProperties, ClStepperComponent, ClStepperProperties, ClStepperStyleProperties, ClTabComponent, ClTabContentComponent, ClTabHeaderComponent, ClTabHeaderProperties, ClTableConfigProperties, ClTabsAlignment, ClTabsComponent, ClTabsProperties, ClTabsService, ClTabsStyleProperties, ClTimelineActivityComponent, ClTimelineActivityProperties, ClTimelineActivityStatus, ClTimelineActivityStyleProperties, ClWizardComponent, ClWizardOptionsStyleProperties, ClWizardProperties, ClWizardStyleProperties, DynamicTreeViewService, GRID_ITEM_GET_RENDER_DATA_TOKEN, StepPreviousComponent, __gridItemGetRenderDataFactoryFunc, clArrayRemoveItem, clGridCompact, clGridItemGetRenderDataFactoryFunc, clTrackById, parseRenderItemToPixels };
//# sourceMappingURL=clay-ui-components-containers.mjs.map
