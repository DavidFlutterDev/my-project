import * as i5$1 from '@angular/common';
import { NgClass, CommonModule, AsyncPipe, NgStyle } from '@angular/common';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/input';
import { MatInputModule, MatFormField as MatFormField$1 } from '@angular/material/input';
import * as i2$1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i4 from '@angular/material/form-field';
import { MatFormFieldModule, MatFormField, MatLabel } from '@angular/material/form-field';
import * as i1 from '@angular/forms';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i0 from '@angular/core';
import { signal, ViewChild, Input, Optional, Self, Component, EventEmitter, Output, ViewEncapsulation, Injectable, inject, forwardRef, Inject, computed } from '@angular/core';
import { ClTooltipDirective, ClPatternInputDirective } from '@clay/app-shell/structural';
import { ClBaseBehavior, ClComponentTypes, ClBaseComponent, ClInputPatternType } from '@clay/ui-components/shared';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i3$1 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import { clAnimations, ClTruncatePipe } from '@clay/ui-commons/ancillary';
import * as i2$2 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2$6 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import * as i1$1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i5 from '@angular/material/select';
import { MatSelectModule, MatSelectTrigger } from '@angular/material/select';
import * as i8 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i6 from '@angular/material/core';
import { MatOptionModule } from '@angular/material/core';
import { includes, filter, cloneDeep } from 'lodash';
import { SPACE, ENTER } from '@angular/cdk/keycodes';
import { includes as includes$1 } from 'lodash-es';
import * as i3$2 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i4$1 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i2$4 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i2$3 from '@angular/material/dialog';
import { MatDialogModule } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import * as i7 from '@angular/cdk/overlay';
import { OverlayModule } from '@angular/cdk/overlay';
import * as i2$5 from '@angular/material/button-toggle';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import * as i1$2 from '@angular/material/progress-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import * as i1$3 from '@angular/material/snack-bar';
import { MAT_SNACK_BAR_DATA, MatSnackBarModule } from '@angular/material/snack-bar';
import { of } from 'rxjs';
import * as i5$2 from '@angular/material/autocomplete';
import { MatAutocompleteModule, MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { ClHighlightComponent } from '@clay/ui-commons/ccc';
import * as pdfjsLib from 'pdfjs-dist';

var ClInputType;
(function (ClInputType) {
    ClInputType["text"] = "text";
    ClInputType["number"] = "number";
    ClInputType["password"] = "password";
})(ClInputType || (ClInputType = {}));
const ClInputBehavior = { ...ClBaseBehavior, ...ClInputType };
class ClInputStyleProperties {
}
class ClInputProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Input';
        this.floatLabel = 'auto';
        this.appearance = 'fill';
        this.subscriptSizing = 'fixed';
        this.inputType = ClInputType.text;
        this.type = ClComponentTypes.input;
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.style = new ClInputStyleProperties();
        this.style.cssClasses = 'flex-auto w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        // set additional default values here.
    }
}

class ClInputComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.numberTypeInputValue = 0;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClInputProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        if (this.inputType != this.properties?.inputType && this.properties?.inputType === ClInputType.number) {
            this.properties.pattern = { patternType: ClInputPatternType.numeric };
        }
        this.inputType = this.properties?.inputType;
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.valueChangesSub?.unsubscribe();
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onValueChange(ev) {
        let value = ev.value;
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    onSuffixIconClicked() {
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked(this);
        }
    }
    onPrefixIconClicked() {
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked(this);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    increment() {
        this.numberTypeInputValue = this._value != '' ? this._value : 0;
        // check if the form control is disabled or not
        // if it is disabled - return
        if (this.disabled) {
            return;
        }
        if (this.properties.max != undefined && this.numberTypeInputValue >= this.properties.max) {
            return;
        }
        else {
            this.numberTypeInputValue++;
            this._value = this.numberTypeInputValue;
            this.onChange(this._value);
        }
    }
    decrement() {
        this.numberTypeInputValue = this._value != '' ? this._value : 0;
        // check if the form control is disabled or not
        // if it is disabled - return
        if (this.disabled) {
            return;
        }
        if (this.properties.min != undefined && this.numberTypeInputValue <= this.properties.min) {
            return;
        }
        else {
            this.numberTypeInputValue--;
            this._value = this.numberTypeInputValue;
            this.onChange(this._value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClInputComponent, isStandalone: true, selector: "cl-input", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput [value]=\"value\" [disabled]=\"disabled\" [type]=\"properties.inputType!\"\n    [clPatternInput]=\"properties.pattern!\" [placeholder]=\"properties.placeholder!\"\n    [attr.minlength]=\"properties.minLength!\" [attr.maxlength]=\"properties.maxLength!\"\n    (input)=\"onValueChange($event.target)\" (blur)=\"onTouched($any($event.target).value)\"\n    (keyup)=\"writeValue($any($event.target).value)\" />\n\n  @if (properties.prefixLabel) {\n    <span matPrefix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.prefixLabel }}</span>\n  }\n\n  @if (properties.suffixLabel) {\n    <span matSuffix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.suffixLabel }}</span>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.inputType == 'number') {\n    <span matSuffix>\n      <div class=\"flex flex-col cl-input-increment-icons\">\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"increment()\" [svgIcon]=\"'fss_icons:up-arrow'\">\n        </mat-icon>\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"decrement()\" [svgIcon]=\"'fss_icons:down-arrow'\">\n        </mat-icon>\n      </div>\n    </span>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }, { kind: "directive", type: ClPatternInputDirective, selector: "[clPatternInput]", inputs: ["clPatternInput", "allowedSpecialChars"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-input', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective,
                        ClPatternInputDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput [value]=\"value\" [disabled]=\"disabled\" [type]=\"properties.inputType!\"\n    [clPatternInput]=\"properties.pattern!\" [placeholder]=\"properties.placeholder!\"\n    [attr.minlength]=\"properties.minLength!\" [attr.maxlength]=\"properties.maxLength!\"\n    (input)=\"onValueChange($event.target)\" (blur)=\"onTouched($any($event.target).value)\"\n    (keyup)=\"writeValue($any($event.target).value)\" />\n\n  @if (properties.prefixLabel) {\n    <span matPrefix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.prefixLabel }}</span>\n  }\n\n  @if (properties.suffixLabel) {\n    <span matSuffix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.suffixLabel }}</span>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.inputType == 'number') {\n    <span matSuffix>\n      <div class=\"flex flex-col cl-input-increment-icons\">\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"increment()\" [svgIcon]=\"'fss_icons:up-arrow'\">\n        </mat-icon>\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"decrement()\" [svgIcon]=\"'fss_icons:down-arrow'\">\n        </mat-icon>\n      </div>\n    </span>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClChipStyleProperties {
}
class ClChipProperties {
    constructor() {
        this.label = 'Chip';
        this.hidden = false;
        this.id = 'default0';
        this.type = ClComponentTypes.chip;
        this.style = new ClChipStyleProperties();
        this.style.cssClasses = 'py-0.5 px-2 text-md text-primary bg-primary';
        this.style.labelCssClasses = 'text-md text-white';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClChipComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClChipProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClChipComponent, isStandalone: true, selector: "cl-chip", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"{{properties.style?.cssClasses}} flex rounded-full items-center justify-center\">\n  <span class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</span>\n</div>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chip', template: "<div [id]=\"properties.id\" class=\"{{properties.style?.cssClasses}} flex rounded-full items-center justify-center\">\n  <span class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</span>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClChipListStyleProperties {
}
class ClChipListProperties {
    constructor() {
        this.id = 'default0';
        this.multiple = true;
        this.optional = false;
        this.disabled = false;
        this.direction = 'row';
        this.label = 'Chip List';
        this.showOptionAll = false;
        this.type = ClComponentTypes.chipList;
        this.style = new ClChipListStyleProperties();
        this.style.cssClasses = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.showInfoMsg = signal(false);
        this.optionAllProperties = {
            text: 'Select All',
            value: 'All',
            disabled: false,
            isSelected: false
        };
        this.options = [
            { text: 'Chip 1', value: 'chip1', isSelected: true, disabled: false },
            { text: 'Chip 2', value: 'chip2', isSelected: false, disabled: false },
            { text: 'Chip 3', value: 'chip3', isSelected: false, disabled: false },
            { text: 'Chip 4', value: 'chip4', isSelected: false, disabled: false },
            { text: 'Chip 5', value: 'chip5', isSelected: false, disabled: false }
        ];
    }
}

class ClChipListOptionComponent {
    constructor() {
        this.optionSelected = new EventEmitter();
    }
    onChipsSelected() {
        if (!this.chip.disabled && !this.listDisabled) {
            this.optionSelected.emit({ chip: this.chip, index: this.index });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListOptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChipListOptionComponent, isStandalone: true, selector: "cl-chip-list-option", inputs: { index: "index", iconCssClasses: "iconCssClasses", imageCssClasses: "imageCssClasses", listDisabled: "listDisabled", chip: "chip" }, outputs: { optionSelected: "optionSelected" }, ngImport: i0, template: "<div (click)=\"onChipsSelected()\" class=\"chip {{(chip.disabled || listDisabled) ? 'disabled' : 'cursor-pointer'}}\">\n  @if (chip.icon) {\n    <mat-icon [class]=\"iconCssClasses\" [svgIcon]=\"chip.icon\"></mat-icon>\n  } @else if (chip.image) {\n    <img [alt]=\"chip.text\" [src]=\"chip.image\" [class]=\"imageCssClasses\" />\n  }\n\n  <mat-label class=\"leading-5 font-normal text-neutral-900\">{{ chip.text }}</mat-label>\n\n  <mat-icon class=\"icon-size-4\"\n    [svgIcon]=\"(chip.isSelected && (chip.disabled || listDisabled)) ? 'fss_icons:filled-circle-check-light-primary' : (chip.isSelected && !(chip.disabled || listDisabled)) ? 'fss_icons:filled-circle-check' : 'fss_icons:filled-circle-check-gray'\">\n  </mat-icon>\n</div>\n", styles: [".chip{display:flex;align-items:center;gap:.5rem;border-radius:1rem;border-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgba(var(--cl-primary-200-rgb),var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity));padding:.25rem .75rem}.chip.disabled{border-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important;--tw-bg-opacity: 1 !important;background-color:rgb(245 245 245 / var(--tw-bg-opacity))!important}\n"], dependencies: [{ kind: "directive", type: MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListOptionComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chip-list-option', imports: [
                        MatLabel,
                        MatIconModule,
                    ], template: "<div (click)=\"onChipsSelected()\" class=\"chip {{(chip.disabled || listDisabled) ? 'disabled' : 'cursor-pointer'}}\">\n  @if (chip.icon) {\n    <mat-icon [class]=\"iconCssClasses\" [svgIcon]=\"chip.icon\"></mat-icon>\n  } @else if (chip.image) {\n    <img [alt]=\"chip.text\" [src]=\"chip.image\" [class]=\"imageCssClasses\" />\n  }\n\n  <mat-label class=\"leading-5 font-normal text-neutral-900\">{{ chip.text }}</mat-label>\n\n  <mat-icon class=\"icon-size-4\"\n    [svgIcon]=\"(chip.isSelected && (chip.disabled || listDisabled)) ? 'fss_icons:filled-circle-check-light-primary' : (chip.isSelected && !(chip.disabled || listDisabled)) ? 'fss_icons:filled-circle-check' : 'fss_icons:filled-circle-check-gray'\">\n  </mat-icon>\n</div>\n", styles: [".chip{display:flex;align-items:center;gap:.5rem;border-radius:1rem;border-width:1px;border-style:solid;--tw-border-opacity: 1;border-color:rgba(var(--cl-primary-200-rgb),var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity));padding:.25rem .75rem}.chip.disabled{border-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important;--tw-bg-opacity: 1 !important;background-color:rgb(245 245 245 / var(--tw-bg-opacity))!important}\n"] }]
        }], propDecorators: { index: [{
                type: Input,
                args: [{ required: true }]
            }], iconCssClasses: [{
                type: Input
            }], imageCssClasses: [{
                type: Input
            }], listDisabled: [{
                type: Input
            }], chip: [{
                type: Input,
                args: [{ required: true }]
            }], optionSelected: [{
                type: Output
            }] } });

class ClChipListComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_value) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClChipListProperties();
        // calling set default value function
        // this.setDefaultValue();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            ?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
        }
    }
    // private setDefaultValue() {
    //   if (this.properties.disabled) {
    //     if(this.properties.showOptionAll && this.properties.optionAllProperties) {
    //       this.properties.optionAllProperties.disabled = true;
    //     }
    //     this.properties.options?.forEach((option: ClChipListOptions) => option.disabled = true);
    //   } else {
    //     if(this.properties.showOptionAll && this.properties.optionAllProperties) {
    //       this.properties.optionAllProperties.disabled = false;
    //     }
    //   }
    // }
    onChipsSelected(index) {
        if (this.properties.options[index].disabled) {
            return;
        }
        this.onTouched(true);
        if (this.properties.multiple) {
            this.toggleMultipleSelection(index);
        }
        else {
            this.toggleSingleSelection(index);
        }
        this.emitSelectedOptions();
    }
    onOptionAllSelected() {
        if (this.properties.optionAllProperties?.disabled) {
            return;
        }
        this.onTouched(true);
        if (this.properties.optionAllProperties) {
            this.properties.optionAllProperties.isSelected = !this.properties.optionAllProperties.isSelected;
            for (let eachChip of this.properties.options) {
                eachChip.isSelected = this.properties.optionAllProperties.isSelected;
            }
            this.emitSelectedOptions();
        }
    }
    toggleMultipleSelection(index) {
        const option = this.properties.options[index];
        option.isSelected = !option.isSelected;
        this.checkIfAllOptionsAreSelectedInOptionsList();
    }
    toggleSingleSelection(index) {
        for (const option of this.properties.options) {
            option.isSelected = false;
        }
        this.properties.options[index].isSelected = true;
    }
    checkIfAllOptionsAreSelectedInOptionsList() {
        let allOptionsSelected = true;
        for (const option of this.properties.options) {
            if (!option.isSelected) {
                allOptionsSelected = false;
            }
        }
        if (this.properties.optionAllProperties) {
            this.properties.optionAllProperties.isSelected = allOptionsSelected;
        }
    }
    emitSelectedOptions() {
        const selectedOptions = this.properties.options.filter((option) => option.isSelected);
        this.onChange(selectedOptions);
        this.writeValue(selectedOptions);
        if (this.properties.optionsSelected) {
            this.properties.optionsSelected(selectedOptions);
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChipListComponent, isStandalone: true, selector: "cl-chip-list", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col\">\n  <div\n    class=\"flex {{ properties.style?.cssClasses }} {{ properties.direction == 'row' ? 'flex-row items-center' : 'flex-col' }}\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n      <div class=\"flex items-center {{ properties.direction === 'row' ? 'w-32' : 'mb-1' }}\">\n        <div class=\"break-all {{ properties.style?.labelCssClasses }}\">{{ properties.label }}</div>\n\n        @if (properties.optional) {\n          <span class=\"optional-text\">(Optional)</span>\n        }\n\n        @if (properties.infoMsg && showInfoMsg) {\n          <mat-icon [tooltip]=\"properties.infoMsg!\"\n            [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n          </mat-icon>\n        }\n      </div>\n    }\n\n    <div class=\"flex gap-2\">\n      @if (properties.showOptionAll && properties.optionAllProperties && properties.multiple) {\n        <cl-chip-list-option [index]=\"0\" [chip]=\"properties.optionAllProperties\" (optionSelected)=\"onOptionAllSelected()\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n\n      @for (chip of properties.options; track chip; let optionIndex = $index;) {\n        <cl-chip-list-option [chip]=\"chip\" [index]=\"optionIndex\" (optionSelected)=\"onChipsSelected(optionIndex)\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n    </div>\n  </div>\n\n  @if (error) {\n    <mat-error class=\"text-warn\">{{ error }}</mat-error>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "component", type: ClChipListOptionComponent, selector: "cl-chip-list-option", inputs: ["index", "iconCssClasses", "imageCssClasses", "listDisabled", "chip"], outputs: ["optionSelected"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], animations: clAnimations }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chip-list', animations: clAnimations, imports: [
                        MatIconModule,
                        MatChipsModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClChipListOptionComponent,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col\">\n  <div\n    class=\"flex {{ properties.style?.cssClasses }} {{ properties.direction == 'row' ? 'flex-row items-center' : 'flex-col' }}\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n      <div class=\"flex items-center {{ properties.direction === 'row' ? 'w-32' : 'mb-1' }}\">\n        <div class=\"break-all {{ properties.style?.labelCssClasses }}\">{{ properties.label }}</div>\n\n        @if (properties.optional) {\n          <span class=\"optional-text\">(Optional)</span>\n        }\n\n        @if (properties.infoMsg && showInfoMsg) {\n          <mat-icon [tooltip]=\"properties.infoMsg!\"\n            [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n          </mat-icon>\n        }\n      </div>\n    }\n\n    <div class=\"flex gap-2\">\n      @if (properties.showOptionAll && properties.optionAllProperties && properties.multiple) {\n        <cl-chip-list-option [index]=\"0\" [chip]=\"properties.optionAllProperties\" (optionSelected)=\"onOptionAllSelected()\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n\n      @for (chip of properties.options; track chip; let optionIndex = $index;) {\n        <cl-chip-list-option [chip]=\"chip\" [index]=\"optionIndex\" (optionSelected)=\"onChipsSelected(optionIndex)\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n    </div>\n  </div>\n\n  @if (error) {\n    <mat-error class=\"text-warn\">{{ error }}</mat-error>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClLabelStyleProperties {
}
class ClLabelProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Label';
        this.showTooltip = false;
        this.type = ClComponentTypes.label;
        this.showInfoMsg = signal(false);
        this.style = new ClLabelStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'text-base text-neutral-700';
    }
}

class ClLabelComponent extends ClBaseComponent {
    // ---------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClLabelProperties();
        super.ngOnInit();
    }
    onLabelClick() {
        if (this.properties.onClick) {
            this.properties.onClick();
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClLabelComponent, isStandalone: true, selector: "cl-label", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" (click)=\"onLabelClick()\" class=\"{{ properties.style?.cssClasses }} flex items-center\"\n  [matTooltip]=\"properties.showTooltip ? properties.label!: ''\">\n\n  @if (properties.lengthToTrim == undefined) {\n    <span>{{ properties.label }}</span>\n  } @else if (properties.lengthToTrim != undefined) {\n    <span>{{ properties.label | truncate: [properties.lengthToTrim] }}</span>\n  }\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n</div>\n", styles: [":host{display:flex!important}\n"], dependencies: [{ kind: "pipe", type: ClTruncatePipe, name: "truncate" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClLabelComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-label', imports: [
                        ClTruncatePipe,
                        MatIconModule,
                        MatTooltipModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" (click)=\"onLabelClick()\" class=\"{{ properties.style?.cssClasses }} flex items-center\"\n  [matTooltip]=\"properties.showTooltip ? properties.label!: ''\">\n\n  @if (properties.lengthToTrim == undefined) {\n    <span>{{ properties.label }}</span>\n  } @else if (properties.lengthToTrim != undefined) {\n    <span>{{ properties.label | truncate: [properties.lengthToTrim] }}</span>\n  }\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n</div>\n", styles: [":host{display:flex!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

var IClButtonType;
(function (IClButtonType) {
    IClButtonType["reset"] = "reset";
    IClButtonType["button"] = "button";
    IClButtonType["submit"] = "submit";
})(IClButtonType || (IClButtonType = {}));
var ClComponentBehaviors;
(function (ClComponentBehaviors) {
    ClComponentBehaviors["flat"] = "flat";
    ClComponentBehaviors["icon"] = "icon";
    ClComponentBehaviors["raised"] = "raised";
})(ClComponentBehaviors || (ClComponentBehaviors = {}));
const ClButtonBehavior = { ...ClBaseBehavior, ...ClComponentBehaviors };
class ClButtonStyleProperties {
}
class ClButtonProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Button';
        this.disabled = signal(false);
        this.showFailed = false;
        this.showLoading = false;
        this.showSuccess = false;
        this.type = ClComponentTypes.button;
        this.buttonType = IClButtonType.button;
        this.buttonBehavior = ClButtonBehavior.flat;
        this.style = new ClButtonStyleProperties();
        this.style.buttonSize = '';
        this.style.alignContent = '';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.iconCssClasses = '';
        this.style.labelCssClasses = '';
        this.style.cssClasses = 'mat-primary';
    }
}

class ClButtonComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        // ---------------------------
        this.buttonLabel = '';
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(changes) {
        this.showFailed = this.properties.showFailed;
        this.showSuccess = this.properties.showSuccess;
        this.showLoading = this.properties.showLoading;
        // this.properties.disabled = signal<boolean>(this.disabled ?? false);
        // calling update button label function
        this.buttonLabel = this.updateButtonLabel();
    }
    ngOnInit() {
        this.properties ??= new ClButtonProperties();
        super.ngOnInit();
    }
    updateButtonLabel() {
        if (this.showLoading) {
            return this.properties.loadingLabel ?? "Processing...";
        }
        if (this.showFailed) {
            return this.properties.failedLabel ?? 'Failed';
        }
        return (this.showSuccess ? this.properties.successLabel ?? 'Done' : this.properties.label) ?? '';
    }
    onSubmit() {
        if (this.properties.onSubmit && this.properties.buttonType != IClButtonType.submit) {
            this.properties.onSubmit(this);
        }
    }
    get isDisabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClButtonComponent, isStandalone: true, selector: "cl-button", inputs: { disabled: "disabled", showFailed: "showFailed", showSuccess: "showSuccess", showLoading: "showLoading", properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "@switch (properties.buttonBehavior) {\n  @case ('raised') {\n    <button mat-raised-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      <span class=\"flex gap-1 items-center\">\n        @if (properties.label) {\n          <div class=\"{{ properties.style?.labelCssClasses }} cursor-pointer\">{{ updateButtonLabel() }}</div>\n        }\n\n        @if (showLoading) {\n          <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n          </mat-icon>\n        }\n\n        @if (showFailed && !showSuccess) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n          </mat-icon>\n        }\n\n        @if (showSuccess && !showLoading) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n          </mat-icon>\n        }\n      </span>\n    </button>\n  }\n\n  @case ('icon') {\n    <button mat-icon-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      @if (showLoading) {\n        <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n        </mat-icon>\n      }\n\n      @if (showFailed && !showSuccess) {\n        <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n        </mat-icon>\n      }\n\n      @if (showSuccess && !showLoading) {\n        <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n        </mat-icon>\n      }\n    </button>\n  }\n\n  @default {\n    <button mat-flat-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      <span class=\"flex gap-1 items-center\">\n        @if (properties.label) {\n          <div class=\"{{ properties.style?.labelCssClasses }} cursor-pointer\">{{ updateButtonLabel() }}</div>\n        }\n\n        @if (showLoading) {\n          <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n          </mat-icon>\n        }\n\n        @if (showFailed && !showSuccess) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n          </mat-icon>\n        }\n\n        @if (showSuccess && !showLoading) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n          </mat-icon>\n        }\n      </span>\n    </button>\n  }\n}\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2$2.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i2$2.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-button', imports: [
                        MatIconModule,
                        MatButtonModule,
                        MatProgressSpinnerModule,
                    ], template: "@switch (properties.buttonBehavior) {\n  @case ('raised') {\n    <button mat-raised-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      <span class=\"flex gap-1 items-center\">\n        @if (properties.label) {\n          <div class=\"{{ properties.style?.labelCssClasses }} cursor-pointer\">{{ updateButtonLabel() }}</div>\n        }\n\n        @if (showLoading) {\n          <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n          </mat-icon>\n        }\n\n        @if (showFailed && !showSuccess) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n          </mat-icon>\n        }\n\n        @if (showSuccess && !showLoading) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n          </mat-icon>\n        }\n      </span>\n    </button>\n  }\n\n  @case ('icon') {\n    <button mat-icon-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      @if (showLoading) {\n        <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n        </mat-icon>\n      }\n\n      @if (showFailed && !showSuccess) {\n        <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n        </mat-icon>\n      }\n\n      @if (showSuccess && !showLoading) {\n        <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n        </mat-icon>\n      }\n    </button>\n  }\n\n  @default {\n    <button mat-flat-button (click)=\"onSubmit()\" [id]=\"properties.id\" [disabled]=\"isDisabled\" [type]=\"properties.buttonType!\"\n      class=\"gap-2 {{ properties.style?.cssClasses }} {{ properties.style?.buttonSize }}\">\n\n      @if (properties.icon && !showLoading && !showFailed && !showSuccess) {\n        <mat-icon [svgIcon]=\"properties.icon!\" class=\"{{ properties.style?.iconCssClasses }}\">\n        </mat-icon>\n      }\n\n      <span class=\"flex gap-1 items-center\">\n        @if (properties.label) {\n          <div class=\"{{ properties.style?.labelCssClasses }} cursor-pointer\">{{ updateButtonLabel() }}</div>\n        }\n\n        @if (showLoading) {\n          <mat-icon [svgIcon]=\"'fss_icons:loading'\" class=\"icon-size-5 animate-spin\">\n          </mat-icon>\n        }\n\n        @if (showFailed && !showSuccess) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:info-fill-failed'\">\n          </mat-icon>\n        }\n\n        @if (showSuccess && !showLoading) {\n          <mat-icon class=\"icon-size-5\" [svgIcon]=\"'fss_icons:filled-circle-check-success'\">\n          </mat-icon>\n        }\n      </span>\n    </button>\n  }\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { disabled: [{
                type: Input
            }], showFailed: [{
                type: Input
            }], showSuccess: [{
                type: Input
            }], showLoading: [{
                type: Input
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClTextareaStyleProperties {
}
class ClTextareaProperties {
    constructor() {
        this.rows = 1;
        this.label = '';
        this.id = 'default0';
        this.label = 'Textarea';
        this.showCounter = true;
        this.subscriptSizing = 'fixed';
        this.appearance = 'outline';
        this.type = ClComponentTypes.textarea;
        this.minLength = 0;
        this.maxLength = 100;
        this.style = new ClTextareaStyleProperties();
        this.style.cssClasses = 'flex-auto w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
    }
}

class ClTextareaComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClTextareaProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.hintOrErrorTextDivElement = this.hintOrErrorTextDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    onValueChange(ev) {
        let value = ev.value;
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextareaComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTextareaComponent, isStandalone: true, selector: "cl-textarea", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField$1, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <textarea matInput #textarea [value]=\"value\" [disabled]=\"disabled\" [rows]=\"properties.rows\"\n    [type]=\"properties.behaviorType!\" [minLength]=\"properties.minLength\" [maxLength]=\"properties.maxLength\"\n    [placeholder]=\"properties.placeholder!\" (input)=\"onValueChange($event.target)\"\n    (blur)=\"onTouched($any($event.target).value)\" (keyup)=\"writeValue($any($event.target).value)\">\n  </textarea>\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"flex w-full items-center justify-between {{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  <!-- <div #hintOrErrorTextDiv class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n    <mat-error class=\"w-full\">{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint class=\"w-full\">{{ properties.hintText }}</mat-hint>\n  }\n\n  @if (properties.showCounter && properties.maxLength) {\n    <div #counterTextDiv class=\"flex place-content-end {{ error ? 'w-1/4' : 'w-full' }}\">{{ textarea.value ? textarea.value.length : 0 }} / {{ properties.maxLength }}</div>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextareaComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-textarea', imports: [
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <textarea matInput #textarea [value]=\"value\" [disabled]=\"disabled\" [rows]=\"properties.rows\"\n    [type]=\"properties.behaviorType!\" [minLength]=\"properties.minLength\" [maxLength]=\"properties.maxLength\"\n    [placeholder]=\"properties.placeholder!\" (input)=\"onValueChange($event.target)\"\n    (blur)=\"onTouched($any($event.target).value)\" (keyup)=\"writeValue($any($event.target).value)\">\n  </textarea>\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"flex w-full items-center justify-between {{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  <!-- <div #hintOrErrorTextDiv class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n    <mat-error class=\"w-full\">{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint class=\"w-full\">{{ properties.hintText }}</mat-hint>\n  }\n\n  @if (properties.showCounter && properties.maxLength) {\n    <div #counterTextDiv class=\"flex place-content-end {{ error ? 'w-1/4' : 'w-full' }}\">{{ textarea.value ? textarea.value.length : 0 }} / {{ properties.maxLength }}</div>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField$1]
            }] } });

class ClIconStyleProperties {
}
class ClIconProperties {
    constructor() {
        this.id = 'default0';
        this.type = ClComponentTypes.icon;
        this.style = new ClIconStyleProperties();
        this.style.cssClasses = 'icon-size-4';
        this.style.contentWidth = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
    }
}

class ClIconComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClIconProperties();
        super.ngOnInit();
    }
    onIconClicked() {
        if (this.properties.onIconClicked != undefined) {
            this.properties.onIconClicked();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClIconComponent, isStandalone: true, selector: "cl-icon", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-icon [id]=\"properties.id\" (click)=\"onIconClicked()\" [svgIcon]=\"properties.iconName!\"\n  [matTooltip]=\"properties.tooltip?? ''\" [matTooltipPosition]=\"properties.tooltipPosition ?? 'above'\"\n  class=\"{{ properties.style?.cssClasses }} flex items-center justify-center {{ this.properties.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n</mat-icon>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-icon', imports: [
                        MatIconModule,
                        MatTooltipModule
                    ], template: "<mat-icon [id]=\"properties.id\" (click)=\"onIconClicked()\" [svgIcon]=\"properties.iconName!\"\n  [matTooltip]=\"properties.tooltip?? ''\" [matTooltipPosition]=\"properties.tooltipPosition ?? 'above'\"\n  class=\"{{ properties.style?.cssClasses }} flex items-center justify-center {{ this.properties.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n</mat-icon>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClMenuStyleProperties {
}
class ClMenuProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Label';
        this.type = ClComponentTypes.menu;
        this.style = new ClMenuStyleProperties();
        this.style.cssClasses = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.labelCssClasses = 'text-base text-neutral-700';
        this.children = [
            { id: '1', label: 'A' },
            { id: '2', label: 'B' },
            { id: '3', label: 'C' },
        ];
    }
}

class ClMenuItemComponent {
    constructor() {
        this.items = [];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMenuItemComponent, isStandalone: true, selector: "cl-menu-item", inputs: { items: "items" }, viewQueries: [{ propertyName: "childMenu", first: true, predicate: ["childMenu"], descendants: true }], ngImport: i0, template: "<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\">\n  @for (child of items; track $index) {\n\n  <!-- Handle branch node menu items -->\n  @if (child.children && child.children.length > 0) {\n  <button mat-menu-item color=\"primary\" [matMenuTriggerFor]=\"menu.childMenu\" class=\"flex items-center\">\n    <!-- <cl-icon *ngIf=\"child.icon\" [properties]=\"child.icon!\"></cl-icon> -->\n    @if (child.icon) {<mat-icon [svgIcon]=\"child.icon\"></mat-icon>}\n\n    <span>{{child.label}}</span>\n  </button>\n\n  <cl-menu-item #menu [items]=\"child.children\"></cl-menu-item>\n  }\n\n  <!-- Handle branch node menu items -->\n\n  <!-- Handle leaf node menu items -->\n  @if (!child.children || child.children.length === 0) {\n  <button mat-menu-item class=\"flex items-center\">\n    <!-- <cl-icon *ngIf=\"child.icon\" [properties]=\"child.icon!\"></cl-icon> -->\n    @if (child.icon) {<mat-icon [svgIcon]=\"child.icon\"></mat-icon>}\n\n    <span>{{child.label}}</span>\n  </button>\n  }\n\n  <!-- Handle leaf node menu items -->\n\n  }\n</mat-menu>\n", dependencies: [{ kind: "component", type: ClMenuItemComponent, selector: "cl-menu-item", inputs: ["items"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i1$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i1$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuItemComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-menu-item', imports: [MatMenuModule, MatIconModule, ClIconComponent], template: "<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\">\n  @for (child of items; track $index) {\n\n  <!-- Handle branch node menu items -->\n  @if (child.children && child.children.length > 0) {\n  <button mat-menu-item color=\"primary\" [matMenuTriggerFor]=\"menu.childMenu\" class=\"flex items-center\">\n    <!-- <cl-icon *ngIf=\"child.icon\" [properties]=\"child.icon!\"></cl-icon> -->\n    @if (child.icon) {<mat-icon [svgIcon]=\"child.icon\"></mat-icon>}\n\n    <span>{{child.label}}</span>\n  </button>\n\n  <cl-menu-item #menu [items]=\"child.children\"></cl-menu-item>\n  }\n\n  <!-- Handle branch node menu items -->\n\n  <!-- Handle leaf node menu items -->\n  @if (!child.children || child.children.length === 0) {\n  <button mat-menu-item class=\"flex items-center\">\n    <!-- <cl-icon *ngIf=\"child.icon\" [properties]=\"child.icon!\"></cl-icon> -->\n    @if (child.icon) {<mat-icon [svgIcon]=\"child.icon\"></mat-icon>}\n\n    <span>{{child.label}}</span>\n  </button>\n  }\n\n  <!-- Handle leaf node menu items -->\n\n  }\n</mat-menu>\n" }]
        }], propDecorators: { items: [{
                type: Input
            }], childMenu: [{
                type: ViewChild,
                args: ['childMenu']
            }] } });

class ClMenuComponent extends ClBaseComponent {
    // ---------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClMenuProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMenuComponent, isStandalone: true, selector: "cl-menu", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<button mat-flat-button type=\"button\" [id]=\"properties.id\" [matMenuTriggerFor]=\"menu.childMenu\"\n  class=\"{{properties.style?.cssClasses}} px-4 py-2 flex gap-1 items-center justify-center\">\n\n  <div class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</div>\n\n  @if (properties.iconName) {\n    <mat-icon [svgIcon]=\"properties.iconName\"></mat-icon>\n  }\n</button>\n\n<cl-menu-item #menu [items]=\"properties.children!\"></cl-menu-item>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "directive", type: i1$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: ClMenuItemComponent, selector: "cl-menu-item", inputs: ["items"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-menu', imports: [
                        MatIconModule,
                        MatMenuModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClMenuItemComponent,
                    ], template: "<button mat-flat-button type=\"button\" [id]=\"properties.id\" [matMenuTriggerFor]=\"menu.childMenu\"\n  class=\"{{properties.style?.cssClasses}} px-4 py-2 flex gap-1 items-center justify-center\">\n\n  <div class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</div>\n\n  @if (properties.iconName) {\n    <mat-icon [svgIcon]=\"properties.iconName\"></mat-icon>\n  }\n</button>\n\n<cl-menu-item #menu [items]=\"properties.children!\"></cl-menu-item>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClSelectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClSelectProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having selected as true and check with the value.
        // if both are not same update the value with the selected true option
        const selectedOption = this.properties.options?.find((opt) => opt.selected == true);
        if (selectedOption && selectedOption.value != this._value) {
            this.writeValue(selectedOption.value);
        }
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            .subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        if (value) {
            this.properties.options?.forEach((option) => {
                if (option.value === value) {
                    option.selected = true;
                }
                else {
                    option.selected = false;
                }
            });
            this._value = value;
        }
        else {
            this.properties.options?.forEach((option) => {
                option.selected = false;
            });
            this._value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onCustomFieldSelected() {
        // this.matSelect.close();
        if (this.properties.onCustomFieldSelected != undefined) {
            this.properties.onCustomFieldSelected();
        }
    }
    onValueChange(value) {
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    clearSelection() {
        this.onValueChange('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClSelectComponent, isStandalone: true, selector: "cl-select", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- custom field div -->\n    @if (properties.showCustomField!) {\n      <div (click)=\"onCustomFieldSelected()\"\n        class=\"flex p-1 w-full h-12 min-h-12 items-center cursor-pointer cl-mat-select-option\">\n\n        @if (properties.customFieldIcon!) {\n          <cl-icon class=\"mr-2 icon-size-5\" [properties]=\"properties.customFieldIcon\">\n          </cl-icon>\n        }\n\n        <cl-label [properties]=\"properties.customFieldLabel!\">\n        </cl-label>\n      </div>\n    }\n\n    <!-- custom field div -->\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" class=\"flex items-center justify-between cl-mat-select-option\"\n        [ngClass]=\"{'hidden': option.hidden}\">\n\n        <mat-label class=\"{{option.cssClasses}}\">{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n  }\n\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-select', imports: [
                        NgClass,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- custom field div -->\n    @if (properties.showCustomField!) {\n      <div (click)=\"onCustomFieldSelected()\"\n        class=\"flex p-1 w-full h-12 min-h-12 items-center cursor-pointer cl-mat-select-option\">\n\n        @if (properties.customFieldIcon!) {\n          <cl-icon class=\"mr-2 icon-size-5\" [properties]=\"properties.customFieldIcon\">\n          </cl-icon>\n        }\n\n        <cl-label [properties]=\"properties.customFieldLabel!\">\n        </cl-label>\n      </div>\n    }\n\n    <!-- custom field div -->\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" class=\"flex items-center justify-between cl-mat-select-option\"\n        [ngClass]=\"{'hidden': option.hidden}\">\n\n        <mat-label class=\"{{option.cssClasses}}\">{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n  }\n\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClSelectStyleProperties {
}
class ClSelectProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Select';
        this.appearance = "fill";
        this.subscriptSizing = 'fixed';
        this.type = ClComponentTypes.select;
        this.style = new ClSelectStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            { text: 'Option 1', value: 'option1' },
            { text: 'Option 2', value: 'option2' },
        ];
    }
}

class ClMultiSelectStyleProperties {
}
class ClMultiSelectProperties {
    constructor() {
        this.itemLimit = 3;
        this.id = 'default0';
        this.subscriptSizing = 'fixed';
        this.appearance = "fill";
        this.label = 'Multi Select';
        this.type = ClComponentTypes.multiselect;
        this.style = new ClMultiSelectStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            { text: 'Option 1', value: 'option1' },
            { text: 'Option 2', value: 'option2' },
        ];
    }
}

class ClMultiselectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClMultiSelectProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            this.writeValue(value);
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    remove(value) {
        this.properties.options.forEach((option) => {
            if (option.value == value) {
                option.selected = false;
            }
        });
        const selectedVal = this.selectedOptions.map((option) => option.value);
        this.onValueChange(selectedVal);
    }
    writeValue(values) {
        // this.properties.options!.forEach((item: any) => item.hidden = false);
        if (values?.length) {
            this.properties.options.forEach((option) => {
                if (includes(values, option.value)) {
                    option.selected = true;
                }
                else {
                    option.selected = false;
                }
            });
        }
        else {
            this.properties.options.forEach((item) => item.selected = false);
        }
        const selectedVal = this.selectedOptions.map((option) => option.value);
        this._value = selectedVal;
    }
    toggleSelectAll(checked) {
        if (checked) {
            this.onValueChange(this.properties.options.map((option) => option.value));
        }
        else {
            this.onValueChange([]);
        }
    }
    get selectedValues() {
        this._value = this.selectedOptions.map((option) => option.value);
        return this._value;
    }
    get selectedOptions() {
        return filter(this.properties.options, 'selected');
    }
    onValueChange(value) {
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    onTouchedOutput(value) {
        // this.writeValue(value);
        // this.onTouched(this._value);
        if (this.properties.onTouched) {
            this.properties.onTouched(this._value);
        }
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onValueChange('');
        //this.onTouchedOutput('');
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiselectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMultiselectComponent, isStandalone: true, selector: "cl-multiselect", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [disabled]=\"disabled\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\" (blur)=\"onTouchedOutput($any($event.target).value)\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">{{ selectedOption.text }}</mat-label>\n\n                <mat-icon (click)=\"remove(selectedOption.value)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n      <mat-checkbox color=\"primary\" (change)=\"toggleSelectAll($event.checked)\"\n        class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        [checked]=\"selectedOptions.length == properties.options!.length\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}:host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3$1.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i3$1.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i8.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiselectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-multiselect', imports: [
                        NgClass,
                        MatIconModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [disabled]=\"disabled\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\" (blur)=\"onTouchedOutput($any($event.target).value)\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">{{ selectedOption.text }}</mat-label>\n\n                <mat-icon (click)=\"remove(selectedOption.value)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n      <mat-checkbox color=\"primary\" (change)=\"toggleSelectAll($event.checked)\"\n        class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        [checked]=\"selectedOptions.length == properties.options!.length\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}:host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClAutoCompleteStyleProperties {
}
class ClAutoCompleteProperties {
    constructor() {
        this.id = 'default0';
        this.floatLabel = 'auto';
        this.subscriptSizing = 'fixed';
        this.appearance = "fill";
        this.label = 'Autocomplete';
        this.type = ClComponentTypes.autocomplete;
        this.style = new ClAutoCompleteStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            { text: 'Option 1', value: 'option1' },
            { text: 'Option 2', value: 'option2' },
        ];
    }
}

class ClAutocompleteComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        //--------------------------------------------
        this.searchQuery = '';
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClAutoCompleteProperties();
        this.select._handleKeydown = (event) => {
            if (event.keyCode == SPACE) {
                return;
            }
        };
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    onValueChange(value) {
        this.onChange(value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(value);
        }
    }
    filter(query) {
        this.properties.options.forEach((option) => {
            if (!option.text?.toLowerCase().includes(query.toLowerCase())) {
                option.hidden = true;
            }
            else {
                option.hidden = false;
            }
        });
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onValueChange('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAutocompleteComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClAutocompleteComponent, isStandalone: true, selector: "cl-autocomplete", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }, { propertyName: "select", first: true, predicate: ["select"], descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field class=\"w-full auto-complete {{ properties.style?.cssClasses }}\" [id]=\"properties.id\"\n  subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg ) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <mat-select (valueChange)=\"onValueChange($event)\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" [value]=\"value\" (blur)=\"onTouched($any($event.target).value)\"\n    [disabled]=\"disabled\" #select=\"matSelect\">\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxHint ?? 'Search...'\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n        <mat-label>{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.cl-select-all-check-box{max-height:48px;--tw-border-opacity: 1;border-bottom-width:1px;border-color:rgba(var(--cl-neutral-200-rgb),var(--tw-border-opacity))}.cl-select-clear-icon{position:absolute;right:30px!important}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-autocomplete', imports: [
                        NgClass,
                        FormsModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatIconModule,
                        MatFormFieldModule,
                        MatTooltipModule,
                        ReactiveFormsModule,
                        MatCheckboxModule,
                        ClTooltipDirective
                    ], encapsulation: ViewEncapsulation.None, template: "<mat-form-field class=\"w-full auto-complete {{ properties.style?.cssClasses }}\" [id]=\"properties.id\"\n  subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg ) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <mat-select (valueChange)=\"onValueChange($event)\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" [value]=\"value\" (blur)=\"onTouched($any($event.target).value)\"\n    [disabled]=\"disabled\" #select=\"matSelect\">\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxHint ?? 'Search...'\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n        <mat-label>{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.cl-select-all-check-box{max-height:48px;--tw-border-opacity: 1;border-bottom-width:1px;border-color:rgba(var(--cl-neutral-200-rgb),var(--tw-border-opacity))}.cl-select-clear-icon{position:absolute;right:30px!important}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], select: [{
                type: ViewChild,
                args: ['select', { static: true }]
            }] } });

class ClMultiAutoCompleteStyleProperties {
}
class ClMultiAutoCompleteProperties {
    constructor() {
        this.itemLimit = 3;
        this.id = 'default0';
        this.subscriptSizing = 'fixed';
        this.appearance = "fill";
        this.label = 'Multi Select Autocomplete';
        this.type = ClComponentTypes.multiAutocomplete;
        this.style = new ClMultiAutoCompleteStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            { text: 'Option 1', value: 'option1' },
            { text: 'Option 2', value: 'option2' },
        ];
    }
}

class ClMultiAutocompleteComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        //--------------------------------------------
        this.selectedOptions = [];
        this.searchQuery = '';
        this.isAllChecked = false;
        this.selectedValues = [];
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClMultiAutoCompleteProperties();
        this.autoComplete._handleKeydown = (event) => {
            if (event.keyCode == SPACE) {
                return;
            }
        };
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (!this.compareValues(value)) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    compareValues(values) {
        // check values and this._value is same or not
        if (values && values.length && values.length == this._value.length) {
            let allValuesExist = true;
            values.forEach((value) => {
                if (!this._value.includes(value)) {
                    allValuesExist = false;
                }
            });
            return allValuesExist;
        }
        else {
            return false;
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    writeValue(values) {
        this.selectedOptions = [];
        this.selectedValues = [];
        if (values?.length) {
            this.properties.options.forEach((option) => {
                if (includes$1(values, option.value)) {
                    option.selected = true;
                    this.selectedOptions.push(option);
                }
                else {
                    option.selected = false;
                }
            });
        }
        else {
            this.properties.options.forEach((item) => item.selected = false);
        }
        if (values && values.length == this.properties.options.length && values.length > 0) {
            // this.toggleSelectAll(true);
            this.isAllChecked = true;
        }
        else {
            this.isAllChecked = false;
        }
        this._value = this.selectedOptions.map((option) => option.value);
        this.selectedValues = this._value;
        this.getSelectedValues();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    onValueChange(value) {
        this.searchQuery = '';
        this.selectedOptions = [];
        this.properties.options.forEach((item) => item.hidden = false);
        this.writeValue(value);
        this.onChange(value);
        // if (value.length) {
        //   value.forEach((selectedValue: any) => {
        //     let filteredOptions = this.properties.options!.filter((option) => option.value == selectedValue);
        //     this.selectedOptions.push(...filteredOptions);
        //   });
        //   if (value.length == this.properties.options!.length) {
        //     this.toggleSelectAll(true);
        //   } else {
        //     this.isAllChecked = false;
        //   }
        // }
        // this.getSelectedValues();
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onValueChange('');
    }
    toggleSelectAll(checked) {
        if (checked) {
            this.isAllChecked = true;
            this.selectedOptions = this.properties.options;
            this.selectedOptions.map((item) => item.value);
        }
        else {
            this.selectedOptions = [];
        }
        // this.getSelectedValues();
        let values = this.selectedOptions.map((option) => option.value);
        this.writeValue(values);
        this.onChange(values);
        // calling emit selection function
    }
    getSelectedValues() {
        // this.selectedValues = [];
        // this.selectedValues = this.selectedOptions.map((option: any) => option.value);
        // this.onChange(this.selectedValues);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this.selectedValues);
        }
    }
    filter(searchQuery) {
        const query = searchQuery.target.value;
        this.properties.options.forEach((option) => {
            if (!option.text?.toLowerCase().includes(query.toLowerCase())) {
                option.hidden = true;
            }
            else {
                option.hidden = false;
            }
        });
    }
    remove(i) {
        let options = this.selectedOptions.slice();
        options.splice(i, 1);
        this.selectedOptions = options.slice();
        let values = this.selectedOptions.map((option) => option.value);
        this.writeValue(values);
        this.onChange(values);
        // this.getSelectedValues();
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiAutocompleteComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMultiAutocompleteComponent, isStandalone: true, selector: "cl-multi-autocomplete", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }, { propertyName: "autoComplete", first: true, predicate: ["autoComplete"], descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"auto-complete {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\" [disabled]=\"disabled\" #autoComplete=\"matSelect\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">\n                  {{ selectedOption.text }}\n                </mat-label>\n\n                <mat-icon (click)=\"remove(i)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (keyup)=\"filter($event)\"\n        class=\"autocomplete-search-input\" placeholder=\"{{properties.searchBoxHint || 'Search here'}}\">\n\n      <mat-icon class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\" matPrefix></mat-icon>\n    </mat-form-field>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n\n      <mat-checkbox color=\"primary\" [checked]=\"isAllChecked\" class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        (change)=\"toggleSelectAll($event.checked)\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n    <!-- div is required the restrict the height of the checkbox -->\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option; let i = $index) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3$1.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i3$1.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i8.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-multi-autocomplete', imports: [
                        NgClass,
                        FormsModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], encapsulation: ViewEncapsulation.None, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"auto-complete {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\" [disabled]=\"disabled\" #autoComplete=\"matSelect\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">\n                  {{ selectedOption.text }}\n                </mat-label>\n\n                <mat-icon (click)=\"remove(i)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (keyup)=\"filter($event)\"\n        class=\"autocomplete-search-input\" placeholder=\"{{properties.searchBoxHint || 'Search here'}}\">\n\n      <mat-icon class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\" matPrefix></mat-icon>\n    </mat-form-field>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n\n      <mat-checkbox color=\"primary\" [checked]=\"isAllChecked\" class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        (change)=\"toggleSelectAll($event.checked)\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n    <!-- div is required the restrict the height of the checkbox -->\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option; let i = $index) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], autoComplete: [{
                type: ViewChild,
                args: ['autoComplete', { static: true }]
            }] } });

var ClDisplay;
(function (ClDisplay) {
    ClDisplay["row"] = "flex-row";
    ClDisplay["col"] = "flex-col";
})(ClDisplay || (ClDisplay = {}));
class ClRadioStyleProperties {
}
class ClRadioProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Radio Button';
        this.type = ClComponentTypes.radio;
        this.style = new ClRadioStyleProperties();
        this.style.cssClasses = '';
        this.style.labelCssClasses = 'text-md';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            { text: 'Radio 1', value: 'radio1', checked: true },
            { text: 'Radio 2', value: 'radio2', checked: false }
        ];
    }
}

class ClRadioComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClRadioProperties();
        this.properties.display ??= ClDisplay.row;
        this.properties.radioStyle ??= 'cl-radio-button';
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having checked as true and check with the value.
        // if both are not same update the value with the checked true option
        const checkedOption = this.properties.options?.find((opt) => opt.checked == true);
        if (checkedOption && checkedOption.value != this._value) {
            this._value = checkedOption.value;
        }
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            this.writeValue(value);
        });
    }
    writeValue(value) {
        if (value) {
            this.properties.options?.forEach((option) => {
                option.checked = option.value === value;
            });
            this._value = value;
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        if (this.properties.options && this.properties.options?.length > 0) {
            const selectedOption = this.properties.options.find(option => option.checked);
            if (selectedOption) {
                this._value = selectedOption?.value;
            }
            else {
                this._value = '';
            }
        }
        return this._value;
    }
    onValueChanged(option) {
        this.writeValue(option.value);
        this.onChange(option.value);
        if (this.properties.onValueChanged) {
            this.properties.onValueChanged(option.value);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClRadioComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClRadioComponent, isStandalone: true, selector: "cl-radio", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 flex-col {{properties.style?.cssClasses}}\">\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span class=\"{{ properties.style?.labelCssClasses }}\">{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-radio-group color=\"primary\" [id]=\"properties.id\" class=\"flex gap-2 {{properties.display}}\" [value]=\"value\"\n    (change)=\"writeValue($any($event).value)\" [disabled]=\"disabled\">\n\n    @for (option of properties.options!; track option) {\n      <mat-radio-button [value]=\"option.value\" (change)=\"onValueChanged(option)\"\n        class=\"cursor-pointer {{properties.radioStyle}}\">\n        <span class=\"cursor-pointer\">{{ option.text }}</span>\n      </mat-radio-button>\n    }\n  </mat-radio-group>\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i3$2.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i3$2.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClRadioComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-radio', imports: [
                        MatIconModule,
                        MatRadioModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 flex-col {{properties.style?.cssClasses}}\">\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span class=\"{{ properties.style?.labelCssClasses }}\">{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-radio-group color=\"primary\" [id]=\"properties.id\" class=\"flex gap-2 {{properties.display}}\" [value]=\"value\"\n    (change)=\"writeValue($any($event).value)\" [disabled]=\"disabled\">\n\n    @for (option of properties.options!; track option) {\n      <mat-radio-button [value]=\"option.value\" (change)=\"onValueChanged(option)\"\n        class=\"cursor-pointer {{properties.radioStyle}}\">\n        <span class=\"cursor-pointer\">{{ option.text }}</span>\n      </mat-radio-button>\n    }\n  </mat-radio-group>\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClSwitchStyleProperties {
}
class ClSwitchProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Switch';
        this.type = ClComponentTypes.switch;
        this.checked = false;
        this.disabled = false;
        this.style = new ClSwitchStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.labelCssClasses = 'text-base text-neutral-700';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.showInfoMsg = signal(false);
    }
}

class ClSwitchComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClSwitchProperties();
        super.ngOnInit();
    }
    writeValue(value) {
        this.properties.checked = value;
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        this._value = this.properties.checked;
        return this._value;
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // calling set default value function
        // this.setDefaultValue();
    }
    // private setDefaultValue() {
    //   this.onChange(this.properties.checked ?? false);
    // }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    onToggleChanged(event) {
        this.writeValue(event.checked);
        this.onChange(this._value);
        if (this.properties.onToggleChanged) {
            this.properties.onToggleChanged(this._value);
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSwitchComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClSwitchComponent, isStandalone: true, selector: "cl-switch", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 {{ properties.style?.cssClasses }}\"\n  [ngClass]=\"properties.rowDisplay ? 'flex-row' : 'flex-col' \">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-slide-toggle color=\"primary\" [checked]=\"value\" [disabled]=\"properties.disabled!\"\n    (change)=\"onToggleChanged($event)\">\n  </mat-slide-toggle>\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatSlideToggleModule }, { kind: "component", type: i4$1.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i5$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSwitchComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-switch', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        MatSlideToggleModule,
                        CommonModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 {{ properties.style?.cssClasses }}\"\n  [ngClass]=\"properties.rowDisplay ? 'flex-row' : 'flex-col' \">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-slide-toggle color=\"primary\" [checked]=\"value\" [disabled]=\"properties.disabled!\"\n    (change)=\"onToggleChanged($event)\">\n  </mat-slide-toggle>\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClTimePickerContentComponent {
    constructor() {
        this.onApply = new EventEmitter();
        this.onCancelClick = new EventEmitter();
        this.disablePrimaryButton = false;
        this.timepickerForm = new FormGroup({ hours: new FormControl(''), minutes: new FormControl('') });
        this.applyButtonProperties = {
            label: 'Apply',
            id: 'btnDatePickerApply',
            onSubmit: this.apply.bind(this),
            type: ClComponentTypes.button
        };
        this.cancelButtonProperties = {
            label: 'Cancel',
            id: 'btnDatePickerCancel',
            type: ClComponentTypes.button,
            onSubmit: this.cancel.bind(this),
        };
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
    }
    //------------------------------------------
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    ngOnInit() {
        let mins = 0;
        let hours = 0;
        if (this.value != undefined && this.value != '') {
            //split it with :
            // get the hours and minutes
            let time = this.value.split(":");
            hours = time[0];
            mins = time[1];
        }
        this.timepickerForm.controls['hours'].setValue(this.convertTwoDigitNumber(hours));
        this.timepickerForm.controls['minutes'].setValue(this.convertTwoDigitNumber(mins));
    }
    convertTwoDigitNumber(currentValue) {
        let convertString = currentValue.toString();
        return convertString.padStart(2, '0');
    }
    minutesInputOnBlur(ev) {
        const currentHoursValue = Number(ev.target.value);
        this.timepickerForm.controls['minutes'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
    }
    minutesInputValueChanges(ev) {
        const currentMinutesValue = Number(ev.target.value);
        if (currentMinutesValue <= 0) {
            this.timepickerForm.controls['minutes'].setValue('');
        }
        else if (currentMinutesValue >= 59) {
            this.timepickerForm.controls['minutes'].setValue('59');
        }
        else {
            this.timepickerForm.controls['minutes'].setValue(!Number.isNaN(currentMinutesValue) ? currentMinutesValue.toString() : '');
        }
    }
    increaseMins() {
        let currentValue;
        currentValue = Number(this.timepickerForm.controls.minutes.value);
        if (currentValue >= 59) {
            currentValue = 59;
        }
        else {
            currentValue++;
        }
        this.timepickerForm.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
    }
    decreaseMins() {
        let currentValue;
        currentValue = Number(this.timepickerForm.controls.minutes.value);
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        this.timepickerForm.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
    }
    increaseHours() {
        let currentValue;
        currentValue = Number(this.timepickerForm.controls.hours.value);
        if (currentValue >= 23) {
            currentValue = 23;
        }
        else {
            currentValue++;
        }
        this.timepickerForm.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
    }
    decreaseHours() {
        let currentValue;
        currentValue = Number(this.timepickerForm.controls.hours.value);
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        this.timepickerForm.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
    }
    timeHoursInputOnBlur(ev) {
        const currentHoursValue = Number(ev.target.value);
        this.timepickerForm.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
    }
    timeHoursInputValueChanges(ev) {
        const currentHoursValue = Number(ev.target.value);
        if (currentHoursValue >= 23) {
            this.timepickerForm.controls['hours'].setValue('23');
        }
        else if (currentHoursValue <= 0) {
            this.timepickerForm.controls['hours'].setValue('');
        }
        else {
            this.timepickerForm.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? currentHoursValue.toString() : '');
        }
    }
    cancel() {
        //emit to the parent component to close the value or panel
        this.onCancelClick.emit('');
    }
    apply() {
        // emit the value back to the timepicker to close the dialog or panel
        const hours = this.timepickerForm.value.hours;
        const mins = this.timepickerForm.value.minutes;
        let value = hours + ":" + mins;
        this.onApply.emit(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTimePickerContentComponent, isStandalone: true, selector: "cl-time-picker-content", inputs: { value: "value" }, outputs: { onApply: "onApply", onCancelClick: "onCancelClick" }, ngImport: i0, template: "<div>\n  <div class=\"bg-white\">\n    <div class=\"py-2 px-4 flex items-center border-b border-neutral-300\">\n      <mat-icon class=\"icon-size-7\" [svgIcon]=\"'fss_icons:clock'\"></mat-icon>\n      <label class=\"text-primary-800 text-2xl ml-2 font-semibold\"> Time Picker </label>\n    </div>\n    <form [formGroup]=\"timepickerForm\">\n      <div class=\"flex justify-between pb-4 px-4 pt-4\">\n        <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n          <label class=\"text-md text-neutral-700\">Hours</label>\n\n          <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n            pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"timeHoursInputValueChanges($event)\"\n            (blur)=\"timeHoursInputOnBlur($event)\">\n\n          <div class=\"flex flex-col\">\n\n            <mat-icon (click)=\"increaseHours()\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n              class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n            <mat-icon (click)=\"decreaseHours()\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n              class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n          </div>\n        </div>\n        <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n          <label class=\"text-md text-neutral-700\">Minutes</label>\n\n          <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\" pattern=\"[0-9]{2}\"\n            min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"minutesInputValueChanges($event)\" (blur)=\"minutesInputOnBlur($event)\">\n\n          <div class=\"flex flex-col\">\n\n            <mat-icon (click)=\"increaseMins()\" [svgIcon]=\"'heroicons_outline:chevron-up'\" class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n            <mat-icon (click)=\"decreaseMins()\" [svgIcon]=\"'heroicons_outline:chevron-down'\" class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n          </div>\n        </div>\n      </div>\n\n      <div class=\"flex justify-end gap-2 timepicker-buttonsdiv pt-3 border-neutral-200 px-4 pb-3\">\n        <!-- <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button> -->\n\n        <button\n          mat-stroked-button\n          (click)=\"cancel()\"\n          [type]=\"cancelButtonProperties.type!\"\n          class=\"cl-button-stroked-primary\">\n          @if (cancelButtonProperties.icon) {\n            <mat-icon\n              class=\"icon-size-5\"\n              [svgIcon]=\"cancelButtonProperties.icon!\">\n            </mat-icon>\n          }\n\n          @if (cancelButtonProperties.label) {\n            <span>{{cancelButtonProperties.label}}</span>\n          }\n        </button>\n\n        <!-- default flat button -->\n        <button\n          mat-flat-button\n          (click)=\"apply()\"\n          [type]=\"applyButtonProperties.type!\"\n          class=\"cl-button-primary\">\n\n          @if (applyButtonProperties.icon) {\n            <mat-icon\n              class=\"icon-size-5\"\n              [svgIcon]=\"applyButtonProperties.icon!\">\n            </mat-icon>\n          }\n\n\n          @if (applyButtonProperties.label) {\n            <span>{{ applyButtonProperties.label }}</span>\n          }\n\n        </button>\n        <!-- default flat button -->\n\n\n      </div>\n    </form>\n  </div>\n</div>\n", styles: [".hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity));width:40px!important}.timepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity))}.timepicker-header{display:flex}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: RouterModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-time-picker-content', imports: [
                        FormsModule,
                        MatIconModule,
                        ReactiveFormsModule,
                        RouterModule
                    ], template: "<div>\n  <div class=\"bg-white\">\n    <div class=\"py-2 px-4 flex items-center border-b border-neutral-300\">\n      <mat-icon class=\"icon-size-7\" [svgIcon]=\"'fss_icons:clock'\"></mat-icon>\n      <label class=\"text-primary-800 text-2xl ml-2 font-semibold\"> Time Picker </label>\n    </div>\n    <form [formGroup]=\"timepickerForm\">\n      <div class=\"flex justify-between pb-4 px-4 pt-4\">\n        <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n          <label class=\"text-md text-neutral-700\">Hours</label>\n\n          <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n            pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"timeHoursInputValueChanges($event)\"\n            (blur)=\"timeHoursInputOnBlur($event)\">\n\n          <div class=\"flex flex-col\">\n\n            <mat-icon (click)=\"increaseHours()\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n              class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n            <mat-icon (click)=\"decreaseHours()\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n              class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n          </div>\n        </div>\n        <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n          <label class=\"text-md text-neutral-700\">Minutes</label>\n\n          <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\" pattern=\"[0-9]{2}\"\n            min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"minutesInputValueChanges($event)\" (blur)=\"minutesInputOnBlur($event)\">\n\n          <div class=\"flex flex-col\">\n\n            <mat-icon (click)=\"increaseMins()\" [svgIcon]=\"'heroicons_outline:chevron-up'\" class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n            <mat-icon (click)=\"decreaseMins()\" [svgIcon]=\"'heroicons_outline:chevron-down'\" class=\"icon-size-4 cursor-pointer\">\n            </mat-icon>\n\n          </div>\n        </div>\n      </div>\n\n      <div class=\"flex justify-end gap-2 timepicker-buttonsdiv pt-3 border-neutral-200 px-4 pb-3\">\n        <!-- <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button> -->\n\n        <button\n          mat-stroked-button\n          (click)=\"cancel()\"\n          [type]=\"cancelButtonProperties.type!\"\n          class=\"cl-button-stroked-primary\">\n          @if (cancelButtonProperties.icon) {\n            <mat-icon\n              class=\"icon-size-5\"\n              [svgIcon]=\"cancelButtonProperties.icon!\">\n            </mat-icon>\n          }\n\n          @if (cancelButtonProperties.label) {\n            <span>{{cancelButtonProperties.label}}</span>\n          }\n        </button>\n\n        <!-- default flat button -->\n        <button\n          mat-flat-button\n          (click)=\"apply()\"\n          [type]=\"applyButtonProperties.type!\"\n          class=\"cl-button-primary\">\n\n          @if (applyButtonProperties.icon) {\n            <mat-icon\n              class=\"icon-size-5\"\n              [svgIcon]=\"applyButtonProperties.icon!\">\n            </mat-icon>\n          }\n\n\n          @if (applyButtonProperties.label) {\n            <span>{{ applyButtonProperties.label }}</span>\n          }\n\n        </button>\n        <!-- default flat button -->\n\n\n      </div>\n    </form>\n  </div>\n</div>\n", styles: [".hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity));width:40px!important}.timepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity));--tw-bg-opacity: 1;background-color:rgb(250 250 250 / var(--tw-bg-opacity))}.timepicker-header{display:flex}\n"] }]
        }], propDecorators: { value: [{
                type: Input
            }], onApply: [{
                type: Output
            }], onCancelClick: [{
                type: Output
            }] } });

class ClTimePickerStyleProperties {
}
class ClTimePickerProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Time Picker';
        this.type = ClComponentTypes.timepicker;
        this.placeholder = '--:--';
        this.style = new ClTimePickerStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.subscriptSizing = 'fixed';
        this.showInfoMsg = signal(false);
    }
}

class ClTimePickerComponent extends ClBaseComponent {
    //------------------------------------------
    constructor(ngControl, dialog) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.dialog = dialog;
        this.showTime = false;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnInit() {
        this.properties ??= new ClTimePickerProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
        const self = this;
        // Prevent scrolling when the dropdown is open
        window.addEventListener('scroll', function (event) {
            if (self.showTime) {
                event.preventDefault(); // Prevent default scrolling behavior
                event.stopPropagation(); // Prevent bubbling to parent elements
            }
        }, { passive: false }); // { passive: false } ensures preventDefault works
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    // this function is triggered on the opening the time picker
    openTimePicker() {
        if (this.properties.showAsDialog) {
            //show as a dialog
            this.dialog.open(this.timepickerDialog);
        }
        else {
            const scrollableDiv = document.getElementById('scrollableDiv');
            if (scrollableDiv) {
                scrollableDiv.scrollTo({
                    left: 0, // Scroll to the very left
                    behavior: 'smooth' // Smooth scrolling animation
                });
                // Delay opening the timepicker slightly to ensure scrolling completes
                setTimeout(() => {
                    this.showTime = true;
                }, 300); // Adjust timeout based on expected scroll duration
            }
            else {
                // If no scrolling is needed, directly open the timepicker
                this.showTime = true;
            }
        }
    }
    onCancel(ev) {
        if (this.properties.showAsDialog) {
            this.dialog.closeAll();
        }
        else {
            this.showTime = false;
        }
    }
    onTimeSelection(ev) {
        this.writeValue(ev);
        if (this.properties.onTimeSelected !== undefined) {
            this.properties.onTimeSelected(ev);
        }
        if (this.properties.showAsDialog) {
            this.dialog.closeAll();
        }
        else {
            this.showTime = false;
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerComponent, deps: [{ token: i1.NgControl, optional: true, self: true }, { token: i2$3.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTimePickerComponent, isStandalone: true, selector: "cl-time-picker", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "timepickerDialog", first: true, predicate: ["timepickerDialog"], descendants: true, static: true }, { propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"cl-time-picker\">\n\n  <mat-form-field subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"w-full {{ properties.style?.cssClasses }}\" cdkOverlayOrigin #customTimePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\"\n      [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\"\n      (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\"/>\n\n    @if (!properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"'fss_icons:clock'\">\n    </mat-icon>\n    }\n\n    @if (properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"properties.icon!\">\n    </mat-icon>\n    }\n  </mat-form-field>\n  <!-- This div is required to show hint text or error message for the component -->\n  <!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"customTimePicker\" [cdkConnectedOverlayOpen]=\"showTime\">\n  <mat-card>\n    <div class=\"cl-timepicker-content-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n\n\n<ng-template #timepickerDialog>\n  <mat-card>\n    <div class=\"cl-timepicker-dialog-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-time-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-time-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.cl-timepicker-content-container{width:300px}::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0!important}.cl-timepicker-dialog-container{width:420px}.cl-timepicker-dialog-container .hours-container{height:46px;width:46%}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2$4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: ClTimePickerContentComponent, selector: "cl-time-picker-content", inputs: ["value"], outputs: ["onApply", "onCancelClick"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i7.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i7.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-time-picker', imports: [
                        FormsModule,
                        MatCardModule,
                        MatIconModule,
                        MatInputModule,
                        MatDialogModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTimePickerContentComponent,
                        OverlayModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"cl-time-picker\">\n\n  <mat-form-field subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"w-full {{ properties.style?.cssClasses }}\" cdkOverlayOrigin #customTimePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\"\n      [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\"\n      (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\"/>\n\n    @if (!properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"'fss_icons:clock'\">\n    </mat-icon>\n    }\n\n    @if (properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"properties.icon!\">\n    </mat-icon>\n    }\n  </mat-form-field>\n  <!-- This div is required to show hint text or error message for the component -->\n  <!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"customTimePicker\" [cdkConnectedOverlayOpen]=\"showTime\">\n  <mat-card>\n    <div class=\"cl-timepicker-content-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n\n\n<ng-template #timepickerDialog>\n  <mat-card>\n    <div class=\"cl-timepicker-dialog-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-time-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-time-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.cl-timepicker-content-container{width:300px}::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0!important}.cl-timepicker-dialog-container{width:420px}.cl-timepicker-dialog-container .hours-container{height:46px;width:46%}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i2$3.MatDialog }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], timepickerDialog: [{
                type: ViewChild,
                args: ['timepickerDialog', { static: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClImageStyleProperties {
}
class ClImageProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Image';
        this.type = ClComponentTypes.image;
        this.style = new ClImageStyleProperties();
    }
}

class ClImageComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClImageProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClImageComponent, isStandalone: true, selector: "cl-image", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<img [id]=\"properties.id\" [src]=\"properties.link\" [alt]=\"properties.alt || ''\" class=\"{{properties.style?.cssClasses}}\">\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClImageComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-image', template: "<img [id]=\"properties.id\" [src]=\"properties.link\" [alt]=\"properties.alt || ''\" class=\"{{properties.style?.cssClasses}}\">\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClIconsListStyleProperties {
}
class ClIconsListProperties {
    constructor() {
        this.options = [];
        this.id = 'default0';
        this.label = 'Icons List';
        this.type = ClComponentTypes.iconsList;
        this.style = new ClIconsListStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClIconsListComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(changes) {
        this.properties.multiple = this.properties.multiple ?? true;
    }
    ngOnInit() {
        this.properties ??= new ClIconsListProperties();
        super.ngOnInit();
    }
    onOptionSelected(index) {
        const selectedOptionsArr = [];
        if (this.properties.multiple) {
            this.properties.options.at(index).selected = !this.properties.options.at(index).selected;
        }
        else {
            this.properties.options.forEach((option) => option.selected = false);
            this.properties.options.at(index).selected = true;
        }
        const selectedOptions = this.properties.options.filter((option) => option.selected);
        selectedOptions.forEach((icon) => selectedOptionsArr.push(icon.option));
        if (this.properties.optionsSelected != undefined) {
            this.properties.optionsSelected(selectedOptionsArr);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconsListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClIconsListComponent, isStandalone: true, selector: "cl-icons-list", inputs: { properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex flex-row gap-4\">\n  @for (icon of properties.options; track icon; let optionIndex = $index) {\n    <div>\n      <div class=\"flex gap-1 flex-col items-center justify-center cursor-pointer\" (click)=\"onOptionSelected(optionIndex)\">\n\n        <div class=\"w-12 h-8 flex rounded bg-white items-center justify-center\"\n          [ngClass]=\"icon.selected! ? 'border-2 border-primary-400' : 'border border-neutral-300'\">\n\n          @if (icon.img) {\n            <cl-image [properties]=\"icon.img!\"></cl-image>\n          }\n\n          @if (icon.icon) {\n            <mat-icon [svgIcon]=\"icon.icon!\"></mat-icon>\n          }\n        </div>\n\n        <mat-label class=\"text-sm leading-normal\"\n          [ngClass]=\"icon.selected! ? 'font-bold text-primary-400' : 'font-normal text-neutral-800'\">\n          {{icon.option.text}}\n        </mat-label>\n      </div>\n    </div>\n  }\n</div>\n", styles: [""], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "component", type: ClImageComponent, selector: "cl-image", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconsListComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-icons-list', imports: [
                        NgClass,
                        MatIconModule,
                        MatFormFieldModule,
                        ClImageComponent,
                    ], template: "<div [id]=\"properties.id\" class=\"flex flex-row gap-4\">\n  @for (icon of properties.options; track icon; let optionIndex = $index) {\n    <div>\n      <div class=\"flex gap-1 flex-col items-center justify-center cursor-pointer\" (click)=\"onOptionSelected(optionIndex)\">\n\n        <div class=\"w-12 h-8 flex rounded bg-white items-center justify-center\"\n          [ngClass]=\"icon.selected! ? 'border-2 border-primary-400' : 'border border-neutral-300'\">\n\n          @if (icon.img) {\n            <cl-image [properties]=\"icon.img!\"></cl-image>\n          }\n\n          @if (icon.icon) {\n            <mat-icon [svgIcon]=\"icon.icon!\"></mat-icon>\n          }\n        </div>\n\n        <mat-label class=\"text-sm leading-normal\"\n          [ngClass]=\"icon.selected! ? 'font-bold text-primary-400' : 'font-normal text-neutral-800'\">\n          {{icon.option.text}}\n        </mat-label>\n      </div>\n    </div>\n  }\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClSpinnerStyleProperties {
}
class ClSpinnerProperties {
    constructor() {
        this.id = 'default0';
        this.height = 'icon-size-20';
        this.type = ClComponentTypes.spinner;
        this.style = new ClSpinnerStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClSpinnerComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClSpinnerProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClSpinnerComponent, isStandalone: true, selector: "cl-spinner", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-icon [id]=\"properties.id\" class=\"animate-spin {{ properties.height }}\" [svgIcon]=\"'fss_icons:loading'\">\n</mat-icon>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-spinner', standalone: true, imports: [
                        MatIconModule
                    ], template: "<mat-icon [id]=\"properties.id\" class=\"animate-spin {{ properties.height }}\" [svgIcon]=\"'fss_icons:loading'\">\n</mat-icon>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

var IClFileType;
(function (IClFileType) {
    IClFileType["csv"] = "text/csv";
    IClFileType["png"] = "image/png";
    IClFileType["txt"] = "text/plain";
    IClFileType["html"] = "text/html";
    IClFileType["jpg"] = "image/jpeg";
    IClFileType["svg"] = "image/svg+xml";
    IClFileType["pdf"] = "application/pdf";
    IClFileType["json"] = "application/json";
    IClFileType["image"] = "image/jpeg,image/png,image/svg+xml";
    IClFileType["xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    IClFileType["docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
})(IClFileType || (IClFileType = {}));
class ClUploadTileStyleProperties {
}
class ClUploadTileProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Upload Tile';
        this.attachmentLabel = 'Upload File';
        this.type = ClComponentTypes.uploadTile;
        this.style = new ClUploadTileStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.allowedFileTypes = [];
    }
}

class ClUploadService {
    constructor() {
        this.fileResult = [];
        this._selectedFiles = signal([]);
    }
    /**
     * uploadFile
     *
     * this method will open dialog to select the allowed files
     * and returns all the selected files either single or multiple
     *
     * @param event
     *
     * @returns selected files list as observable
     */
    uploadFile(event, allowedFileTypes, maxLimit, uploadError, fileGridView) {
        this.fileResult = [];
        const fileList = event.target.files;
        const acceptedFilesList = [];
        const unacceptedFilesList = [];
        // Return if canceled
        if (!fileList.length && (fileGridView == undefined || !fileGridView)) {
            this._selectedFiles.set([]);
            return this._selectedFiles;
        }
        const allowedTypes = allowedFileTypes.split(',');
        for (const file of fileList) {
            // check if file is allowed or not
            if (!allowedTypes.includes(file.type)) {
                // add to unaccepted files list if file is not allowed
                unacceptedFilesList.push(file);
                this.fileResult.push({
                    fileSize: 0,
                    fileSizeDesc: '0 b',
                    errorMessage: uploadError?.formatErrorMsg ?? 'The file type selected is not allowed.',
                });
            }
            else {
                // add to accepted files list if file is not allowed
                acceptedFilesList.push(file);
            }
        }
        for (const file of acceptedFilesList) {
            // calling get file result method
            this.fileResult.push(this.getFileResult(maxLimit, uploadError, file));
        }
        if (this.fileResult.length > 0 && this.fileResult[0].errorMessage != undefined) {
            this._selectedFiles.set([]);
        }
        else {
            this._selectedFiles.set(acceptedFilesList);
        }
        return this._selectedFiles;
    }
    /**
     * deleteFile
     *
     * This function will delete the file at selected index
     *
     * @param index
     *
     * @returns selected files as observable
     */
    deleteFile(index) {
        this.fileResult = [];
        this._selectedFiles().splice(index, 1);
        return this._selectedFiles;
    }
    /**
     * get file size
     *
     * this method will result the size of the file
     *
     * @param  maxLimit
     *
     * @param file
     *
     * @returns size of the file in b or kb or mb or gb
     */
    getFileResult(maxLimit, uploadError, file) {
        if (file == undefined) {
            return { fileSize: 0, fileSizeDesc: '0 b' };
        }
        const size = file.size;
        if (size === 0) {
            return { fileSize: 0, fileSizeDesc: '0 b' };
        }
        const base = 1024;
        const units = ['b', 'kb', 'mb', 'gb'];
        const sizeInKb = size / base;
        const displaySizeInKb = Math.log(size) / Math.log(base);
        const i = Math.floor(displaySizeInKb);
        const errorMessage = sizeInKb > maxLimit ? 'File size has exceeded max limit' : undefined;
        return {
            fileSize: +displaySizeInKb.toFixed(2),
            fileSizeDesc: `${(size / Math.pow(base, i)).toFixed(2)} ${units[i]}`,
            errorMessage: sizeInKb > maxLimit ? (uploadError?.fileSizeErrorMsg ?? errorMessage) : undefined,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClUploadTileComponent extends ClBaseComponent {
    constructor(uploadService) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.uploadService = uploadService;
        this.accept = '';
        this.fileTypeImage = false;
        this.localUrl = [];
        this.selectedFiles = [];
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
        this.uploadIconProperties = {
            id: 'uploadTileIcon',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:file-upload',
            style: {
                cssClasses: 'icon-size-6 text-primary',
            },
        };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(changes) {
        this.previewImageProperties = {
            id: 'imgPreview',
            alt: 'imgPreview',
            type: ClComponentTypes.image,
            link: this.preLoadImageProperties?.imageUrl ?? '',
            style: {
                cssClasses: "opacity-1 " + this.properties.fullWidthPreview ? 'w-full min-h-12 h-12' : 'min-w-10 w-10 min-h-10 h-10',
            },
        };
        if (this.preLoadImageProperties?.imageUrl) {
            this.localUrl.push(this.preLoadImageProperties.imageUrl);
        }
        // calling extract name from image url method
        this.extractNameFromImageUrl();
    }
    ngOnInit() {
        this.properties ??= new ClUploadTileProperties();
        this.accept = this.properties.allowedFileTypes?.join(',');
        this.uploadIconProperties.iconName = this.properties.uploadIcon ?? this.properties.darkMode ? 'fss_icons:file-upload-white' : 'fss_icons:file-upload';
        this.attachmentLabelProperties = {
            id: 'uploadTileAttachmentLabel',
            type: ClComponentTypes.label,
            label: this.properties.attachmentLabel,
            style: {
                cssClasses: 'text-base leading-6 font-normal ',
            },
        };
        this.attachmentLabelProperties.style.cssClasses = this.properties.darkMode ?
            this.attachmentLabelProperties.style.cssClasses + ' text-white' :
            this.attachmentLabelProperties.style.cssClasses + ' text-primary';
        this.dimensionTitleProperties = {
            id: 'labelDimensionsTitleText',
            type: ClComponentTypes.label,
            label: this.properties.dimensionTitle ?? 'Supported dimensions: ',
            style: {
                cssClasses: 'text-sm font-normal text-neutral-700',
            },
        };
        this.dimensionDescProperties = {
            type: ClComponentTypes.label,
            id: 'labelDimensionsDescText',
            label: this.properties.dimension ?? '',
            style: {
                cssClasses: 'text-sm font-semibold text-neutral-800',
            },
        };
        this.supportedTitleProperties = {
            id: 'labelSupportedTitleText',
            type: ClComponentTypes.label,
            label: this.properties.supportedFileTitle ?? 'Supported formats: ',
            style: {
                cssClasses: 'text-sm font-normal text-neutral-700',
            },
        };
        this.supportedDescProperties = {
            type: ClComponentTypes.label,
            id: 'labelDimensionsDescText',
            label: this.properties.supportedFile ?? '',
            style: {
                cssClasses: 'text-sm font-semibold text-neutral-800',
            },
        };
        this.maxLimitTitleProperties = {
            type: ClComponentTypes.label,
            id: 'labelMaxLimitTitleText',
            label: this.properties.maxLimitTitle ?? 'Max limit: ',
            style: {
                cssClasses: 'text-sm font-normal text-neutral-700',
            },
        };
        this.maxLimitDescProperties = {
            id: 'labelMaxLimitDescText',
            type: ClComponentTypes.label,
            label: this.properties.maxLimitDesc ?? '',
            style: {
                cssClasses: 'text-sm font-semibold text-neutral-800',
            },
        };
        super.ngOnInit();
    }
    /**
     * onFileUpload
     *
     * This function will call the service to upload the file
     *
     * @param event
     */
    onFileUpload(event) {
        // calling upload file method
        const result = this.uploadService.uploadFile(event, this.accept, this.properties.maxLimitInKb, this.properties.uploadError);
        // calling reset view method
        this.resetView();
        this.selectedFiles = result();
        // calling get file size method
        // this.fileResult = this.uploadService.getFileSize(this.selectedFiles[0]);
        this.fileResult = this.uploadService.fileResult;
        // calling is file type image method
        this.isFileTypeImage();
        // calling extract name from image url method
        this.extractNameFromImageUrl();
        // calling push selected files method
        this.pushSelectedFiles();
    }
    /**
     * deleteSelectedFile
     *
     * this function will delete the selected file
     *
     * @param index
     */
    deleteSelectedFile(index) {
        // calling delete file method
        const result = this.uploadService.deleteFile(index);
        this.selectedFiles = result();
        this.fileResult = this.uploadService.fileResult;
        // calling reset view method
        this.resetView();
        // calling is file type image method
        this.isFileTypeImage();
        // On File type image delete
        if (this.fileTypeImage) {
            if (this.properties.onFileUpload) {
                this.properties.onFileUpload([]);
            }
        }
        // calling push selected files method
        this.pushSelectedFiles();
    }
    /**
     * resetView
     *
     * This function will reset the entire view
     */
    resetView() {
        this.fileName = '';
        this.localUrl = [];
        this.preLoadImageProperties = undefined;
        this.properties.preLoadImageProperties = undefined;
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
    }
    /**
     * extractNameFromImageUrl
     *
     * this function will extract the name from the image url
     */
    extractNameFromImageUrl() {
        if (this.preLoadImageProperties?.imageUrl) {
            this.fileName = this.preLoadImageProperties.fileName;
        }
        else if (this.selectedFiles.length > 0) {
            this.fileName = this.selectedFiles[0].name;
        }
    }
    /**
     * show preview image
     *
     * this method will generate a url for showing preview of the file
     *
     */
    showPreviewImage() {
        for (const file of this.selectedFiles) {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = (e) => {
                const image = new Image();
                image.src = e.target.result;
                // calling validate image dimensions
                this._validateImageDimensions(image);
            };
        }
    }
    _validateImageDimensions(image) {
        image.onload = () => {
            const isWidthValid = (this.properties.maxWidth != undefined && this.properties.maxWidth >= image.naturalWidth);
            const isHeightValid = (this.properties.maxHeight != undefined && this.properties.maxHeight >= image.naturalHeight);
            if (isWidthValid && isHeightValid) {
                this.localUrl.push(image.src);
                this.previewImageProperties = {
                    id: 'imgPreview',
                    alt: 'imgPreview',
                    link: this.localUrl[0],
                    type: ClComponentTypes.image,
                    style: {
                        cssClasses: "opacity-1 " + this.properties.fullWidthPreview ? 'w-full min-h-12 h-12' : 'min-w-10 w-10 min-h-10 h-10'
                    },
                };
                // calling on file upload method
                if (this.properties.onFileUpload) {
                    this.properties.onFileUpload(this.selectedFiles);
                }
            }
            else {
                // calling delete selected file function
                this.deleteSelectedFile(0);
                this.fileResult = [
                    {
                        fileSize: 0,
                        fileSizeDesc: '',
                        errorMessage: this.properties.uploadError?.dimensionErrorMsg ?? 'File dimensions has exceeded max dimensions',
                    },
                ];
            }
        };
    }
    /**
     * show preview icon method
     *
     * this method will be used to show icon preview for files other then image
     */
    showPreviewIcon() {
        this.previewIconProperties = {
            id: 'iconPreview',
            type: ClComponentTypes.icon,
            iconName: this.properties.afterUploadIcon ?? 'fss_icons:csv-file',
            style: {
                cssClasses: 'icon-size-8',
            },
        };
    }
    /**
     * push selected files
     *
     * this function will call the callback function
     */
    pushSelectedFiles() {
        if (this.fileTypeImage) {
            // calling show preview image method
            this.showPreviewImage();
        }
        else {
            // calling show preview icon method
            this.showPreviewIcon();
            // calling on file upload method
            if (this.properties.onFileUpload) {
                this.properties.onFileUpload(this.selectedFiles);
            }
        }
    }
    /**
     * is file type image method
     *
     * This method will check if the image type is
     *
     * @param fileType - allowed file type
     */
    isFileTypeImage() {
        for (const fileTypeV of this.properties.allowedFileTypes) {
            if (!this.fileTypeImage) {
                this.fileTypeImage = fileTypeV.includes('image');
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadTileComponent, deps: [{ token: ClUploadService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClUploadTileComponent, isStandalone: true, selector: "cl-upload-tile", inputs: { properties: "properties", preLoadImageProperties: "preLoadImageProperties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col {{properties.style?.cssClasses}}\">\n  <div>\n    <!-- BEFORE FILE UPLOAD -->\n\n    <!-- upload container - light mode -->\n    @if (!properties.darkMode && !properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"gap-3 upload-dashed-border {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <div class=\"upload-icon-dashed-border\">\n          <cl-icon [properties]=\"uploadIconProperties\"\n            class=\"w-14 h-14 flex min-w-14 min-h-14 border-r items-center justify-center border-r-neutral-400\">\n          </cl-icon>\n        </div>\n        <!-- upload icon -->\n        <!-- upload text -->\n\n        <div class=\"{{ attachmentLabelProperties.style?.cssClasses }}\">\n          <span>{{ properties.attachmentLabel }}</span>\n        </div>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - light mode -->\n\n    <!-- upload container - full width - light mode -->\n    @if (!properties.darkMode && properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"upload-dashed-border {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <cl-icon [properties]=\"uploadIconProperties\" class=\"w-14 h-14 flex min-w-14 min-h-14 items-center justify-center\">\n        </cl-icon>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - full width - light mode -->\n\n    <!-- upload container - dark mode -->\n    @if (properties.darkMode && !properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"flex gap-3 upload-dashed-border-dark {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <div class=\"upload-icon-dashed-border-dark\">\n          <cl-icon [properties]=\"uploadIconProperties\"\n            class=\"w-14 h-14 flex min-w-14 min-h-14 border-r items-center justify-center border-r-white\">\n          </cl-icon>\n        </div>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - dark mode -->\n\n    <!-- upload container - full width - dark mode -->\n    @if (properties.darkMode && properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"upload-dashed-border-dark {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <cl-icon [properties]=\"uploadIconProperties\" class=\"w-14 h-14 flex min-w-14 min-h-14 items-center justify-center\">\n        </cl-icon>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - full width - dark mode -->\n\n    <!-- BEFORE FILE UPLOAD -->\n\n    <!-- AFTER FILE UPLOAD -->\n\n    <!-- upload container - after upload - light mode -->\n    @if (!properties.darkMode && !properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div class=\"flex pr-3 gap-3 rounded-md items-center justify-center {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div\n          class=\"flex items-center {{properties.fullWidthPreview ? 'w-full' : 'px-3 w-14 h-14 justify-center border-r border-r-neutral-400'}}\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center {{properties.fullWidthPreview ? 'w-full h-14' : ''}}\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"{{properties.fullWidthPreview ? 'w-full h-14' : 'flex w-14 min-w-14 items-center justify-center'}}\">\n            </cl-image>\n          }\n\n          @if (!fileTypeImage && previewIconProperties) {\n            <cl-icon [properties]=\"previewIconProperties!\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-icon>\n          }\n\n          @if (!fileTypeImage && properties.afterUploadIcon) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label class=\"text-base font-normal leading-6 text-neutral-900\">{{ properties.afterUploadLabel }}</mat-label>\n            }\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-primary {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{ fileName | truncate:[properties.fileNameMaxLength || 20] }}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-800\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"text-red-600 cursor-pointer icons-size-4\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - light mode -->\n\n    <!-- upload container - after upload - full width preview - light mode -->\n    @if (!properties.darkMode && properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div class=\"flex px-3 gap-3 rounded-md items-center justify-center {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div class=\"flex items-center w-full\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\" class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - full width preview - light mode -->\n\n    <!-- upload container - after upload - dark mode -->\n    @if (properties.darkMode && !properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div\n        class=\"flex pr-3 gap-3 rounded-md items-center justify-center bg-primary-900 {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div\n          class=\"flex items-center {{properties.fullWidthPreview ? 'w-full' : 'px-3 w-14 h-14 justify-center border-r border-r-neutral-400'}}\">\n\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center {{properties.fullWidthPreview ? 'w-full h-14' : ''}}\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"{{properties.fullWidthPreview ? 'w-full h-14' : 'flex w-14 min-w-14 items-center justify-center'}}\">\n            </cl-image>\n          }\n\n          @if (!fileTypeImage && previewIconProperties) {\n            <cl-icon [properties]=\"previewIconProperties!\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-icon>\n          }\n\n          @if (!fileTypeImage && properties.afterUploadIcon) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - dark mode -->\n\n    <!-- upload container - full image preview - after upload - dark mode -->\n    @if (properties.darkMode && properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div\n        class=\"flex px-3 gap-3 rounded-md items-center justify-center bg-primary-900 {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div class=\"flex items-center w-full\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\" class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - full image preview - after upload - dark mode -->\n\n    <!-- AFTER FILE UPLOAD -->\n  </div>\n\n  <!-- AFTER FILE UPLOAD - FILE DETAILS -->\n  <!-- this will only be visible when full width preview is required -->\n\n  @if (localUrl.length > 0 && (properties.fullWidthPreview || false)) {\n    <div class=\"flex gap-1 items-center\">\n      <mat-label class=\"text-md font-bold text-primary\">{{fileName}}</mat-label>\n      @if (properties.preLoadImageProperties == undefined) {\n        <mat-label class=\"text-sm text-neutral-800\">\n          Size: {{fileResult[0].fileSizeDesc}}\n        </mat-label>\n      }\n    </div>\n  }\n  <!-- AFTER FILE UPLOAD - FILE DETAILS -->\n\n  <!-- Hint text -->\n  @if ((fileResult.length > 0 && fileResult[0].errorMessage == undefined)) {\n    <div class=\"flex flex-wrap gap-1\">\n      @if (properties.supportedFile) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n          <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n        </div>\n      }\n      @if (properties.dimension) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n          <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n        </div>\n      }\n      @if (properties.maxLimitDesc) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n          <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n        </div>\n      }\n    </div>\n  }\n  <!-- Hint text -->\n\n  <!-- Error message -->\n  @if ((fileResult.length > 0 && fileResult[0].errorMessage != undefined)) {\n    <mat-label class=\"text-md text-warn\">{{fileResult[0].errorMessage}}</mat-label>\n  }\n  <!-- Error message -->\n\n</div>\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"false\" (change)=\"onFileUpload($event)\"\n  class=\"hidden pointer-events-none\">\n", styles: [".upload-dashed-border{display:flex;cursor:pointer;align-items:center;border-radius:.375rem;background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23D7D9DDFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-failed{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-dark{display:flex;cursor:pointer;align-items:center;border-radius:.375rem;background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%2301193BFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-failed-dark{background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-50-rgb),var(--tw-bg-opacity));background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23D7D9DDFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border-failed{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\") repeat var(--cl-primary-50)}.upload-shadow{box-shadow:0 0 1px #abafb866,0 3px 5px #abafb833}.upload-icon-dashed-border-dark{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%2301193BFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border-failed-dark{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\") repeat var(--cl-primary-900)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "component", type: ClImageComponent, selector: "cl-image", inputs: ["properties"] }, { kind: "pipe", type: ClTruncatePipe, name: "truncate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadTileComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-upload-tile', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClImageComponent,
                        ClTruncatePipe,
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col {{properties.style?.cssClasses}}\">\n  <div>\n    <!-- BEFORE FILE UPLOAD -->\n\n    <!-- upload container - light mode -->\n    @if (!properties.darkMode && !properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"gap-3 upload-dashed-border {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <div class=\"upload-icon-dashed-border\">\n          <cl-icon [properties]=\"uploadIconProperties\"\n            class=\"w-14 h-14 flex min-w-14 min-h-14 border-r items-center justify-center border-r-neutral-400\">\n          </cl-icon>\n        </div>\n        <!-- upload icon -->\n        <!-- upload text -->\n\n        <div class=\"{{ attachmentLabelProperties.style?.cssClasses }}\">\n          <span>{{ properties.attachmentLabel }}</span>\n        </div>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - light mode -->\n\n    <!-- upload container - full width - light mode -->\n    @if (!properties.darkMode && properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"upload-dashed-border {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <cl-icon [properties]=\"uploadIconProperties\" class=\"w-14 h-14 flex min-w-14 min-h-14 items-center justify-center\">\n        </cl-icon>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - full width - light mode -->\n\n    <!-- upload container - dark mode -->\n    @if (properties.darkMode && !properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"flex gap-3 upload-dashed-border-dark {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <div class=\"upload-icon-dashed-border-dark\">\n          <cl-icon [properties]=\"uploadIconProperties\"\n            class=\"w-14 h-14 flex min-w-14 min-h-14 border-r items-center justify-center border-r-white\">\n          </cl-icon>\n        </div>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - dark mode -->\n\n    <!-- upload container - full width - dark mode -->\n    @if (properties.darkMode && properties.fullWidthPreview && localUrl.length <= 0 && selectedFiles.length <= 0) {\n      <div\n        class=\"upload-dashed-border-dark {{properties.hideShadow ? '' : 'upload-shadow'}}\"\n        (click)=\"fileUpload.value = ''; fileUpload.click()\">\n        <!-- upload icon -->\n        <cl-icon [properties]=\"uploadIconProperties\" class=\"w-14 h-14 flex min-w-14 min-h-14 items-center justify-center\">\n        </cl-icon>\n        <!-- upload icon -->\n        <!-- upload text -->\n        <cl-label [properties]=\"attachmentLabelProperties\"></cl-label>\n        <!-- upload text -->\n      </div>\n    }\n    <!-- upload container - full width - dark mode -->\n\n    <!-- BEFORE FILE UPLOAD -->\n\n    <!-- AFTER FILE UPLOAD -->\n\n    <!-- upload container - after upload - light mode -->\n    @if (!properties.darkMode && !properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div class=\"flex pr-3 gap-3 rounded-md items-center justify-center {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div\n          class=\"flex items-center {{properties.fullWidthPreview ? 'w-full' : 'px-3 w-14 h-14 justify-center border-r border-r-neutral-400'}}\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center {{properties.fullWidthPreview ? 'w-full h-14' : ''}}\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"{{properties.fullWidthPreview ? 'w-full h-14' : 'flex w-14 min-w-14 items-center justify-center'}}\">\n            </cl-image>\n          }\n\n          @if (!fileTypeImage && previewIconProperties) {\n            <cl-icon [properties]=\"previewIconProperties!\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-icon>\n          }\n\n          @if (!fileTypeImage && properties.afterUploadIcon) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label class=\"text-base font-normal leading-6 text-neutral-900\">{{ properties.afterUploadLabel }}</mat-label>\n            }\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-primary {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{ fileName | truncate:[properties.fileNameMaxLength || 20] }}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-800\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"text-red-600 cursor-pointer icons-size-4\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - light mode -->\n\n    <!-- upload container - after upload - full width preview - light mode -->\n    @if (!properties.darkMode && properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div class=\"flex px-3 gap-3 rounded-md items-center justify-center {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div class=\"flex items-center w-full\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\" class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - full width preview - light mode -->\n\n    <!-- upload container - after upload - dark mode -->\n    @if (properties.darkMode && !properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div\n        class=\"flex pr-3 gap-3 rounded-md items-center justify-center bg-primary-900 {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div\n          class=\"flex items-center {{properties.fullWidthPreview ? 'w-full' : 'px-3 w-14 h-14 justify-center border-r border-r-neutral-400'}}\">\n\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center {{properties.fullWidthPreview ? 'w-full h-14' : ''}}\">\n            </cl-image>\n          }\n\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"{{properties.fullWidthPreview ? 'w-full h-14' : 'flex w-14 min-w-14 items-center justify-center'}}\">\n            </cl-image>\n          }\n\n          @if (!fileTypeImage && previewIconProperties) {\n            <cl-icon [properties]=\"previewIconProperties!\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-icon>\n          }\n\n          @if (!fileTypeImage && properties.afterUploadIcon) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"flex items-center justify-center w-14 min-w-14\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - after upload - dark mode -->\n\n    <!-- upload container - full image preview - after upload - dark mode -->\n    @if (properties.darkMode && properties.fullWidthPreview && (localUrl.length > 0 || selectedFiles.length > 0)) {\n      <div\n        class=\"flex px-3 gap-3 rounded-md items-center justify-center bg-primary-900 {{properties.hideShadow ? '' : 'upload-shadow'}}\">\n        <!-- uploaded file -->\n        <div class=\"flex items-center w-full\">\n          @if (fileTypeImage) {\n            <cl-image [properties]=\"previewImageProperties\" class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n          @if (properties.preLoadImageProperties != undefined) {\n            <cl-image [properties]=\"previewImageProperties\"\n              class=\"h-14 flex w-full items-center\">\n            </cl-image>\n          }\n        </div>\n        <!-- uploaded file -->\n        <!-- Uploaded file details in full view -->\n        <!--\n        here we are changing the layout from col to row\n        if we have to show a label inside once the user has uploaded the file\n        -->\n        @if (!properties.fullWidthPreview) {\n          <div class=\"flex w-full flex-col\">\n            @if (properties.afterUploadLabel) {\n              <mat-label\n                class=\"text-base font-normal leading-6 {{properties.darkMode ? 'text-white' : 'text-neutral-900'}}\">\n                {{properties.afterUploadLabel}}\n              </mat-label>\n            }\n            <div class=\"flex gap-1 {{properties.afterUploadLabel ? 'flex-row items-center' : 'flex-col'}}\">\n              <mat-label [matTooltip]=\"fileName!\"\n                class=\"text-white {{properties.afterUploadLabel ? 'text-md' : 'text-base'}}\">\n                {{fileName | truncate:[properties.fileNameMaxLength || 20]}}\n              </mat-label>\n              @if (properties.preLoadImageProperties == undefined) {\n                <mat-label class=\"text-sm text-neutral-400\">\n                  Size: {{fileResult[0].fileSizeDesc}}\n                </mat-label>\n              }\n            </div>\n          </div>\n        }\n        <!-- Uploaded file details in full view -->\n        <!-- delete file button -->\n        <mat-icon [svgIcon]=\"'heroicons_outline:trash'\" (click)=\"fileUpload.value = ''; deleteSelectedFile(0)\"\n          class=\"p-1 text-red-500 rounded-md cursor-pointer icon-size-6 bg-primary-100\">\n        </mat-icon>\n        <!-- delete file button -->\n      </div>\n    }\n    <!-- upload container - full image preview - after upload - dark mode -->\n\n    <!-- AFTER FILE UPLOAD -->\n  </div>\n\n  <!-- AFTER FILE UPLOAD - FILE DETAILS -->\n  <!-- this will only be visible when full width preview is required -->\n\n  @if (localUrl.length > 0 && (properties.fullWidthPreview || false)) {\n    <div class=\"flex gap-1 items-center\">\n      <mat-label class=\"text-md font-bold text-primary\">{{fileName}}</mat-label>\n      @if (properties.preLoadImageProperties == undefined) {\n        <mat-label class=\"text-sm text-neutral-800\">\n          Size: {{fileResult[0].fileSizeDesc}}\n        </mat-label>\n      }\n    </div>\n  }\n  <!-- AFTER FILE UPLOAD - FILE DETAILS -->\n\n  <!-- Hint text -->\n  @if ((fileResult.length > 0 && fileResult[0].errorMessage == undefined)) {\n    <div class=\"flex flex-wrap gap-1\">\n      @if (properties.supportedFile) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n          <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n        </div>\n      }\n      @if (properties.dimension) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n          <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n        </div>\n      }\n      @if (properties.maxLimitDesc) {\n        <div class=\"flex gap-0.5\">\n          <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n          <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n        </div>\n      }\n    </div>\n  }\n  <!-- Hint text -->\n\n  <!-- Error message -->\n  @if ((fileResult.length > 0 && fileResult[0].errorMessage != undefined)) {\n    <mat-label class=\"text-md text-warn\">{{fileResult[0].errorMessage}}</mat-label>\n  }\n  <!-- Error message -->\n\n</div>\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"false\" (change)=\"onFileUpload($event)\"\n  class=\"hidden pointer-events-none\">\n", styles: [".upload-dashed-border{display:flex;cursor:pointer;align-items:center;border-radius:.375rem;background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23D7D9DDFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-failed{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-dark{display:flex;cursor:pointer;align-items:center;border-radius:.375rem;background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%2301193BFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-dashed-border-failed-dark{background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='6' ry='6' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;--tw-bg-opacity: 1;background-color:rgba(var(--cl-primary-50-rgb),var(--tw-bg-opacity));background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23D7D9DDFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border-failed{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\") repeat var(--cl-primary-50)}.upload-shadow{box-shadow:0 0 1px #abafb866,0 3px 5px #abafb833}.upload-icon-dashed-border-dark{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background-color:var(--cl-primary-900);background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%2301193BFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\")}.upload-icon-dashed-border-failed-dark{width:3.5rem;border-start-start-radius:.375rem;border-end-start-radius:.375rem;background:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' rx='0' ry='0' stroke='%23F5222DFF' stroke-width='3' stroke-dasharray='8' stroke-dashoffset='0' stroke-linecap='butt'/%3e%3c/svg%3e\") repeat var(--cl-primary-900)}\n"] }]
        }], ctorParameters: () => [{ type: ClUploadService }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], preLoadImageProperties: [{
                type: Input
            }] } });

class ClCheckboxStyleProperties {
}
class ClCheckboxProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Checkbox';
        this.type = ClComponentTypes.checkbox;
        this.style = new ClCheckboxStyleProperties();
        this.style.cssClasses = "";
        this.style.contentWidth = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.labelCssClasses = 'text-md';
        this.showInfoMsg = signal(false);
    }
}

class ClCheckboxComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClCheckboxProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'INVALID' && this.ngControl.errors) {
                if (this.properties.isReactiveFormControl) {
                    const keys = Object.keys(this.ngControl.errors);
                    this.error = getErrorMessage(keys[0], this.properties.errorsList);
                }
                else {
                    this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
                }
                // this.error = this.ngControl.errors ? this.ngControl.errors!['error'] : null;
            }
            else if (changes === 'VALID') {
                this.error = null;
            }
        });
    }
    writeValue(value) {
        this.properties.checked = value;
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        this._value = this.properties.checked ?? false;
        return this._value;
    }
    onValueChanged(event) {
        this.writeValue(event.checked);
        this.onChange(this._value);
        if (this.properties.onValueChanged) {
            this.properties.onValueChanged(this._value);
        }
    }
    get isDisabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        // this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCheckboxComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClCheckboxComponent, isStandalone: true, selector: "cl-checkbox", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-checkbox color=\"primary\" [checked]=\"value\" class=\"flex w-full\" [id]=\"properties.id\" [disabled]=\"isDisabled\"\n  (change)=\"onValueChanged($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n  <div class=\"flex w-full items-center\">\n    <div class=\"{{ properties.style?.labelCssClasses }} select-none\">{{ properties.label }}</div>\n\n    @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n    }\n  </div>\n</mat-checkbox>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i8.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCheckboxComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-checkbox', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        ClTooltipDirective
                    ], template: "<mat-checkbox color=\"primary\" [checked]=\"value\" class=\"flex w-full\" [id]=\"properties.id\" [disabled]=\"isDisabled\"\n  (change)=\"onValueChanged($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n  <div class=\"flex w-full items-center\">\n    <div class=\"{{ properties.style?.labelCssClasses }} select-none\">{{ properties.label }}</div>\n\n    @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n    }\n  </div>\n</mat-checkbox>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClToggleButtonStyleProperties {
}
class ClToggleButtonProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Toggle Button';
        this.type = ClComponentTypes.toggleButton;
        this.style = new ClToggleButtonStyleProperties();
        this.options = [
            { text: 'Option 1', value: 'option1', selected: true },
            { text: 'Option 2', value: 'option2', selected: false },
        ];
    }
}

class ClToggleButtonComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClToggleButtonProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having selected as true and check with the value.
        // if both are not same update the value with the selected true option
        const selectedOption = this.properties.options?.find((opt) => opt.selected == true);
        if (selectedOption && selectedOption.value != this._value) {
            this.writeValue(selectedOption.value);
        }
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
    }
    writeValue(value) {
        // this._value = value;
        // this.properties.selectedText = this._value;
        if (value) {
            this.properties.options?.forEach((option) => {
                if (option.value === value) {
                    option.selected = true;
                }
                else {
                    option.selected = false;
                }
            });
            this._value = value;
        }
        else {
            this.properties.options?.forEach((option) => {
                option.selected = false;
            });
            this._value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onChangeButtonToggle(event) {
        this.writeValue(event.value);
        this.onChange(this._value);
        if (this.properties.onToggleChange) {
            this.properties.onToggleChange(this._value);
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToggleButtonComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClToggleButtonComponent, isStandalone: true, selector: "cl-toggle-button", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\"\n  class=\"{{properties.style?.parentClass ? properties.style?.parentClass : 'cl-toggle-button'}}\">\n\n  <mat-button-toggle-group class=\"{{properties.style?.cssClasses}}\"\n    [hideSingleSelectionIndicator]=\"properties.hideSelectionIndicator\"\n    [value]=\"value\"\n    [disabled]=\"properties.disabled\"\n    (change)=\"onChangeButtonToggle($event)\" aria-label=\"Font Style\">\n\n    @for (option of properties.options; track option) {\n      <mat-button-toggle class=\"{{properties.style?.innerClass}}\" [value]=\"option.value\" [disabled]=\"option.disabled\">\n        @if (option.icon){\n          <mat-icon class=\"icon-size-4\" [svgIcon]=\"option.icon\"></mat-icon>\n        }\n\n        {{option.text}}\n      </mat-button-toggle>\n    }\n  </mat-button-toggle-group>\n</div>\n", styles: [".cl-toggle-button{width:fit-content!important;padding:4px;background:#dfe3ec;border-radius:8px}.cl-toggle-button .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle{border-radius:4px!important;overflow:hidden;border:none!important;font-weight:500;color:#181b21!important;background:#dfe3ec}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-button .mat-button-toggle-label-content{color:#181b21!important}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle-checked{background:#fff;color:#181b21!important;font-weight:600!important}.cl-toggle-button-rounded-black{width:fit-content!important;padding:8px;background:#fff;border-radius:8px!important;border:.5px solid #E1E1E1!important}.cl-toggle-button-rounded-black .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle{border-radius:20px!important;overflow:hidden}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked{background:#181b21!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked .mat-button-toggle-label-content,.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked mat-icon{color:#fff!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-label-content{padding:8px!important}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonToggleModule }, { kind: "directive", type: i2$5.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i2$5.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToggleButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-toggle-button', imports: [
                        MatButtonToggleModule,
                        MatIconModule
                    ], encapsulation: ViewEncapsulation.None, template: "<div [id]=\"properties.id\"\n  class=\"{{properties.style?.parentClass ? properties.style?.parentClass : 'cl-toggle-button'}}\">\n\n  <mat-button-toggle-group class=\"{{properties.style?.cssClasses}}\"\n    [hideSingleSelectionIndicator]=\"properties.hideSelectionIndicator\"\n    [value]=\"value\"\n    [disabled]=\"properties.disabled\"\n    (change)=\"onChangeButtonToggle($event)\" aria-label=\"Font Style\">\n\n    @for (option of properties.options; track option) {\n      <mat-button-toggle class=\"{{properties.style?.innerClass}}\" [value]=\"option.value\" [disabled]=\"option.disabled\">\n        @if (option.icon){\n          <mat-icon class=\"icon-size-4\" [svgIcon]=\"option.icon\"></mat-icon>\n        }\n\n        {{option.text}}\n      </mat-button-toggle>\n    }\n  </mat-button-toggle-group>\n</div>\n", styles: [".cl-toggle-button{width:fit-content!important;padding:4px;background:#dfe3ec;border-radius:8px}.cl-toggle-button .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle{border-radius:4px!important;overflow:hidden;border:none!important;font-weight:500;color:#181b21!important;background:#dfe3ec}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-button .mat-button-toggle-label-content{color:#181b21!important}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle-checked{background:#fff;color:#181b21!important;font-weight:600!important}.cl-toggle-button-rounded-black{width:fit-content!important;padding:8px;background:#fff;border-radius:8px!important;border:.5px solid #E1E1E1!important}.cl-toggle-button-rounded-black .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle{border-radius:20px!important;overflow:hidden}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked{background:#181b21!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked .mat-button-toggle-label-content,.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked mat-icon{color:#fff!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-label-content{padding:8px!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClTextBlockStyleProperties {
}
class ClTextBlockProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Text Block';
        this.type = ClComponentTypes.textBlock;
        this.style = new ClTextBlockStyleProperties();
        this.style.cssClasses = 'text-base text-neutral-700';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.showInfoMsg = signal(false);
    }
}

class ClTextBlockComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClTextBlockProperties();
        super.ngOnInit();
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextBlockComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTextBlockComponent, isStandalone: true, selector: "cl-text-block", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"{{ properties.style?.cssClasses }}\">\n  <span>{{ properties.label }}</span>\n\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextBlockComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-text-block', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"{{ properties.style?.cssClasses }}\">\n  <span>{{ properties.label }}</span>\n\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n  }\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

var ClPatterns;
(function (ClPatterns) {
    ClPatterns["numeric"] = "[0-9]+$";
    ClPatterns["textOnly"] = "[A-Za-z]+$";
    ClPatterns["decimalNumber"] = "^[0-9.]+$";
    ClPatterns["inMobile"] = "[6-9]{1}[0-9]{9}";
    ClPatterns["textWithSpace"] = "[A-Za-z ]+$";
    ClPatterns["inIFSC"] = "[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}";
    ClPatterns["alphaNumericWithSpace"] = "^[a-zA-Z0-9 ]+$";
    ClPatterns["alphaNumericWithOutSpace"] = "^[a-zA-Z0-9]+$";
    ClPatterns["pan"] = "([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$";
    ClPatterns["email"] = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[.][a-zA-Z]{2,}$";
    ClPatterns["gst"] = "[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[0-9A-Z]{2}";
})(ClPatterns || (ClPatterns = {}));
class ClChipInputStyleProperties {
}
class ClChipsInputProperties {
    constructor() {
        this.id = 'default0';
        this.subscriptSizing = 'fixed';
        this.appearance = 'fill';
        this.floatLabel = 'auto';
        this.label = 'Chips Input';
        this.type = ClComponentTypes.chipInput;
        this.style = new ClChipInputStyleProperties();
        this.style.cssClasses = 'flex-auto w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.showInfoMsg = signal(false);
        this.disabled = signal(false);
    }
}

class ClChipsInputComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        // @ViewChild('matTextField')
        // public matTextFieldDivElementRef!: ElementRef;
        // @ViewChild('errorOrHintDivElementRef')
        // public errorOrHintDivElementRef!: ElementRef;
        // private errorOrHintDivElement!: HTMLDivElement;
        // private matTextFieldDivElement!: HTMLDivElement;
        this.optionsAdded = new EventEmitter();
        this.options = [];
        this.announcer = inject(LiveAnnouncer);
        this.separatorKeysCodes = [ENTER];
        this.iconProperties = {
            id: 'chipCloseIcon',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:x-mark',
        };
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClChipsInputProperties();
        this.options = this.properties?.options ?? [];
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
            if (value) {
                if (value.length > 0 && this.options != value) {
                    this.options = value;
                }
            }
        });
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    add(event) {
        const value = (event.value || '').trim();
        if (value) {
            this.options.push(value);
        }
        // Clear the input value
        event.chipInput.clear();
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    remove(option) {
        const index = this.options.indexOf(option);
        if (index >= 0) {
            this.options.splice(index, 1);
            this.announcer.announce(`Removed $option`);
        }
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    edit(option, event) {
        const value = event.value.trim();
        // Remove option if it no longer has a name
        if (!value) {
            this.remove(option);
            return;
        }
        // Edit existing option
        const index = this.options.indexOf(option);
        if (index >= 0) {
            this.options[index] = value;
        }
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    pushSelectedOptions() {
        if (this.properties.onOptionsAdded != undefined) {
            this.properties.onOptionsAdded(this.options);
        }
        this.optionsAdded.emit(this.options);
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        // this.valueChanges?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipsInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChipsInputComponent, isStandalone: true, selector: "cl-chips-input", inputs: { properties: "properties" }, outputs: { optionsAdded: "optionsAdded" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  class=\"{{ properties.style?.cssClasses }}\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-chip-grid #chipGrid aria-label=\"Enter options\" class=\"max-h-10 overflow-auto\" [disabled]=\"disabled\">\n\n    @for (option of options; track option) {\n      <mat-chip-row [editable]=\"true\" (removed)=\"remove(option)\" (edited)=\"edit(option, $event)\"\n        [aria-description]=\"'press enter to edit ' + option\">\n\n        <span class=\"flex gap-1 items-center\">\n          <mat-label class=\"text-primary-700\">{{ option }}</mat-label>\n\n          <mat-icon (click)=\"remove(option)\" class=\"icon-size-4 text-primary-700\" [svgIcon]=\"'heroicons_outline:x-mark'\">\n          </mat-icon>\n        </span>\n      </mat-chip-row>\n    }\n\n    <input [matChipInputFor]=\"chipGrid\" [matChipInputAddOnBlur]=\"true\" (matChipInputTokenEnd)=\"add($event)\"\n      placeholder=\"{{properties.placeholder}}\" (blur)=\"onTouched($any($event.target).value)\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\" />\n\n  </mat-chip-grid>\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.cl-input-chip-grid{max-height:2.5rem!important;overflow:auto!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3$1.MatChipGrid, selector: "mat-chip-grid", inputs: ["disabled", "placeholder", "required", "value", "errorStateMatcher"], outputs: ["change", "valueChange"] }, { kind: "directive", type: i3$1.MatChipInput, selector: "input[matChipInputFor]", inputs: ["matChipInputFor", "matChipInputAddOnBlur", "matChipInputSeparatorKeyCodes", "placeholder", "id", "disabled"], outputs: ["matChipInputTokenEnd"], exportAs: ["matChipInput", "matChipInputFor"] }, { kind: "component", type: i3$1.MatChipRow, selector: "mat-chip-row, [mat-chip-row], mat-basic-chip-row, [mat-basic-chip-row]", inputs: ["editable"], outputs: ["edited"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipsInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chips-input', imports: [
                        MatIconModule,
                        MatChipsModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  class=\"{{ properties.style?.cssClasses }}\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-chip-grid #chipGrid aria-label=\"Enter options\" class=\"max-h-10 overflow-auto\" [disabled]=\"disabled\">\n\n    @for (option of options; track option) {\n      <mat-chip-row [editable]=\"true\" (removed)=\"remove(option)\" (edited)=\"edit(option, $event)\"\n        [aria-description]=\"'press enter to edit ' + option\">\n\n        <span class=\"flex gap-1 items-center\">\n          <mat-label class=\"text-primary-700\">{{ option }}</mat-label>\n\n          <mat-icon (click)=\"remove(option)\" class=\"icon-size-4 text-primary-700\" [svgIcon]=\"'heroicons_outline:x-mark'\">\n          </mat-icon>\n        </span>\n      </mat-chip-row>\n    }\n\n    <input [matChipInputFor]=\"chipGrid\" [matChipInputAddOnBlur]=\"true\" (matChipInputTokenEnd)=\"add($event)\"\n      placeholder=\"{{properties.placeholder}}\" (blur)=\"onTouched($any($event.target).value)\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\" />\n\n  </mat-chip-grid>\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.cl-input-chip-grid{max-height:2.5rem!important;overflow:auto!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], optionsAdded: [{
                type: Output
            }] } });

var ClProgressBarMode;
(function (ClProgressBarMode) {
    ClProgressBarMode["indeterminate"] = "indeterminate";
    ClProgressBarMode["determinate"] = "determinate";
    ClProgressBarMode["buffer"] = "buffer";
    ClProgressBarMode["query"] = "query";
})(ClProgressBarMode || (ClProgressBarMode = {}));
var ClProgressSize;
(function (ClProgressSize) {
    ClProgressSize["large"] = "cl-large-progress-bar";
    ClProgressSize["normal"] = "cl-normal-progress-bar";
})(ClProgressSize || (ClProgressSize = {}));
class ClProgressBarStyleProperties {
}
class ClProgressBarProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Progress Bar';
        this.type = ClComponentTypes.progressBar;
        this.showRadius = false;
        this.size = ClProgressSize.normal;
        this.style = new ClProgressBarStyleProperties();
        this.style.alignContent = '';
        this.style.cssClasses = "w-40";
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
    }
}

class ClProgressBarComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(changes) {
        this.properties.size ??= ClProgressSize.normal;
        this.properties.mode ??= ClProgressBarMode.determinate;
    }
    ngOnInit() {
        this.properties ??= new ClProgressBarProperties();
        super.ngOnInit();
    }
    //--------------------------------------------
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClProgressBarComponent, isStandalone: true, selector: "cl-progress-bar", inputs: { properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 items-center {{ properties.style?.cssClasses }}\">\n  <mat-progress-bar [mode]=\"properties.mode!\" [value]=\"properties.value\"\n    class=\"{{ properties.size }} {{ properties.showRadius ? 'rounded-2xl' : 'rounded-none' }} {{ properties.style?.cssClasses }}\"\n    [ngClass]=\"properties.value != undefined && properties.value === 100 ? 'progress-green' : properties.value != undefined && properties.value &lt; 50 ? 'progress-yellow' : ''\">\n  </mat-progress-bar>\n\n  @if (properties.mode === 'determinate') {\n    <div class=\"text-xs font-bold\">{{ properties.value }}%</div>\n  }\n</div>\n", styles: [".progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatProgressBarModule }, { kind: "component", type: i1$2.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClProgressBarComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-progress-bar', imports: [
                        NgClass,
                        MatProgressBarModule,
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 items-center {{ properties.style?.cssClasses }}\">\n  <mat-progress-bar [mode]=\"properties.mode!\" [value]=\"properties.value\"\n    class=\"{{ properties.size }} {{ properties.showRadius ? 'rounded-2xl' : 'rounded-none' }} {{ properties.style?.cssClasses }}\"\n    [ngClass]=\"properties.value != undefined && properties.value === 100 ? 'progress-green' : properties.value != undefined && properties.value &lt; 50 ? 'progress-yellow' : ''\">\n  </mat-progress-bar>\n\n  @if (properties.mode === 'determinate') {\n    <div class=\"text-xs font-bold\">{{ properties.value }}%</div>\n  }\n</div>\n", styles: [".progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClTimerStyleProperties {
}
class ClTimerProperties {
    constructor() {
        this.timeInSec = 90;
        this.id = 'default0';
        this.type = ClComponentTypes.timer;
        this.style = new ClTimerStyleProperties();
        this.style.cssClasses = "flex-auto w-full";
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClTimerComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClTimerProperties();
        this.timeInSeconds = this.properties.timeInSec;
        // calling update display time function
        this.updateDisplayTime();
        // calling calculate reverse progress function
        this.calculateReverseProgress();
        // calling start timer function
        this.startTimer();
        // calling on timer started function
        this.onTimerStarted();
        super.ngOnInit();
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    startTimer() {
        this.intervalId = setInterval(() => {
            if (this.timeInSeconds > 0) {
                this.timeInSeconds--;
            }
            else if (this.timeInSeconds <= 0) {
                // calling stop timer function
                this.stopTimer();
                if (this.properties.onTimerStopped) {
                    // calling on timer stopped callback function
                    this.properties.onTimerStopped();
                }
            }
            // calling update display time function
            this.updateDisplayTime();
            // calling calculate reverse progress function
            this.calculateReverseProgress();
        }, 1000);
    }
    stopTimer() {
        clearInterval(this.intervalId);
    }
    formatTime(time) {
        return time < 10 ? `0${time}` : `${time}`;
    }
    onTimerStarted() {
        if (this.properties.onTimerStarted != undefined) {
            this.properties.onTimerStarted();
        }
    }
    calculateReverseProgress() {
        const totalTime = this.properties.timeInSec;
        const remainingTime = this.timeInSeconds > 0 ? this.timeInSeconds : 0;
        const progress = (remainingTime / totalTime) * 100;
        // Ensure progress is between 0 and 100;
        this.remainingProgress = 100 - Math.max(0, Math.min(100 - progress, 100));
    }
    updateDisplayTime() {
        const seconds = this.timeInSeconds % 60;
        const hours = Math.floor(this.timeInSeconds / 3600);
        const minutes = Math.floor((this.timeInSeconds % 3600) / 60);
        if (hours <= 0) {
            // for showing minutes and seconds
            this.displayTime = `${this.formatTime(minutes)}:${this.formatTime(seconds)}`;
        }
        else {
            // for showing hours, minutes and seconds
            this.displayTime = `${this.formatTime(hours)}:${this.formatTime(minutes)}:${this.formatTime(seconds)}`;
        }
    }
    ngOnDestroy() {
        this.stopTimer();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClTimerComponent, isStandalone: true, selector: "cl-timer", inputs: { properties: "properties" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClTimerComponent),
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"countdown-container\">\n  <mat-progress-spinner mode=\"determinate\" [strokeWidth]=\"5\" [value]=\"remainingProgress\"\n    class=\"progress-spinner -scale-x-1 -scale-y--1\" style=\"width: 5rem; height: 5rem;\">\n  </mat-progress-spinner>\n\n  <mat-label class=\"time-display\">{{ displayTime }}</mat-label>\n</div>\n", styles: [".countdown-container{position:relative;display:flex;align-items:center;justify-content:center;height:100px;width:100px}.progress-spinner{position:absolute;top:0;left:0}.time-display{position:absolute;font-size:1.125rem;font-weight:400;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity));top:1.85rem!important;left:1.5rem!important}::ng-deep .countdown-container mat-progress-spinner circle{stroke-linecap:round;--mdc-circular-progress-active-indicator-color: var(--cl-primary-300)}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i2$6.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-timer', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClTimerComponent),
                            multi: true
                        }
                    ], imports: [MatFormFieldModule, MatProgressSpinnerModule], template: "<div [id]=\"properties.id\" class=\"countdown-container\">\n  <mat-progress-spinner mode=\"determinate\" [strokeWidth]=\"5\" [value]=\"remainingProgress\"\n    class=\"progress-spinner -scale-x-1 -scale-y--1\" style=\"width: 5rem; height: 5rem;\">\n  </mat-progress-spinner>\n\n  <mat-label class=\"time-display\">{{ displayTime }}</mat-label>\n</div>\n", styles: [".countdown-container{position:relative;display:flex;align-items:center;justify-content:center;height:100px;width:100px}.progress-spinner{position:absolute;top:0;left:0}.time-display{position:absolute;font-size:1.125rem;font-weight:400;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity));top:1.85rem!important;left:1.5rem!important}::ng-deep .countdown-container mat-progress-spinner circle{stroke-linecap:round;--mdc-circular-progress-active-indicator-color: var(--cl-primary-300)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

var ClToastMessageType;
(function (ClToastMessageType) {
    ClToastMessageType["info"] = "info";
    ClToastMessageType["error"] = "error";
    ClToastMessageType["success"] = "success";
})(ClToastMessageType || (ClToastMessageType = {}));
class ClToastStyleProperties {
}
class ClToastProperties {
    constructor() {
        this.id = 'default0';
        this.type = ClComponentTypes.toast;
        this.style = new ClToastStyleProperties();
        this.style.cssClasses = 'text-md leading-5 font-medium text-white';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
    }
}

class ClToastComponent {
    constructor(data, snackBarRef) {
        this.data = data;
        this.snackBarRef = snackBarRef;
        this.toastProperties = this.data.properties;
    }
    ngOnInit() {
        this.setIconProperties();
    }
    setIconProperties() {
        this.iconProperties = {
            id: 'toastMsgIcon',
            type: ClComponentTypes.icon,
            iconName: this.getIconName(),
            style: { cssClasses: 'text-white icon-size-5' }
        };
    }
    getIconName() {
        switch (this.toastProperties.messageType) {
            case ClToastMessageType.info:
                return 'fss_icons:info-fill-white';
            case ClToastMessageType.error:
                return 'heroicons_outline:exclamation-triangle';
            default:
                return 'fss_icons:filled-circle-check-white';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastComponent, deps: [{ token: MAT_SNACK_BAR_DATA }, { token: i1$3.MatSnackBarRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClToastComponent, isStandalone: true, selector: "cl-toast", ngImport: i0, template: "<div class=\"flex gap-3 items-center\">\n  <cl-icon class=\"flex self-center\" [properties]=\"iconProperties\"></cl-icon>\n\n  @if (toastProperties.message) {\n    <mat-label [class]=\"toastProperties.style?.cssClasses\">{{toastProperties.message}}</mat-label>\n  }\n\n  @if (toastProperties.customMsg?.length) {\n    <div class=\"flex gap-1 items-center\">\n      @for (labelProperties of toastProperties.customMsg; track labelProperties) {\n        <mat-label class=\"{{ labelProperties.fontSize }} {{ labelProperties.lineHeight }} {{ labelProperties.fontWeight }}\">{{labelProperties.text}}</mat-label>\n      }\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatSnackBarModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-toast', imports: [
                        MatSnackBarModule,
                        MatFormFieldModule,
                        ClIconComponent
                    ], template: "<div class=\"flex gap-3 items-center\">\n  <cl-icon class=\"flex self-center\" [properties]=\"iconProperties\"></cl-icon>\n\n  @if (toastProperties.message) {\n    <mat-label [class]=\"toastProperties.style?.cssClasses\">{{toastProperties.message}}</mat-label>\n  }\n\n  @if (toastProperties.customMsg?.length) {\n    <div class=\"flex gap-1 items-center\">\n      @for (labelProperties of toastProperties.customMsg; track labelProperties) {\n        <mat-label class=\"{{ labelProperties.fontSize }} {{ labelProperties.lineHeight }} {{ labelProperties.fontWeight }}\">{{labelProperties.text}}</mat-label>\n      }\n    </div>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1$3.MatSnackBarRef }] });

class ClToastService {
    constructor(_snackBar) {
        this._snackBar = _snackBar;
    }
    _openSnackbar(toastProperties, panelClass = '') {
        this._snackBar.openFromComponent(ClToastComponent, {
            panelClass: panelClass,
            data: { properties: toastProperties },
            duration: toastProperties.duration ?? 5000,
            verticalPosition: toastProperties.verticalPosition ?? 'top',
            horizontalPosition: toastProperties.horizontalPosition ?? 'end'
        });
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------
    info(toastProperties) {
        toastProperties.messageType = ClToastMessageType.info;
        this._openSnackbar(toastProperties, 'info');
    }
    error(toastProperties) {
        toastProperties.messageType = ClToastMessageType.error;
        this._openSnackbar(toastProperties, 'error');
    }
    success(toastProperties) {
        toastProperties.messageType = ClToastMessageType.success;
        this._openSnackbar(toastProperties, 'success');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, deps: [{ token: i1$3.MatSnackBar }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1$3.MatSnackBar }] });

class ClContactInputStyleProperties {
}
class ClContactInputProperties {
    constructor() {
        this.id = 'default0';
        this.floatLabel = 'auto';
        this.subscriptSizing = 'fixed';
        this.appearance = 'fill';
        this.label = 'Contact Input';
        this.type = ClComponentTypes.contactInput;
        this.disabled = false;
        this.countries = [
            { code: '+91', name: 'India', id: 'ind' }
        ];
        this.selectedCountry = { code: '+91', name: 'India', id: 'ind' };
        this.style = new ClContactInputStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
        this.showInfoMsg = signal(false);
    }
}

class ClContactInputComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClContactInputProperties();
        this.selectedCountry = this.properties.selectedCountry;
        super.ngOnInit();
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    allowOnlyNumbers(event) {
        const input = event.key;
        const isNumeric = /^[0-9]$/.test(input);
        if (!isNumeric) {
            event.preventDefault();
        }
    }
    countryCodeSelection(selected) {
        const filteredValues = this.properties.countries?.filter((country) => country.code == selected);
        if (filteredValues?.length) {
            this.selectedCountry = filteredValues[0];
        }
        if (this.properties.onCountryChanged && this.selectedCountry) {
            this.properties.onCountryChanged(this.selectedCountry);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClContactInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClContactInputComponent, isStandalone: true, selector: "cl-contact-input", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n  <mat-label class=\"flex items-center\">\n    <span>{{ properties.label }}</span>\n\n    @if (properties.optional) {\n    <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n      class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input matInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" (keypress)=\"allowOnlyNumbers($event)\"\n    [placeholder]=\"properties.placeholder!\" (blur)=\"onTouched($any($event.target).value)\"\n    (input)=\"onChange(selectedCountry?.code + ' ' + $any($event.target).value)\" />\n\n  @if (properties.countries!.length > 0) {\n  <div matPrefix class=\"border-r border-solid border-neutral-500 pr-2 mr-1\">\n    <mat-select [value]=\"selectedCountry?.code\" [hideSingleSelectionIndicator]=\"true\"\n      (valueChange)=\"countryCodeSelection($event)\">\n\n      <mat-select-trigger>{{selectedCountry?.code}}</mat-select-trigger>\n\n      @for (country of properties.countries; track country) {\n      <mat-option [value]=\"country.code\" class=\"flex items-center justify-between cl-mat-select-option\">\n        {{country.code}} - {{country.name}}\n      </mat-option>\n      }\n    </mat-select>\n  </div>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClContactInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-contact-input', imports: [
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatSelectModule,
                        MatOptionModule,
                        MatSelectTrigger,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n  <mat-label class=\"flex items-center\">\n    <span>{{ properties.label }}</span>\n\n    @if (properties.optional) {\n    <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n      class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input matInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" (keypress)=\"allowOnlyNumbers($event)\"\n    [placeholder]=\"properties.placeholder!\" (blur)=\"onTouched($any($event.target).value)\"\n    (input)=\"onChange(selectedCountry?.code + ' ' + $any($event.target).value)\" />\n\n  @if (properties.countries!.length > 0) {\n  <div matPrefix class=\"border-r border-solid border-neutral-500 pr-2 mr-1\">\n    <mat-select [value]=\"selectedCountry?.code\" [hideSingleSelectionIndicator]=\"true\"\n      (valueChange)=\"countryCodeSelection($event)\">\n\n      <mat-select-trigger>{{selectedCountry?.code}}</mat-select-trigger>\n\n      @for (country of properties.countries; track country) {\n      <mat-option [value]=\"country.code\" class=\"flex items-center justify-between cl-mat-select-option\">\n        {{country.code}} - {{country.name}}\n      </mat-option>\n      }\n    </mat-select>\n  </div>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClSelectWithGroupStyleProperties {
}
class ClSelectWithGroupProperties {
    constructor() {
        this.id = 'default0';
        this.subscriptSizing = 'fixed';
        this.label = 'Select With Group';
        this.type = ClComponentTypes.selectWithGroup;
        this.searchBoxPlaceholder = 'Enter Search Query...';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.style = new ClSelectWithGroupStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
        this.options = [
            {
                group: 'Group 1',
                children: [
                    { text: 'Option 1', value: 'option1' },
                    { text: 'Option 2', value: 'option2' }
                ]
            },
            {
                group: 'Group 2',
                children: [
                    { text: 'Option 3', value: 'option3' },
                    { text: 'Option 4', value: 'option4' }
                ]
            }
        ];
    }
}

class ClSelectWithGroupComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.searchQuery = '';
        this.filteredOptions = [];
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(_changes) {
        this.filteredOptions = this.properties.options;
    }
    ngOnInit() {
        this.properties ??= new ClSelectWithGroupProperties();
        this.setDefaultSelectedOption();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    filter(searchQuery) {
        if (!searchQuery) {
            this.filteredOptions = this.properties.options;
            return;
        }
        this.filteredOptions = this.properties.options.map((group) => ({ ...group, children: group.children.filter((option) => option.text.toLowerCase().includes(searchQuery.toLowerCase())) }));
    }
    onOptionSelected(option) {
        this.onChange(option);
        this.selectedOption = option;
        this.properties.selectedOption = option;
        this.writeValue(this.selectedOption);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(option);
        }
    }
    onOpenedChange(event) {
        if (!event) {
            this.searchQuery = '';
            this.filter(this.searchQuery);
        }
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onOptionSelected('');
    }
    setDefaultSelectedOption() {
        if (this.properties.selectedOption) {
            for (const group of this.properties.options) {
                const foundOption = group.children.find(option => option.value === this.properties.selectedOption.value);
                if (foundOption) {
                    this.selectedOption = foundOption.value;
                    this.writeValue(this.selectedOption);
                    break;
                }
            }
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.sub?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectWithGroupComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClSelectWithGroupComponent, isStandalone: true, selector: "cl-select-with-group", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex gap-1 items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"flex icon-size-4 cursor-pointer text-neutral-600 place-content-center\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" (openedChange)=\"onOpenedChange($event)\"\n    (valueChange)=\"onOptionSelected($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxPlaceholder!\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n    <!-- search field for auto complete -->\n\n    <!-- options for dropdown -->\n    <div class=\"autocomplete-options-container\">\n      @for (optionGroup of filteredOptions; track optionGroup) {\n        <mat-optgroup [label]=\"optionGroup.group\" [disabled]=\"optionGroup.disabled\" class=\"font-bold text-neutral-700\">\n          @for (option of optionGroup.children; track option) {\n            <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\">\n              <div class=\"ml-3 text-md font-normal text-neutral-700\">{{ option.text }}</div>\n            </mat-option>\n          }\n        </mat-optgroup>\n      }\n    </div>\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.hide-option{display:none!important}.mat-mdc-checkbox .mdc-form-field,.mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.autocomplete-options:not(:last-child){border-bottom-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important}.mat-mdc-option{min-height:42px!important;padding-left:.25rem!important;padding-right:.25rem!important}.mat-mdc-option .mat-icon,.mat-mdc-option .mat-pseudo-checkbox-full{margin-right:0!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "component", type: i6.MatOptgroup, selector: "mat-optgroup", inputs: ["label", "disabled"], exportAs: ["matOptgroup"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectWithGroupComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-select-with-group', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex gap-1 items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"flex icon-size-4 cursor-pointer text-neutral-600 place-content-center\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" (openedChange)=\"onOpenedChange($event)\"\n    (valueChange)=\"onOptionSelected($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxPlaceholder!\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n    <!-- search field for auto complete -->\n\n    <!-- options for dropdown -->\n    <div class=\"autocomplete-options-container\">\n      @for (optionGroup of filteredOptions; track optionGroup) {\n        <mat-optgroup [label]=\"optionGroup.group\" [disabled]=\"optionGroup.disabled\" class=\"font-bold text-neutral-700\">\n          @for (option of optionGroup.children; track option) {\n            <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\">\n              <div class=\"ml-3 text-md font-normal text-neutral-700\">{{ option.text }}</div>\n            </mat-option>\n          }\n        </mat-optgroup>\n      }\n    </div>\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.hide-option{display:none!important}.mat-mdc-checkbox .mdc-form-field,.mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.autocomplete-options:not(:last-child){border-bottom-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important}.mat-mdc-option{min-height:42px!important;padding-left:.25rem!important;padding-right:.25rem!important}.mat-mdc-option .mat-icon,.mat-mdc-option .mat-pseudo-checkbox-full{margin-right:0!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClNestedAutoCompleteStyleProperties {
}
class ClNestedAutoCompleteProperties {
    constructor() {
        this.id = 'default0';
        this.appearance = 'fill';
        this.floatLabel = 'auto';
        this.manualEntry = false;
        this.subscriptSizing = 'fixed';
        this.label = 'Nested Auto Complete';
        this.type = ClComponentTypes.nestedAutoComplete;
        this.style = new ClNestedAutoCompleteStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            {
                text: 'Option1',
                value: "option1",
                list: [
                    { text: 'Option2', value: "option2" },
                    { text: 'Option3', value: "option3" }
                ]
            },
            {
                text: 'Option4',
                value: "option4",
                list: [
                    { text: 'Option5', value: "option5" },
                    { text: 'Option6', value: "option6" }
                ]
            },
            {
                text: 'Option7',
                value: "option7",
                list: [
                    { text: 'Option8', value: "option8" },
                    {
                        text: 'Option9',
                        value: "option9",
                        list: [
                            { text: 'Option10', value: "option10" },
                            { text: 'Option11', value: "option11" }
                        ]
                    }
                ]
            }
        ];
    }
}

class ClNestedAutocompleteComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.inputControl = new FormControl();
        this.selectedOptions = [];
        this.filteredOptions = of([]);
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(_changes) {
        this.setDefaultValueAndOptions();
    }
    ngOnInit() {
        this.properties ??= new ClNestedAutoCompleteProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            .subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
        }
    }
    setDefaultValueAndOptions() {
        if (this.properties.selectedValue) {
            this.setDefaultSelectedValues();
            this.filteredOptions = of([]);
        }
        else {
            this.filteredOptions = of(this.properties.options);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    filterOptions(value) {
        let filterValue;
        if (typeof value === 'object') {
            filterValue = value.name.toLowerCase();
        }
        else {
            filterValue = value.toLowerCase();
        }
        let currentOptions = this.properties.options;
        // Traverse the selected options to reach the current level
        this.selectedOptions.forEach((selected) => {
            if (selected.list) {
                currentOptions = selected.list;
            }
        });
        // Filter out already selected options
        const selectedNames = this.selectedOptions.map((option) => option.text.toLowerCase());
        // If filterValue ends with ".", show list of the last selected option
        if (filterValue.endsWith('.')) {
            const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
            return lastSelected?.list || [];
        }
        return currentOptions.filter((option) => option.text.toLowerCase().includes(filterValue) && !selectedNames.includes(option.text.toLowerCase()));
    }
    onOptionSelected(event) {
        const selectedOption = event.option.value;
        // Check if the selected option is already in the selectedOptions array
        if (!this.selectedOptions.includes(selectedOption)) {
            // Add to the selected options
            this.selectedOptions.push(selectedOption);
            // Update the input control to show the selected path
            const selectedPath = this.selectedOptions.map((option) => option.text).join('.');
            this.inputControl.setValue(selectedPath, { emitEvent: false });
            // Reset filtered options to empty
            this.filteredOptions = of([]);
            this.onValueChange(this.inputControl.value);
        }
    }
    setDefaultSelectedValues() {
        const defaultPath = this.properties.selectedValue;
        if (!defaultPath) {
            return;
        }
        this.selectedOptions = [];
        let currentOptions = this.properties.options;
        const parts = defaultPath.split('.');
        for (const part of parts) {
            const selectedOption = currentOptions?.find((option) => option.text === part);
            if (selectedOption) {
                this.selectedOptions.push(selectedOption);
                if (selectedOption.list) {
                    currentOptions = selectedOption.list;
                }
                else {
                    break;
                }
            }
            else {
                break;
            }
        }
        if (this.selectedOptions.length > 0) {
            const selectedPath = this.selectedOptions.map((option) => option.text).join('.');
            this.inputControl.setValue(selectedPath, { emitEvent: false });
        }
        else {
            this.inputControl.setValue(defaultPath, { emitEvent: false });
        }
    }
    onInputChange(event) {
        const value = event.target.value;
        if (!value || value.trim() === '') {
            // If the input field is empty, show all top-level options
            this.filteredOptions = of(this.properties.options);
        }
        else {
            const lastDotIndex = value.lastIndexOf('.');
            let additionalText = '';
            if (lastDotIndex !== -1 && this.selectedOptions.length > 0) {
                // Separate the additional typed text from the selected options
                additionalText = value.slice(lastDotIndex + 1);
                const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
                const children = lastSelected?.list || [];
                this.filteredOptions = of(children.filter((option) => option.text?.toLowerCase().includes(additionalText.toLowerCase())));
            }
            else if (!this.properties.manualEntry) {
                // Filter options based on the input value
                this.filteredOptions = of(this.filterOptions(value));
            }
            else if (this.properties.manualEntry) {
                // Emit the combined result: selected options + manually typed text
                const combinedValue = this.selectedOptions.map((option) => option.text).join('.') + (additionalText ? `.${additionalText}` : '');
                this.onValueChange(combinedValue);
            }
        }
    }
    onKeydown(event) {
        if (event.key === 'Backspace') {
            const currentValue = this.inputControl.value;
            const lastDotIndex = currentValue.lastIndexOf('.');
            if (lastDotIndex !== -1) {
                // Remove everything after and including the last dot
                const newValue = currentValue.slice(0, lastDotIndex);
                this.inputControl.setValue(newValue, { emitEvent: false });
                // Update the selected options accordingly
                this.selectedOptions = [];
                let currentOptions = this.properties.options;
                newValue.split('.').every((part) => {
                    const selectedOption = currentOptions.find((option) => option.text === part);
                    if (selectedOption) {
                        this.selectedOptions.push(selectedOption);
                        currentOptions = selectedOption.list || [];
                        return true;
                    }
                    return false;
                });
                // Update the filtered options to reflect the current state
                const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
                this.filteredOptions = of(lastSelected?.list || []);
                this.onValueChange(this.inputControl.value);
                // If there are no list, don't open the dropdown
                if (!lastSelected?.list) {
                    this.autocompleteTrigger?.closePanel();
                }
            }
            else {
                // Clear the input control and reset selections
                this.clearSelection();
                this.autocompleteTrigger?.openPanel();
            }
            event.preventDefault();
        }
    }
    onPrefixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked();
        }
    }
    onSuffixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked();
        }
    }
    clearSelection() {
        this.selectedOptions = [];
        this.inputControl.setValue('', { emitEvent: false });
        this.filteredOptions = of(this.properties.options);
        this.onValueChange('');
    }
    onValueChange(value) {
        this.onChange(value);
        this.writeValue(value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(value);
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.sub?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedAutocompleteComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedAutocompleteComponent, isStandalone: true, selector: "cl-nested-autocomplete", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "autocompleteTrigger", first: true, predicate: ["autocompleteInput"], descendants: true, read: MatAutocompleteTrigger }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput #autocompleteInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" [matAutocomplete]=\"auto\"\n    [formControl]=\"inputControl\" (keydown)=\"onKeydown($event)\" (input)=\"onInputChange($event)\"\n    [placeholder]=\"properties.placeholder!\">\n\n  <mat-autocomplete #auto=\"matAutocomplete\" (optionSelected)=\"onOptionSelected($event)\">\n    @for (option of filteredOptions | async; track option) {\n      <mat-option [value]=\"option\" [style.display]=\"option?.hideOption ? 'none' : 'flex'\">{{ option.text }}</mat-option>\n    }\n  </mat-autocomplete>\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\" (click)=\"onPrefixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\" (click)=\"onSuffixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i5$2.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i5$2.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-autocomplete', imports: [
                        NgClass,
                        AsyncPipe,
                        FormsModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        MatAutocompleteModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput #autocompleteInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" [matAutocomplete]=\"auto\"\n    [formControl]=\"inputControl\" (keydown)=\"onKeydown($event)\" (input)=\"onInputChange($event)\"\n    [placeholder]=\"properties.placeholder!\">\n\n  <mat-autocomplete #auto=\"matAutocomplete\" (optionSelected)=\"onOptionSelected($event)\">\n    @for (option of filteredOptions | async; track option) {\n      <mat-option [value]=\"option\" [style.display]=\"option?.hideOption ? 'none' : 'flex'\">{{ option.text }}</mat-option>\n    }\n  </mat-autocomplete>\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\" (click)=\"onPrefixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\" (click)=\"onSuffixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], autocompleteTrigger: [{
                type: ViewChild,
                args: ['autocompleteInput', { read: MatAutocompleteTrigger }]
            }] } });

class ClCodeViewStyleProperties {
}
class ClCodeViewProperties {
    constructor() {
        this.id = "default0";
        this.type = ClComponentTypes.codeView;
        this.code = "";
        this.lang = 'json';
        this.style = new ClCodeViewStyleProperties();
        this.style.fontStyle = '';
        this.style.alignContent = '';
        this.style.contentWidth = '';
        this.style.justifyContent = '';
        this.style.iconCssClasses = '';
        this.style.labelCssClasses = '';
        this.style.cssClasses = 'w-full';
    }
}

class ClCodeViewComponent extends ClBaseComponent {
    constructor(cdr) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.cdr = cdr;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClCodeViewProperties();
        this.formatCode();
        super.ngOnInit();
    }
    ngOnChanges(_changes) {
        this.formatCode();
    }
    formatCode() {
        if (this.code?.length && this.properties.lang?.toLowerCase() == 'json') {
            // Step 1: Clean the escape characters
            let code = this.code?.replace(/\\"/g, '"'); // Replace escaped quotes \" with actual "
            code = code?.replace(/\\n/g, ''); // Remove any newlines
            code = code?.replace(/\\/g, ''); // Remove unnecessary backslashes
            try {
                // Step 2: Parse the string to JSON
                const validJson = JSON.parse(code);
                // Step 3: Prettify JSON object
                this.properties.code = JSON.stringify(validJson, null, 2);
                this.cdr.detectChanges();
            }
            catch (e) {
                console.error(66, "Error parsing JSON:", e.message);
                console.error(67, "JSON:", code);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCodeViewComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClCodeViewComponent, isStandalone: true, selector: "cl-code-view", inputs: { code: "code", properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<textarea cl-highlight [lang]=\"properties.lang\" [code]=\"properties.code\" [class]=\"properties.style?.cssClasses\"\n  [fontStyle]=\"properties.style?.fontStyle\">\n</textarea>\n", styles: [":host{display:flex;width:100%;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClHighlightComponent, selector: "textarea[cl-highlight]", inputs: ["code", "lang", "fontStyle"], exportAs: ["clHighlight"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCodeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-code-view', imports: [
                        MatIconModule,
                        MatFormFieldModule,
                        ClHighlightComponent
                    ], template: "<textarea cl-highlight [lang]=\"properties.lang\" [code]=\"properties.code\" [class]=\"properties.style?.cssClasses\"\n  [fontStyle]=\"properties.style?.fontStyle\">\n</textarea>\n", styles: [":host{display:flex;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { code: [{
                type: Input,
                args: [{ required: true }]
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClMultiLevelSelectStyleProperties {
}
class ClMultiLevelSelectProperties {
    constructor() {
        this.id = 'default0';
        this.subscriptSizing = 'fixed';
        this.label = 'Multi Level Select';
        this.type = ClComponentTypes.multiLevelSelect;
        this.searchBoxPlaceholder = 'Enter Search Query...';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.itemLimit = 3;
        this.style = new ClMultiLevelSelectStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
        this.options = [
            {
                group: 'Group 1',
                children: [
                    { text: 'Option 1', value: 'option1' },
                    { text: 'Option 2', value: 'option2' }
                ]
            },
            {
                group: 'Group 2',
                children: [
                    { text: 'Option 3', value: 'option3' },
                    { text: 'Option 4', value: 'option4' }
                ]
            }
        ];
    }
}

class ClMultiLevelSelectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        // @ViewChild('matTextField')
        // public matTextFieldDivElementRef!: ElementRef;
        // @ViewChild('errorOrHintDivElementRef')
        // public errorOrHintDivElementRef!: ElementRef;
        // private errorOrHintDivElement!: HTMLDivElement;
        // private matTextFieldDivElement!: HTMLDivElement;
        // Required to implement ControlValueAccessor
        this._value = [];
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.selectedValues = [];
        this.selectedOptions = [];
        this.searchQuery = '';
        this.filteredOptions = [];
        this.optionsLength = 0;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(_changes) {
        this.filteredOptions = this.properties.options;
    }
    ngDoCheck() {
        if (this.optionsLength != this.properties.options?.length) {
            this.filteredOptions = this.properties.options;
        }
    }
    ngOnInit() {
        this.properties ??= new ClMultiLevelSelectProperties();
        this.setDefaultSelectedOption();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        this.filteredOptions = this.properties.options;
        this.optionsLength = this.properties.options.length;
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    filter(searchQuery) {
        if (!searchQuery) {
            this.filteredOptions = this.properties.options;
            return;
        }
        this.filteredOptions = this.properties.options.map((group) => ({ ...group, children: group.children.filter((option) => option.text.toLowerCase().includes(searchQuery.toLowerCase())) }));
    }
    onOptionSelected(option) {
        this.selectedOptions = [];
        for (const group of this.properties.options) {
            for (const childOption of group.children) {
                if (option.includes(childOption.value)) {
                    this.selectedOptions.push(childOption);
                }
            }
        }
        this.writeValue(option);
        this.onChange(option);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this.selectedOptions);
        }
    }
    onOpenedChange(event) {
        if (!event) {
            this.searchQuery = '';
            this.filter(this.searchQuery);
        }
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onOptionSelected('');
    }
    setDefaultSelectedOption() {
        if (this.properties.selectedOption) {
            for (const group of this.properties.options) {
                const foundOption = group.children.find(option => option.value === this.properties.selectedOption.value);
                if (foundOption) {
                    this.selectedOptions = foundOption.value;
                    this.writeValue(this.selectedOptions);
                    break;
                }
            }
        }
    }
    writeValue(values) {
        this._value = values;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    remove(value) {
        this.properties.options.forEach((option) => {
            option.children.forEach((child) => {
                if (child.value == value) {
                    child.selected = false;
                }
            });
        });
        //remove the values from selected values
        const index = this.selectedOptions.findIndex((option) => option.value == value);
        this.selectedOptions.splice(index, 1);
        const selectedVal = this.selectedOptions.map((option) => option.value);
        this.onOptionSelected(selectedVal);
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    groupChecked(data) {
        let allSelected = true;
        //find the group from the filteredOptions
        const selectedGroup = this.filteredOptions.find((option) => option.group == data.group);
        if (selectedGroup) {
            //for loop the group options
            for (let i = 0; i < selectedGroup.children.length; i++) {
                const child = selectedGroup.children[i];
                if (!this._value.includes(child.value)) {
                    allSelected = false;
                    break;
                }
            }
        }
        return allSelected;
    }
    onCheckboxChanged(ev, optionGroup) {
        // if group is checked
        // get all the options from the filteredOptions and push them into the this._value
        // if group is unChecked
        // get all the options from the filteredOptions and remove them from the this._value
        const values = JSON.parse(JSON.stringify(this._value));
        const selectedGroup = this.filteredOptions.find((option) => option.group == optionGroup.group);
        selectedGroup.children.forEach((child) => {
            if (ev.checked) {
                // push only if it is not there in values array.
                if (!values.includes(child.value)) {
                    values.push(child.value);
                }
            }
            else {
                //remove if it contains the group option from the values.
                if (values.includes(child.value)) {
                    values.splice(values.indexOf(child.value), 1);
                }
            }
        });
        //update the values
        // this.writeValue(values);
        this.onOptionSelected(values);
    }
    ngOnDestroy() {
        this.sub?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiLevelSelectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMultiLevelSelectComponent, isStandalone: true, selector: "cl-multi-level-select", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex gap-1 items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"flex icon-size-4 cursor-pointer text-neutral-600 place-content-center\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [multiple]=\"true\" [disabled]=\"disabled\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" (openedChange)=\"onOpenedChange($event)\"\n    (valueChange)=\"onOptionSelected($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">{{ selectedOption.text }}</mat-label>\n\n                <mat-icon (click)=\"remove(selectedOption.value)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxPlaceholder!\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n    <!-- search field for auto complete -->\n\n    <!-- options for dropdown -->\n    <div class=\"autocomplete-options-container\">\n      @for (optionGroup of filteredOptions; track optionGroup) {\n        <div>\n          <mat-checkbox color=\"primary\" class=\"multi-level-group-checkbox\" [checked]=\"groupChecked(optionGroup)\"\n            (change)=\"onCheckboxChanged($event, optionGroup)\">\n\n            <mat-label class=\"font-bold text-neutral-700\"> {{optionGroup.group}} </mat-label>\n          </mat-checkbox>\n\n          @for (option of optionGroup.children; track option) {\n            <mat-option class=\"ml-1\" [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\">\n              <div class=\"ml-3 text-md font-normal text-neutral-700\">{{ option.text }}</div>\n            </mat-option>\n          }\n        </div>\n      }\n    </div>\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.hide-option{display:none!important}.mat-mdc-checkbox .mdc-form-field,.mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.autocomplete-options:not(:last-child){border-bottom-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important}.mat-mdc-option{min-height:42px!important;padding-left:.25rem!important;padding-right:.25rem!important}.mat-mdc-option .mat-icon,.mat-mdc-option .mat-pseudo-checkbox-full{margin-right:0!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3$1.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i3$1.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i8.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiLevelSelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-multi-level-select', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatChipsModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex gap-1 items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"flex icon-size-4 cursor-pointer text-neutral-600 place-content-center\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [multiple]=\"true\" [disabled]=\"disabled\" [hideSingleSelectionIndicator]=\"true\"\n    [placeholder]=\"properties.placeholder!\" (openedChange)=\"onOpenedChange($event)\"\n    (valueChange)=\"onOptionSelected($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">{{ selectedOption.text }}</mat-label>\n\n                <mat-icon (click)=\"remove(selectedOption.value)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"fill\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (ngModelChange)=\"filter($event)\"\n        class=\"autocomplete-search-input\" [placeholder]=\"properties.searchBoxPlaceholder!\">\n\n      <mat-icon matPrefix class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\"></mat-icon>\n    </mat-form-field>\n    <!-- search field for auto complete -->\n\n    <!-- options for dropdown -->\n    <div class=\"autocomplete-options-container\">\n      @for (optionGroup of filteredOptions; track optionGroup) {\n        <div>\n          <mat-checkbox color=\"primary\" class=\"multi-level-group-checkbox\" [checked]=\"groupChecked(optionGroup)\"\n            (change)=\"onCheckboxChanged($event, optionGroup)\">\n\n            <mat-label class=\"font-bold text-neutral-700\"> {{optionGroup.group}} </mat-label>\n          </mat-checkbox>\n\n          @for (option of optionGroup.children; track option) {\n            <mat-option class=\"ml-1\" [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\">\n              <div class=\"ml-3 text-md font-normal text-neutral-700\">{{ option.text }}</div>\n            </mat-option>\n          }\n        </div>\n      }\n    </div>\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.hide-option{display:none!important}.mat-mdc-checkbox .mdc-form-field,.mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.autocomplete-options:not(:last-child){border-bottom-width:1px!important;border-style:solid!important;--tw-border-opacity: 1 !important;border-color:rgb(212 212 212 / var(--tw-border-opacity))!important}.mat-mdc-option{min-height:42px!important;padding-left:.25rem!important;padding-right:.25rem!important}.mat-mdc-option .mat-icon,.mat-mdc-option .mat-pseudo-checkbox-full{margin-right:0!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

class ClHyperLinkTextStyleProperties {
}
class ClHyperLinkTextProperties {
    constructor() {
        this.id = 'default0';
        this.type = ClComponentTypes.hyperLinkText;
        this.style = new ClHyperLinkTextStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex flex-row gap-2 items-center';
        this.linkProperties = [
            { text: 'This is a simple' },
            { isLink: true, text: 'Hyperlink', url: 'https://google.com' },
            { text: 'sample' }
        ];
    }
}

class ClHyperLinkTextComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClHyperLinkTextProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClHyperLinkTextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClHyperLinkTextComponent, isStandalone: true, selector: "cl-hyper-link-text", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div class=\"{{ properties.style?.cssClasses }}\">\n  <mat-label>\n    @for (child of properties.linkProperties; track child) {\n      @if (child.isLink) {\n        <a [href]=\"child.url\" class=\"text-primary {{ child.cssClasses }} cursor-pointer\">\n          {{ child.text }}\n        </a>\n      } @else {\n        <span class=\"{{ child.cssClasses }}\">{{ child.text }}</span>\n      }\n    }\n  </mat-label>\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClHyperLinkTextComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-hyper-link-text', imports: [
                        MatFormFieldModule
                    ], template: "<div class=\"{{ properties.style?.cssClasses }}\">\n  <mat-label>\n    @for (child of properties.linkProperties; track child) {\n      @if (child.isLink) {\n        <a [href]=\"child.url\" class=\"text-primary {{ child.cssClasses }} cursor-pointer\">\n          {{ child.text }}\n        </a>\n      } @else {\n        <span class=\"{{ child.cssClasses }}\">{{ child.text }}</span>\n      }\n    }\n  </mat-label>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

var ClFilePreviewType;
(function (ClFilePreviewType) {
    ClFilePreviewType["png"] = "image/png";
    ClFilePreviewType["jpg"] = "image/jpeg";
    ClFilePreviewType["svg"] = "image/svg+xml";
    ClFilePreviewType["pdf"] = "application/pdf";
})(ClFilePreviewType || (ClFilePreviewType = {}));
class ClFilePreviewStyleProperties {
}
class ClFilePreviewProperties {
    constructor() {
        this.id = 'default0';
        this.fileName = '';
        this.base64 = '';
        this.fileType = ClFilePreviewType.png;
        this.type = ClComponentTypes.filePreview;
        this.showExpansionIcon = false;
        this.style = new ClFilePreviewStyleProperties();
        this.style.cssClasses = 'flex-auto w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        // set additional default values here.
    }
}

if (pdfjsLib !== undefined) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = "https://npmcdn.com/pdfjs-dist@2.16.105/build/pdf.worker.js";
}
class ClFilePreviewComponent extends ClBaseComponent {
    // End of pdf variable
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.data = '';
        this.zoomInIconProperties = {
            id: 'zoomIn0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:magnifying-glass-plus',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.zoomInFn.bind(this)
        };
        this.zoomOutIconProperties = {
            id: 'zoomOut0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:magnifying-glass-minus',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.zoomOutFn.bind(this)
        };
        this.resetIconZoomProperties = {
            id: 'zoomOut0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:arrow-path',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.resetZoomFn.bind(this)
        };
        this.expansionIconProperties = {
            id: 'expand0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:arrows-pointing-out',
            style: {
                cssClasses: 'icon-size-9 text-3xl w-10 text-primary-600 border-l-2 border-gray-400 pl-2',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.onExpansionIconClicked.bind(this)
        };
        this.pageNumberIncrementIcon = {
            id: 'pageIncrement0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:chevron-right',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.pageNumberIncrement.bind(this)
        };
        this.pageNumberDecrementIcon = {
            id: 'pageIncrement0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:chevron-left',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.pageNumberDecrement.bind(this)
        };
        this.goToPageInputProperties = {
            id: 'goTo0',
            type: ClComponentTypes.input,
            placeholder: 'Page Number',
            appearance: 'fill',
            inputType: ClInputType.number,
            onValueChange: this.goToPage.bind(this)
        };
        // common variable
        this.fileType = '';
        this.scale = 1;
        // Image zoom variable
        this.blobUrl = null;
        this.imageTransform = `scale(${this.scale})`;
        this.imagePosition = { x: 0, y: 0 };
        this.isDragging = false;
        this.lastMousePosition = { x: 0, y: 0 };
        this.pageNumber = 1;
        this.totalPageSize = 0;
        this.goPageIndex = 1;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClFilePreviewProperties();
        super.ngOnInit();
    }
    ngOnChanges(_changes) {
        if (this.properties.fileType == ClFilePreviewType.jpg || this.properties.fileType == ClFilePreviewType.png || this.properties.fileType == ClFilePreviewType.svg) {
            this.fileType = 'Image';
            if (this.properties.base64) {
                this.convertBase64ToBlobUrl(this.properties.base64);
            }
        }
        if (this.properties.fileType == ClFilePreviewType.pdf) {
            this.fileType = 'Pdf';
            if (this.properties.base64) {
                this.pdfData = this.properties.base64;
                this.loadPdf();
            }
        }
    }
    convertBase64ToBlobUrl(base64) {
        // Convert base64 string to binary
        const byteCharacters = atob(base64);
        const byteArray = new Uint8Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteArray[i] = byteCharacters.charCodeAt(i);
        }
        // Create a Blob object
        const blob = new Blob([byteArray], { type: this.properties.fileType }); // Adjust the MIME type accordingly
        // Generate Blob URL
        this.blobUrl = URL.createObjectURL(blob);
    }
    zoomInFn() {
        if (this.fileType == 'Image') {
            this.zoomIn();
        }
        if (this.fileType == 'Pdf') {
            this.pdfZoomIn();
        }
    }
    zoomOutFn() {
        if (this.fileType == 'Image') {
            this.zoomOut();
        }
        if (this.fileType == 'Pdf') {
            this.pdfZoomOut();
        }
    }
    resetZoomFn() {
        if (this.fileType == 'Image') {
            this.resetZoom();
        }
        if (this.fileType == 'Pdf') {
        }
    }
    // Image Zoom feature control funtion
    // zoomIn() {
    //   this.scale += 0.1;
    //   this.updateImageTransform();
    // }
    // zoomOut() {
    //   if (this.scale > 0.2) {
    //     this.scale -= 0.1;
    //     this.updateImageTransform();
    //   }
    // }
    // private updateImageTransform() {
    //   this.imageTransform = `scale(${this.scale})`;
    // }
    zoomIn() {
        this.scale += 0.1;
        this.updateImageTransform();
    }
    zoomOut() {
        if (this.scale > 0.2) {
            this.scale -= 0.1;
            this.updateImageTransform();
        }
    }
    updateImageTransform() {
        this.imageTransform = `scale(${this.scale}) translate(${this.imagePosition.x}px, ${this.imagePosition.y}px)`;
    }
    onMouseDown(event) {
        event.preventDefault();
        this.isDragging = true;
        this.lastMousePosition = { x: event.clientX, y: event.clientY };
    }
    onMouseMove(event) {
        if (!this.isDragging)
            return;
        const deltaX = event.clientX - this.lastMousePosition.x;
        const deltaY = event.clientY - this.lastMousePosition.y;
        this.imagePosition.x += deltaX;
        this.imagePosition.y += deltaY;
        this.updateImageTransform();
        this.lastMousePosition = { x: event.clientX, y: event.clientY };
    }
    onMouseUp() {
        this.isDragging = false;
    }
    onMouseOut() {
        this.isDragging = false;
    }
    resetZoom() {
        this.scale = 1;
        this.imageTransform = `scale(${this.scale})`;
        this.imagePosition = { x: 0, y: 0 };
        this.isDragging = false;
        this.lastMousePosition = { x: 0, y: 0 };
    }
    // End of Image Zoom feature control function
    // Pdf file load and zoom feature function
    loadPdf() {
        const loadingTask = pdfjsLib.getDocument({ data: atob(this.pdfData) });
        loadingTask.promise.then((pdf) => {
            this.totalPageSize = pdf.numPages;
            pdf.getPage(this.pageNumber).then((page) => {
                const scale = this.scale;
                const viewport = page.getViewport({ scale: scale });
                // Prepare canvas using PDF page dimensions
                const canvas = document.getElementById('pdfCanvas');
                const context = canvas.getContext('2d');
                // Check if context is not null
                if (context) {
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    // Render PDF page into canvas context
                    const renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    const renderTask = page.render(renderContext);
                    renderTask.promise.then(() => {
                        console.log('Page rendered');
                    });
                }
                else {
                    console.error('Could not get 2D context for canvas');
                }
            });
        }, (reason) => {
            console.error('Error loading PDF', reason);
        });
    }
    pageNumberIncrement() {
        if ((this.pageNumber + 1) < this.totalPageSize) {
            this.pageNumber += 1;
            this.goPageIndex = this.pageNumber;
            this.loadPdf();
        }
    }
    pageNumberDecrement() {
        if ((this.pageNumber - 1) > 0) {
            this.pageNumber -= 1;
            this.goPageIndex = this.pageNumber;
            this.loadPdf();
        }
    }
    pdfZoomIn() {
        this.scale += 0.1;
        this.loadPdf();
    }
    pdfZoomOut() {
        this.scale -= 0.1;
        this.loadPdf();
    }
    goToPage(val) {
        if (Number(val) >= 1) {
            this.pageNumber = Number(val);
            this.loadPdf();
        }
    }
    onExpansionIconClicked() {
        if (this.properties.onExpansionIconClicked != undefined) {
            this.properties.onExpansionIconClicked();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFilePreviewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClFilePreviewComponent, isStandalone: true, selector: "cl-file-preview", inputs: { properties: "properties", data: "data" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<!-- <mat-card class=\"{{properties.style?.cssClasses}} flex w-full h-full\">\n  <mat-card-header class=\"flex flex-row justify-between bg-white-200 p-4\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex flex-row gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow overflow-scroll relative\">\n      <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{'transform': imageTransform}\">\n  </mat-card-content>\n</mat-card> -->\n\n<mat-card class=\"flex w-full h-full {{properties.style?.cssClasses}}\">\n  <mat-card-header class=\"flex justify-between bg-white p-4 border-b-2\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"resetIconZoomProperties\"></cl-icon>\n      @if(properties.showExpansionIcon){\n        <cl-icon [properties]=\"expansionIconProperties\"></cl-icon>\n      }\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow relative overflow-hidden bg-primary-50\">\n    @if(fileType == 'Image'){\n      <div class=\"relative flex justify-center items-center w-full h-full max-h-lvh cursor-grab\" (mousedown)=\"onMouseDown($event)\"\n        (mousemove)=\"onMouseMove($event)\" (mouseup)=\"onMouseUp()\" (mouseout)=\"onMouseOut()\">\n        <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{ 'transform': imageTransform }\"\n          class=\"transition-transform duration-300 ease-in-out\" />\n      </div>\n    }\n    @if(fileType == 'Pdf'){\n      <!-- <canvas #pdfCanvas></canvas> -->\n      <div class=\"w-full h-full overflow-auto flex justify-center items-center\">\n        <canvas id=\"pdfCanvas\"></canvas>\n      </div>\n    }\n  </mat-card-content>\n  @if(fileType == 'Pdf'){\n    <mat-card-actions class=\"flex flex-row justify-between\">\n      <div class=\"flex flex-start text-xl font-bold\">\n        Total Page: {{totalPageSize}}\n      </div>\n      <div class=\"flex flex-row justify-center gap-8\">\n        <cl-icon [properties]=\"pageNumberDecrementIcon\"></cl-icon>\n        <cl-icon [properties]=\"pageNumberIncrementIcon\"></cl-icon>\n      </div>\n      <div class=\"flex flex-end\">\n        <cl-input [properties]=\"goToPageInputProperties\" [(ngModel)]=\"goPageIndex\"></cl-input>\n      </div>\n    </mat-card-actions>\n  }\n</mat-card>\n", styles: [""], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2$4.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2$4.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }, { kind: "directive", type: i2$4.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i2$4.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i2$4.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClInputComponent, selector: "cl-input", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFilePreviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-file-preview', standalone: true, imports: [
                        NgStyle,
                        CommonModule,
                        FormsModule,
                        MatCardModule,
                        ClIconComponent,
                        ClInputComponent,
                    ], template: "<!-- <mat-card class=\"{{properties.style?.cssClasses}} flex w-full h-full\">\n  <mat-card-header class=\"flex flex-row justify-between bg-white-200 p-4\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex flex-row gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow overflow-scroll relative\">\n      <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{'transform': imageTransform}\">\n  </mat-card-content>\n</mat-card> -->\n\n<mat-card class=\"flex w-full h-full {{properties.style?.cssClasses}}\">\n  <mat-card-header class=\"flex justify-between bg-white p-4 border-b-2\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"resetIconZoomProperties\"></cl-icon>\n      @if(properties.showExpansionIcon){\n        <cl-icon [properties]=\"expansionIconProperties\"></cl-icon>\n      }\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow relative overflow-hidden bg-primary-50\">\n    @if(fileType == 'Image'){\n      <div class=\"relative flex justify-center items-center w-full h-full max-h-lvh cursor-grab\" (mousedown)=\"onMouseDown($event)\"\n        (mousemove)=\"onMouseMove($event)\" (mouseup)=\"onMouseUp()\" (mouseout)=\"onMouseOut()\">\n        <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{ 'transform': imageTransform }\"\n          class=\"transition-transform duration-300 ease-in-out\" />\n      </div>\n    }\n    @if(fileType == 'Pdf'){\n      <!-- <canvas #pdfCanvas></canvas> -->\n      <div class=\"w-full h-full overflow-auto flex justify-center items-center\">\n        <canvas id=\"pdfCanvas\"></canvas>\n      </div>\n    }\n  </mat-card-content>\n  @if(fileType == 'Pdf'){\n    <mat-card-actions class=\"flex flex-row justify-between\">\n      <div class=\"flex flex-start text-xl font-bold\">\n        Total Page: {{totalPageSize}}\n      </div>\n      <div class=\"flex flex-row justify-center gap-8\">\n        <cl-icon [properties]=\"pageNumberDecrementIcon\"></cl-icon>\n        <cl-icon [properties]=\"pageNumberIncrementIcon\"></cl-icon>\n      </div>\n      <div class=\"flex flex-end\">\n        <cl-input [properties]=\"goToPageInputProperties\" [(ngModel)]=\"goPageIndex\"></cl-input>\n      </div>\n    </mat-card-actions>\n  }\n</mat-card>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], data: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClNestedSelectStyleProperties {
}
class ClNestedSelectProperties {
    constructor() {
        this.id = 'default0';
        this.appearance = 'fill';
        this.floatLabel = 'auto';
        this.manualEntry = false;
        this.subscriptSizing = 'fixed';
        this.label = 'Nested Select';
        this.type = ClComponentTypes.nestedAutoComplete;
        this.style = new ClNestedSelectStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
        this.disabled = signal(false);
        this.showInfoMsg = signal(false);
        this.options = [
            {
                text: 'Option1',
                value: "option1",
                list: [
                    { text: 'Option2', value: "option2" },
                    { text: 'Option3', value: "option3" }
                ]
            },
            {
                text: 'Option4',
                value: "option4",
                list: [
                    { text: 'Option5', value: "option5" },
                    { text: 'Option6', value: "option6" }
                ]
            },
            {
                text: 'Option7',
                value: "option7",
                list: [
                    { text: 'Option8', value: "option8" },
                    {
                        text: 'Option9',
                        value: "option9",
                        list: [
                            { text: 'Option10', value: "option10" },
                            { text: 'Option11', value: "option11" }
                        ]
                    }
                ]
            }
        ];
    }
}

class ClNestedItemComponent {
    constructor() {
        this.optionSelected = new EventEmitter();
    }
    onOptionSelected(value) {
        this.optionSelected.emit(value);
    }
    ngOnChanges() {
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedItemComponent, isStandalone: true, selector: "cl-nested-item", inputs: { items: "items" }, outputs: { optionSelected: "optionSelected" }, viewQueries: [{ propertyName: "childMenu", first: true, predicate: ["childMenu"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "\n<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\" class=\"max-h-56\">\n  @for (child of items; track child) {\n  <span>\n    <!-- Handle branch node menu items -->\n    @if ((child.list && child.list.length > 0)) {\n    <span>\n      <button mat-menu-item [matMenuTriggerFor]=\"menu.childMenu\" (dblclick)=\"onOptionSelected(child)\">\n        <span>{{child.text}}</span>\n      </button>\n\n      <cl-nested-item #menu [items]=\"child.list\" (optionSelected)=\"onOptionSelected($event)\">\n      </cl-nested-item>\n    </span>\n    }\n\n    <!-- Handle leaf node menu items -->\n\n    @if ((!child.list || child.list.length === 0)) {\n    <span>\n      <button mat-menu-item (click)=\"onOptionSelected(child)\">\n        <span>{{ child.text }}</span>\n      </button>\n    </span>\n    }\n  </span>\n  }\n</mat-menu>\n", dependencies: [{ kind: "component", type: ClNestedItemComponent, selector: "cl-nested-item", inputs: ["items"], outputs: ["optionSelected"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1$1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i1$1.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i1$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: CommonModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedItemComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-item', imports: [MatMenuModule, CommonModule], template: "\n<mat-menu #childMenu=\"matMenu\" [overlapTrigger]=\"false\" class=\"max-h-56\">\n  @for (child of items; track child) {\n  <span>\n    <!-- Handle branch node menu items -->\n    @if ((child.list && child.list.length > 0)) {\n    <span>\n      <button mat-menu-item [matMenuTriggerFor]=\"menu.childMenu\" (dblclick)=\"onOptionSelected(child)\">\n        <span>{{child.text}}</span>\n      </button>\n\n      <cl-nested-item #menu [items]=\"child.list\" (optionSelected)=\"onOptionSelected($event)\">\n      </cl-nested-item>\n    </span>\n    }\n\n    <!-- Handle leaf node menu items -->\n\n    @if ((!child.list || child.list.length === 0)) {\n    <span>\n      <button mat-menu-item (click)=\"onOptionSelected(child)\">\n        <span>{{ child.text }}</span>\n      </button>\n    </span>\n    }\n  </span>\n  }\n</mat-menu>\n" }]
        }], propDecorators: { childMenu: [{
                type: ViewChild,
                args: ['childMenu']
            }], items: [{
                type: Input
            }], optionSelected: [{
                type: Output
            }] } });

class ClNestedSelectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this._value = '';
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.filterString = signal('');
        this.filteredListSignal = computed(() => this.filterNestedListSkipParents(this.properties.options, this.filterString())
        // this.filterNestedList(this.properties.options!, this.filterString())
        );
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        ;
    }
    ngOnChanges(_changes) {
        this.setDefaultValue();
    }
    ngOnInit() {
        this.properties ??= new ClNestedSelectProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            const val = this.findValue(this.properties.options, value);
            if (val) {
                this.selectedOption = val;
                if (this._value !== val.value) {
                    this.writeValue(val.value);
                }
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
    }
    setDefaultValue() {
        if (this.properties.selectedValue) {
            this.setDefaultSelectedValues();
        }
    }
    onOptionSelected(event) {
        this.selectedOption = event;
        this.onValueChange();
    }
    setDefaultSelectedValues() {
        if (!this.properties.selectedValue) {
            return;
        }
        if (this.properties.options) {
            const val = this.findValue(this.properties.options, this.properties.selectedValue);
            if (val) {
                this.selectedOption = val;
                this.onValueChange();
            }
        }
    }
    onInputChange(event) {
        const value = event.target.value;
        if (value === this.filterString()) {
            this.filterString.set(' ');
            this.filterString.set(value);
        }
        else {
            this.filterString.set(value);
        }
    }
    // filterNestedList(data: ClNestedSelectOption[], searchText: string): ClNestedSelectOption[] {
    //   return data.reduce((acc: ClNestedSelectOption[], item: ClNestedSelectOption) => {
    //     // If the current item's text matches the searchText, add it to the result
    //     if (item.text?.toLowerCase().includes(searchText.toLowerCase())) {
    //       acc.push(item);
    //     }
    //     // If the item has a nested 'list', filter it as well recursively
    //     if (item.list && item.list.length > 0) {
    //       const filteredList = this.filterNestedList(item.list, searchText);
    //       if (filteredList.length > 0) {
    //         // Add the item to the result if its nested list has matches
    //         acc.push({ text: item.text, value: item.value, list: filteredList });
    //       }
    //     }
    //     return acc;
    //   }, []);
    // }
    filterNestedListSkipParents(data, searchText) {
        let result = [];
        if (!searchText && this.properties.options) {
            return this.properties.options;
        }
        // Iterate through the array of items
        for (const item of data) {
            // If the item's text matches the search text, add it to the result
            if (item.text?.toLowerCase().includes(searchText.toLowerCase())) {
                result.push(item);
            }
            // If the item has a 'list', we need to check the nested items (children)
            if (item.list && item.list.length > 0) {
                // Recursively filter the nested list
                const nestedMatches = this.filterNestedListSkipParents(item.list, searchText);
                // If we find matching items in the nested list, include them in the result
                if (nestedMatches.length > 0) {
                    result = result.concat(nestedMatches);
                }
            }
        }
        return result;
    }
    findValue(arr, targetValue) {
        for (const item of arr) {
            // Check the current level
            if (item.value === targetValue) {
                return item;
            }
            // Recursively check the 'list' array in case of nested objects
            if (item.list && item.list.length > 0) {
                const result = this.findValue(item.list, targetValue);
                if (result) {
                    return result;
                }
            }
        }
        return null; // Return null if the value is not found
    }
    onPrefixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked();
        }
    }
    onSuffixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked();
        }
    }
    onValueChange() {
        if (this.selectedOption) {
            this.writeValue(this.selectedOption.value);
            this.onChange(this.selectedOption.value);
            if (this.properties.onValueChange) {
                this.properties.onValueChange(this.selectedOption.value);
            }
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        if (this.selectedOption) {
            return cloneDeep(this.selectedOption.text);
        }
        else if (this.properties.options && this._value) {
            const val = this.findValue(this.properties.options, this._value);
            return val ? val.text : '';
        }
        return '';
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.valueChangesSub?.unsubscribe();
        this.sub?.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedSelectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedSelectComponent, isStandalone: true, selector: "cl-nested-select", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"h-fit {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input #nestedSelectInput matInput [placeholder]=\"properties.placeholder!\"\n    [matMenuTriggerFor]=\"menu.childMenu\" [value]=\"value ? value : ''\" [disabled]=\"disabled\"\n    (input)=\"onInputChange($event)\" (blur)=\"onTouched($any($event.target).value)\"\n    (focus)=\"onInputChange($event)\"\n    (keyup)=\"writeValue($any($event.target).value)\"/>\n\n  @if (properties.suffixIcon) {\n  <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked($event)\" [svgIcon]=\"properties.suffixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n  </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n  <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked($event)\" [svgIcon]=\"properties.prefixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n  </mat-icon>\n  }\n</mat-form-field>\n\n<cl-nested-item #menu [items]=\"filteredListSignal()\" (optionSelected)=\"onOptionSelected($event)\">\n</cl-nested-item>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i5$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "directive", type: i1$1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: ClNestedItemComponent, selector: "cl-nested-item", inputs: ["items"], outputs: ["optionSelected"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedSelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-select', imports: [
                        FormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatFormFieldModule,
                        CommonModule,
                        MatMenuModule,
                        ReactiveFormsModule,
                        ClNestedItemComponent,
                        MatIconModule,
                        MatInputModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"h-fit {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input #nestedSelectInput matInput [placeholder]=\"properties.placeholder!\"\n    [matMenuTriggerFor]=\"menu.childMenu\" [value]=\"value ? value : ''\" [disabled]=\"disabled\"\n    (input)=\"onInputChange($event)\" (blur)=\"onTouched($any($event.target).value)\"\n    (focus)=\"onInputChange($event)\"\n    (keyup)=\"writeValue($any($event.target).value)\"/>\n\n  @if (properties.suffixIcon) {\n  <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked($event)\" [svgIcon]=\"properties.suffixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n  </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n  <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked($event)\" [svgIcon]=\"properties.prefixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n  </mat-icon>\n  }\n</mat-form-field>\n\n<cl-nested-item #menu [items]=\"filteredListSignal()\" (optionSelected)=\"onOptionSelected($event)\">\n</cl-nested-item>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ClAutoCompleteProperties, ClAutoCompleteStyleProperties, ClAutocompleteComponent, ClButtonBehavior, ClButtonComponent, ClButtonProperties, ClButtonStyleProperties, ClCheckboxComponent, ClCheckboxProperties, ClCheckboxStyleProperties, ClChipComponent, ClChipInputStyleProperties, ClChipListComponent, ClChipListProperties, ClChipListStyleProperties, ClChipProperties, ClChipStyleProperties, ClChipsInputComponent, ClChipsInputProperties, ClCodeViewComponent, ClCodeViewProperties, ClCodeViewStyleProperties, ClComponentBehaviors, ClContactInputComponent, ClContactInputProperties, ClContactInputStyleProperties, ClDisplay, ClFilePreviewComponent, ClFilePreviewProperties, ClFilePreviewStyleProperties, ClFilePreviewType, ClHyperLinkTextComponent, ClHyperLinkTextProperties, ClHyperLinkTextStyleProperties, ClIconComponent, ClIconProperties, ClIconStyleProperties, ClIconsListComponent, ClIconsListProperties, ClIconsListStyleProperties, ClImageComponent, ClImageProperties, ClImageStyleProperties, ClInputBehavior, ClInputComponent, ClInputProperties, ClInputStyleProperties, ClInputType, ClLabelComponent, ClLabelProperties, ClLabelStyleProperties, ClMenuComponent, ClMenuProperties, ClMenuStyleProperties, ClMultiAutoCompleteProperties, ClMultiAutoCompleteStyleProperties, ClMultiAutocompleteComponent, ClMultiLevelSelectComponent, ClMultiLevelSelectProperties, ClMultiLevelSelectStyleProperties, ClMultiSelectProperties, ClMultiSelectStyleProperties, ClMultiselectComponent, ClNestedAutoCompleteProperties, ClNestedAutoCompleteStyleProperties, ClNestedAutocompleteComponent, ClNestedItemComponent, ClNestedSelectComponent, ClNestedSelectProperties, ClNestedSelectStyleProperties, ClPatterns, ClProgressBarComponent, ClProgressBarMode, ClProgressBarProperties, ClProgressBarStyleProperties, ClProgressSize, ClRadioComponent, ClRadioProperties, ClRadioStyleProperties, ClSelectComponent, ClSelectProperties, ClSelectStyleProperties, ClSelectWithGroupComponent, ClSelectWithGroupProperties, ClSelectWithGroupStyleProperties, ClSpinnerComponent, ClSpinnerProperties, ClSpinnerStyleProperties, ClSwitchComponent, ClSwitchProperties, ClSwitchStyleProperties, ClTextBlockComponent, ClTextBlockProperties, ClTextBlockStyleProperties, ClTextareaComponent, ClTextareaProperties, ClTextareaStyleProperties, ClTimePickerComponent, ClTimePickerProperties, ClTimePickerStyleProperties, ClTimerComponent, ClTimerProperties, ClTimerStyleProperties, ClToastMessageType, ClToastProperties, ClToastService, ClToastStyleProperties, ClToggleButtonComponent, ClToggleButtonProperties, ClToggleButtonStyleProperties, ClUploadService, ClUploadTileComponent, ClUploadTileProperties, ClUploadTileStyleProperties, IClButtonType, IClFileType };
//# sourceMappingURL=clay-ui-components-basic.mjs.map
