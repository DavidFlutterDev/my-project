import * as i0 from '@angular/core';
import { inject, signal, computed, Input, Injectable, ViewEncapsulation, Component } from '@angular/core';
import * as i3 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { clAnimations } from '@clay/ui-commons/ancillary';
import { staticSuite, test, enforce, omitWhen } from 'vest';
import * as i4 from '@clay/ui-components/form-validations';
import { FormDirective, FormModelDirective, vestForms } from '@clay/ui-components/form-validations';
import { ClComponentPropertyFactory } from '@clay/ui-components/property-factory';
import { IClButtonType, ClButtonBehavior, ClInputComponent, ClButtonComponent } from '@clay/ui-components/basic';
import { ClEmailComponent } from '@clay/ui-components/derived';
import { ClComponentTypes } from '@clay/ui-components/shared';
import * as i1 from '@clay/app-shell/structural';
import { ClAuthSignInComponent } from '@clay/app-shell/structural';
import * as i2 from '@angular/router';
import { ClCardComponent } from '@clay/ui-components/containers';

const createSignUpFormValidationSuite = (userList) => {
    return staticSuite((model, field) => {
        test('firstName', 'First name is required.', () => {
            enforce(model.firstName).isNotBlank();
        });
        test('lastName', 'Last name is required.', () => {
            enforce(model.lastName).isNotBlank();
        });
        test('email', 'Email is required.', () => {
            enforce(model.email).isNotBlank();
        });
        omitWhen(!model.email, () => {
            test('email', 'Email already registered.', () => {
                const existingEmailIds = userList.map(user => user.email?.toLowerCase());
                return !existingEmailIds.includes(model.email?.toLowerCase());
            });
        });
        test('userName', 'User name is required.', () => {
            enforce(model.userName).isNotBlank();
        });
        omitWhen(!model.userName, () => {
            test('userName', 'User name already exists.', () => {
                const existingUserIds = userList.map(user => user.username.toLowerCase());
                return !existingUserIds.includes(model.userName?.toLowerCase());
            });
        });
        // test('password', 'Password is required.', () => {
        //   enforce(model.password).isNotBlank();
        // });
        // omitWhen(!model.password, () => {
        //   test('password', 'Password is invalid.', () => {
        //     const passwordFormatRegEx: RegExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
        //     return passwordFormatRegEx.test(model.password!);
        //   });
        //   test('confirmPassword', 'Confirm password is required.', () => {
        //     enforce(model.confirmPassword).isNotBlank();
        //   }
        //   );
        // });
        // omitWhen(!model.password || !model.confirmPassword, () => {
        //   test('confirmPassword', 'Passwords do not match.', () => {
        //     enforce(model.confirmPassword).equals(model.password);
        //   });
        // });
        // test('termsAndConditions', 'Please select terms and conditions.', () => {
        //   enforce(model.termsAndConditions).isTruthy();
        // });
    });
};

class ClAuthSignUpComponent {
    constructor(_authService, _router) {
        this._authService = _authService;
        this._router = _router;
        this._propertyFactory = inject(ClComponentPropertyFactory);
        this.userNameInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.input);
        this.firstNameInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.input);
        this.lastNameInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.input);
        this.emailInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.email);
        // public readonly passwordInputProperties: ClInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.input);
        // public readonly confirmPasswordInputProperties: ClInputProperties = this._propertyFactory.generateProperty(ClComponentTypes.input);
        // public readonly termAndConditionsCheckBoxProperties: ClCheckboxProperties = this._propertyFactory.generateProperty(ClComponentTypes.checkbox);
        this.submitButtonProperties = this._propertyFactory.generateProperty(ClComponentTypes.button);
        this.alert = { type: 'success', message: '' };
        this.showAlert = false;
        this.showLoading = false;
        this.formValue = signal({});
        this.formValid = signal(false);
        this.loading = signal(false);
        this.errors = signal({});
        this.viewModel = computed(() => {
            return {
                formValue: this.formValue(),
                errors: this.errors(),
                formValid: this.formValid(),
                loading: this.loading(),
            };
        });
        this.formDisabled = computed(() => {
            return !this.formValid();
        });
    }
    ngOnChanges(changes) {
        this.signUpValidationSuite = createSignUpFormValidationSuite(this.userList);
    }
    ngOnInit() {
        this.setFormFieldProperties();
    }
    setFormValue(v) {
        this.formValue.set(v);
    }
    get vm() {
        return this.viewModel();
    }
    setFormFieldProperties() {
        this.userNameInputProperties.placeholder = "User Name";
        this.userNameInputProperties.label = "User Name";
        this.userNameInputProperties.appearance = "fill";
        this.userNameInputProperties.floatLabel = 'always';
        this.userNameInputProperties.style.cssClasses = 'cl-mat-dense-1';
        this.firstNameInputProperties.placeholder = "First Name";
        this.firstNameInputProperties.label = "First Name";
        this.firstNameInputProperties.appearance = "fill";
        this.firstNameInputProperties.floatLabel = 'always';
        this.firstNameInputProperties.style.cssClasses = 'cl-mat-dense-1';
        this.lastNameInputProperties.placeholder = "Last name";
        this.lastNameInputProperties.label = "Last Name";
        this.lastNameInputProperties.appearance = "fill";
        this.lastNameInputProperties.floatLabel = 'always';
        this.lastNameInputProperties.style.cssClasses = 'cl-mat-dense-1';
        this.emailInputProperties.placeholder = "Enter Email";
        this.emailInputProperties.label = "Email";
        this.emailInputProperties.appearance = "fill";
        this.emailInputProperties.floatLabel = 'always';
        this.emailInputProperties.style.cssClasses = 'cl-mat-dense-1';
        // this.passwordInputProperties.placeholder = "Enter Password";
        // this.passwordInputProperties.label = "Password";
        // this.passwordInputProperties.inputType = ClInputType.password;
        // this.passwordInputProperties.appearance = "fill";
        // this.passwordInputProperties.floatLabel = 'always';
        // this.passwordInputProperties.style!.cssClasses = 'cl-mat-dense-1';
        // this.passwordInputProperties.infoMsg = `
        // <p><strong>Password must match following cases.</strong></p><ul><li>Must be 8 minimum characters</li><li>Must be 16 maximum characters</li><li>Must contain one Upper case character.</li><li>Must contain one Lower case character.</li><li>Must container one special character.</li></ul>`;
        // this.passwordInputProperties.showInfoMsg = true;
        // this.passwordInputProperties.suffixIcon = 'heroicons_solid:eye';
        // this.passwordInputProperties.onSuffixIconClicked = this.togglePasswordInputType.bind(this);
        // this.confirmPasswordInputProperties.placeholder = "Enter Password again";
        // this.confirmPasswordInputProperties.label = "Confirm Password";
        // this.confirmPasswordInputProperties.inputType = ClInputType.password;;
        // this.confirmPasswordInputProperties.appearance = "fill";
        // this.confirmPasswordInputProperties.floatLabel = 'always';
        // this.confirmPasswordInputProperties.style!.cssClasses = 'cl-mat-dense-1';
        // this.termAndConditionsCheckBoxProperties.label = 'Terms and conditions.'
        this.submitButtonProperties.label = 'Sign up';
        this.submitButtonProperties.buttonType = IClButtonType.submit;
        this.submitButtonProperties.style.cssClasses += ' rounded-lg w-full';
        this.submitButtonProperties.buttonBehavior = ClButtonBehavior.flat;
        this.submitButtonProperties.disabled = this.formDisabled;
        this.submitButtonProperties.style.labelCssClasses = 'text-base text-white font-semibold';
        this.submitButtonProperties.onSubmit = this.signUp.bind(this);
    }
    // togglePasswordInputType() {
    //   if(this.passwordInputProperties.suffixIcon === 'heroicons_solid:eye') {
    //     this.passwordInputProperties.suffixIcon = 'heroicons_solid:eye-slash';
    //     this.passwordInputProperties.inputType = ClInputType.text;
    //   } else {
    //     this.passwordInputProperties.suffixIcon = 'heroicons_solid:eye';
    //     this.passwordInputProperties.inputType = ClInputType.password;
    //   }
    // }
    /**
     * Sign in
     */
    signUp() {
        const reqBody = {
            "username": this.formValue().userName,
            "email": this.formValue().email,
            "firstName": this.formValue().firstName,
            "lastName": this.formValue().lastName,
            // "password": null,
        };
        // Sign up
        this._authService.signUp(reqBody)
            .subscribe({
            complete: () => {
                // redirect to sign in page
                this._router.navigateByUrl('/sign-in');
            },
            error: (_error) => {
                // Set the alert
                this.alert = { type: 'error', message: 'Signup failed.' };
                // Show the alert
                this.showAlert = true;
            }
        });
    }
    ngOnDestroy() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthSignUpComponent, deps: [{ token: i1.ClAuthService }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClAuthSignUpComponent, isStandalone: true, selector: "auth-sign-up", inputs: { userList: "userList" }, usesOnChanges: true, ngImport: i0, template: "<!-- title -->\n<!-- <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign Up</div>\n<div class=\"flex items-baseline mt-0.5 font-medium\">\n  <div>Already have an account?</div>\n  <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign In\n  </div>\n</div> -->\n\n\n<div class=\"flex w-full py-8 rounded-xl\">\n  <form class=\"flex w-full\" clValidationForm [formValue]=\"formValue()\" [validateRootForm]=\"true\"\n    [suite]=\"signUpValidationSuite\" (validChange)=\"formValid.set($event)\" (errorsChange)=\"errors.set($event)\"\n    (formValueChange)=\"setFormValue($event)\">\n\n    <div class=\"flex w-full flex-col gap-4 gt-xs:flex-row gt-xs:items-start\">\n      <cl-input [properties]=\"firstNameInputProperties\" [ngModel]=\"vm.formValue.firstName\" name=\"firstName\">\n      </cl-input>\n\n      <cl-input class=\"w-full\" [properties]=\"lastNameInputProperties\" [ngModel]=\"vm.formValue.lastName\" name=\"lastName\">\n      </cl-input>\n\n      <cl-email class=\"w-full\" [properties]=\"emailInputProperties\" [ngModel]=\"vm.formValue.email\" name=\"email\">\n      </cl-email>\n\n      <cl-input class=\"w-full\" [properties]=\"userNameInputProperties\" [ngModel]=\"vm.formValue.userName\" name=\"userName\">\n      </cl-input>\n\n      <!--  <cl-input class=\"w-full\" [properties]=\"passwordInputProperties\" [ngModel]=\"vm.formValue.password\"\n            name=\"password\">\n          </cl-input>\n\n          <cl-input class=\"w-full\" [properties]=\"confirmPasswordInputProperties\"\n            [ngModel]=\"vm.formValue.confirmPassword\" name=\"confirmPassword\">\n          </cl-input>\n\n          <cl-checkbox [properties]=\"termAndConditionsCheckBoxProperties\" [ngModel]=\"vm.formValue.termsAndConditions\"\n            name=\"termsAndConditions\">\n          </cl-checkbox> -->\n\n      <cl-button [properties]=\"submitButtonProperties\"></cl-button>\n    </div>\n  </form>\n</div>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: i3.NgForm, selector: "form:not([ngNoForm]):not([formGroup]),ng-form,[ngForm]", inputs: ["ngFormOptions"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: FormDirective, selector: "form[clValidationForm]", inputs: ["formValue", "suite", "formShape", "validationConfig"], outputs: ["formValueChange", "errorsChange", "dirtyChange", "validChange"] }, { kind: "directive", type: FormModelDirective, selector: "[ngModel]", inputs: ["validationOptions", "dynamicControlOptions"] }, { kind: "directive", type: i4.ValidateRootFormDirective, selector: "form[validateRootForm][formValue][suite]", inputs: ["validationOptions", "formValue", "suite", "validateRootForm"] }, { kind: "component", type: ClInputComponent, selector: "cl-input", inputs: ["properties"] }, { kind: "component", type: ClEmailComponent, selector: "cl-email", inputs: ["properties"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }], animations: clAnimations, encapsulation: i0.ViewEncapsulation.None }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthSignUpComponent, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthSignUpComponent, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }, {
            type: Component,
            args: [{ standalone: true, selector: 'auth-sign-up', animations: clAnimations, encapsulation: ViewEncapsulation.None, imports: [
                        FormsModule,
                        FormDirective,
                        FormModelDirective,
                        vestForms,
                        ClInputComponent,
                        ClEmailComponent,
                        ClButtonComponent,
                    ], template: "<!-- title -->\n<!-- <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign Up</div>\n<div class=\"flex items-baseline mt-0.5 font-medium\">\n  <div>Already have an account?</div>\n  <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign In\n  </div>\n</div> -->\n\n\n<div class=\"flex w-full py-8 rounded-xl\">\n  <form class=\"flex w-full\" clValidationForm [formValue]=\"formValue()\" [validateRootForm]=\"true\"\n    [suite]=\"signUpValidationSuite\" (validChange)=\"formValid.set($event)\" (errorsChange)=\"errors.set($event)\"\n    (formValueChange)=\"setFormValue($event)\">\n\n    <div class=\"flex w-full flex-col gap-4 gt-xs:flex-row gt-xs:items-start\">\n      <cl-input [properties]=\"firstNameInputProperties\" [ngModel]=\"vm.formValue.firstName\" name=\"firstName\">\n      </cl-input>\n\n      <cl-input class=\"w-full\" [properties]=\"lastNameInputProperties\" [ngModel]=\"vm.formValue.lastName\" name=\"lastName\">\n      </cl-input>\n\n      <cl-email class=\"w-full\" [properties]=\"emailInputProperties\" [ngModel]=\"vm.formValue.email\" name=\"email\">\n      </cl-email>\n\n      <cl-input class=\"w-full\" [properties]=\"userNameInputProperties\" [ngModel]=\"vm.formValue.userName\" name=\"userName\">\n      </cl-input>\n\n      <!--  <cl-input class=\"w-full\" [properties]=\"passwordInputProperties\" [ngModel]=\"vm.formValue.password\"\n            name=\"password\">\n          </cl-input>\n\n          <cl-input class=\"w-full\" [properties]=\"confirmPasswordInputProperties\"\n            [ngModel]=\"vm.formValue.confirmPassword\" name=\"confirmPassword\">\n          </cl-input>\n\n          <cl-checkbox [properties]=\"termAndConditionsCheckBoxProperties\" [ngModel]=\"vm.formValue.termsAndConditions\"\n            name=\"termsAndConditions\">\n          </cl-checkbox> -->\n\n      <cl-button [properties]=\"submitButtonProperties\"></cl-button>\n    </div>\n  </form>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.ClAuthService }, { type: i2.Router }], propDecorators: { userList: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClAuthComponent {
    /**
     * Constructor
     */
    constructor() {
        this.showSigInForm = true;
        this.cardFace = 'front';
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------
    /**
     * On init
     */
    ngOnInit() { }
    toggleCard() {
        this.showSigInForm = !this.showSigInForm;
        if (this.cardFace === 'front') {
            this.cardFace = 'back';
        }
        else {
            this.cardFace = 'front';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClAuthComponent, isStandalone: true, selector: "cl-auth", inputs: { userList: "userList" }, ngImport: i0, template: "<div\n  class=\"flex flex-col sm:flex-row items-center md:items-start sm:justify-center md:justify-start flex-auto min-w-0 h-screen\">\n  <div\n    class=\"relative hidden md:flex flex-auto items-center justify-center w-1/2 h-full p-16 lg:px-28 overflow-hidden bg-gray-800 dark:border-r\">\n    <!-- Background - @formatter:off -->\n    <!-- Rings -->\n    <svg class=\"absolute inset-0 pointer-events-none\" viewBox=\"0 0 960 540\" width=\"100%\" height=\"100%\"\n      preserveAspectRatio=\"xMidYMax slice\" xmlns=\"http://www.w3.org/2000/svg\">\n      <g class=\"text-gray-700 opacity-25\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"100\">\n        <circle r=\"234\" cx=\"196\" cy=\"23\"></circle>\n        <circle r=\"234\" cx=\"790\" cy=\"491\"></circle>\n      </g>\n    </svg>\n    <!-- Dots -->\n    <svg class=\"absolute -top-16 -right-16 text-gray-700\" viewBox=\"0 0 220 192\" width=\"220\" height=\"192\" fill=\"none\">\n      <defs>\n        <pattern id=\"837c3e70-6c3a-44e6-8854-cc48c737b659\" x=\"0\" y=\"0\" width=\"20\" height=\"20\"\n          patternUnits=\"userSpaceOnUse\">\n          <rect x=\"0\" y=\"0\" width=\"4\" height=\"4\" fill=\"currentColor\"></rect>\n        </pattern>\n      </defs>\n      <rect width=\"220\" height=\"192\" fill=\"url(#837c3e70-6c3a-44e6-8854-cc48c737b659)\"></rect>\n    </svg>\n    <!-- @formatter:on -->\n    <!-- Content -->\n    <div class=\"z-10 relative w-full max-w-2xl\">\n      <div class=\"text-7xl font-bold leading-none text-gray-100\">\n        <div>Welcome to</div>\n        <div>Best Bank</div>\n      </div>\n      <div class=\"mt-6 text-lg tracking-tight leading-6 text-gray-400\">\n        The bank that has all the tech you need!\n      </div>\n    </div>\n  </div>\n  <div\n    class=\"md:flex md:items-center md:justify-start w-full sm:w-auto md:h-full md:w-1/2 py-8 px-4 sm:p-12 md:p-16 sm:rounded-2xl md:rounded-none sm:shadow md:shadow-none sm:bg-card bg-gray-800 dark:border-r\">\n    <div class=\"w-full max-w-80 sm:w-80 mx-auto sm:mx-0\">\n      <!-- Logo -->\n      <div class=\"w-12\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"30\" height=\"28\" viewBox=\"0 0 30 28\" fill=\"none\">\n          <path\n            d=\"M9.25719 10.8868C8.14587 10.3312 7.39342 9.52083 7.08086 8.35162C6.86091 7.54129 6.84933 6.71937 7.23135 5.97849C8.04169 4.36939 8.9099 2.79502 9.96334 1.32484C10.5769 0.445043 11.5146 0.0167213 12.5912 0.005145C16.5155 -0.00643125 20.4399 0.005145 24.3758 0.005145C26.5174 0.005145 28.6937 1.62582 29.3536 3.66324C30.1292 6.09425 29.5272 8.35162 27.5245 9.93757C26.8763 10.4469 26.5868 10.8868 26.4711 11.7319C26.1933 13.8735 24.9777 15.4131 22.9288 16.2466C22.2921 16.5129 21.6206 16.5823 20.9261 16.5823C16.3997 16.5823 11.8734 16.5823 7.34711 16.5823C6.49047 16.5823 5.63382 16.6518 4.82349 16.9759C4.42989 17.1264 4.33728 16.9296 4.32571 16.5823C4.19837 14.1166 6.15476 11.593 8.57419 11.1068C8.79414 11.0605 9.01409 11.0257 9.26877 10.8868H9.25719ZM18.032 10.9216C20.1041 10.9216 22.1879 10.9216 24.26 10.9216C24.7925 10.9216 25.2787 10.7711 25.7881 10.6553C26.2164 10.5511 26.2974 10.2849 26.2048 9.87969C25.7071 7.59917 23.6928 5.77012 21.366 5.68909C19.0044 5.59648 16.6313 5.66593 14.2581 5.66593C14.0266 5.66593 13.8645 5.74697 13.7488 5.95534C12.9153 7.41395 12.0586 8.87256 11.2252 10.3427C10.9126 10.8984 10.9242 10.9216 11.5493 10.9216C13.7025 10.9216 15.8672 10.9216 18.0204 10.9216H18.032Z\"\n            fill=\"#1D1F23\" />\n          <path\n            d=\"M9.82441 27.5798C7.47443 27.5798 5.12445 27.5798 2.77447 27.5798C2.1262 27.5798 1.52424 27.6956 0.922273 27.9155C0.424494 28.0892 0.331884 28.0197 0.320308 27.4756C0.262427 24.5237 2.79763 21.9306 5.74957 21.9306C10.3569 21.9306 14.9643 21.9306 19.56 21.9306C20.3935 21.9306 21.2154 21.8496 21.9911 21.5602C22.4194 21.3981 22.5004 21.5949 22.512 21.9653C22.6162 24.2459 20.926 26.6306 18.7266 27.302C18.0667 27.4988 17.4069 27.603 16.7123 27.603C14.4086 27.5798 12.1049 27.603 9.80126 27.603L9.82441 27.5798Z\"\n            fill=\"#00A9B4\" />\n        </svg>\n      </div>\n\n      <!-- title -->\n      @if(showSigInForm) {\n      <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign in</div>\n      <div class=\"flex items-baseline mt-0.5 font-medium\">\n        <div>Don't have an account?</div>\n        <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign Up\n        </div>\n      </div>\n      }\n      @if(!showSigInForm) {\n      <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign Up</div>\n      <div class=\"flex items-baseline mt-0.5 font-medium\">\n        <div>Already have an account?</div>\n        <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign In\n        </div>\n      </div>\n      }\n\n      <cl-card [flippable]=\"true\" [face]=\"cardFace\">\n          <auth-sign-in clCardFront></auth-sign-in>\n\n          <auth-sign-up clCardBack [userList]=\"userList\"></auth-sign-up>\n      </cl-card>\n\n\n\n      <!-- <cl-card clCardBack [flippable]=\"true\" [face]=\"'back'\">\n        <auth-sign-in></auth-sign-in>\n      </cl-card>\n\n      <cl-card clCardBack [flippable]=\"true\" [face]=\"'back'\">\n        <auth-sign-up [userList]=\"userList\"></auth-sign-up>\n      </cl-card> -->\n\n    </div>\n  </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "component", type: ClCardComponent, selector: "cl-card", inputs: ["expanded", "face", "flippable", "properties"], exportAs: ["clCard"] }, { kind: "component", type: ClAuthSignInComponent, selector: "auth-sign-in", outputs: ["checkIfSignedIn"] }, { kind: "component", type: ClAuthSignUpComponent, selector: "auth-sign-up", inputs: ["userList"] }], animations: clAnimations, encapsulation: i0.ViewEncapsulation.None }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthComponent, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClAuthComponent, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }, {
            type: Component,
            args: [{ standalone: true, selector: 'cl-auth', animations: clAnimations, encapsulation: ViewEncapsulation.None, imports: [
                        FormsModule,
                        ClCardComponent,
                        ClAuthSignInComponent,
                        ClAuthSignUpComponent,
                    ], template: "<div\n  class=\"flex flex-col sm:flex-row items-center md:items-start sm:justify-center md:justify-start flex-auto min-w-0 h-screen\">\n  <div\n    class=\"relative hidden md:flex flex-auto items-center justify-center w-1/2 h-full p-16 lg:px-28 overflow-hidden bg-gray-800 dark:border-r\">\n    <!-- Background - @formatter:off -->\n    <!-- Rings -->\n    <svg class=\"absolute inset-0 pointer-events-none\" viewBox=\"0 0 960 540\" width=\"100%\" height=\"100%\"\n      preserveAspectRatio=\"xMidYMax slice\" xmlns=\"http://www.w3.org/2000/svg\">\n      <g class=\"text-gray-700 opacity-25\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"100\">\n        <circle r=\"234\" cx=\"196\" cy=\"23\"></circle>\n        <circle r=\"234\" cx=\"790\" cy=\"491\"></circle>\n      </g>\n    </svg>\n    <!-- Dots -->\n    <svg class=\"absolute -top-16 -right-16 text-gray-700\" viewBox=\"0 0 220 192\" width=\"220\" height=\"192\" fill=\"none\">\n      <defs>\n        <pattern id=\"837c3e70-6c3a-44e6-8854-cc48c737b659\" x=\"0\" y=\"0\" width=\"20\" height=\"20\"\n          patternUnits=\"userSpaceOnUse\">\n          <rect x=\"0\" y=\"0\" width=\"4\" height=\"4\" fill=\"currentColor\"></rect>\n        </pattern>\n      </defs>\n      <rect width=\"220\" height=\"192\" fill=\"url(#837c3e70-6c3a-44e6-8854-cc48c737b659)\"></rect>\n    </svg>\n    <!-- @formatter:on -->\n    <!-- Content -->\n    <div class=\"z-10 relative w-full max-w-2xl\">\n      <div class=\"text-7xl font-bold leading-none text-gray-100\">\n        <div>Welcome to</div>\n        <div>Best Bank</div>\n      </div>\n      <div class=\"mt-6 text-lg tracking-tight leading-6 text-gray-400\">\n        The bank that has all the tech you need!\n      </div>\n    </div>\n  </div>\n  <div\n    class=\"md:flex md:items-center md:justify-start w-full sm:w-auto md:h-full md:w-1/2 py-8 px-4 sm:p-12 md:p-16 sm:rounded-2xl md:rounded-none sm:shadow md:shadow-none sm:bg-card bg-gray-800 dark:border-r\">\n    <div class=\"w-full max-w-80 sm:w-80 mx-auto sm:mx-0\">\n      <!-- Logo -->\n      <div class=\"w-12\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"30\" height=\"28\" viewBox=\"0 0 30 28\" fill=\"none\">\n          <path\n            d=\"M9.25719 10.8868C8.14587 10.3312 7.39342 9.52083 7.08086 8.35162C6.86091 7.54129 6.84933 6.71937 7.23135 5.97849C8.04169 4.36939 8.9099 2.79502 9.96334 1.32484C10.5769 0.445043 11.5146 0.0167213 12.5912 0.005145C16.5155 -0.00643125 20.4399 0.005145 24.3758 0.005145C26.5174 0.005145 28.6937 1.62582 29.3536 3.66324C30.1292 6.09425 29.5272 8.35162 27.5245 9.93757C26.8763 10.4469 26.5868 10.8868 26.4711 11.7319C26.1933 13.8735 24.9777 15.4131 22.9288 16.2466C22.2921 16.5129 21.6206 16.5823 20.9261 16.5823C16.3997 16.5823 11.8734 16.5823 7.34711 16.5823C6.49047 16.5823 5.63382 16.6518 4.82349 16.9759C4.42989 17.1264 4.33728 16.9296 4.32571 16.5823C4.19837 14.1166 6.15476 11.593 8.57419 11.1068C8.79414 11.0605 9.01409 11.0257 9.26877 10.8868H9.25719ZM18.032 10.9216C20.1041 10.9216 22.1879 10.9216 24.26 10.9216C24.7925 10.9216 25.2787 10.7711 25.7881 10.6553C26.2164 10.5511 26.2974 10.2849 26.2048 9.87969C25.7071 7.59917 23.6928 5.77012 21.366 5.68909C19.0044 5.59648 16.6313 5.66593 14.2581 5.66593C14.0266 5.66593 13.8645 5.74697 13.7488 5.95534C12.9153 7.41395 12.0586 8.87256 11.2252 10.3427C10.9126 10.8984 10.9242 10.9216 11.5493 10.9216C13.7025 10.9216 15.8672 10.9216 18.0204 10.9216H18.032Z\"\n            fill=\"#1D1F23\" />\n          <path\n            d=\"M9.82441 27.5798C7.47443 27.5798 5.12445 27.5798 2.77447 27.5798C2.1262 27.5798 1.52424 27.6956 0.922273 27.9155C0.424494 28.0892 0.331884 28.0197 0.320308 27.4756C0.262427 24.5237 2.79763 21.9306 5.74957 21.9306C10.3569 21.9306 14.9643 21.9306 19.56 21.9306C20.3935 21.9306 21.2154 21.8496 21.9911 21.5602C22.4194 21.3981 22.5004 21.5949 22.512 21.9653C22.6162 24.2459 20.926 26.6306 18.7266 27.302C18.0667 27.4988 17.4069 27.603 16.7123 27.603C14.4086 27.5798 12.1049 27.603 9.80126 27.603L9.82441 27.5798Z\"\n            fill=\"#00A9B4\" />\n        </svg>\n      </div>\n\n      <!-- title -->\n      @if(showSigInForm) {\n      <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign in</div>\n      <div class=\"flex items-baseline mt-0.5 font-medium\">\n        <div>Don't have an account?</div>\n        <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign Up\n        </div>\n      </div>\n      }\n      @if(!showSigInForm) {\n      <div class=\"mt-8 text-4xl font-extrabold tracking-tight leading-tight\">Sign Up</div>\n      <div class=\"flex items-baseline mt-0.5 font-medium\">\n        <div>Already have an account?</div>\n        <div class=\"ml-1 text-md text-primary-500 underline cursor-pointer\" (click)=\"toggleCard()\">Sign In\n        </div>\n      </div>\n      }\n\n      <cl-card [flippable]=\"true\" [face]=\"cardFace\">\n          <auth-sign-in clCardFront></auth-sign-in>\n\n          <auth-sign-up clCardBack [userList]=\"userList\"></auth-sign-up>\n      </cl-card>\n\n\n\n      <!-- <cl-card clCardBack [flippable]=\"true\" [face]=\"'back'\">\n        <auth-sign-in></auth-sign-in>\n      </cl-card>\n\n      <cl-card clCardBack [flippable]=\"true\" [face]=\"'back'\">\n        <auth-sign-up [userList]=\"userList\"></auth-sign-up>\n      </cl-card> -->\n\n    </div>\n  </div>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { userList: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ClAuthComponent, ClAuthSignUpComponent };
//# sourceMappingURL=clay-ui-components-auth.mjs.map
