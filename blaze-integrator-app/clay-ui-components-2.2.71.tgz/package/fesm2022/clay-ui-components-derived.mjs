import { NgClass } from '@angular/common';
import * as i0 from '@angular/core';
import { Input, Optional, Self, Component, signal } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i4 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { Subject, debounceTime } from 'rxjs';
import { ClInputComponent, ClInputStyleProperties } from '@clay/ui-components/basic';
import { ClComponentTypes } from '@clay/ui-components/shared';

class ClEmailComponent extends ClInputComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super(ngControl);
        this.ngControl = ngControl;
        this.emailValidationSubject = new Subject(); // Subject for debouncing
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        // Set up the debounced validation
        this.emailValidationSubject
            .pipe(debounceTime(200)) // 300ms debounce time
            .subscribe(value => this.validateEmail(value));
    }
    // When we want to implement component level lifecycle Hooks, the super class call for the same hook is absolutely necessary.
    //override ngOnInit(): void {
    /**
     * !! Warning !!
     * The below super calls are always to be implemented for any component. Otherwise nothing will work.
     */
    //super.ngOnInit();
    //-----------------------------------------------------------------------------------------------------
    //}
    //override ngOnDestroy(): void {
    /**
     * !! Warning !!
     * The below super calls are always to be implemented for any component. Otherwise nothing will work.
     */
    //super.ngOnDestroy();
    //-----------------------------------------------------------------------------------------------------
    //}
    writeValue(value) {
        this._value = value;
        // this.validateEmail(this._value);
        // Emit the value into the Subject for debouncing
        this.emailValidationSubject.next(this._value);
    }
    validateEmail(value) {
        if (this.ngControl != null && this.ngControl.touched === true) {
            const regex = new RegExp(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/);
            if (value && !regex.test(value)) {
                this.error = ["Please enter valid email address."];
                super.setErrorText(this.error);
            }
        }
    }
    get value() {
        return this._value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClEmailComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClEmailComponent, isStandalone: true, selector: "cl-email", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input type=\"email\" matInput [placeholder]=\"properties.placeholder!\" [value]=\"value\"\n    (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value);validateEmail($any($event.target).value);\"\n    (keyup)=\"writeValue($any($event.target).value)\" [disabled]=\"disabled\" />\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClEmailComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-email', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input type=\"email\" matInput [placeholder]=\"properties.placeholder!\" [value]=\"value\"\n    (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value);validateEmail($any($event.target).value);\"\n    (keyup)=\"writeValue($any($event.target).value)\" [disabled]=\"disabled\" />\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClEmailStyleProperties extends ClInputStyleProperties {
}
class ClEmailProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Input';
        this.floatLabel = 'auto';
        this.appearance = 'fill';
        this.subscriptSizing = 'fixed';
        this.type = ClComponentTypes.email;
        this.disabled = signal(false);
        this.style = new ClEmailStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.cssClasses = 'flex-auto w-full';
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { ClEmailComponent, ClEmailProperties, ClEmailStyleProperties };
//# sourceMappingURL=clay-ui-components-derived.mjs.map
