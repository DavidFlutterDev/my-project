import { Subject, filter, BehaviorSubject as BehaviorSubject$1, takeUntil, timer } from 'rxjs';
import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Output, Input, Component, inject, Inject, ChangeDetectionStrategy, ViewEncapsulation, signal, ViewChildren, ViewChild, Optional, Self, TemplateRef, ContentChildren } from '@angular/core';
import * as i1$2 from '@angular/common';
import { NgClass, NgStyle, DatePipe, CommonModule, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i2 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i8 from '@angular/material/form-field';
import { MatFormFieldModule, MatFormField } from '@angular/material/form-field';
import { ClIconComponent, ClChipComponent, ClButtonComponent, ClButtonBehavior, IClButtonType, ClButtonProperties } from '@clay/ui-components/basic';
import { ClBaseContainerComponent, ClComponentTypes, ClBaseComponent } from '@clay/ui-components/shared';
import * as i4 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1$1 from '@angular/router';
import { NavigationEnd, RouterModule } from '@angular/router';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import * as i1$3 from '@angular/forms';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i5 from '@angular/material/card';
import { MatCardModule } from '@angular/material/card';
import * as i3 from '@angular/material/core';
import { MAT_DATE_FORMATS, MatNativeDateModule } from '@angular/material/core';
import * as i2$1 from '@angular/material/datepicker';
import { MatDatepickerModule, DateRange } from '@angular/material/datepicker';
import * as i7 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i4$1 from '@angular/cdk/overlay';
import { OverlayModule, FullscreenOverlayContainer, OverlayContainer } from '@angular/cdk/overlay';
import { ClTooltipDirective } from '@clay/app-shell/structural';

class ClTreeViewService {
    constructor() {
        this.treeNodeToExpandedCollapse = new Subject();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClChildTreeViewComponent {
    constructor() {
        this.addClicked = new EventEmitter();
        this.editClicked = new EventEmitter();
        this.viewClicked = new EventEmitter();
        this.deleteClicked = new EventEmitter();
        this.actionClicked = new EventEmitter();
        this.treeNodeClicked = new EventEmitter();
    }
    /**
     * this function will calculate the width for tree nodes
     *
     * @param depth - depth of the tree node
     *
     * @returns - style with width properties calculated
     */
    getTreeNodeWidth(depth) {
        return { 'width': `calc(100% - ${16 + (40 * depth)}px)` };
    }
    /**
     * this function will be triggered when the tree node was clicked
     * this function also calls expand collapse tree function
     *
     * @param treeNode - tree node where clicked and needs to be expanded or collapsed
     */
    onTreeNodeClicked(treeNode) {
        this.treeNodeClicked.emit(treeNode);
    }
    /**
     * this function is the call back function for add button
     *
     * @param treeNode - tree node where clicked
     */
    onAddClicked(treeNode) {
        this.addClicked.emit(treeNode);
    }
    /**
     * this function is the call back function for edit button
     *
     * @param treeNode - tree node where clicked
     */
    onEditClicked(treeNode) {
        this.editClicked.emit(treeNode);
    }
    /**
     * this function is the call back function for view button
     *
     * @param treeNode - tree node where clicked
     */
    onViewClicked(treeNode) {
        this.viewClicked.emit(treeNode);
    }
    /**
     * this function is the call back function for delete button
     *
     * @param treeNode - tree node where clicked
     */
    onDeleteClicked(treeNode) {
        this.deleteClicked.emit(treeNode);
    }
    onActionIconClicked(treeNode, selectedAction, index) {
        this.actionClicked.emit({ treeNode, selectedAction, index });
    }
    onMouseHoverFunction(tree) {
        if (this.treeViewConfig.alwaysShowActionButtons) {
            tree.showActionButtons = true;
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChildTreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChildTreeViewComponent, isStandalone: true, selector: "cl-child-tree-view", inputs: { treeViewConfig: "treeViewConfig", properties: "properties" }, outputs: { addClicked: "addClicked", editClicked: "editClicked", viewClicked: "viewClicked", deleteClicked: "deleteClicked", actionClicked: "actionClicked", treeNodeClicked: "treeNodeClicked" }, ngImport: i0, template: "@for (tree of properties; track tree; let index = $index) {\n  <div class=\"tree-node connector\">\n    <div class=\"flex ml-[-4px]\" [ngStyle]=\"getTreeNodeWidth(tree.depth!)\">\n\n      <div class=\"mt-[23px] w-1 h-1 rotate-45 bg-primary-300 text-primary-300\"></div>\n\n      <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n        (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 tree-node-div flex justify-between\n          border border-white hover:border hover:border-primary-300\n          {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\">\n\n        <mat-label class=\"py-2 text-md text-neutral-800 font-bold leading-5\">{{ tree.text }}</mat-label>\n\n        <div class=\"flex gap-3 items-center\">\n          <div class=\"flex gap-1 items-center\">\n            @for (chip of tree.chipsList; track chip) {\n              <cl-chip [properties]=\"chip\"></cl-chip>\n            }\n          </div>\n\n          @if (treeViewConfig.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n            <div\n              [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : 'px-2 py-1 flex gap-2 rounded-md items-center bg-primary-50'\">\n\n              @if (!tree.hideViewIcon && treeViewConfig.viewOnIconProperties && treeViewConfig.viewOffIconProperties && treeViewConfig.partialViewIconProperties) {\n                <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                  [properties]=\"tree.partialView ? treeViewConfig.partialViewIconProperties! : tree.viewOn ? treeViewConfig.viewOnIconProperties! : treeViewConfig.viewOffIconProperties!\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideAddIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.addIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideEditIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.editIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideDeleteIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.deleteIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                </cl-icon>\n              }\n            </div>\n          }\n\n          @if (treeViewConfig.showActionIcon) {\n            <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n              (click)=\"$event.stopPropagation()\" [properties]=\"treeViewConfig.actionIconProperties!\">\n            </cl-icon>\n\n            <mat-menu #actionPropertiesMenu=\"matMenu\">\n              @for (action of tree.actionList; track action; let actionIndex = $index) {\n                <div class=\"\">\n                  <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                    [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                    (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                    {{ action.label }}\n                  </mat-checkbox>\n                </div>\n              }\n            </mat-menu>\n          }\n\n          @if (tree.expanded && tree.children && tree.children.length > 0) {\n            <cl-icon class=\"py-2\" [properties]=\"treeViewConfig.upArrowIconProperties!\">\n            </cl-icon>\n          }\n\n          @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n            <cl-icon class=\"py-2\" [properties]=\"treeViewConfig.downArrowIconProperties!\">\n            </cl-icon>\n          }\n        </div>\n      </div>\n    </div>\n\n    @if (tree.children && tree.children.length > 0 && tree.expanded) {\n      <div>\n        <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"treeViewConfig\"\n          (addClicked)=\"onAddClicked($event)\" (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n          (deleteClicked)=\"onDeleteClicked($event)\"\n          (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n          (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n        </cl-child-tree-view>\n      </div>\n    }\n  </div>\n}\n", styles: [".tree-node-div{margin-left:-2px;box-shadow:0 2px 8px #0000001a;margin-bottom:1rem;display:flex;width:100%;align-items:center;border-radius:.375rem;--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity))}.tree-node{width:100%;max-width:100%}.arrow-icon-rotate{animation:spin .4s linear infinite}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(180deg)}}.connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-32px;width:28px;content:\"\";height:42px;position:absolute;border-style:solid;border-width:0 0 2px 2px;color:var(--cl-primary-300);border-color:var(--cl-primary-300)}.connector:after{top:10px;left:-32px;content:\"\";height:100%;position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary-300)}.connector:last-child:after{content:none}\n"], dependencies: [{ kind: "component", type: ClChildTreeViewComponent, selector: "cl-child-tree-view", inputs: ["treeViewConfig", "properties"], outputs: ["addClicked", "editClicked", "viewClicked", "deleteClicked", "actionClicked", "treeNodeClicked"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClChipComponent, selector: "cl-chip", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChildTreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-child-tree-view', imports: [
                        NgClass,
                        NgStyle,
                        MatMenuModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClChipComponent,
                    ], template: "@for (tree of properties; track tree; let index = $index) {\n  <div class=\"tree-node connector\">\n    <div class=\"flex ml-[-4px]\" [ngStyle]=\"getTreeNodeWidth(tree.depth!)\">\n\n      <div class=\"mt-[23px] w-1 h-1 rotate-45 bg-primary-300 text-primary-300\"></div>\n\n      <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n        (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 tree-node-div flex justify-between\n          border border-white hover:border hover:border-primary-300\n          {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\">\n\n        <mat-label class=\"py-2 text-md text-neutral-800 font-bold leading-5\">{{ tree.text }}</mat-label>\n\n        <div class=\"flex gap-3 items-center\">\n          <div class=\"flex gap-1 items-center\">\n            @for (chip of tree.chipsList; track chip) {\n              <cl-chip [properties]=\"chip\"></cl-chip>\n            }\n          </div>\n\n          @if (treeViewConfig.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n            <div\n              [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : 'px-2 py-1 flex gap-2 rounded-md items-center bg-primary-50'\">\n\n              @if (!tree.hideViewIcon && treeViewConfig.viewOnIconProperties && treeViewConfig.viewOffIconProperties && treeViewConfig.partialViewIconProperties) {\n                <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                  [properties]=\"tree.partialView ? treeViewConfig.partialViewIconProperties! : tree.viewOn ? treeViewConfig.viewOnIconProperties! : treeViewConfig.viewOffIconProperties!\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideAddIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.addIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideEditIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.editIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                </cl-icon>\n              }\n\n              @if (!tree.hideDeleteIcon) {\n                <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"treeViewConfig.deleteIconProperties!\"\n                  (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                </cl-icon>\n              }\n            </div>\n          }\n\n          @if (treeViewConfig.showActionIcon) {\n            <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n              (click)=\"$event.stopPropagation()\" [properties]=\"treeViewConfig.actionIconProperties!\">\n            </cl-icon>\n\n            <mat-menu #actionPropertiesMenu=\"matMenu\">\n              @for (action of tree.actionList; track action; let actionIndex = $index) {\n                <div class=\"\">\n                  <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                    [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                    (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                    {{ action.label }}\n                  </mat-checkbox>\n                </div>\n              }\n            </mat-menu>\n          }\n\n          @if (tree.expanded && tree.children && tree.children.length > 0) {\n            <cl-icon class=\"py-2\" [properties]=\"treeViewConfig.upArrowIconProperties!\">\n            </cl-icon>\n          }\n\n          @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n            <cl-icon class=\"py-2\" [properties]=\"treeViewConfig.downArrowIconProperties!\">\n            </cl-icon>\n          }\n        </div>\n      </div>\n    </div>\n\n    @if (tree.children && tree.children.length > 0 && tree.expanded) {\n      <div>\n        <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"treeViewConfig\"\n          (addClicked)=\"onAddClicked($event)\" (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n          (deleteClicked)=\"onDeleteClicked($event)\"\n          (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n          (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n        </cl-child-tree-view>\n      </div>\n    }\n  </div>\n}\n", styles: [".tree-node-div{margin-left:-2px;box-shadow:0 2px 8px #0000001a;margin-bottom:1rem;display:flex;width:100%;align-items:center;border-radius:.375rem;--tw-bg-opacity: 1;background-color:rgb(255 255 255 / var(--tw-bg-opacity))}.tree-node{width:100%;max-width:100%}.arrow-icon-rotate{animation:spin .4s linear infinite}@keyframes spin{0%{transform:rotate(0)}to{transform:rotate(180deg)}}.connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-32px;width:28px;content:\"\";height:42px;position:absolute;border-style:solid;border-width:0 0 2px 2px;color:var(--cl-primary-300);border-color:var(--cl-primary-300)}.connector:after{top:10px;left:-32px;content:\"\";height:100%;position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary-300)}.connector:last-child:after{content:none}\n"] }]
        }], propDecorators: { treeViewConfig: [{
                type: Input,
                args: [{ required: true }]
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }], addClicked: [{
                type: Output
            }], editClicked: [{
                type: Output
            }], viewClicked: [{
                type: Output
            }], deleteClicked: [{
                type: Output
            }], actionClicked: [{
                type: Output
            }], treeNodeClicked: [{
                type: Output
            }] } });

class ClTreeViewComponent extends ClBaseContainerComponent {
    constructor() {
        super(...arguments);
        this.treeViewService = inject(ClTreeViewService);
        this.addIconProperties = {
            id: 'treeViewIconAdd',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:plus-circle',
            style: { cssClasses: 'icon-size-5 text-primary-600' },
        };
        this.editIconProperties = {
            id: 'treeViewIconEdit',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:edit-filled',
            style: { cssClasses: 'icon-size-4 text-primary-600' },
        };
        this.deleteIconProperties = {
            id: 'treeViewIconDelete',
            iconName: 'fss_icons:trash',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-4' },
        };
        this.actionIconProperties = {
            id: 'treeViewIcon',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:dotted-ellipsis',
            style: { cssClasses: 'icon-size-4' },
        };
        this.viewOnIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:eye-open-filled',
            style: { cssClasses: 'icon-size-5' },
        };
        this.viewOffIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:eye-closed',
            style: { cssClasses: 'icon-size-5' },
        };
        this.upArrowIconProperties = {
            id: 'treeViewIconUp',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:chevron-circle-up-filled',
        };
        this.downArrowIconProperties = {
            id: 'treeViewIconDown',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:chevron-circle-down',
        };
        this.partialViewIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:partial-eye-filled',
        };
        this.disableViewIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:disable-eye-filled',
        };
    }
    ngOnInit() {
        // calling set default properties function
        this.setDefaultProperties();
        // calling add depth function
        this.addDepth(this.properties.treeViewChildren);
        // calling subscribe to tree view service function
        this.subscribeToTreeViewService();
        super.ngOnInit();
    }
    subscribeToTreeViewService() {
        this.treeViewSubscription = this.treeViewService.treeNodeToExpandedCollapse
            .subscribe((selectedTreeNode) => {
            // calling expand collapse tree function
            this.expandCollapseTree(selectedTreeNode);
            // calling add depth function
            this.addDepth(this.properties.treeViewChildren);
        });
    }
    /**
     * this function will set the default values to the property of the tree view
     */
    setDefaultProperties() {
        // this property is used to always show the icons
        // and has higher precedence over other properties
        this.properties.alwaysShowActionButtons ??= true;
        this.properties.addIconProperties ??= this.addIconProperties;
        this.properties.editIconProperties ??= this.editIconProperties;
        this.properties.deleteIconProperties ??= this.deleteIconProperties;
        this.properties.actionIconProperties ??= this.actionIconProperties;
        this.properties.viewOnIconProperties ??= this.viewOnIconProperties;
        this.properties.viewOffIconProperties ??= this.viewOffIconProperties;
        this.properties.upArrowIconProperties ??= this.upArrowIconProperties;
        this.properties.downArrowIconProperties ??= this.downArrowIconProperties;
        this.properties.partialViewIconProperties ??= this.partialViewIconProperties;
        this.properties.disableViewIconProperties ??= this.disableViewIconProperties;
    }
    /**
     * this function is used to add depth to the tree view for managing the width of the children
     *
     * @param treeNode - array of objects
     *
     * @param depth - depth of the tree node
     */
    addDepth(treeNode, depth = 0) {
        treeNode.forEach((childTreeNode) => {
            childTreeNode.depth = depth;
            childTreeNode.viewOn ??= false;
            childTreeNode.partialView ??= false;
            childTreeNode.showArrowIcons ??= false;
            childTreeNode.showActionButtons ??= false;
            if (childTreeNode.children && childTreeNode.children.length > 0) {
                // calling add depth function
                this.addDepth(childTreeNode.children, depth + 1);
            }
        });
    }
    /**
     * this function will expand or collapse the tree view
     * this function will also call another function to collapse the tree nodes children
     *
     * @param treeNode - tree node which needs to be expanded or collapsed
     */
    expandCollapseTree(treeNode) {
        if (treeNode.children && treeNode.children.length > 0) {
            treeNode.expanded = !treeNode.expanded;
            // calling expand collapse child tree function
            this.expandCollapseChildTree(treeNode.children);
        }
    }
    /**
     * this function will expand or collapse the child tree of a tree node
     *
     * @param treeNode - tree node children which needs to be collapsed
     */
    expandCollapseChildTree(treeNode) {
        treeNode?.forEach((treeNode) => {
            treeNode.expanded = false;
            // calling expand collapse child tree function
            this.expandCollapseChildTree(treeNode.children);
        });
    }
    /**
     * this function will change all the tree node's viewOn property to true or false based on the result
     *
     * @param treeNode - tree node of the tree view
     *
     * @param result - result is based on view on or off
     *                 result should be true to show view on
     *                 result should be true to show view off
     */
    changeViewForAllChildTreeNode(treeNode, result) {
        treeNode.viewOn = result;
        treeNode.partialView = false;
        treeNode.children?.forEach((childTreeNode) => {
            // calling change all view for tree node function
            this.changeViewForAllChildTreeNode(childTreeNode, result);
        });
    }
    /**
     * this function will find the parent and grand parent and so on for the tree node
     * on which view button/icon was clicked
     *
     * @param treeArr - array of tree nodes
     *
     * @param treeId - the id of the tree node where view button/icon was clicked
     *
     * @returns - either return empty array if parent is clicked
     *          - or returns false if id not found
     *          - or returns array of parent and grand parent and so on
     */
    findParentOfTreeNode(treeArr, treeId) {
        for (const treeNode of treeArr) {
            if (treeNode.id === treeId) {
                return [];
            }
            else if (treeNode.children?.length) {
                const parentTreeNodes = this.findParentOfTreeNode(treeNode.children, treeId);
                if (parentTreeNodes !== false) {
                    // this will only add immediate parent of tree node
                    // if (parentTreeNodes.length == 0) parentTreeNodes.push(treeNode);
                    // this will add parent and parent of tree node
                    parentTreeNodes.push(treeNode);
                    return parentTreeNodes;
                }
            }
        }
        return false;
    }
    /**
     * this function will change the view of parent and grand parents and so on
     * based on the combination of it's child's view status
     *
     * in this function we will check the view permission of all the child nodes of each parent
     * if all the child nodes view permission is true then parent's view permission will also be true
     * if all the child nodes view permission is false then parent's view permission will also be false
     * if any of the child's view permission is false and rest of the child's view permission is true
     * then the parent will have partial view permission
     *
     * @param parentTreeNodes - array of tree nodes to change the view
     */
    changeViewForAllParentTreeNode(parentTreeNodes) {
        for (const childTreeNode of parentTreeNodes) {
            const childTreeNodesViewPermission = [];
            childTreeNode.children?.forEach((subChildTreeNode) => {
                childTreeNodesViewPermission.push(subChildTreeNode.viewOn);
            });
            // here we are checking if the tree node has combination of true and false to consider parent as partial view
            if (childTreeNodesViewPermission.indexOf(true) > -1 && childTreeNodesViewPermission.indexOf(false) > -1) {
                childTreeNode.viewOn = true;
                childTreeNode.partialView = true;
            }
            // here we are checking if the tree node has true and does not have false to consider parent as full view
            if (childTreeNodesViewPermission.indexOf(true) > -1 && childTreeNodesViewPermission.indexOf(false) == -1) {
                childTreeNode.viewOn = true;
                childTreeNode.partialView = false;
            }
            // here we are checking if the tree node has false and does not have true to consider parent as no view
            if (childTreeNodesViewPermission.indexOf(true) == -1 && childTreeNodesViewPermission.indexOf(false) > -1) {
                childTreeNode.viewOn = false;
                childTreeNode.partialView = false;
            }
        }
    }
    /**
     * this function will be triggered when the tree node was clicked
     * this function also calls expand collapse tree function
     *
     * @param treeNode - tree node where clicked and needs to be expanded or collapsed
     */
    onTreeNodeClicked(treeNode) {
        let result = true;
        if (treeNode.onTreeNodeClicked != undefined) {
            // calling on tree node clicked callback function
            result = treeNode.onTreeNodeClicked(treeNode);
        }
        if (result) {
            // calling expand collapse tree function
            this.expandCollapseTree(treeNode);
            // calling add depth function
            this.addDepth(this.properties.treeViewChildren);
        }
    }
    /**
     * this function will generate the object for sending it to the client
     *
     * @param treeNode - selected tree node
     *
     * @returns - generated tree node object
     */
    generateReturnObjectForCallback(treeNode) {
        return {
            id: treeNode.id,
            data: treeNode.data,
            text: treeNode.text,
            depth: treeNode.depth,
            viewOn: treeNode.viewOn,
            expanded: treeNode.expanded,
            parentId: treeNode.parentId,
            children: treeNode.children,
            actionList: treeNode.actionList,
            chipsList: treeNode.chipsList,
            partialView: treeNode.partialView,
            showActionButtons: treeNode.showActionButtons,
        };
    }
    /**
     * this function is the call back function for add button
     *
     * @param treeNode - tree node where clicked
     */
    onAddClicked(treeNode) {
        if (treeNode.disableAddIcon) {
            return;
        }
        if (this.properties.onAddClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for add button
            this.properties.onAddClicked(returnObjForCallback);
        }
    }
    /**
     * this function is the call back function for edit button
     *
     * @param treeNode - tree node where clicked
     */
    onEditClicked(treeNode) {
        if (treeNode.disableEditIcon) {
            return;
        }
        if (this.properties.onEditClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for edit button
            this.properties.onEditClicked(returnObjForCallback);
        }
    }
    /**
     * this function is the call back function for delete button
     *
     * @param treeNode - tree node where clicked
     */
    onDeleteClicked(treeNode) {
        if (treeNode.disableDeleteIcon) {
            return;
        }
        if (this.properties.onDeleteClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for delete button
            this.properties.onDeleteClicked(returnObjForCallback);
        }
    }
    onActionIconClicked(treeNode, selectedAction, actionIndex) {
        if (treeNode.disableActionIcon) {
            return;
        }
        if (this.properties.onActionIconClicked != undefined) {
            // toggling checkbox of treeNode
            treeNode.actionList[actionIndex].checked = !treeNode.actionList[actionIndex].checked;
            treeNode.actionList[actionIndex].indeterminate = false;
            // Find parent
            const parentTreeNodes = this.findParentOfTreeNode(this.properties.treeViewChildren, treeNode.id);
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for action button
            this.properties.onActionIconClicked(returnObjForCallback, selectedAction, parentTreeNodes);
        }
    }
    /**
     * this function is the callback function for view button
     *
     * @param treeNode - tree node where clicked
     */
    onViewClicked(treeNode) {
        if (treeNode.disableViewIcon) {
            return;
        }
        if (this.properties.onViewClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for view button
            const result = this.properties.onViewClicked(returnObjForCallback);
            // calling check if parent is present function
            const parentTreeNodes = this.findParentOfTreeNode(this.properties.treeViewChildren, treeNode.id);
            // calling change all view for tree node function
            this.changeViewForAllChildTreeNode(treeNode, result);
            // calling mark tree node as partial view function
            this.changeViewForAllParentTreeNode(parentTreeNodes);
        }
    }
    onMouseHoverFunction(tree) {
        if (this.properties.alwaysShowActionButtons) {
            tree.showActionButtons = true;
        }
    }
    ngOnDestroy() {
        this.treeViewSubscription.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTreeViewComponent, isStandalone: true, selector: "cl-tree-view", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "@if (properties.treeViewChildren && properties.treeViewChildren.length > 0) {\n  <div class=\"flex w-full flex-col rounded-md border border-solid border-primary-100\">\n    @for (tree of properties.treeViewChildren; track tree; let index = $index) {\n      <div class=\"{{tree.depth == 0 && tree.expanded ? 'bg-neutral-50' : ''}}\n        {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n        {{ index == properties.treeViewChildren.length - 1 ? 'rounded-bl-md rounded-br-md' : '' }}\">\n\n        <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n          (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 flex w-full items-center justify-between\n            {{ (tree.depth == 0 && tree.expanded) ? 'mb-4 bg-neutral-100' : '' }}\n            {{ (index &lt; properties.treeViewChildren.length - 1 && !tree.expanded) ? 'border-b border-solid border-primary-100' : '' }}\n            {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n            {{ (index == properties.treeViewChildren.length - 1 && !tree.expanded) ? 'rounded-bl-md rounded-br-md' : '' }}\n            {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\n            hover:border hover:border-solid hover:border-primary-300\">\n\n          <mat-label class=\"py-2 text-base font-bold leading-6 text-primary-700\">{{ tree.text }}</mat-label>\n\n          <div class=\"flex gap-3 items-center\">\n            <div class=\"flex gap-1 items-center\">\n              @for (chip of tree.chipsList; track chip) {\n                <cl-chip [properties]=\"chip\"></cl-chip>\n              }\n            </div>\n\n            @if (properties.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n              <div\n                [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : tree.expanded ? 'bg-white px-2 py-1 flex gap-2 rounded-md items-center' : 'bg-neutral-50 px-2 py-1 flex gap-2 rounded-md items-center'\">\n\n                @if (!tree.hideViewIcon && properties.viewOnIconProperties && properties.viewOffIconProperties && properties.partialViewIconProperties && properties.disableViewIconProperties) {\n                  <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                    [properties]=\"tree.partialView ? properties.partialViewIconProperties : tree.viewOn ? properties.viewOnIconProperties : tree.disableViewIcon ? properties.disableViewIconProperties! : properties.viewOffIconProperties\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideAddIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.addIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideEditIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.editIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideDeleteIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.deleteIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                  </cl-icon>\n                }\n              </div>\n            }\n\n            @if (properties.showActionIcon) {\n              <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n                (click)=\"$event.stopPropagation();\" [properties]=\"properties.actionIconProperties!\">\n              </cl-icon>\n\n              <mat-menu #actionPropertiesMenu=\"matMenu\">\n                @for (action of tree.actionList; track action; let actionIndex = $index) {\n                  <div class=\"\">\n                    <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                      [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                      (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                      {{ action.label }}\n                    </mat-checkbox>\n                  </div>\n                }\n              </mat-menu>\n            }\n\n            @if (tree.expanded && tree.children && tree.children.length > 0) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.upArrowIconProperties!\">\n              </cl-icon>\n            }\n\n            @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.downArrowIconProperties!\">\n              </cl-icon>\n            }\n          </div>\n        </div>\n\n        @if (tree.children && tree.children.length > 0 && tree.expanded) {\n          <div>\n            <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"properties\" (addClicked)=\"onAddClicked($event)\"\n              (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n              (deleteClicked)=\"onDeleteClicked($event)\"\n              (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n              (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n            </cl-child-tree-view>\n          </div>\n        }\n      </div>\n    }\n  </div>\n}\n", dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClChipComponent, selector: "cl-chip", inputs: ["properties"] }, { kind: "component", type: ClChildTreeViewComponent, selector: "cl-child-tree-view", inputs: ["treeViewConfig", "properties"], outputs: ["addClicked", "editClicked", "viewClicked", "deleteClicked", "actionClicked", "treeNodeClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tree-view', imports: [
                        NgClass,
                        MatMenuModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClChipComponent,
                        ClChildTreeViewComponent
                    ], template: "@if (properties.treeViewChildren && properties.treeViewChildren.length > 0) {\n  <div class=\"flex w-full flex-col rounded-md border border-solid border-primary-100\">\n    @for (tree of properties.treeViewChildren; track tree; let index = $index) {\n      <div class=\"{{tree.depth == 0 && tree.expanded ? 'bg-neutral-50' : ''}}\n        {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n        {{ index == properties.treeViewChildren.length - 1 ? 'rounded-bl-md rounded-br-md' : '' }}\">\n\n        <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n          (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 flex w-full items-center justify-between\n            {{ (tree.depth == 0 && tree.expanded) ? 'mb-4 bg-neutral-100' : '' }}\n            {{ (index &lt; properties.treeViewChildren.length - 1 && !tree.expanded) ? 'border-b border-solid border-primary-100' : '' }}\n            {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n            {{ (index == properties.treeViewChildren.length - 1 && !tree.expanded) ? 'rounded-bl-md rounded-br-md' : '' }}\n            {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\n            hover:border hover:border-solid hover:border-primary-300\">\n\n          <mat-label class=\"py-2 text-base font-bold leading-6 text-primary-700\">{{ tree.text }}</mat-label>\n\n          <div class=\"flex gap-3 items-center\">\n            <div class=\"flex gap-1 items-center\">\n              @for (chip of tree.chipsList; track chip) {\n                <cl-chip [properties]=\"chip\"></cl-chip>\n              }\n            </div>\n\n            @if (properties.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n              <div\n                [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : tree.expanded ? 'bg-white px-2 py-1 flex gap-2 rounded-md items-center' : 'bg-neutral-50 px-2 py-1 flex gap-2 rounded-md items-center'\">\n\n                @if (!tree.hideViewIcon && properties.viewOnIconProperties && properties.viewOffIconProperties && properties.partialViewIconProperties && properties.disableViewIconProperties) {\n                  <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                    [properties]=\"tree.partialView ? properties.partialViewIconProperties : tree.viewOn ? properties.viewOnIconProperties : tree.disableViewIcon ? properties.disableViewIconProperties! : properties.viewOffIconProperties\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideAddIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.addIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideEditIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.editIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideDeleteIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.deleteIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                  </cl-icon>\n                }\n              </div>\n            }\n\n            @if (properties.showActionIcon) {\n              <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n                (click)=\"$event.stopPropagation();\" [properties]=\"properties.actionIconProperties!\">\n              </cl-icon>\n\n              <mat-menu #actionPropertiesMenu=\"matMenu\">\n                @for (action of tree.actionList; track action; let actionIndex = $index) {\n                  <div class=\"\">\n                    <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                      [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                      (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                      {{ action.label }}\n                    </mat-checkbox>\n                  </div>\n                }\n              </mat-menu>\n            }\n\n            @if (tree.expanded && tree.children && tree.children.length > 0) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.upArrowIconProperties!\">\n              </cl-icon>\n            }\n\n            @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.downArrowIconProperties!\">\n              </cl-icon>\n            }\n          </div>\n        </div>\n\n        @if (tree.children && tree.children.length > 0 && tree.expanded) {\n          <div>\n            <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"properties\" (addClicked)=\"onAddClicked($event)\"\n              (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n              (deleteClicked)=\"onDeleteClicked($event)\"\n              (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n              (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n            </cl-child-tree-view>\n          </div>\n        }\n      </div>\n    }\n  </div>\n}\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class ClTreeViewStyleProperties {
}
class ClTreeViewProperties {
    constructor() {
        this.id = 'default0';
        this.showActionIcon = true;
        this.alwaysShowActionButtons = true;
        this.type = ClComponentTypes.treeView;
        this.style = new ClTreeViewStyleProperties();
        this.style.cssClasses = 'flex w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.treeViewChildren = [
            {
                id: '1',
                text: 'Parent 1',
                onTreeNodeClicked: (treeNode) => true,
                children: [
                    {
                        id: '3',
                        text: 'Child 1',
                        onTreeNodeClicked: (treeNode) => true,
                        children: [
                            { id: '7', text: 'Sub-Child 1' },
                            { id: '8', text: 'Sub-Child 2' },
                        ],
                    },
                    {
                        id: '4',
                        text: 'Child 2',
                        onTreeNodeClicked: (treeNode) => true,
                        children: [
                            { id: '9', text: 'Sub-Child 1' },
                            { id: '10', text: 'Sub-Child 2' },
                        ],
                    },
                ],
            },
            {
                id: '2',
                text: 'Parent 2',
                onTreeNodeClicked: (treeNode) => true,
                children: [
                    {
                        id: '5',
                        text: 'Child 1',
                        onTreeNodeClicked: (treeNode) => true,
                        children: [
                            { id: '11', text: 'Sub-Child 1' },
                            { id: '12', text: 'Sub-Child 2' },
                        ],
                    },
                    {
                        id: '6',
                        text: 'Child 2',
                        onTreeNodeClicked: (treeNode) => true,
                        children: [
                            { id: '13', text: 'Sub-Child 1' },
                            { id: '14', text: 'Sub-Child 2' },
                        ],
                    },
                ],
            },
            {
                id: '15',
                text: 'Parent 3',
                onTreeNodeClicked: (treeNode) => true,
                children: [
                    { id: '16', text: 'Child 1' },
                    { id: '17', text: 'Child 2' },
                ],
            },
            { id: '18', text: 'Parent 4', onTreeNodeClicked: (treeNode) => true },
        ];
    }
}

class ClBreadCrumbService {
    constructor() {
        this.pageTitle = new BehaviorSubject('');
        this.breadcrumbString = new BehaviorSubject('');
        this.breadcrumbActionButtons = new BehaviorSubject([]);
    }
    /**
     * this function will set the page title and replace it with breadcrumb
     *
     * @param value title of the page
     */
    setPageTitle(value) {
        this.pageTitle.next(value);
    }
    /**
     * this function will reset the page title
     */
    resetPageTitle() {
        this.pageTitle.next('');
    }
    /**
     * this function will add a custom string at the end of breadcrumb
     *
     * @param string to be added
     */
    setBreadCrumbString(value) {
        this.breadcrumbString.next(value);
    }
    /**
     * this function will reset the custom string
     */
    resetBreadCrumbString() {
        this.breadcrumbString.next('');
    }
    /**
     * this function will add action buttons at the extreme end of breadcrumb row
     *
     * @param button properties
     */
    setBreadCrumbActionButtons(actionButtons) {
        this.breadcrumbActionButtons.next(actionButtons);
    }
    /**
     * this function will reset the action buttons
     */
    resetBreadCrumbActionButtons() {
        this.breadcrumbActionButtons.next([]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class ClBreadcrumbComponent {
    constructor(router, activatedRoute, breadCrumbService) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.breadCrumbService = breadCrumbService;
        this.pageTitle = '';
        this.breadcrumbString = '';
        this.breadcrumbActionButtons = [];
        this.breadcrumbs = this._buildBreadcrumbs(this.activatedRoute.root);
    }
    ngOnInit() {
        this.router.events
            .pipe(filter(event => event instanceof NavigationEnd))
            .subscribe(() => {
            this.breadcrumbs = this._buildBreadcrumbs(this.activatedRoute.root);
        });
    }
    ngAfterViewInit() {
        this.breadCrumbService.pageTitle.subscribe((value) => {
            this.pageTitle = value;
        });
        this.breadCrumbService.breadcrumbString.subscribe((value) => {
            this.breadcrumbString = value;
        });
        this.breadCrumbService.breadcrumbActionButtons.subscribe((buttons) => {
            this.breadcrumbActionButtons = buttons;
        });
    }
    _buildBreadcrumbs(activatedRoute, url = "") {
        const children = activatedRoute.children;
        if (children.length === 0) {
            return [];
        }
        let breadcrumbs = [];
        for (const child of children) {
            const routeData = child.snapshot.data;
            const urlSegment = child.snapshot.url.map((segment) => segment.path).join("/");
            if (urlSegment !== "") {
                url += `/${urlSegment}`;
                breadcrumbs.push({
                    route: url,
                    urlSegment: urlSegment,
                    label: routeData['breadcrumb'],
                    clickable: routeData['clickable'] ?? true,
                });
            }
            // if (routeData['multipleRoute']) {
            //   url += `/${urlSegment}`;
            // }
            // if (routeData['multipleRoute']) {
            // }
            breadcrumbs = breadcrumbs.concat(this._buildBreadcrumbs(child, url));
        }
        return breadcrumbs;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadcrumbComponent, deps: [{ token: i1$1.Router }, { token: i1$1.ActivatedRoute }, { token: ClBreadCrumbService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClBreadcrumbComponent, isStandalone: true, selector: "cl-breadcrumb", ngImport: i0, template: "<div class=\"flex items-center justify-between\">\n  <ul id=\"breadcrumb\" class=\"gap-1\">\n\n    @if (breadcrumbs.length > 1 && pageTitle.length <= 0) { <mat-icon [svgIcon]=\"'fss_icons:breadcrumb-home'\"\n      class=\"icon-size-4 text-neutral-700 dark:text-white\">\n      </mat-icon>\n      }\n\n      @if(breadcrumbs.length > 1 && pageTitle.length <= 0){ <ng-container>\n        @for (breadcrumb of breadcrumbs; track breadcrumb) {\n        <li class=\"gap-1 {{breadcrumb.clickable ? '' : 'link-disabled'}}\">\n\n          @if (breadcrumbs.length > 1) {\n          <mat-icon [svgIcon]=\"'fss_icons:chevron-left'\" class=\"icon-size-4 text-neutral-600 dark:text-white\">\n          </mat-icon>\n          }\n\n          <mat-label [routerLink]=\"breadcrumb.clickable ? breadcrumb.route : undefined\"\n            class=\"{{breadcrumbs.length > 1 ? '' : 'text-xl font-semibold leading-8 text-neutral-900 dark:text-neutral-50'}}\">\n            {{breadcrumb.label || breadcrumb.urlSegment}}\n          </mat-label>\n        </li>\n        }\n\n        </ng-container>\n        }\n\n        @if (pageTitle.length > 0) {\n        <ng-container>\n          <li class=\"gap-1\" class=\"link-disabled\">\n            <mat-label class=\"text-xl font-semibold leading-8 text-neutral-900 dark:text-neutral-50\">\n              {{pageTitle}}\n            </mat-label>\n          </li>\n        </ng-container>\n        }\n\n        @if (breadcrumbString) {\n        <li>\n          <mat-icon [svgIcon]=\"'fss_icons:chevron-left'\" class=\"icon-size-4 text-neutral-600 dark:text-white\">\n          </mat-icon>\n          <mat-label>{{breadcrumbString}}</mat-label>\n        </li>\n        }\n  </ul>\n\n  @if (breadcrumbActionButtons.length > 0) {\n  <div class=\"flex gap-2\">\n    @for (action of breadcrumbActionButtons; track action) {\n    <ng-container>\n      <cl-button [properties]=\"action\"></cl-button>\n    </ng-container>\n    }\n  </div>\n  }\n</div>\n", styles: ["ul{display:flex;flex-direction:row;align-items:center}li{display:flex;list-style-type:none;flex-direction:row;align-items:center}li:last-child{font-size:1rem;font-weight:700;line-height:2.25rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}li:last-child:is(.dark *){--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}li:not(:last-child){cursor:pointer;font-size:.875rem;font-weight:500;line-height:1.5rem;--tw-text-opacity: 1;color:rgba(var(--cl-primary-rgb),var(--tw-text-opacity))}li:not(:last-child):is(.dark *){--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}.link-disabled{cursor:default!important;font-size:.875rem!important;font-weight:500!important;line-height:2.25rem!important;--tw-text-opacity: 1 !important;color:rgb(23 23 23 / var(--tw-text-opacity))!important}.link-disabled:is(.dark *){--tw-text-opacity: 1 !important;color:rgb(250 250 250 / var(--tw-text-opacity))!important}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i1$1.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-breadcrumb', standalone: true, imports: [MatFormFieldModule, MatIconModule, ClButtonComponent, RouterModule], template: "<div class=\"flex items-center justify-between\">\n  <ul id=\"breadcrumb\" class=\"gap-1\">\n\n    @if (breadcrumbs.length > 1 && pageTitle.length <= 0) { <mat-icon [svgIcon]=\"'fss_icons:breadcrumb-home'\"\n      class=\"icon-size-4 text-neutral-700 dark:text-white\">\n      </mat-icon>\n      }\n\n      @if(breadcrumbs.length > 1 && pageTitle.length <= 0){ <ng-container>\n        @for (breadcrumb of breadcrumbs; track breadcrumb) {\n        <li class=\"gap-1 {{breadcrumb.clickable ? '' : 'link-disabled'}}\">\n\n          @if (breadcrumbs.length > 1) {\n          <mat-icon [svgIcon]=\"'fss_icons:chevron-left'\" class=\"icon-size-4 text-neutral-600 dark:text-white\">\n          </mat-icon>\n          }\n\n          <mat-label [routerLink]=\"breadcrumb.clickable ? breadcrumb.route : undefined\"\n            class=\"{{breadcrumbs.length > 1 ? '' : 'text-xl font-semibold leading-8 text-neutral-900 dark:text-neutral-50'}}\">\n            {{breadcrumb.label || breadcrumb.urlSegment}}\n          </mat-label>\n        </li>\n        }\n\n        </ng-container>\n        }\n\n        @if (pageTitle.length > 0) {\n        <ng-container>\n          <li class=\"gap-1\" class=\"link-disabled\">\n            <mat-label class=\"text-xl font-semibold leading-8 text-neutral-900 dark:text-neutral-50\">\n              {{pageTitle}}\n            </mat-label>\n          </li>\n        </ng-container>\n        }\n\n        @if (breadcrumbString) {\n        <li>\n          <mat-icon [svgIcon]=\"'fss_icons:chevron-left'\" class=\"icon-size-4 text-neutral-600 dark:text-white\">\n          </mat-icon>\n          <mat-label>{{breadcrumbString}}</mat-label>\n        </li>\n        }\n  </ul>\n\n  @if (breadcrumbActionButtons.length > 0) {\n  <div class=\"flex gap-2\">\n    @for (action of breadcrumbActionButtons; track action) {\n    <ng-container>\n      <cl-button [properties]=\"action\"></cl-button>\n    </ng-container>\n    }\n  </div>\n  }\n</div>\n", styles: ["ul{display:flex;flex-direction:row;align-items:center}li{display:flex;list-style-type:none;flex-direction:row;align-items:center}li:last-child{font-size:1rem;font-weight:700;line-height:2.25rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}li:last-child:is(.dark *){--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}li:not(:last-child){cursor:pointer;font-size:.875rem;font-weight:500;line-height:1.5rem;--tw-text-opacity: 1;color:rgba(var(--cl-primary-rgb),var(--tw-text-opacity))}li:not(:last-child):is(.dark *){--tw-text-opacity: 1;color:rgb(250 250 250 / var(--tw-text-opacity))}.link-disabled{cursor:default!important;font-size:.875rem!important;font-weight:500!important;line-height:2.25rem!important;--tw-text-opacity: 1 !important;color:rgb(23 23 23 / var(--tw-text-opacity))!important}.link-disabled:is(.dark *){--tw-text-opacity: 1 !important;color:rgb(250 250 250 / var(--tw-text-opacity))!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.Router }, { type: i1$1.ActivatedRoute }, { type: ClBreadCrumbService }] });

class DatePickerService {
    constructor() {
        this.dataSubject = new BehaviorSubject$1({});
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root'
                }]
        }], ctorParameters: () => [] });

class DatePickerHeaderComponent {
    constructor(datePipe, cdr, calendar, _dateAdapter, datepickerService, _dateFormats) {
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.calendar = calendar;
        this._dateAdapter = _dateAdapter;
        this.datepickerService = datepickerService;
        this._dateFormats = _dateFormats;
        this._destroyed = new Subject();
        this.range = false;
        this.toLabel = 'To';
        this.fromLabel = 'From';
        this.displayFormat = 'dd MMM YY';
        this.endDate = '--/--/--';
        this.endDateTime = '00 hr: 00 min';
        this.startDate = '--/--/--';
        this.startDateTime = '00 hr: 00 min';
        this.showTime = true;
        this.showYearAndMonth = false;
        calendar.stateChanges.pipe(takeUntil(this._destroyed)).subscribe(() => cdr.markForCheck());
        this.subscription = this.datepickerService.dataSubject.subscribe((value) => {
            this.parseData(value);
        });
    }
    /** Handles user clicks on the period label. */
    currentPeriodClicked() {
        if (this.showYearAndMonth) {
            this.calendar.currentView = 'multi-year';
            return;
        }
        this.calendar.currentView = this.calendar.currentView == 'month' ? 'multi-year' : 'month';
    }
    /** Handles user clicks on the previous button. */
    customPrev() {
        if (this.showYearAndMonth) {
            this.calendar.activeDate = this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
        }
        else {
            let mode = 'month';
            this.calendar.activeDate =
                mode === 'month'
                    ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, -1)
                    : this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
        }
    }
    /** Handles user clicks on the next button. */
    customNext() {
        if (this.showYearAndMonth) {
            this.calendar.activeDate = this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
            return;
        }
        let mode = 'month';
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, 1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
    }
    // this function is triggered whenever user click on the right arrow in the date picker to switch to the previous month or year
    previousClicked(mode) {
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, -1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
    }
    // this function is triggered whenever user click on the right arrow in the date picker to switch to the next month or year
    nextClicked(mode) {
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, 1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
    }
    //this function returns the period label (month and year name)
    get periodLabel() {
        return this._dateAdapter
            .format(this.calendar.activeDate, this._dateFormats.display.monthYearLabel)
            .toLocaleUpperCase();
    }
    // this function will be triggered when ever there is a change in date or time picker
    // to display the updated value
    parseData(data) {
        this.range = data.range;
        this.showYearAndMonth = data.showOnlyMonthYear;
        if (this.range) {
            this.startDateTime = data.startDateTime;
            if (data.startDate != '' && data.startDate != null) {
                this.startDate = this.datePipe.transform(data.startDate, this.displayFormat);
            }
            else {
                this.startDate = '--/--/--';
            }
            this.endDateTime = data.endDateTime;
            if (data.endDate != '' && data.endDate != null) {
                this.endDate = this.datePipe.transform(data.endDate, this.displayFormat);
            }
            else {
                this.endDate = '--/--/--';
            }
        }
        else {
            this.startDateTime = data.startDateTime;
            if (data.startDate != '' && data.startDate != null) {
                this.startDate = this.datePipe.transform(data.startDate, this.displayFormat);
            }
            else {
                this.startDate = '--/--/--';
            }
        }
        this.showTime = data.showTime;
        this.cdr.markForCheck();
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerHeaderComponent, deps: [{ token: i1$2.DatePipe }, { token: i0.ChangeDetectorRef }, { token: i2$1.MatCalendar }, { token: i3.DateAdapter }, { token: DatePickerService }, { token: MAT_DATE_FORMATS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: DatePickerHeaderComponent, isStandalone: true, selector: "cl-date-picker-header", providers: [DatePipe], ngImport: i0, template: "<div class=\"mat-calendar-header\">\n\n  @if (range) {\n    <div class=\"flex justify-between\">\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\">\n        <label class=\"label text-neutral-800 text-xs\">From date</label>\n        <label class=\"text-base\">{{startDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{startDateTime}}</label>\n        }\n      </div>\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\" >\n        <label class=\"label text-neutral-800 text-xs\">To date</label>\n        <label class=\"text-base\">{{endDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{endDateTime}}</label>\n        }\n      </div>\n    </div>\n  }\n\n  <div class=\"mat-calendar-controls\">\n\n    <mat-icon (click)=\"customPrev()\" [svgIcon]=\"'heroicons_outline:arrow-left'\" class=\"icon-size-4 cursor-pointer\">\n    </mat-icon>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <button mat-button type=\"button\" class=\"mat-calendar-period-button\" (click)=\"currentPeriodClicked()\"\n      [attr.aria-label]=\"periodLabel\" cdkAriaLive=\"polite\">\n      {{periodLabel}}\n    </button>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <mat-icon (click)=\"customNext()\" class=\"icon-size-4 cursor-pointer\" [svgIcon]=\"'heroicons_outline:arrow-right'\">\n    </mat-icon>\n\n  </div>\n</div>\n", styles: [".mat-calendar-header .label-container{width:48%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatDatepickerModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-date-picker-header', standalone: true, imports: [MatIconModule, MatInputModule, MatDatepickerModule], providers: [DatePipe], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"mat-calendar-header\">\n\n  @if (range) {\n    <div class=\"flex justify-between\">\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\">\n        <label class=\"label text-neutral-800 text-xs\">From date</label>\n        <label class=\"text-base\">{{startDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{startDateTime}}</label>\n        }\n      </div>\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\" >\n        <label class=\"label text-neutral-800 text-xs\">To date</label>\n        <label class=\"text-base\">{{endDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{endDateTime}}</label>\n        }\n      </div>\n    </div>\n  }\n\n  <div class=\"mat-calendar-controls\">\n\n    <mat-icon (click)=\"customPrev()\" [svgIcon]=\"'heroicons_outline:arrow-left'\" class=\"icon-size-4 cursor-pointer\">\n    </mat-icon>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <button mat-button type=\"button\" class=\"mat-calendar-period-button\" (click)=\"currentPeriodClicked()\"\n      [attr.aria-label]=\"periodLabel\" cdkAriaLive=\"polite\">\n      {{periodLabel}}\n    </button>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <mat-icon (click)=\"customNext()\" class=\"icon-size-4 cursor-pointer\" [svgIcon]=\"'heroicons_outline:arrow-right'\">\n    </mat-icon>\n\n  </div>\n</div>\n", styles: [".mat-calendar-header .label-container{width:48%}\n"] }]
        }], ctorParameters: () => [{ type: i1$2.DatePipe }, { type: i0.ChangeDetectorRef }, { type: i2$1.MatCalendar }, { type: i3.DateAdapter }, { type: DatePickerService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DATE_FORMATS]
                }] }] });

class ClDatePickerStyleProperties {
}
class ClDatePickerProperties {
    constructor() {
        this.id = 'default0';
        this.label = 'Date Picker';
        this.subscriptSizing = 'fixed';
        this.type = ClComponentTypes.datePicker;
        this.style = new ClDatePickerStyleProperties();
        this.style.cssClasses = 'flex-auto w-full';
        this.style.contentWidth = 'w-full';
        this.style.justifyContent = '';
        this.style.alignContent = '';
        this.showInfoMsg = signal(false);
    }
}

class ClDatepickerComponent extends ClBaseComponent {
    constructor(ngControl, datePipe, cdr, datepickerService, overlay) {
        super();
        this.ngControl = ngControl;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.datepickerService = datepickerService;
        this.overlay = overlay;
        this.range = false;
        this.showCalendar = false;
        this.positions = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom',
            },
            {
                originX: 'center',
                originY: 'center',
                overlayX: 'start',
                overlayY: 'center',
            }
        ];
        this.scrollStrategy = this.overlay.scrollStrategies.reposition();
        this.startAt = new Date();
        this.customHeader = DatePickerHeaderComponent;
        this.singleDateSelection = { range: false, startDate: '', startDateTime: '' };
        this.multiDateSelection = { endDate: '', range: true, startDate: '', endDateTime: '', startDateTime: '' };
        this.applyButtonDisable = signal(true);
        this.applyButtonProperties = {
            label: 'Apply',
            disabled: this.applyButtonDisable,
            id: 'btnDatePickerApply',
            buttonType: IClButtonType.button,
            buttonBehavior: ClButtonBehavior.flat,
            type: ClComponentTypes.button,
            onSubmit: this.apply.bind(this),
            style: {
                cssClasses: 'apply-btn bg-primary',
                labelCssClasses: 'text-white text-base'
            },
        };
        this.cancelButtonProperties = {
            label: 'Cancel',
            id: 'btnDatePickerCancel',
            buttonType: IClButtonType.button,
            buttonBehavior: ClButtonBehavior.flat,
            type: ClComponentTypes.button,
            onSubmit: this.cancel.bind(this),
            style: {
                cssClasses: 'bg-tertiary',
                labelCssClasses: 'text-base',
            },
        };
        this.startDateHoursMinutes = new FormGroup({
            hours: new FormControl(''),
            minutes: new FormControl('')
        });
        this.endDateHoursMinutes = new FormGroup({
            hours: new FormControl(''),
            minutes: new FormControl('')
        });
        this.showEndTime = false;
        this.showStartTime = true;
        this.displayFormatWithoutTime = 'd MMM, y';
        this.displayFormatWithTime = 'd MMM, y HH:mm';
        this.selectedDate = new Date();
        this.previousRange = false;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.disableFromDate = (d) => {
            const date = d || new Date();
            const fromDate = this.properties.fromDate ? new Date(this.properties.fromDate) : null;
            if (!fromDate) {
                return ''; // If fromDate is undefined, return an empty string, no date will be disabled
            }
            return this.formatDateToYyyyMmDd(date) === this.formatDateToYyyyMmDd(fromDate) ? 'disabled-date' : '';
        };
        super.setProperties(this.properties);
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnInit() {
        this.properties ??= new ClDatePickerProperties();
        const startDateHour = this.selectedDateRange?.start ? this.selectedDateRange?.start.getHours() : 0;
        const startDateMinutes = this.selectedDateRange?.start ? this.selectedDateRange?.start.getMinutes() : 0;
        const endDateHour = this.selectedDateRange?.end ? this.selectedDateRange?.end.getHours() : 23;
        const endDateMinutes = this.selectedDateRange?.end ? this.selectedDateRange?.end.getMinutes() : 59;
        this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
        this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
        this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(endDateHour));
        this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(endDateMinutes));
        // assign the range value from the properties object
        // this.range = this.properties?.range ?  : false;
        this.setValues();
        this.properties.showTime ??= true;
        if (this.properties.fromDate || this.properties.toDate) {
            if (this.properties.fromDate) {
                this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
                this.previousFromDate = this.properties.fromDate;
            }
            if (this.properties.toDate) {
                this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
                this.previousToDate = this.properties.toDate;
            }
            this.setValues();
        }
        this.ngControl?.valueChanges?.subscribe((value) => {
            this.setValuesFromFormGroup(value);
            this.setValues();
        });
        super.ngOnInit();
    }
    ngDoCheck() {
        if (this.properties?.range !== this.previousRange) {
            if (this.properties?.range !== undefined) {
                this.previousRange = this.properties?.range;
                if (this.properties.fromDate && this.properties.fromDate != '') {
                    this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
                }
                if (this.properties.toDate && this.properties.toDate != '') {
                    this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
                }
                this.setValues();
            }
        }
        // if (this.properties.fromDate || this.properties.toDate) {
        this.updateFromAndToDate();
        if (this.previousShowTime != this.properties.showTime) {
            this.prepareHeaderDateObject();
            this.previousShowTime = this.properties.showTime;
        }
        if (this.properties.minDate != this.previousMinDate) {
            this.updateMinDate();
            this.previousMinDate = this.properties.minDate;
        }
        if (this.properties.maxDate != this.previousMaxDate) {
            this.updateMaxDate();
            this.previousMaxDate = this.properties.maxDate;
        }
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    updateFromAndToDate() {
        if (this.properties.fromDate && this.properties.fromDate != '' && this.properties.fromDate != this.previousFromDate) {
            this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
            this.previousFromDate = this.properties.fromDate;
            this.setValues();
        }
        else if (this.properties.fromDate == '' && this.properties.fromDate != this.previousFromDate) {
            this.updateMinDate();
            this.previousFromDate = this.properties.fromDate;
        }
        if (this.properties.toDate && this.properties.toDate != '' && this.properties.toDate != this.previousToDate) {
            this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
            this.previousToDate = this.properties.toDate;
            this.setValues();
        }
        else if (this.properties.toDate == '' && this.properties.toDate != this.previousToDate) {
            this.updateMaxDate();
            this.previousToDate = this.properties.toDate;
        }
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    setValuesFromFormGroup(value) {
        if (this.properties.range) {
            //split the date with '-'
            if (value != undefined) {
                let selectedDates = value.split('-');
                const startDate = new Date(selectedDates[0]);
                const endDate = new Date(selectedDates[1]);
                this.selectedDateRange = new DateRange(startDate, endDate);
            }
        }
        else {
            this.selectedDate = new Date(value);
        }
    }
    formatDateToYyyyMmDd(date) {
        if (!date)
            return '';
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    setValuesFromFormGroupStart(value, dateKey) {
        if (this.properties.range) {
            //split the date with '-'
            const dateValue = new Date(value);
            if (dateKey == 'startDate') {
                this.selectedDateRange = new DateRange(dateValue, null);
                this.updateMinDate();
            }
            else if (dateKey == 'endDate') {
                this.selectedDateRange = new DateRange(null, dateValue);
                this.updateMaxDate();
            }
        }
        else {
            this.selectedDate = new Date(value);
        }
    }
    updateMinDate() {
        if (this.properties.minDate) {
            const parsedDate = new Date(this.properties.minDate);
            if (!isNaN(parsedDate.getTime())) {
                this.minDate = parsedDate;
            }
            else {
                this.minDate = null;
            }
        }
        else if (this.properties.fromDate && this.properties.fromDate != '') {
            this.minDate = new Date(this.properties.fromDate);
        }
        else {
            this.minDate = null;
        }
    }
    updateMaxDate() {
        if (this.properties.maxDate) {
            const parsedDate = new Date(this.properties.maxDate);
            if (!isNaN(parsedDate.getTime())) {
                this.maxDate = parsedDate;
            }
            else {
                this.maxDate = null;
            }
        }
        else if (this.properties.toDate && this.properties.toDate != '') {
            this.maxDate = new Date(this.properties.toDate);
        }
        else {
            this.maxDate = null;
        }
    }
    setValues() {
        if (this.properties.range) {
            const startDateHour = this.selectedDateRange?.start ? this.selectedDateRange?.start.getHours() : 0;
            const startDateMinutes = this.selectedDateRange?.start ? this.selectedDateRange?.start.getMinutes() : 0;
            const endDateHour = this.selectedDateRange?.end ? this.selectedDateRange?.end.getHours() : 23;
            const endDateMinutes = this.selectedDateRange?.end ? this.selectedDateRange?.end.getMinutes() : 59;
            this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
            this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
            this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(endDateHour));
            this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(endDateMinutes));
        }
        else {
            const startDateHour = this.selectedDate ? this.selectedDate.getHours() : 0;
            const startDateMinutes = this.selectedDate ? this.selectedDate.getMinutes() : 0;
            this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
            this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
        }
        //sending the header obj to datepicker header
        this.prepareHeaderDateObject();
    }
    // this function is triggered on the opening the calendar panel
    openCalendar() {
        const scrollableDiv = document.getElementById('scrollableDiv');
        if (scrollableDiv) {
            scrollableDiv.scrollTo({
                left: 0, // Scroll to the very left
                behavior: 'smooth' // Smooth scrolling animation
            });
            // Delay opening the calendar slightly to ensure scrolling completes
            setTimeout(() => {
                // this.openCalendarAfterScroll();
                this.showCalendar = !this.showCalendar;
            }, 300); // Adjust timeout based on expected scroll duration
        }
        else {
            // If no scrolling is needed, directly open the calendar
            // this.openCalendarAfterScroll();
            this.showCalendar = !this.showCalendar;
        }
    }
    openCalendarAfterScroll() {
        // if (this.customDatePicker) {
        //   const { left, right, bottom } = this.customDatePicker.nativeElement.getBoundingClientRect();
        //   this.datePickerLeft = left;
        //   this.datePickerTop = bottom - 20;
        // } else {
        //   this.datePickerLeft = screen.availWidth / 2;
        //   this.datePickerTop = screen.availHeight / 2 - 20;
        // }
        // Show the calendar after positioning
        this.showCalendar = true;
    }
    closeCalendar() {
        this.showCalendar = false;
    }
    dateChange(date) {
        if (this.properties.range) {
            if (this.selectedDateRange && this.selectedDateRange.start && date >= this.selectedDateRange.start && !this.selectedDateRange.end) {
                // this.applyButtonProperties.disabled = false;
                // this.applyButtonDisable.set(false);
                this.selectedDateRange = new DateRange(this.selectedDateRange.start, date);
                this.showEndTime = true;
                this.showStartTime = false;
            }
            else {
                // this.applyButtonProperties.disabled = true;
                // this.applyButtonDisable.set(true);
                this.showEndTime = false;
                this.showStartTime = true;
                if (this.properties.fromDate) {
                    // this.applyButtonDisable.set(false);
                    this.selectedDateRange = new DateRange(new Date(this.properties.fromDate), date);
                    this.showEndTime = true;
                    this.showStartTime = false;
                }
                else {
                    if (this.properties.toDate) {
                        this.selectedDateRange = new DateRange(date, new Date(this.properties.toDate));
                    }
                    else {
                        this.selectedDateRange = new DateRange(date, null);
                    }
                    // this.applyButtonDisable.set(false);
                }
            }
            if (this.selectedDateRange && this.selectedDateRange.start && this.selectedDateRange.end) {
                this.applyButtonDisable.set(false);
            }
            else {
                this.applyButtonDisable.set(true);
            }
        }
        else {
            this.selectedDate = date;
            // this.applyButtonProperties.disabled = false;
            this.applyButtonDisable.set(false);
            this.showStartTime = true;
            this.showEndTime = false;
        }
        this.prepareHeaderDateObject();
    }
    decreaseMins(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.minutes.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.minutes.value);
        }
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    increaseMins(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.minutes.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.minutes.value);
        }
        if (currentValue >= 59) {
            currentValue = 59;
        }
        else {
            currentValue++;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    increaseHours(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.hours.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.hours.value);
        }
        if (currentValue >= 23) {
            currentValue = 23;
        }
        else {
            currentValue++;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    decreaseHours(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.hours.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.hours.value);
        }
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    convertTwoDigitNumber(currentValue) {
        let convertString = currentValue.toString();
        return convertString.padStart(2, '0');
    }
    // function to prepare the header object to send to the header component
    prepareHeaderDateObject() {
        let obj;
        if (this.properties.range) {
            let endHours, endMins, startHours, startMins;
            obj = Object.assign({}, this.multiDateSelection);
            endHours = this.endDateHoursMinutes.controls.hours.value;
            endMins = this.endDateHoursMinutes.controls.minutes.value;
            startHours = this.startDateHoursMinutes.controls.hours.value;
            startMins = this.startDateHoursMinutes.controls.minutes.value;
            obj.startDate = this.selectedDateRange?.start ? this.selectedDateRange.start : null;
            obj.endDate = this.selectedDateRange?.end ? this.selectedDateRange.end : null;
            obj.endDateTime = endHours + ' hr:' + endMins + ' min';
            obj.startDateTime = startHours + ' hr:' + startMins + ' min';
            obj.range = this.properties.range;
        }
        else {
            let startHours, startMins;
            startHours = this.startDateHoursMinutes.controls.hours.value;
            startMins = this.startDateHoursMinutes.controls.minutes.value;
            obj = Object.assign({}, this.singleDateSelection);
            obj.startDate = this.selectedDateRange ? this.selectedDateRange : null;
            obj.startDateTime = startHours + ' hr:' + startMins + ' min';
            // range should be false
            obj.range = false;
        }
        obj.showTime = this.properties.showTime;
        this.previousShowTime = this.properties.showTime;
        obj.showOnlyMonthYear = this.properties.showOnlyMonthYear ? this.properties.showOnlyMonthYear : false;
        this.sendChangesToHeader(obj);
    }
    // this function gets triggered when the user clicks on the apply button
    apply() {
        let selectedDate, value;
        let format = this.properties.showTime ? this.displayFormatWithTime : this.displayFormatWithoutTime;
        format = (this.properties.format && this.properties.format != '') ? this.properties.format : format;
        if (this.properties.range) {
            let startTimeHours, startTimeMinutes, endTimeHours, endTimeMinutes;
            startTimeHours = Number(this.startDateHoursMinutes.controls['hours'].value);
            startTimeMinutes = Number(this.startDateHoursMinutes.controls['minutes'].value);
            endTimeHours = Number(this.endDateHoursMinutes.controls['hours'].value);
            endTimeMinutes = Number(this.endDateHoursMinutes.controls['minutes'].value);
            selectedDate = new DateRange(this.getSelectedDateAndTime(this.selectedDateRange.start, startTimeHours, startTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0), this.getSelectedDateAndTime(this.selectedDateRange.end, endTimeHours, endTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0));
            const startDate = this.datePipe.transform(selectedDate.start, format);
            const endDate = this.datePipe.transform(selectedDate?.end, format);
            value = startDate + ' - ' + endDate;
        }
        else {
            let startTimeHours, startTimeMinutes;
            startTimeHours = isNaN(Number(this.startDateHoursMinutes.controls['hours'].value)) ? 0 : Number(this.startDateHoursMinutes.controls['hours'].value);
            startTimeMinutes = isNaN(Number(this.startDateHoursMinutes.controls['minutes'].value)) ? 0 : Number(this.startDateHoursMinutes.controls['minutes'].value);
            if (this.properties.showOnlyMonthYear) {
                selectedDate = this.selectedDate;
            }
            else {
                selectedDate = new Date(this.getSelectedDateAndTime(this.selectedDate, startTimeHours, startTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0));
            }
            const startDate = this.datePipe.transform(selectedDate, format);
            value = startDate;
        }
        this.writeValue(value);
        this.onChange(this._value);
        this.showCalendar = false;
        if (this.properties.onValueChange !== undefined) {
            this.properties.onValueChange(value);
        }
    }
    getSelectedDateAndTime(date, hours, minutes) {
        const month = date.getMonth(); //months from 1-12
        const day = date.getDate();
        const year = date.getFullYear();
        return new Date(year, month, day, hours, minutes);
    }
    // this function is triggered on the click of the cancel button
    cancel() {
        this.showCalendar = false;
        let value = this.ngControl.value;
        if (value != undefined && value != '') {
            this.setValuesFromFormGroup(value);
            this.setValues();
        }
    }
    // function to send the changes to the date picker header component
    sendChangesToHeader(obj) {
        this.datepickerService.dataSubject.next(obj);
    }
    // this function is triggered when there is any change in the startTime hours Input
    startTimeHoursInputValueChanges(event) {
        const currentHoursValue = Number(event.target.value);
        if (currentHoursValue >= 23) {
            this.startDateHoursMinutes.controls['hours'].setValue('23');
        }
        else if (currentHoursValue <= 0) {
            this.startDateHoursMinutes.controls['hours'].setValue('');
        }
        else {
            this.startDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? currentHoursValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of startTime hours Input
    startTimeHoursInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.startDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the startTime minutes Input
    startTimeMinutesInputValueChanges(event) {
        const currentMinutesValue = Number(event.target.value);
        if (currentMinutesValue <= 0) {
            this.startDateHoursMinutes.controls['minutes'].setValue('');
        }
        else if (currentMinutesValue >= 59) {
            this.startDateHoursMinutes.controls['minutes'].setValue('59');
        }
        else {
            this.startDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentMinutesValue) ? currentMinutesValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of startTime mins Input
    startTimeMinutesInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.startDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the endTime hours Input
    endTimeHoursInputValueChanges(event) {
        const currentHoursValue = Number(event.target.value);
        if (currentHoursValue >= 23) {
            this.endDateHoursMinutes.controls['hours'].setValue('23');
        }
        else if (currentHoursValue <= 0) {
            this.endDateHoursMinutes.controls['hours'].setValue('');
        }
        else {
            this.endDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? currentHoursValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of endTime Hours Input
    endTimeHoursInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.endDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the endTime mins Input
    endTimeMinutesInputValueChanges(event) {
        const currentMinutesValue = Number(event.target.value);
        if (currentMinutesValue <= 0) {
            this.endDateHoursMinutes.controls['minutes'].setValue('');
        }
        else if (currentMinutesValue >= 59) {
            this.endDateHoursMinutes.controls['minutes'].setValue('59');
        }
        else {
            this.endDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentMinutesValue) ? currentMinutesValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of endTime mins Input
    endTimeMinutesInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.endDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    getErrorMessage() {
        if (this.properties.optional) {
            return null;
        }
    }
    monthSelected(ev, matCalendar) {
        let year = ev.getFullYear();
        let month = ev.getMonth();
        let value = new Date();
        value.setFullYear(year);
        value.setMonth(month);
        this.selectedDate = value;
        matCalendar.selected = value;
        // this.applyButtonProperties.disabled = false;
        this.applyButtonDisable.set(false);
        this.cdr.detach();
    }
    viewChangedHandler(ev, matCalendar) {
        if (ev == 'month') {
            matCalendar.currentView = 'year';
        }
        this.cdr.reattach();
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    clearSelection() {
        this.writeValue('');
        this.onChange('');
        this.showCalendar = false;
        this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(0));
        this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(0));
        this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(23));
        this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(59));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDatepickerComponent, deps: [{ token: i1$3.NgControl, optional: true, self: true }, { token: i1$2.DatePipe }, { token: i0.ChangeDetectorRef }, { token: DatePickerService }, { token: i4$1.Overlay }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDatepickerComponent, isStandalone: true, selector: "cl-datepicker", inputs: { properties: "properties" }, providers: [DatePipe,
            { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
        ], viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }, { propertyName: "matIcons", predicate: ["mat-icon"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\">\n  <mat-form-field [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"{{ properties.style?.cssClasses }}\" subscriptSizing=\"dynamic\" cdkOverlayOrigin\n    #customDatePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\" [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\">\n\n    @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"cursor-pointer\" [svgIcon]=\"properties.prefixIcon\">\n    </mat-icon>\n    }\n\n    @if (properties.optional && value != '') {\n      <mat-icon class=\"cl-datepicker-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n    }\n\n    <mat-icon matSuffix (click)=\"openCalendar()\" class=\"cursor-pointer\"\n      [svgIcon]=\"properties.suffixIcon ?? 'heroicons_outline:calendar'\">\n    </mat-icon>\n  </mat-form-field>\n\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"customDatePicker\"\n  [cdkConnectedOverlayOpen]=\"showCalendar\"\n  [cdkConnectedOverlayPositions]=\"positions\"\n  [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n  (backdropClick)=\"closeCalendar()\"\n  [cdkConnectedOverlayHasBackdrop]=\"true\">\n\n  <mat-card class=\"overlay-content\">\n    <mat-calendar #matCalendar [headerComponent]=\"customHeader\" [startAt]=\"selectedDate\" [minDate]=\"minDate || null\"\n      [maxDate]=\"maxDate || null\" (selectedChange)=\"dateChange($event)\"\n      [startView]=\"properties.startView ? properties.startView : 'month'\"\n      [selected]=\"properties.range ? selectedDateRange: selectedDate\" [dateClass]=\"disableFromDate\"\n      (monthSelected)=\"properties.showOnlyMonthYear ? monthSelected($event, matCalendar) : null\"\n      (viewChanged)=\"properties.showOnlyMonthYear ? viewChangedHandler($event, matCalendar) : null\">\n    </mat-calendar>\n\n    <div class=\"time-container px-4 pb-4 pt-3\">\n      @if (showStartTime && properties.showTime) {\n      <form [formGroup]=\"startDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input matInput class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"startTimeHoursInputValueChanges($event)\"\n              (blur)=\"startTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"startTimeMinutesInputValueChanges($event)\"\n              (blur)=\"startTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      @if (showEndTime && properties.showTime) {\n      <form [formGroup]=\"endDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"endTimeHoursInputValueChanges($event)\"\n              (blur)=\"endTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"endTimeMinutesInputValueChanges($event)\"\n              (blur)=\"endTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      <div class=\"flex justify-between datepicker-buttonsdiv pt-3 border-neutral-200\">\n        <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button>\n      </div>\n\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-date-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-date-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.mat-calendar{width:300px}.mat-calendar-content{padding:8px 16px!important}.hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-cell-content{font-size:.875rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-in-range:before{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-100-rgb),var(--tw-bg-opacity))!important}.datepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity))}.mat-calendar-period-button{font-size:1.125rem;font-weight:600;--tw-text-opacity: 1;color:rgb(0 0 0 / var(--tw-text-opacity))}.hoursInput{width:40px!important}.mat-calendar-body-selected{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-400-rgb),var(--tw-bg-opacity))!important}.mat-datepicker-actions{display:block!important}.matdatepicker-cancel{--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.disabled-date{pointer-events:none;opacity:.5}.cl-datepicker-clear-icon{position:absolute;right:3rem;cursor:pointer;width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.cl-datepicker-clear-icon svg{width:1.25rem;height:1.25rem}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1$3.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1$3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1$3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1$3.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1$3.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1$3.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i8.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i8.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i2$1.MatCalendar, selector: "mat-calendar", inputs: ["headerComponent", "startAt", "startView", "selected", "minDate", "maxDate", "dateFilter", "dateClass", "comparisonStart", "comparisonEnd", "startDateAccessibleName", "endDateAccessibleName"], outputs: ["selectedChange", "yearSelected", "monthSelected", "viewChanged", "_userSelection", "_userDragDrop"], exportAs: ["matCalendar"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1$3.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1$3.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i4$1.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i4$1.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDatepickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, providers: [DatePipe,
                        { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
                    ], selector: 'cl-datepicker', encapsulation: ViewEncapsulation.None, imports: [
                        FormsModule,
                        MatCardModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        MatDatepickerModule,
                        ReactiveFormsModule,
                        MatNativeDateModule,
                        ClButtonComponent,
                        OverlayModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\">\n  <mat-form-field [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"{{ properties.style?.cssClasses }}\" subscriptSizing=\"dynamic\" cdkOverlayOrigin\n    #customDatePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\" [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\">\n\n    @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"cursor-pointer\" [svgIcon]=\"properties.prefixIcon\">\n    </mat-icon>\n    }\n\n    @if (properties.optional && value != '') {\n      <mat-icon class=\"cl-datepicker-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n    }\n\n    <mat-icon matSuffix (click)=\"openCalendar()\" class=\"cursor-pointer\"\n      [svgIcon]=\"properties.suffixIcon ?? 'heroicons_outline:calendar'\">\n    </mat-icon>\n  </mat-form-field>\n\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"customDatePicker\"\n  [cdkConnectedOverlayOpen]=\"showCalendar\"\n  [cdkConnectedOverlayPositions]=\"positions\"\n  [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n  (backdropClick)=\"closeCalendar()\"\n  [cdkConnectedOverlayHasBackdrop]=\"true\">\n\n  <mat-card class=\"overlay-content\">\n    <mat-calendar #matCalendar [headerComponent]=\"customHeader\" [startAt]=\"selectedDate\" [minDate]=\"minDate || null\"\n      [maxDate]=\"maxDate || null\" (selectedChange)=\"dateChange($event)\"\n      [startView]=\"properties.startView ? properties.startView : 'month'\"\n      [selected]=\"properties.range ? selectedDateRange: selectedDate\" [dateClass]=\"disableFromDate\"\n      (monthSelected)=\"properties.showOnlyMonthYear ? monthSelected($event, matCalendar) : null\"\n      (viewChanged)=\"properties.showOnlyMonthYear ? viewChangedHandler($event, matCalendar) : null\">\n    </mat-calendar>\n\n    <div class=\"time-container px-4 pb-4 pt-3\">\n      @if (showStartTime && properties.showTime) {\n      <form [formGroup]=\"startDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input matInput class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"startTimeHoursInputValueChanges($event)\"\n              (blur)=\"startTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"startTimeMinutesInputValueChanges($event)\"\n              (blur)=\"startTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      @if (showEndTime && properties.showTime) {\n      <form [formGroup]=\"endDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"endTimeHoursInputValueChanges($event)\"\n              (blur)=\"endTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"endTimeMinutesInputValueChanges($event)\"\n              (blur)=\"endTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      <div class=\"flex justify-between datepicker-buttonsdiv pt-3 border-neutral-200\">\n        <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button>\n      </div>\n\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-date-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-date-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.mat-calendar{width:300px}.mat-calendar-content{padding:8px 16px!important}.hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-cell-content{font-size:.875rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-in-range:before{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-100-rgb),var(--tw-bg-opacity))!important}.datepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity))}.mat-calendar-period-button{font-size:1.125rem;font-weight:600;--tw-text-opacity: 1;color:rgb(0 0 0 / var(--tw-text-opacity))}.hoursInput{width:40px!important}.mat-calendar-body-selected{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-400-rgb),var(--tw-bg-opacity))!important}.mat-datepicker-actions{display:block!important}.matdatepicker-cancel{--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.disabled-date{pointer-events:none;opacity:.5}.cl-datepicker-clear-icon{position:absolute;right:3rem;cursor:pointer;width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.cl-datepicker-clear-icon svg{width:1.25rem;height:1.25rem}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1$3.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i1$2.DatePipe }, { type: i0.ChangeDetectorRef }, { type: DatePickerService }, { type: i4$1.Overlay }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], matIcons: [{
                type: ViewChildren,
                args: ['mat-icon']
            }] } });

class ClNestedLayoutChildComponent {
    constructor() {
        this.nestedLayoutChildContents = [];
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.nestedLayoutChildContents = this.nestedLayoutChildContentItems.toArray();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutChildComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedLayoutChildComponent, isStandalone: true, selector: "cl-nested-layout-child", inputs: { properties: "properties" }, queries: [{ propertyName: "nestedLayoutChildContentItems", predicate: ClNestedLayoutChildComponent }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clNestedLayoutChild>\n  <div class=\"-ml-1 flex w-full flex-col\">\n    <div class=\"flex flex-col w-full {{ properties?.cssClasses }}\">\n      <ng-content></ng-content>\n\n      @for (nestedChildLayout of nestedLayoutChildContents; track nestedChildLayout; let nestedChildLayoutIndex = $index) {\n        <div class=\"flex connector\">\n          <div class=\"z-10 size-2 mt-[21px] rotate-45 bg-primary text-primary\"></div>\n          <ng-container *ngTemplateOutlet=\"nestedChildLayout.contentTemplate\"></ng-container>\n        </div>\n      }\n    </div>\n\n    @if (properties?.addButtonProperties) {\n      <cl-button class=\"my-4\" [properties]=\"properties!.addButtonProperties!\"></cl-button>\n    }\n  </div>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutChildComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-layout-child', imports: [
                        CommonModule,
                        NgTemplateOutlet,
                        ClButtonComponent
                    ], template: "<ng-template #clNestedLayoutChild>\n  <div class=\"-ml-1 flex w-full flex-col\">\n    <div class=\"flex flex-col w-full {{ properties?.cssClasses }}\">\n      <ng-content></ng-content>\n\n      @for (nestedChildLayout of nestedLayoutChildContents; track nestedChildLayout; let nestedChildLayoutIndex = $index) {\n        <div class=\"flex connector\">\n          <div class=\"z-10 size-2 mt-[21px] rotate-45 bg-primary text-primary\"></div>\n          <ng-container *ngTemplateOutlet=\"nestedChildLayout.contentTemplate\"></ng-container>\n        </div>\n      }\n    </div>\n\n    @if (properties?.addButtonProperties) {\n      <cl-button class=\"my-4\" [properties]=\"properties!.addButtonProperties!\"></cl-button>\n    }\n  </div>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input
            }], contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], nestedLayoutChildContentItems: [{
                type: ContentChildren,
                args: [ClNestedLayoutChildComponent]
            }] } });

class ClNestedLayoutParentComponent {
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.nestedLayoutChildContents = this.nestedLayoutChildContentItems;
        });
    }
    ngAfterViewInit() { }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutParentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedLayoutParentComponent, isStandalone: true, selector: "cl-nested-layout-parent", queries: [{ propertyName: "nestedLayoutChildContentItems", predicate: ClNestedLayoutChildComponent }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clNestedLayoutParent>\n  <div class=\"flex w-full flex-col\">\n    <ng-content></ng-content>\n\n    @for (nestedChildLayout of nestedLayoutChildContents; track nestedChildLayout) {\n      <div class=\"flex connector\">\n        <div class=\"z-10 size-2 mt-[21px] rotate-45 bg-primary text-primary\"></div>\n        <ng-container *ngTemplateOutlet=\"nestedChildLayout.contentTemplate\"></ng-container>\n      </div>\n    }\n  </div>\n</ng-template>\n", dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutParentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-layout-parent', imports: [
                        NgTemplateOutlet,
                        ClButtonComponent,
                    ], template: "<ng-template #clNestedLayoutParent>\n  <div class=\"flex w-full flex-col\">\n    <ng-content></ng-content>\n\n    @for (nestedChildLayout of nestedLayoutChildContents; track nestedChildLayout) {\n      <div class=\"flex connector\">\n        <div class=\"z-10 size-2 mt-[21px] rotate-45 bg-primary text-primary\"></div>\n        <ng-container *ngTemplateOutlet=\"nestedChildLayout.contentTemplate\"></ng-container>\n      </div>\n    }\n  </div>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], nestedLayoutChildContentItems: [{
                type: ContentChildren,
                args: [ClNestedLayoutChildComponent]
            }] } });

class ClNestedLayoutStyleProperties {
}
class ClNestedLayoutProperties {
    constructor() {
        this.id = 'default0';
        this.type = ClComponentTypes.nestedLayout;
        this.style = new ClNestedLayoutStyleProperties();
        this.style.cssClasses = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
    }
}

class ClNestedLayoutComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.nestedLayoutParentContents = [];
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        // calling set default properties function
        this.properties ??= new ClNestedLayoutProperties();
        this.setButtonProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.nestedLayoutParentContents = this.nestedLayoutParentContentItems.toArray();
        });
    }
    setButtonProperties() {
        if (this.properties.addButtonProperties === undefined) {
            this.properties.addButtonProperties = new ClButtonProperties();
            this.properties.addButtonProperties.label = 'Add New Parent';
            this.properties.addButtonProperties.style.cssClasses = 'p-0 bg-white';
            this.properties.addButtonProperties.icon = 'heroicons_outline:plus-circle';
            this.properties.addButtonProperties.buttonBehavior = ClButtonBehavior.flat;
            this.properties.addButtonProperties.style.iconCssClasses = 'p-0 text-primary';
            this.properties.addButtonProperties.style.labelCssClasses = 'p-0 text-primary';
        }
        this.properties.addButtonProperties.onSubmit = this.onButtonClick.bind(this);
    }
    onButtonClick() {
        this.nestedLayoutParentContents.push(this.nestedLayoutParentContents[0]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedLayoutComponent, isStandalone: true, selector: "cl-nested-layout", inputs: { properties: "properties" }, queries: [{ propertyName: "nestedLayoutParentContentItems", predicate: ClNestedLayoutParentComponent }], usesInheritance: true, ngImport: i0, template: "<div class=\"flex gap-4 w-full flex-col\">\n  <div class=\"flex w-full flex-col {{ properties.style?.cssClasses }}\">\n    @for (parentLayoutContent of nestedLayoutParentContents; track parentLayoutContent) {\n      <div class=\"flex w-full\">\n        <ng-container *ngTemplateOutlet=\"parentLayoutContent.contentTemplate\"></ng-container>\n      </div>\n    }\n  </div>\n\n  <cl-button [properties]=\"properties.addButtonProperties!\"></cl-button>\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:42px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:after{top:10px;left:-28px;content:\"\";height:100%;position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}.connector:last-child:after{content:none}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedLayoutComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-layout', encapsulation: ViewEncapsulation.None, imports: [
                        CommonModule,
                        NgTemplateOutlet,
                        ClButtonComponent,
                        ClNestedLayoutParentComponent
                    ], template: "<div class=\"flex gap-4 w-full flex-col\">\n  <div class=\"flex w-full flex-col {{ properties.style?.cssClasses }}\">\n    @for (parentLayoutContent of nestedLayoutParentContents; track parentLayoutContent) {\n      <div class=\"flex w-full\">\n        <ng-container *ngTemplateOutlet=\"parentLayoutContent.contentTemplate\"></ng-container>\n      </div>\n    }\n  </div>\n\n  <cl-button [properties]=\"properties.addButtonProperties!\"></cl-button>\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:42px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:after{top:10px;left:-28px;content:\"\";height:100%;position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}.connector:last-child:after{content:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], nestedLayoutParentContentItems: [{
                type: ContentChildren,
                args: [ClNestedLayoutParentComponent]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ClBreadCrumbService, ClBreadcrumbComponent, ClDatePickerProperties, ClDatePickerStyleProperties, ClDatepickerComponent, ClNestedLayoutChildComponent, ClNestedLayoutComponent, ClNestedLayoutParentComponent, ClNestedLayoutProperties, ClNestedLayoutStyleProperties, ClTreeViewComponent, ClTreeViewProperties, ClTreeViewService, ClTreeViewStyleProperties };
//# sourceMappingURL=clay-ui-components-complex.mjs.map
