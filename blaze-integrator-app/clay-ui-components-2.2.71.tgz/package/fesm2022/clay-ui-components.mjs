const LIB_NAME = '@clay/ui-components';

/**
 * Generated bundle index. Do not edit.
 */

export { LIB_NAME };
//# sourceMappingURL=clay-ui-components.mjs.map
