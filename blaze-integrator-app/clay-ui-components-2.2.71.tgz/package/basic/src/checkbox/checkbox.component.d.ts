import { NgControl, ControlValueAccessor } from '@angular/forms';
import { OnDestroy, AfterViewInit } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClCheckboxProperties } from './checkbox.properties';
import * as i0 from "@angular/core";
export declare class ClCheckboxComponent extends ClBaseComponent implements ControlValueAccessor, AfterViewInit, OnDestroy {
    ngControl: NgControl;
    properties: ClCheckboxProperties;
    protected _value: any;
    onChange: (_: any) => void;
    onTouched: (_: any) => void;
    private sub?;
    private error?;
    constructor(ngControl: NgControl);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => {}): void;
    registerOnTouched(fn: (_: any) => {}): void;
    get value(): any;
    onValueChanged(event: any): void;
    get isDisabled(): boolean;
    get showInfoMsg(): boolean;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClCheckboxComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClCheckboxComponent, "cl-checkbox", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
