import { Signal, TemplateRef } from "@angular/core";
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties, ClErrorHandler } from "@clay/ui-components/shared";
export interface IClCheckboxProperties extends IClBaseComponentProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    checked?: boolean;
    optional?: boolean;
    onValueChanged?: (value: boolean) => void;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
}
export declare class ClCheckboxStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    labelCssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClCheckboxProperties implements IClCheckboxProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    checked?: boolean;
    optional?: boolean;
    disabled?: boolean | Signal<boolean>;
    onValueChanged?: ((value: boolean) => void);
    id: string;
    label?: string;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: ClCheckboxStyleProperties;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    constructor();
}
