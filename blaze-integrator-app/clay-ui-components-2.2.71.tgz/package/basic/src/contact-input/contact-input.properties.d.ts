import { Signal, TemplateRef } from '@angular/core';
import { FloatLabelType, MatFormFieldAppearance, SubscriptSizing } from '@angular/material/form-field';
import { ClCountry, ClBaseVisual, ClBaseBehavior, ClErrorHandler, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export interface IClContactInputProperties extends IClBaseComponentProperties {
    id: string;
    label?: string;
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    optional?: boolean;
    minLength?: number;
    maxLength?: number;
    placeholder?: string;
    showLoading?: boolean;
    validationsList?: any[];
    onValueChange?: Function;
    selectedCountry?: ClCountry;
    floatLabel?: FloatLabelType;
    appearance?: MatFormFieldAppearance;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    onCountryChanged?: ((country: ClCountry) => void);
}
export declare class ClContactInputStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export declare class ClContactInputProperties implements IClContactInputProperties {
    id: string;
    label?: string;
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    optional?: boolean;
    minLength?: number;
    maxLength?: number;
    placeholder?: string;
    showLoading?: boolean;
    validationsList?: any[];
    onValueChange?: Function;
    selectedCountry?: ClCountry;
    floatLabel?: FloatLabelType;
    appearance?: MatFormFieldAppearance;
    onCountryChanged?: ((country: ClCountry) => void);
    type: ClComponentTypes;
    style?: IClBaseStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    countries?: ClCountry[];
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    constructor();
}
