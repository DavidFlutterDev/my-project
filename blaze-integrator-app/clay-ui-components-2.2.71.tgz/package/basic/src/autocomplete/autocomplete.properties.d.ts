import { Signal, TemplateRef } from "@angular/core";
import { ClSelectOptions } from "../select";
import { FloatLabelType, MatFormFieldAppearance, SubscriptSizing } from "@angular/material/form-field";
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties, ClErrorHandler } from '@clay/ui-components/shared';
export interface IClAutoCompleteProperties extends IClBaseComponentProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    optional?: boolean;
    itemLimit?: number;
    placeholder?: string;
    searchBoxHint?: string;
    validationsList?: any[];
    onValueChange?: Function;
    showCustomField?: boolean;
    options?: ClSelectOptions[];
    floatLabel?: FloatLabelType;
    onCustomFieldSelected?: () => void;
    appearance?: MatFormFieldAppearance;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
}
export declare class ClAutoCompleteStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClAutoCompleteProperties implements IClAutoCompleteProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    optional?: boolean;
    multiple?: boolean;
    itemLimit?: number;
    placeholder?: string;
    searchBoxHint?: string;
    validationsList?: any[];
    onValueChange?: Function;
    showCustomField?: boolean;
    options?: ClSelectOptions[];
    floatLabel?: FloatLabelType;
    onCustomFieldSelected?: (() => void);
    appearance?: MatFormFieldAppearance;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClAutoCompleteStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    constructor();
}
