import { OnInit } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClHyperLinkTextProperties } from './hyper-link-text.properties';
import * as i0 from "@angular/core";
export declare class ClHyperLinkTextComponent extends ClBaseComponent implements OnInit {
    properties: ClHyperLinkTextProperties;
    constructor();
    ngOnInit(): void;
    protected _value: any;
    onChange: (_: any) => void;
    onTouched: (_: any) => void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClHyperLinkTextComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClHyperLinkTextComponent, "cl-hyper-link-text", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
