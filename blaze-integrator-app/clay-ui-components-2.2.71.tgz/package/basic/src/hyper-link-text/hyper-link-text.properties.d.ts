import { IClBaseComponentProperties, IClBaseStyleProperties, ClComponentTypes, ClBaseBehavior, ClBaseVisual } from '@clay/ui-components/shared';
export interface ClHyperLinkProperties {
    url?: string;
    text: string;
    isLink?: boolean;
    cssClasses?: string;
}
export interface IClHyperLinkTextProperties extends IClBaseComponentProperties {
    linkProperties: ClHyperLinkProperties[];
}
export declare class ClHyperLinkTextStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export declare class ClHyperLinkTextProperties implements IClHyperLinkTextProperties {
    id: string;
    label?: string;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: ClHyperLinkTextStyleProperties;
    linkProperties: ClHyperLinkProperties[];
    constructor();
}
