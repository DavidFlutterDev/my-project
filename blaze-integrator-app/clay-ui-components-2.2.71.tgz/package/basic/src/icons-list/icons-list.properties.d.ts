import { ClImageProperties } from "../image";
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface IClIconsListProperties {
    icon?: string;
    selected: boolean;
    option: IClListOption;
    img?: ClImageProperties;
    showDetailsBtn?: boolean;
    onDetailClicked?: () => void;
}
export interface IClIconsListConfig extends IClBaseComponentProperties {
    multiple?: boolean;
    optionsSelected?: Function;
    options: IClIconsListProperties[];
}
export interface IClListOption {
    text: string;
    value: string;
}
export declare class ClIconsListStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    labelCssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClIconsListProperties implements IClIconsListConfig {
    multiple?: boolean;
    optionsSelected?: Function;
    options: IClIconsListProperties[];
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClIconsListStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    constructor();
}
