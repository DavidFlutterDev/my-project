import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClIconsListProperties } from './icons-list.properties';
import * as i0 from "@angular/core";
export declare class ClIconsListComponent extends ClBaseComponent implements OnInit, OnChanges {
    properties: ClIconsListProperties;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    onOptionSelected(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClIconsListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClIconsListComponent, "cl-icons-list", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
