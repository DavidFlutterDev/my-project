import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export declare enum ClFilePreviewType {
    png = "image/png",
    jpg = "image/jpeg",
    svg = "image/svg+xml",
    pdf = "application/pdf"
}
export interface IClFilePreviewProperties extends IClBaseComponentProperties {
    fileName?: string;
    onExpansionIconClicked?: Function;
    fileType?: ClFilePreviewType;
    base64?: string;
    showExpansionIcon?: boolean;
}
export declare class ClFilePreviewStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export declare class ClFilePreviewProperties implements IClFilePreviewProperties {
    id: string;
    type: ClComponentTypes;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    fileName?: string;
    showExpansionIcon?: boolean;
    onExpansionIconClicked?: Function;
    fileType?: ClFilePreviewType;
    base64?: string;
    style?: ClFilePreviewStyleProperties;
    constructor();
}
