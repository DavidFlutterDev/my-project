import { ClImageProperties } from './image.properties';
import { OnInit } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export declare class ClImageComponent extends ClBaseComponent implements OnInit {
    properties: ClImageProperties;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClImageComponent, "cl-image", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
