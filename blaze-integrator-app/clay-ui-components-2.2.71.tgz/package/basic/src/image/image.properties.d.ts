import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface IClImageProperties extends IClBaseComponentProperties {
    alt?: string;
    link?: string;
}
export declare class ClImageStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClImageProperties implements IClImageProperties {
    alt?: string;
    link?: string;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClImageStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    constructor();
}
