import { Signal } from '@angular/core';
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export declare enum IClButtonType {
    reset = "reset",
    button = "button",
    submit = "submit"
}
export interface IClButtonProperties extends IClBaseComponentProperties {
    icon?: string;
    disabled?: Signal<boolean> | boolean;
    onSubmit?: Function;
    showFailed?: boolean;
    failedLabel?: string;
    showSuccess?: boolean;
    showLoading?: boolean;
    loadingLabel?: string;
    successLabel?: string;
    buttonType?: IClButtonType;
    buttonBehavior?: ClButtonBehavior;
}
export declare enum ClComponentBehaviors {
    flat = "flat",
    icon = "icon",
    raised = "raised"
}
export type ClButtonBehavior = ClBaseBehavior | ClComponentBehaviors;
export declare const ClButtonBehavior: {
    flat: ClComponentBehaviors.flat;
    icon: ClComponentBehaviors.icon;
    raised: ClComponentBehaviors.raised;
    default: ClBaseBehavior.default;
};
export declare class ClButtonStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    buttonSize?: string;
    alignContent?: string;
    contentWidth?: string;
    iconCssClasses?: string;
    justifyContent?: string;
    labelCssClasses?: string;
}
export declare class ClButtonProperties implements IClButtonProperties {
    id: string;
    icon?: string;
    label?: string;
    showFailed?: boolean;
    failedLabel?: string;
    showSuccess?: boolean;
    showLoading?: boolean;
    loadingLabel?: string;
    successLabel?: string;
    onSubmit?: Function;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    disabled?: Signal<boolean> | boolean;
    buttonType?: IClButtonType;
    behaviorType?: ClBaseBehavior;
    style?: ClButtonStyleProperties;
    buttonBehavior?: ClButtonBehavior;
    constructor();
}
