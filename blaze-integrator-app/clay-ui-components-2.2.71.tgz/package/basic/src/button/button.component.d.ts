import { OnChanges, SimpleChanges } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClButtonProperties } from './button.properties';
import * as i0 from "@angular/core";
export declare class ClButtonComponent extends ClBaseComponent implements OnChanges {
    disabled?: boolean;
    showFailed?: boolean;
    showSuccess?: boolean;
    showLoading?: boolean;
    properties: ClButtonProperties;
    buttonLabel: string;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    updateButtonLabel(): string;
    onSubmit(): void;
    get isDisabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClButtonComponent, "cl-button", never, { "disabled": { "alias": "disabled"; "required": false; }; "showFailed": { "alias": "showFailed"; "required": false; }; "showSuccess": { "alias": "showSuccess"; "required": false; }; "showLoading": { "alias": "showLoading"; "required": false; }; "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
