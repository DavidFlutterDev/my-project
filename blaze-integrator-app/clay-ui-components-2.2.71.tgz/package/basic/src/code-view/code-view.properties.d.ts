import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export interface IClCodeViewProperties extends IClBaseComponentProperties {
    code?: string;
    lang?: string;
}
export declare class ClCodeViewStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    fontStyle?: string;
    alignContent?: string;
    contentWidth?: string;
    iconCssClasses?: string;
    justifyContent?: string;
    labelCssClasses?: string;
}
export declare class ClCodeViewProperties implements IClCodeViewProperties {
    id: string;
    code?: any;
    lang?: string;
    label?: string;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: ClCodeViewStyleProperties;
    constructor();
}
