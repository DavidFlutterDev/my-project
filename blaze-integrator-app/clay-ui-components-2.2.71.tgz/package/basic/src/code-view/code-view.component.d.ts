import { OnInit, SimpleChanges, ChangeDetectorRef } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClCodeViewProperties } from './code-view.properties';
import * as i0 from "@angular/core";
export declare class ClCodeViewComponent extends ClBaseComponent implements OnInit {
    private cdr;
    code: any;
    properties: ClCodeViewProperties;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnChanges(_changes: SimpleChanges): void;
    private formatCode;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClCodeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClCodeViewComponent, "cl-code-view", never, { "code": { "alias": "code"; "required": true; }; "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
