import { OnInit } from '@angular/core';
import { ClChipProperties } from './chip.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export declare class ClChipComponent extends ClBaseComponent implements OnInit {
    properties: ClChipProperties;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClChipComponent, "cl-chip", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
