import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export interface IClChipProperties extends IClBaseComponentProperties {
    hidden?: boolean;
}
export declare class ClChipStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    labelCssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClChipProperties implements IClChipProperties {
    id: string;
    type: ClComponentTypes;
    label?: string;
    hidden?: boolean;
    style?: ClChipStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    constructor();
}
