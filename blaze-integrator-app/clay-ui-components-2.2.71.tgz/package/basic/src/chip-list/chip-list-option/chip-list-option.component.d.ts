import { EventEmitter, Signal } from '@angular/core';
import { ClChipListOptions } from '../chip-list.properties';
import * as i0 from "@angular/core";
export declare class ClChipListOptionComponent {
    index: number;
    iconCssClasses?: string;
    imageCssClasses?: string;
    listDisabled?: boolean | Signal<boolean>;
    chip: ClChipListOptions;
    optionSelected: EventEmitter<any>;
    protected onChipsSelected(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClChipListOptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClChipListOptionComponent, "cl-chip-list-option", never, { "index": { "alias": "index"; "required": true; }; "iconCssClasses": { "alias": "iconCssClasses"; "required": false; }; "imageCssClasses": { "alias": "imageCssClasses"; "required": false; }; "listDisabled": { "alias": "listDisabled"; "required": false; }; "chip": { "alias": "chip"; "required": true; }; }, { "optionSelected": "optionSelected"; }, never, never, true, never>;
}
