import { Signal, TemplateRef } from "@angular/core";
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties, ClErrorHandler } from "@clay/ui-components/shared";
export interface ClChipListOptions {
    text: string;
    value: string;
    icon?: string;
    image?: string;
    disabled: boolean;
    isSelected: boolean;
}
export interface IClChipListProperties extends IClBaseComponentProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    name?: string;
    optional?: boolean;
    multiple?: boolean;
    showOptionAll?: boolean;
    direction?: 'row' | 'col';
    optionsSelected?: Function;
    options?: ClChipListOptions[];
    disabled?: Signal<boolean> | boolean;
    optionAllProperties?: ClChipListOptions;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
}
export declare class ClChipListStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
    iconCssClasses?: string;
    imageCssClasses?: string;
    labelCssClasses?: string;
}
export declare class ClChipListProperties implements IClChipListProperties {
    id: string;
    label?: string;
    optional?: boolean;
    name?: string;
    multiple?: boolean;
    type: ClComponentTypes;
    showOptionAll?: boolean;
    direction?: "row" | "col";
    visualType?: ClBaseVisual;
    optionsSelected?: Function;
    behaviorType?: ClBaseBehavior;
    options?: ClChipListOptions[];
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    style?: ClChipListStyleProperties;
    disabled?: boolean | Signal<boolean>;
    optionAllProperties?: ClChipListOptions;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    constructor();
}
