import { TooltipPosition } from "@angular/material/tooltip";
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface IClIconProperties extends IClBaseComponentProperties {
    iconName?: string;
    tooltip?: string;
    onIconClicked?: Function;
    tooltipPosition?: TooltipPosition;
}
export declare class ClIconStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClIconProperties implements IClIconProperties {
    iconName?: string;
    tooltip?: string;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClIconStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    onIconClicked?: Function;
    tooltipPosition?: TooltipPosition;
    constructor();
}
