import { OnInit } from '@angular/core';
import { ClIconProperties } from './icon.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export declare class ClIconComponent extends ClBaseComponent implements OnInit {
    properties: ClIconProperties;
    constructor();
    ngOnInit(): void;
    onIconClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClIconComponent, "cl-icon", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
