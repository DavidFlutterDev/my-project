import { Signal, TemplateRef } from "@angular/core";
import { FloatLabelType, MatFormFieldAppearance, SubscriptSizing } from "@angular/material/form-field";
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties, ClErrorHandler } from "@clay/ui-components/shared";
export declare enum ClPatterns {
    numeric = "[0-9]+$",
    textOnly = "[A-Za-z]+$",
    decimalNumber = "^[0-9.]+$",
    inMobile = "[6-9]{1}[0-9]{9}",
    textWithSpace = "[A-Za-z ]+$",
    inIFSC = "[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}",
    alphaNumericWithSpace = "^[a-zA-Z0-9 ]+$",
    alphaNumericWithOutSpace = "^[a-zA-Z0-9]+$",
    pan = "([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$",
    email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[.][a-zA-Z]{2,}$",
    gst = "[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[0-9A-Z]{2}"
}
export interface IClChipInputProperties extends IClBaseComponentProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    options?: string[];
    optional?: boolean;
    suffixIcon?: string;
    prefixIcon?: string;
    placeholder?: string;
    floatLabel?: FloatLabelType;
    appearance?: MatFormFieldAppearance;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    onOptionsAdded?: (selectedOptions: string[]) => void;
}
export declare class ClChipInputStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClChipsInputProperties implements IClChipInputProperties {
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    options?: string[];
    optional?: boolean;
    suffixIcon?: string;
    prefixIcon?: string;
    placeholder?: string;
    floatLabel?: FloatLabelType;
    appearance?: MatFormFieldAppearance;
    onOptionsAdded?: (selectedOptions: string[]) => void;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClChipInputStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    errorsList?: ClErrorHandler;
    isReactiveFormControl?: false;
    constructor();
}
