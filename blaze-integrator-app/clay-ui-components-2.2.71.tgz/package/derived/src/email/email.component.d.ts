import { ControlValueAccessor, NgControl } from "@angular/forms";
import { ClEmailProperties } from "./email.properties";
import { ClInputComponent } from "@clay/ui-components/basic";
import * as i0 from "@angular/core";
export declare class ClEmailComponent extends ClInputComponent implements ControlValueAccessor {
    ngControl: NgControl;
    properties: ClEmailProperties;
    protected _value: any;
    private emailValidationSubject;
    constructor(ngControl: NgControl);
    /**
     * !! Warning !!
     * The below super calls are always to be implemented for any component. Otherwise nothing will work.
     */
    /**
     * !! Warning !!
     * The below super calls are always to be implemented for any component. Otherwise nothing will work.
     */
    writeValue(value: any): void;
    protected validateEmail(value: any): void;
    get value(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClEmailComponent, [{ optional: true; self: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClEmailComponent, "cl-email", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
