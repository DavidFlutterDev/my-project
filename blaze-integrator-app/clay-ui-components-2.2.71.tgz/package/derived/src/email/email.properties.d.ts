import { Signal, TemplateRef } from '@angular/core';
import { FloatLabelType, MatFormFieldAppearance, SubscriptSizing } from '@angular/material/form-field';
import { ClInputStyleProperties } from '@clay/ui-components/basic';
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseComponentProperties } from '@clay/ui-components/shared';
export interface IClEmailProperties extends IClBaseComponentProperties {
    label?: string;
    name?: string;
    infoMsg?: string | TemplateRef<any>;
    hintText?: string;
    optional?: boolean;
    minLength?: number;
    maxLength?: number;
    suffixIcon?: string;
    prefixIcon?: string;
    suffixLabel?: string;
    prefixLabel?: string;
    placeholder?: string;
    showLoading?: boolean;
    allowDecimal?: boolean;
    validationsList?: any[];
    onValueChange?: Function;
    floatLabel?: FloatLabelType;
    disabled?: Signal<boolean> | boolean;
    onPrefixIconClicked?: Function;
    onSuffixIconClicked?: Function;
    appearance?: MatFormFieldAppearance;
    availableText?: string[];
    subscriptSizing?: SubscriptSizing;
}
export declare class ClEmailStyleProperties extends ClInputStyleProperties {
}
export declare class ClEmailProperties implements IClEmailProperties {
    label?: string;
    name?: string;
    infoMsg?: string | TemplateRef<any>;
    hintText?: string;
    optional?: boolean;
    minLength?: number;
    maxLength?: number;
    suffixIcon?: string;
    prefixIcon?: string;
    suffixLabel?: string;
    prefixLabel?: string;
    placeholder?: string;
    showLoading?: boolean;
    allowDecimal?: boolean;
    validationsList?: any[];
    onValueChange?: Function;
    floatLabel?: FloatLabelType;
    onPrefixIconClicked?: Function;
    onSuffixIconClicked?: Function;
    appearance?: MatFormFieldAppearance;
    availableText?: string[];
    id: string;
    type: ClComponentTypes;
    style?: ClEmailStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    disabled?: Signal<boolean> | boolean;
    subscriptSizing?: SubscriptSizing;
    constructor();
}
