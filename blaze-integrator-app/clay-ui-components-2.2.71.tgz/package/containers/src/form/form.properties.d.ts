import { WritableSignal } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from '@clay/ui-components/shared';
import { Suite } from 'vest';
export interface IClFormProperties extends IClBaseComponentProperties {
    formTitle?: string;
    onSubmit?: Function;
    formGroup?: FormGroup;
    formValue?: WritableSignal<Partial<{}>>;
    validationSuite?: Suite<string, string, (model: Partial<{}>, field: string) => void>;
    children: any[];
    colsPerRow?: number;
    style?: ClFormStyleProperties;
}
export declare class ClFormStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    alignItem?: string;
    gap?: string;
}
export declare class ClFormProperties implements IClFormProperties {
    formTitle?: string;
    onSubmit?: Function;
    formValue?: WritableSignal<Partial<{}>>;
    validationSuite?: Suite<string, string, (model: Partial<{}>, field: string) => void>;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClFormStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    dataModel?: any;
    children: any;
    formGroup?: FormGroup;
    colsPerRow?: number;
    constructor();
}
