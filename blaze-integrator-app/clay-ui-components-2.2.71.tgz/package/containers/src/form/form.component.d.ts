import { ClFormProperties } from './form.properties';
import * as i0 from "@angular/core";
export declare class ClFormComponent {
    properties: ClFormProperties;
    gridClass?: string;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClFormComponent, "cl-form", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
