import { ClExpansionPanelHeaderProperties } from './expansion-panel-header';
import { ClExpansionPanelDescriptionProperties } from './expansion-panel-description';
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, ClComponentInjectProperties, ClBaseContainerComponentProperties } from '@clay/ui-components/shared';
export interface IClAccordionProperties extends ClBaseContainerComponentProperties {
    hideToggle?: boolean;
    expandedIcon?: string;
    openMultiple?: boolean;
    collapsedIcon?: string;
    onExpansionPanelSelected?: (panelIndex: any) => void;
    expansionPanelProperties?: ClExpansionPanelProperties[];
}
export interface ClExpansionPanelProperties {
    expansionPanelContentProperties: any;
    expansionPanelHeaderProperties: ClExpansionPanelHeaderProperties;
    expansionPanelContentComponentProperties?: ClComponentInjectProperties;
    expansionPanelDescriptionProperties?: ClExpansionPanelDescriptionProperties;
}
export declare class ClAccordionStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    iconCssClasses?: string;
    bodyCssClasses?: string;
    justifyContent?: string;
    descCssClasses?: string;
    panelCssClasses?: string;
    titleCssClasses?: string;
    headerCssClasses?: string;
}
export declare class ClAccordionProperties implements IClAccordionProperties {
    id: string;
    label?: string;
    hideToggle?: boolean;
    expandedIcon?: string;
    type: ClComponentTypes;
    openMultiple?: boolean;
    collapsedIcon?: string;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: ClAccordionStyleProperties;
    onExpansionPanelSelected?: (panelIndex: any) => void;
    expansionPanelProperties?: ClExpansionPanelProperties[];
    constructor();
}
