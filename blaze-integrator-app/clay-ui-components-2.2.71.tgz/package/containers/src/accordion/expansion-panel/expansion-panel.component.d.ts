import { TemplateRef } from '@angular/core';
import { ClExpansionPanelHeaderComponent } from '../expansion-panel-header/expansion-panel-header.component';
import { ClExpansionPanelDescriptionComponent } from '../expansion-panel-description/expansion-panel-description.component';
import { ClExpansionPanelActionButtonsComponent } from '../expansion-panel-action-buttons/expansion-panel-action-buttons.component';
import * as i0 from "@angular/core";
export declare class ClExpansionPanelComponent {
    contentTemplate: TemplateRef<any> | null;
    expansionPanelHeader: ClExpansionPanelHeaderComponent | null;
    expansionPanelDescription: ClExpansionPanelDescriptionComponent | null;
    expansionPanelActionButtons: ClExpansionPanelActionButtonsComponent | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClExpansionPanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClExpansionPanelComponent, "cl-expansion-panel", never, {}, {}, ["expansionPanelHeader", "expansionPanelDescription", "expansionPanelActionButtons"], ["cl-expansion-panel-content"], true, never>;
}
