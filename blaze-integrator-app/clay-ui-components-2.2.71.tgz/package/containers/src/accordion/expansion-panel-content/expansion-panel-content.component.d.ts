import * as i0 from "@angular/core";
export declare class ClExpansionPanelContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClExpansionPanelContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClExpansionPanelContentComponent, "cl-expansion-panel-content", never, {}, {}, never, ["*"], true, never>;
}
