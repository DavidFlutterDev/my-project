import { TemplateRef } from '@angular/core';
import { ClExpansionPanelHeaderProperties } from './expansion-panel-header.properties';
import * as i0 from "@angular/core";
export declare class ClExpansionPanelHeaderComponent {
    properties: ClExpansionPanelHeaderProperties;
    headerTemplate: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClExpansionPanelHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClExpansionPanelHeaderComponent, "cl-expansion-panel-header", ["clExpansionPanelHeader"], { "properties": { "alias": "properties"; "required": true; }; }, {}, never, never, true, never>;
}
