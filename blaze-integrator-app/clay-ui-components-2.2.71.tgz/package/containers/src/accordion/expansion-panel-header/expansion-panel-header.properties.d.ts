import { ComponentType } from "@angular/cdk/overlay";
import { TooltipPosition } from "@angular/material/tooltip";
import { ClButtonProperties } from "@clay/ui-components/basic";
import { ClComponentInjectProperties, ClComponentTypes } from "@clay/ui-components/shared";
export interface ClPanelActionIconProperties {
    id?: string;
    type?: ClComponentTypes;
    iconName?: string;
    tooltip?: string;
    style?: ClIconStyleProperties;
    tooltipPosition?: TooltipPosition;
    onIconClicked?: (index: number) => void;
}
export interface ClIconStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export interface IClExpansionPanelHeaderProperties {
    label: string;
    hideDefaultHeader?: boolean;
    component?: ComponentType<any>;
    componentProperties?: ClComponentInjectProperties;
    panelOpenState?: boolean;
    actionIcons?: ClPanelActionIconProperties[];
    actionButtons?: ClButtonProperties[];
}
export declare class ClExpansionPanelHeaderProperties implements IClExpansionPanelHeaderProperties {
    label: string;
    hideDefaultHeader?: boolean;
    component?: ComponentType<any>;
    componentProperties?: ClComponentInjectProperties;
    panelOpenState?: boolean;
    actionIcons?: ClPanelActionIconProperties[];
    actionButtons?: ClButtonProperties[];
    constructor();
}
