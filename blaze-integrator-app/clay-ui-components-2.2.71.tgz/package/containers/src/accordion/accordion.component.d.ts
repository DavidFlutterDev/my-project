import { OnInit, QueryList, AfterContentInit, ChangeDetectorRef } from '@angular/core';
import { ClExpansionPanelComponent } from './expansion-panel';
import { ClAccordionProperties } from './accordion.properties';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import { ClPanelActionIconProperties } from './expansion-panel-header';
import * as i0 from "@angular/core";
export declare class ClAccordionComponent extends ClBaseContainerComponent implements OnInit, AfterContentInit {
    private readonly cdr;
    properties: ClAccordionProperties;
    private readonly contentItems;
    protected expansionPanels: QueryList<ClExpansionPanelComponent>;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    onPanelStateChanged(expansionPanel: ClExpansionPanelComponent, value: boolean): void;
    onExpansionPanelSelected(index: any): void;
    protected onActionIconClicked(index: any, iconProperties: ClPanelActionIconProperties): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClAccordionComponent, "cl-accordion", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, ["contentItems"], never, true, never>;
}
