import { TemplateRef } from '@angular/core';
import { IClExpansionPanelActionButtonsProperties } from './expansion-panel-action-buttons.properties';
import * as i0 from "@angular/core";
export declare class ClExpansionPanelActionButtonsComponent {
    properties: IClExpansionPanelActionButtonsProperties;
    actionButtonsTemplate: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClExpansionPanelActionButtonsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClExpansionPanelActionButtonsComponent, "cl-expansion-panel-action-buttons", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, ["*"], true, never>;
}
