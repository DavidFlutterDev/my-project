export interface IClExpansionPanelActionButtonsProperties {
    label: any;
}
