export interface IClExpansionPanelDescriptionProperties {
    description: string;
}
export declare class ClExpansionPanelDescriptionProperties implements IClExpansionPanelDescriptionProperties {
    description: string;
    constructor();
}
