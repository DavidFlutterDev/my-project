import { TemplateRef } from '@angular/core';
import { ClExpansionPanelDescriptionProperties } from './expansion-panel-description.properties';
import * as i0 from "@angular/core";
export declare class ClExpansionPanelDescriptionComponent {
    properties: ClExpansionPanelDescriptionProperties;
    descriptionTemplate: TemplateRef<any> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClExpansionPanelDescriptionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClExpansionPanelDescriptionComponent, "cl-expansion-panel-description", never, { "properties": { "alias": "properties"; "required": true; }; }, {}, never, ["*"], true, never>;
}
