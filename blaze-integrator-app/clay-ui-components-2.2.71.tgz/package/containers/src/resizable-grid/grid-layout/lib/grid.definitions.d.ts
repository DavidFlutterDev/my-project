import { InjectionToken } from '@angular/core';
import { ClClientRect } from './utils/client-rect';
import { CompactType } from './utils/react-grid-layout.utils';
export interface ClGridLayoutItem {
    id: string;
    x: number;
    y: number;
    w: number;
    h: number;
    minW?: number;
    minH?: number;
    maxW?: number;
    maxH?: number;
    children: any;
}
export type ClGridCompactType = CompactType;
export interface ClGridBackgroundCfg {
    show: 'never' | 'always' | 'whenDragging';
    borderColor?: string;
    gapColor?: string;
    rowColor?: string;
    columnColor?: string;
    borderWidth?: number;
}
export interface ClGridCfg {
    cols: number;
    rowHeight: number | 'fit';
    height?: number | null;
    layout: ClGridLayoutItem[];
    preventCollision: boolean;
    gap: number;
}
export type ClGridLayout = ClGridLayoutItem[];
export interface ClGridItemRect {
    top: number;
    left: number;
    width: number;
    height: number;
}
export interface ClGridItemRenderData<T = number | string> {
    id: string;
    top: T;
    left: T;
    width: T;
    height: T;
}
/**
 * We inject a token because of the 'circular dependency issue warning'. In case we don't had this issue with the circular dependency, we could just
 * import ClGridComponent on ClGridItem and execute the needed function to get the rendering data.
 */
export type ClGridItemRenderDataTokenType = (id: string) => ClGridItemRenderData<string>;
export declare const GRID_ITEM_GET_RENDER_DATA_TOKEN: InjectionToken<ClGridItemRenderDataTokenType>;
export interface ClDraggingData {
    pointerDownEvent: MouseEvent | TouchEvent;
    pointerDragEvent: MouseEvent | TouchEvent;
    gridElemClientRect: ClClientRect;
    dragElemClientRect: ClClientRect;
    scrollDifference: {
        top: number;
        left: number;
    };
}
