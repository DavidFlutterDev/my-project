import { ClDictionary } from '../../types';
import { ClGridItemComponent } from '../grid-item/grid-item.component';
import { CompactType } from './react-grid-layout.utils';
import { ClDraggingData, ClGridCfg, ClGridCompactType, ClGridItemRect, ClGridLayout, ClGridLayoutItem } from '../grid.definitions';
/** Tracks items by id. This function is mean to be used in conjunction with the ngFor that renders the 'cl-grid-items' */
export declare function clTrackById(index: number, item: {
    id: string;
}): string;
/** Given a layout, the gridHeight and the gap return the resulting rowHeight */
export declare function clGetGridItemRowHeight(layout: ClGridLayout, gridHeight: number, gap: number): number;
/**
 * Call react-grid-layout utils 'compact()' function and return the compacted layout.
 * @param layout to be compacted.
 * @param compactType, type of compaction.
 * @param cols, number of columns of the grid.
 */
export declare function clGridCompact(layout: ClGridLayout, compactType: ClGridCompactType, cols: number): ClGridLayout;
/** Returns a Dictionary where the key is the id and the value is the change applied to that item. If no changes Dictionary is empty. */
export declare function clGetGridLayoutDiff(gridLayoutA: ClGridLayoutItem[], gridLayoutB: ClGridLayoutItem[]): ClDictionary<{
    change: 'move' | 'resize' | 'moveresize';
}>;
/**
 * Given the grid config & layout data and the current drag position & information, returns the corresponding layout and drag item position
 * @param gridItem grid item that is been dragged
 * @param config current grid configuration
 * @param compactionType type of compaction that will be performed
 * @param draggingData contains all the information about the drag
 */
export declare function clGridItemDragging(gridItem: ClGridItemComponent, config: ClGridCfg, compactionType: CompactType, draggingData: ClDraggingData): {
    layout: ClGridLayoutItem[];
    draggedItemPos: ClGridItemRect;
};
/**
 * Given the grid config & layout data and the current drag position & information, returns the corresponding layout and drag item position
 * @param gridItem grid item that is been dragged
 * @param config current grid configuration
 * @param compactionType type of compaction that will be performed
 * @param draggingData contains all the information about the drag
 */
export declare function clGridItemResizing(gridItem: ClGridItemComponent, config: ClGridCfg, compactionType: CompactType, draggingData: ClDraggingData): {
    layout: ClGridLayoutItem[];
    draggedItemPos: ClGridItemRect;
};
/** Returns true if both item1 and item2 ClGridLayoutItems are equivalent. */
export declare function clGridItemLayoutItemAreEqual(item1: ClGridLayoutItem, item2: ClGridLayoutItem): boolean;
