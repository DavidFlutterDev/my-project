import { NgZone, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ClGridService implements OnDestroy {
    private ngZone;
    touchMove$: Observable<TouchEvent>;
    private touchMoveSubject;
    private touchMoveSubscription?;
    constructor(ngZone: NgZone);
    ngOnDestroy(): void;
    mouseOrTouchMove$(element: any): Observable<MouseEvent | TouchEvent>;
    private registerTouchMoveSubscription;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClGridService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClGridService>;
}
