import { ElementRef, InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Injection token that can be used to reference instances of `ClGridDragHandle`. It serves as
 * alternative token to the actual `ClGridDragHandle` class which could cause unnecessary
 * retention of the class and its directive metadata.
 */
export declare const CL_GRID_DRAG_HANDLE: InjectionToken<ClGridDragHandle>;
/** Handle that can be used to drag a ClGridItem instance. */
export declare class ClGridDragHandle {
    element: ElementRef<HTMLElement>;
    constructor(element: ElementRef<HTMLElement>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ClGridDragHandle, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ClGridDragHandle, "[clGridDragHandle]", never, {}, {}, never, never, true, never>;
}
