import { SortDirection } from "@angular/material/sort";
import { IClBaseComponentProperties, IClBaseStyleProperties, ClComponentTypes, ClBaseBehavior, ClBaseVisual } from "@clay/ui-components/shared";
import { ClSelectOptions, ClChipListOptions, ClIconProperties, ClImageProperties, ClInputProperties, ClLabelProperties, ClButtonProperties } from "@clay/ui-components/basic";
/**
 * this object is used to style an individual cell
 * based on the tailwind css classes provided by client application
 */
export interface ClColumnStyle {
    style?: string;
    alignment?: string;
    minWidth?: string;
    maxWidth?: string;
    backgroundAndTextColor?: Function;
    indicatorBgAndTextColor?: Function;
    headerCellClasses?: string;
    dataCellClasses?: string;
}
export interface ClErrorHandler {
    key: string;
    message: string;
}
/**
 * this object is to set what type of cell it should render based on data
 * this determines the view template of the cell
 */
export declare enum ClColumnType {
    text = "text",
    time = "time",
    date = "date",
    input = "input",
    image = "image",
    number = "number",
    status = "status",
    select = "select",
    button = "button",
    amount = "amount",
    primary = "primary",
    percent = "percent",
    actions = "actions",
    checkbox = "checkbox",
    criteria = "criteria",
    progressBar = "progressBar",
    reorderIndex = "reorderIndex"
}
export interface IClTableConfigProperties extends IClBaseComponentProperties {
    data?: any[];
    pageSize?: number;
    editField?: boolean;
    showFilter?: boolean;
    isMultiple?: boolean;
    rowDragEnable?: boolean;
    borderColor?: string;
    bodyBgColor?: string;
    showLoading?: boolean;
    totalRecords?: number;
    matSortActive?: string;
    headerBgColor?: string;
    showPaginator?: boolean;
    showMultiFilter?: boolean;
    isCustomDataFilter?: boolean;
    customDataFilter?: any[] | null;
    enableServerSidePagination?: boolean;
    setMultiFilter?: ClFilterChipList[];
    columns?: ClColumnConfig[];
    filterConfig?: ClFilterConfig[];
    customButtons?: ClButtonProperties[];
    pageSizeOptions?: number[];
    selectAllRecords?: boolean;
    showColumnFilter?: boolean;
    showFilterDropdown?: boolean;
    searchPlaceholder?: string;
    onSearchBtnSubmit?: Function;
    onFilterChange?: Function;
    noDataLayout?: ClNoDataLayout;
    onCheckboxSelection?: Function;
    onPrimaryColumnClick?: Function;
    matSortDirection?: SortDirection;
    onDropdownValueChange?: Function;
    onPageNoChanged?: (pageNo: any, pageSize: any, sortColumn: string, sortOrder: string) => void;
    onInputChanged?: (row: any) => void;
    onMultiFilterDialogApply?: (data: any) => void;
    uniqueKey?: string;
    rowValidation?: ClTableValidation;
    onCriteriaColumnClick?: Function;
    columnCustomization?: boolean;
}
export declare class ClDataGridStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export interface ClTableValidation {
    errorList: ClErrorHandler[];
    validationFunction: Function;
}
export interface ClActionIconProperties {
    id: string;
    iconName: string;
    iconSize?: string;
    iconColor?: string;
    options: ClSelectOptions[];
    onActionIconClicked?: Function;
}
export interface ClFilterChipList {
    id: string;
    label: string;
    value: string;
    options: ClChipListOptions[];
    optionAllProperties?: ClChipListOptions;
}
export interface ClFilterChipOption {
}
export interface ClStatusProperties {
    label: string;
    backgroundColorProperties: string;
}
/**
 * this header config is used to configure the cell
 * and it also determines what type of cell it should show based on cell type
 */
export interface ClColumnConfig {
    key: string;
    name: string;
    icon?: string;
    pinned?: boolean;
    visible?: boolean;
    canSort?: boolean;
    currency?: string;
    columnType?: ClColumnType;
    imageLabelKey?: string;
    columnStyle?: ClColumnStyle;
    showIndicator?: boolean;
    textTrimLength?: number;
    icons?: ClIconProperties;
    options?: ClSelectOptions[];
    validation?: ClTableValidation;
    hideFromCustomization?: boolean;
    actionIcons?: ClIconProperties[];
    imageProperties?: ClImageProperties;
    inputProperties?: ClInputProperties;
    actionIconDropdownProperties?: ClActionIconProperties;
    hideActionIconOnKeyStatus?: string;
    editing?: boolean;
    multipleSelect?: boolean;
    properties?: ClRowAndDropdownProperties;
    hasEditableRights?: boolean;
    disableDrag?: boolean;
    component?: any;
    componentProperty?: any;
    displayAlways?: boolean;
    statusProperties?: ClStatusProperties[];
    enableSearchOnColumn?: boolean;
}
/**
 * this config object is used for the entire data grid configuration
 * here the client application set the default configuration based on the use case
 */
export declare class ClTableConfigProperties implements IClTableConfigProperties {
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClDataGridStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    data?: any[];
    pageSize?: number;
    hideGoToPage?: boolean;
    hideFirstLastPageBtn?: boolean;
    editField?: boolean;
    showFilter?: boolean;
    isMultiple?: boolean;
    rowDragEnable?: boolean;
    borderColor?: string;
    bodyBgColor?: string;
    showLoading?: boolean;
    totalRecords?: number;
    matSortActive?: string;
    headerBgColor?: string;
    showPaginator?: boolean;
    showMultiFilter?: boolean;
    isCustomDataFilter?: boolean;
    isComponentDragged?: boolean;
    customDataFilter?: any[] | null;
    enableServerSidePagination?: boolean;
    setMultiFilter?: ClFilterChipList[];
    columns?: ClColumnConfig[];
    filterConfig?: ClFilterConfig[];
    customButtons?: ClButtonProperties[];
    pageSizeOptions?: number[];
    selectAllRecords?: boolean;
    showColumnFilter?: boolean;
    showFilterDropdown?: boolean;
    searchPlaceholder?: string;
    onSearchBtnSubmit?: Function;
    onFilterChange?: Function;
    noDataLayout?: ClNoDataLayout;
    onCheckboxSelection?: Function;
    onPrimaryColumnClick?: Function;
    matSortDirection?: SortDirection;
    onDropdownValueChange?: Function;
    onPageNoChanged?: ((pageNo: any, pageSize: any, sortColumn: string, sortOrder: string) => void);
    onInputChanged?: ((row: any) => void);
    onMultiFilterDialogApply?: ((data: any) => void);
    isTooltipForFilterDropdown?: boolean;
    uniqueKey?: string;
    rowValidation?: ClTableValidation;
    onCriteriaColumnClick?: Function;
    columnCustomization?: boolean;
    constructor();
}
/**
 *  this object is used to show label and icons when there are
 *  no record in the data grid which we provided by the client application
 */
export interface ClNoDataLayout {
    gap?: string;
    layoutType?: 'row' | 'col';
    iconProperties?: ClIconProperties;
    labelProperties: ClLabelProperties;
    descLabelProperties?: ClLabelProperties;
}
/**
 * This object is used to validate the input and select fields in the data grid
 */
export interface ClTableValidation {
    errorList: ClErrorHandler[];
    validationFunction: Function;
}
/**
 * This object contains the data grid filter dropdown required properties
 */
export interface ClFilterConfig {
    label: string;
    key: string;
    selectedValue: string;
    onValueChange?: Function;
    options: ClSelectOptions[];
    filterFromServerSide?: boolean;
    widthFilterDropdown?: any;
}
export interface ClRowAndDropdownProperties {
    id?: string;
    label?: string;
    valueIn?: string;
    options?: SelectOption[];
    rowSelection?: boolean;
    disabled?: boolean;
}
export interface SelectOption {
    text: string;
    value: string;
}
