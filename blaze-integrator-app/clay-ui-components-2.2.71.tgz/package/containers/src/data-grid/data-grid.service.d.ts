import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class ClDataGridService {
    clearSelection: BehaviorSubject<string>;
    clearDataGridSelection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDataGridService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClDataGridService>;
}
