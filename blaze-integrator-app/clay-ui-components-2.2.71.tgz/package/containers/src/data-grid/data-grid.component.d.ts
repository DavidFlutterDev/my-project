import { SelectionModel } from '@angular/cdk/collections';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort, SortDirection } from '@angular/material/sort';
import { MatTable, MatTableDataSource } from '@angular/material/table';
import { ControlValueAccessor, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ChangeDetectorRef, ElementRef, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { ClDataGridService } from './data-grid.service';
import { ClColumnConfig, ClTableConfigProperties } from './data-grid.properties';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import { ClIconProperties, ClButtonProperties, ClTextBlockComponent } from '@clay/ui-components/basic';
import * as i0 from "@angular/core";
export declare class ClDataGridComponent extends ClBaseContainerComponent implements OnInit, ControlValueAccessor, OnDestroy {
    private fb;
    private cdr;
    private dialog;
    private dataGridService;
    matSortActive: string;
    totalRecords?: number;
    showLoading: boolean;
    matSortDirection: SortDirection;
    data: any[];
    properties: ClTableConfigProperties;
    customData: any[] | null;
    sort: MatSort;
    table: MatTable<any>;
    paginator: MatPaginator;
    editingColumn: string | null;
    editingRowIndex: number | null;
    editableFields: string[];
    modifiedRow: any[];
    currentPage: number;
    isSortingSubscribed: boolean;
    formGroup: FormGroup;
    columnFilters: string[];
    selection: SelectionModel<any>;
    dataSource: MatTableDataSource<any, MatPaginator>;
    formControl: {
        [key: string]: FormControl;
    };
    private searchButtonDisable;
    searchButtonProperties: ClButtonProperties;
    private editedRows;
    protected dragDisabled: boolean;
    protected rowDetails: any;
    tableFilter: any;
    tableFilterChip: any;
    selectedMultiFilter: any;
    customFilterData: any[] | null;
    private disableSearchButton;
    private globalSearchAppliedColumns;
    textBlockComponent: typeof ClTextBlockComponent;
    private previousIndex;
    tableContainer: ElementRef;
    protected _value: any;
    onChange: (_: any) => void;
    onTouched: (_: any) => void;
    private _clearSelectionSubscription;
    constructor(fb: FormBuilder, cdr: ChangeDetectorRef, dialog: MatDialog, dataGridService: ClDataGridService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    setSearchButtonProperties(): void;
    checkServerSideCustomData(data: any[] | null): void;
    openDialogMultiFilter(): void;
    onScroll(event: Event): void;
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => {}): void;
    registerOnTouched(fn: (_: any) => {}): void;
    get value(): any;
    handleValueChange(newValue: any): void;
    ngAfterViewInit(): void;
    /**
     * This function will add global search control to the from group for global filter
     */
    private addGlobalSearchControl;
    /**
     * This function will add column level filter controls to form group for column level filters
     */
    private addColumnLevelFilterControls;
    private initializeTableFilter;
    /**
     * this function will set the default values to the input fields
     * which is received from the client application
     */
    private setDefaultValues;
    /**
     * this function will set the default values to properties of table config
     */
    private setDefaultTableConfig;
    /**
     * This function will initialize data source once data is sent from client
     */
    private setDataToDataSource;
    /**
     * this function subscribe to the sort change event of mat sort
     */
    private setSortingSubscription;
    /**
     * This function will set paginator for applying pagination to mat table
     */
    private setPaginator;
    /**
     * This function is used directly inside the table to render the columns header
     * This function will only show the columns which are visible.
     *
     * This function also updates the column level filter row based on changes made by the user;
     * when the is hiding or showing the column
     */
    getDisplayColumns(): string[];
    /**
     * This function will change the order of the dropped column when the user is dragging and dropping the column.
     *
     * @param event - event of the column dropped
     */
    dropCol(event: any): void;
    dropRow(event: any): void;
    dragStarted(row: any): void;
    /**
     * This function is called when the page size is changed.
     *
     * @param pageSize - number of records per page
     */
    onPageSizeChange(pageSize: number): void;
    /**
     * This function is called when the page is changed.
     *
     * @param index - page no or nxt or prev
     */
    goToPageNo(index: any): void;
    /**
     * This function will check if all the items in a row for that page is selected or not
     */
    isAllSelected(): boolean;
    /**
     * Selects all rows in a page if they are not all selected; otherwise clear selection.
     * This function is also used to either select all items in the page or de-select.
     */
    masterToggle(): void;
    /**
     * This function will mark or select the row.
     */
    selectRows(): void;
    onRowValueChange(value: any, row: any, columnKey: any, index: number): void;
    onRowValueChangeCheckbox(value: any, row: any, columnKey: any, index: number): void;
    /**
     * this function will return the records which are minimum
     *
     * @returns - entire records length if select all records is true
     *
     *          - page per records will be returned if records are greater than page size
     *
     *          - records length will be sent if records are lesser than page size
     */
    private getDataLimit;
    /**
     * This function will clear all the selections.
     */
    clearSelections(): void;
    /**
     * This function will emit the selected row or rows.
     */
    onCheckboxSelection(): void;
    /**
     * this function is the callback function of dropdown cell
     *
     * @param row - row of the dropdown
     */
    onDropdownValueChange(row: any, column: any, closePanel: boolean): void;
    /**
     * This function will create and set filter predicate to data source;
     * and is used to filter out based on input at column level
     */
    private createFilter;
    /**
     * This function will return all the rows where entered value in global or column level filter is found
     *
     * @param globalSearch - Send global search query
     *
     * @param filterObj - send filter object to identify which column needs to be kept
     *
     * @param filterObject - send filter object for column level search
     *
     * @returns - returns true or false based on search query is found or not
     */
    private getSearchResult;
    onSearchBtnSubmit(): void;
    /**
     * onPrimaryColumnClicked
     *
     * This function is the callback function on primary column
     * this function will be triggered when primary column is clicked
     *
     * @param row - row of the selected primary column
     */
    onPrimaryColumnClicked(row: any): void;
    /**
     * this function will check for validation and show error message
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     *
     * @returns - returns error message if there is any error or else returns null
     */
    getErrorMessage(column: ClColumnConfig, row: any): any;
    /**
     * this function will allow only numeric values in the input field
     *
     * @param event - event of the input field
     *
     * @param column - column of the input field
     */
    allowOnlyNumbers(event: KeyboardEvent, column: ClColumnConfig): void;
    /**
     * this function will increment the value of the input field
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     */
    increment(column: ClColumnConfig, row: any): void;
    /**
     * this function will decrement the value of the input field
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     */
    decrement(column: ClColumnConfig, row: any): void;
    /**
     * this function is the callback function on input field when user types
     *
     * @param column - column of the input field
     *
     * @param row - row of the input field
     */
    onInputChanged: import("lodash").DebouncedFunc<(event: any, row: any) => void>;
    /**
     * Editing the particular cell based on below param
     * @param element Element to be edited
     * @param column column name
     * @param rowIndex  row Index
     */
    startEditing(element: any, column: any, rowIndex: number): void;
    /**
     * Stop editing the particular cell based on below param
     * @param element element to be stopped editing
     */
    stopEditing(element: any): void;
    /**
     * Stop editing the particular cell based on below param
     * @param element element to be stopped editing
     */
    stopEditingSelect(element: any, column: any): void;
    shouldHighlightCell(row: any, column: any): string;
    rowValidation(row: any): string;
    rowChanged(row: any): void;
    inputChanged(row: any, column: any, autoSuggest?: boolean): void;
    isEdited(column: any, row: any): any;
    isRowEdited(row: any): boolean;
    isObjExist(value: string): any;
    hasKey(obj: any, key: string): boolean;
    /**
     * Auto suggestion in input field stop editing on blur
     * @param element element which cell is edited
     * @param availableOptions array of strings which was passed as autosuggestion
     * @param value value what user enters in input field
     */
    stopEditingCheck(element: any, availableOptions: any, value: string): void;
    /**
     * Moving to next cell in the same row ad make it editable
     * @param event tab event
     * @param columnKey column name
     * @param rowIndex index of the editing row
     */
    tabToNextCell(event: any, columnKey: any, rowIndex: number): void;
    /**
     * Function to make first field as editable on clicking on Tab
     * @param event tab event
     * @param columnKey column name
     * @param rowIndex index of the editing row
     */
    tabChangeEditableField(event: any, columnKey: any, rowIndex: number): void;
    /**
     * Filter data from the autosuggestion string
     * @param availableOptions Autosuggestion options array of string
     * @param value value entered in the input field
     * @returns array of filtered string based on the value entered
     */
    getFilteredText(availableOptions: any, value: string): any;
    /**
     * Function call on clicking tab
     * @param event keyboard event
     * @param columnKey column key which is unique value
     * @param rowIndex row index where the user edits
     */
    handleKeyDown(event: KeyboardEvent, columnKey: any, rowIndex: number): void;
    /**
     *
     * @param event keyboard event
     * @param columnKey column key unique parameter
     * @param rowIndex row index where the user edits
     */
    getElementRef(event: any, columnKey: any, rowIndex: number): void;
    isDisabled(row: any, icons: any): any;
    onFilterChange(event: any, index: number): void;
    filterSearchQueryChange: import("lodash").DebouncedFunc<(searchQuery: any) => void>;
    /**
      * onCriteriaColumnClick
      *
      * This function is the callback function on criteria column
      * this function will be triggered when criteria column is clicked
      *
      * @param row - row of the selected criteria column
      * @param selectedValue - value of the selected criteria column
      */
    onCriteriaColumnClicked(row: any, selectedValue: any): void;
    getColumnStyle(column: any): string;
    protected onActionIconClicked(row: any, actionIcon: ClIconProperties, index: number): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDataGridComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDataGridComponent, "cl-data-grid", never, { "matSortActive": { "alias": "matSortActive"; "required": false; }; "totalRecords": { "alias": "totalRecords"; "required": false; }; "showLoading": { "alias": "showLoading"; "required": false; }; "matSortDirection": { "alias": "matSortDirection"; "required": false; }; "data": { "alias": "data"; "required": true; }; "properties": { "alias": "properties"; "required": true; }; "customData": { "alias": "customData"; "required": false; }; }, {}, never, never, true, never>;
}
