import { ViewContainerRef, EventEmitter, InputSignal, OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ClDataGridInjectorComponent implements OnChanges {
    value: any;
    rowDetail: any;
    component: any;
    properties: any;
    isComponentDragged: InputSignal<boolean>;
    valueChange: EventEmitter<any>;
    viewContainer: ViewContainerRef;
    private textBlockProperties;
    private componentRef;
    ngOnChanges(): void;
    private createComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDataGridInjectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDataGridInjectorComponent, "cl-data-grid-injector", never, { "value": { "alias": "value"; "required": false; }; "rowDetail": { "alias": "rowDetail"; "required": false; }; "component": { "alias": "component"; "required": false; }; "properties": { "alias": "properties"; "required": false; }; "isComponentDragged": { "alias": "isComponentDragged"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}
