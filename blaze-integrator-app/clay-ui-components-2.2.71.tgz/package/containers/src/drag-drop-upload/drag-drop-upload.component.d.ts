import { ControlValueAccessor } from '@angular/forms';
import { SimpleChanges } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClDragDropProperties, ClPreLoadImageProperties, CustomFile, ClPreLoadMultiFileProperties } from './drag-drop-upload.properties';
import { ClFileResult, ClIconProperties, ClLabelProperties, ClUploadService } from '@clay/ui-components/basic';
import * as i0 from "@angular/core";
export declare class ClDragDropUploadComponent extends ClBaseComponent implements ControlValueAccessor {
    private uploadService;
    properties: ClDragDropProperties;
    updatedUploadIconProperties?: string;
    preLoadImageProperties?: ClPreLoadImageProperties;
    preLoadMultiFileProperties?: ClPreLoadMultiFileProperties[];
    accept: string;
    localUrl: string[];
    selectedFiles: CustomFile[];
    maxLimitDescProperties: ClLabelProperties;
    maxLimitTitleProperties: ClLabelProperties;
    maxAllowedFileTitleTextProperties: ClLabelProperties;
    maxAllowedFileDescTextProperties: ClLabelProperties;
    dimensionDescProperties: ClLabelProperties;
    dimensionTitleProperties: ClLabelProperties;
    supportedDescProperties: ClLabelProperties;
    supportedTitleProperties: ClLabelProperties;
    stackLayoutProperties: any;
    fileDisplayGridProperties: any;
    protected _value: any;
    onChange: (_: any) => void;
    onTouched: (_: any) => void;
    fileResult: ClFileResult[];
    errorTextProperties: ClLabelProperties;
    duplicateErrorTextProperties: ClLabelProperties;
    deleteIconProperties: ClIconProperties;
    dragDropTextProperties: ClLabelProperties;
    orTextProperties: ClLabelProperties;
    browseFileTextProperties: ClLabelProperties;
    fileUploadIconProperties: ClIconProperties;
    getImageUrl(): string;
    constructor(uploadService: ClUploadService);
    writeValue(value: any): void;
    registerOnChange(fn: (_: any) => {}): void;
    registerOnTouched(fn: (_: any) => {}): void;
    get value(): any;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    /**
     * onFileUpload
     *
     * This function will call the service to upload the file
     *
     * @param event
     */
    onFileUpload(event: unknown): void;
    /**
     * resetView
     *
     * This function will reset the entire view
     */
    private resetView;
    /**
     * show preview image
     *
     * This method will generate the url of the selected file for preview
     *
     * @param files - array of files
     */
    private showPreviewImage;
    private setPreviewImageProperties;
    /**
     * files dropped
     *
     * This function is called when the file is dropped in the UI
     *
     * @param selectedFiles - selected Files array which were dropped
     */
    filesDropped(selectedFiles: unknown): void;
    /**
     * on delete file
     *
     * this function will delete the selected file
     */
    onDeleteFile(): void;
    pushBase64Files(base64Files: {
        name: string;
        base64: string;
    }[]): void;
    /**
     * push selected files
     *
     * this function will call the callback function
     */
    pushSelectedFiles(): void;
    private setDefaultPropertyValue;
    onDeleteEachFile(index: any): void;
    protected onFileClicked(fileName: string): void;
    displaySize(sizeInBytes: number): string;
    convertBytesToMB(bytes: number): number;
    convertBytesToKB(bytes: number): number;
    createIconProperties(id: string, iconName: string): ClIconProperties;
    getFileIconProperties(file: any): ClIconProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDragDropUploadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDragDropUploadComponent, "cl-drag-drop-upload", never, { "properties": { "alias": "properties"; "required": true; }; "updatedUploadIconProperties": { "alias": "updatedUploadIconProperties"; "required": false; }; "preLoadImageProperties": { "alias": "preLoadImageProperties"; "required": false; }; "preLoadMultiFileProperties": { "alias": "preLoadMultiFileProperties"; "required": false; }; }, {}, never, never, true, never>;
}
