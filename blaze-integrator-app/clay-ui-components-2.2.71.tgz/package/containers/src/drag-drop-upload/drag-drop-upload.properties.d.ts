import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface ClUploadError {
    formatErrorMsg?: string;
    fileSizeErrorMsg?: string;
    dimensionErrorMsg?: string;
    maxFileAllowedErrorMsg?: string;
}
export declare enum ClFileType {
    csv = "text/csv",
    png = "image/png",
    txt = "text/plain",
    html = "text/html",
    jpg = "image/jpeg",
    svg = "image/svg+xml",
    pdf = "application/pdf",
    json = "application/json",
    image = "image/jpeg,image/png,image/svg+xml",
    xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    docx = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
}
export interface ClPreLoadImageProperties {
    size?: string;
    imageUrl: string;
    fileName: string;
}
export interface ClPreLoadMultiFileProperties {
    fileName?: string;
    base64val?: string;
    base64DataType?: ClFileType;
}
export interface IClDragDropProperties extends IClBaseComponentProperties {
    width?: string;
    height?: string;
    maxLimit?: string;
    dimension?: string;
    uploadIcon?: string;
    maxLimitInKb?: number;
    onFileUpload?: Function;
    onFileClicked?: Function;
    maxLimitTitle?: string;
    maxAllowedFileHintTitleText?: string;
    maxAllowedFileHintDescText?: string;
    maxAllowedFiles?: number;
    supportedFile?: string;
    dimensionTitle?: string;
    validationsList?: any[];
    uploadError?: ClUploadError;
    afterUploadBgColor?: string;
    supportedFileTitle?: string;
    allowedFileTypes?: ClFileType[];
    preLoadImageProperties?: ClPreLoadImageProperties;
    preLoadMultiFileProperties?: ClPreLoadMultiFileProperties[];
    isMultiple?: boolean;
    fileGridView?: boolean;
}
export declare class ClDragDropStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    uploadIconCssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClDragDropProperties implements IClDragDropProperties {
    width?: string;
    height?: string;
    maxLimit?: string;
    dimension?: string;
    uploadIcon?: string;
    maxLimitInKb?: number;
    onFileUpload?: Function;
    onFileClicked?: Function;
    maxLimitTitle?: string;
    maxAllowedFileHintTitleText?: string;
    maxAllowedFileHintDescText?: string;
    maxAllowedFiles?: number;
    supportedFile?: string;
    dimensionTitle?: string;
    validationsList?: any[];
    uploadError?: ClUploadError;
    afterUploadBgColor?: string;
    supportedFileTitle?: string;
    allowedFileTypes?: ClFileType[];
    preLoadImageProperties?: ClPreLoadImageProperties;
    preLoadMultiFileProperties?: ClPreLoadMultiFileProperties[];
    isMultiple?: boolean;
    fileGridView?: boolean;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClDragDropStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    constructor();
}
export interface CustomFile extends File {
    error?: string;
    extension?: string;
}
