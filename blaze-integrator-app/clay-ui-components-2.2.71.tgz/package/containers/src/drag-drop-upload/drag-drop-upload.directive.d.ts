import { EventEmitter } from "@angular/core";
import * as i0 from "@angular/core";
export declare class ClDragDropDirective {
    selectedFiles: EventEmitter<unknown>;
    private _background;
    onDragOver(event: DragEvent): void;
    onDragLeave(event: DragEvent): void;
    onDrop(event: DragEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDragDropDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ClDragDropDirective, "[clDragDropUpload]", never, {}, { "selectedFiles": "selectedFiles"; }, never, never, true, never>;
}
