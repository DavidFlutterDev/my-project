export declare const base64string: string;
