import { Subscription } from 'rxjs';
import { OnInit, QueryList, OnDestroy, AfterContentInit } from '@angular/core';
import { ClCarouselProperties } from './carousel.properties';
import { ClCarouselContentComponent } from './carousel-content';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export declare class ClCarouselComponent extends ClBaseContainerComponent implements OnInit, OnDestroy, AfterContentInit {
    properties: ClCarouselProperties;
    private readonly carouselContentItems;
    protected carouselContents: QueryList<ClCarouselContentComponent>;
    protected animationStates: any;
    protected currentIndex: number;
    protected autoSlideSubscription: Subscription;
    constructor();
    ngOnInit(): void;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private startAutoSlide;
    private prevSlide;
    private nextSlide;
    protected goToSlide(index: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClCarouselComponent, "cl-carousel", never, { "properties": { "alias": "properties"; "required": false; }; }, {}, ["carouselContentItems"], never, true, never>;
}
