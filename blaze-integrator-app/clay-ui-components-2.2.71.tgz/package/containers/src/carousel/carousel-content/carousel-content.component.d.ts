import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ClCarouselContentComponent {
    contentTemplate: TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClCarouselContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClCarouselContentComponent, "cl-carousel-content", never, {}, {}, never, ["*"], true, never>;
}
