import { ClIconProperties } from "@clay/ui-components/basic";
import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, ClBaseContainerComponentProperties } from "@clay/ui-components/shared";
export interface IClCarouselProperties extends ClBaseContainerComponentProperties {
    numberOfSlides?: number;
    showIndicatorsInside?: boolean;
    enableAnimationDuration?: boolean;
    animationDurationInMilliseconds?: number;
    children?: any[];
}
export declare class ClCarouselStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    sliderContentCss?: string;
    activeNavigationColor?: string;
    inActiveNavigationColor?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export declare class ClCarouselProperties implements IClCarouselProperties {
    id: string;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    showIndicatorsInside?: boolean;
    style?: ClCarouselStyleProperties;
    iconProperties?: ClIconProperties;
    enableAnimationDuration?: boolean;
    animationDurationInMilliseconds?: number;
    numberOfSlides?: number;
    children?: any[];
    constructor();
}
