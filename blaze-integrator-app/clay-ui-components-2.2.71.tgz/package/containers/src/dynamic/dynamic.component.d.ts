import { SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ClDynamicComponent {
    properties: any;
    ngForm?: any;
    isDynamicTree: boolean;
    dynamicTreeOptions: any;
    dynamicTreeValidation: boolean;
    validationOptions: {
        debounceTime: number;
    };
    dynamicForm: any;
    dynamicValidationOptions: any;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    protected onValueChange(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDynamicComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDynamicComponent, "cl-dynamic-renderer", never, { "properties": { "alias": "properties"; "required": false; }; "ngForm": { "alias": "ngForm"; "required": false; }; "isDynamicTree": { "alias": "isDynamicTree"; "required": false; }; "dynamicTreeOptions": { "alias": "dynamicTreeOptions"; "required": false; }; "dynamicTreeValidation": { "alias": "dynamicTreeValidation"; "required": false; }; }, {}, never, never, true, never>;
}
