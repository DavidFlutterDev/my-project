import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface IClDualSortListProperties extends IClBaseComponentProperties {
    validationsList?: any[];
    options?: ClDualSortListOption[];
    leftListTitle?: string;
    rightListTitle?: string;
    leftListTooltipContent?: string[];
    rightListTooltipContent?: string[];
    onSelected?: (selectedItems: ClDualSortListOption[]) => void;
}
export interface ClDualSortListOption {
    name: string;
    value: string;
    selected: boolean;
}
export declare class ClDualSortListStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    titleCssClasses?: string;
    titleIconSizeCssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClDualSortListProperties implements IClDualSortListProperties {
    validationsList?: any[];
    options?: ClDualSortListOption[];
    leftListTitle?: string;
    rightListTitle?: string;
    leftListTooltipContent?: string[];
    rightListTooltipContent?: string[];
    onSelected?: (selectedItems: ClDualSortListOption[]) => void;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClDualSortListStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    constructor();
}
