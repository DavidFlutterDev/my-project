import { OnChanges } from '@angular/core';
import { ClDynamicTreeViewNode } from '../dynamic-tree-view.properties';
import { ClButtonProperties } from '@clay/ui-components/basic';
import * as i0 from "@angular/core";
export declare class ClDynamicTreeViewChildComponent implements OnChanges {
    index: number;
    node: ClDynamicTreeViewNode;
    childAddButtonProperties?: ClButtonProperties;
    dynamicTreeId: string;
    private dynamicTreeService;
    dynamicTreeOptions: any;
    private addChildFunction;
    private parentNodeIds;
    /**
     * this function will calculate the width for tree nodes
     *
     * @param depth - depth of the tree node
     *
     * @returns - style with width properties calculated
     */
    protected getTreeNodeWidth(depth: number): {
        width: string;
    };
    ngOnInit(): void;
    setDynamicTreeOptions(): void;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    ngDoCheck(): void;
    addChildNode(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDynamicTreeViewChildComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDynamicTreeViewChildComponent, "cl-dynamic-tree-view-child", never, { "index": { "alias": "index"; "required": true; }; "node": { "alias": "node"; "required": true; }; "childAddButtonProperties": { "alias": "childAddButtonProperties"; "required": false; }; "dynamicTreeId": { "alias": "dynamicTreeId"; "required": false; }; }, {}, never, never, true, never>;
}
