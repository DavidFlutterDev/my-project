import { Subject } from 'rxjs';
import { FormGroup } from '@angular/forms';
import { ClDynamicTreeViewProperties } from './dynamic-tree-view.properties';
import * as i0 from "@angular/core";
export declare class DynamicTreeViewService {
    addChildNode: Subject<any>;
    ngForm: any;
    deletedNodeIds: string[];
    properties: ClDynamicTreeViewProperties;
    constructor();
    getAllParentIds(nodeId: any): string[];
    getParentIds(tree: any[], targetId: string, path?: string[]): string[];
    deleteNodeFormGroup(id: string, parentNodeIds: string[]): void;
    findFormGroup(formArr: FormGroup[], id: string): {
        index: number;
        formGroup: FormGroup<any>;
    } | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicTreeViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DynamicTreeViewService>;
}
