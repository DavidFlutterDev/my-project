import { ClButtonProperties } from "@clay/ui-components/basic";
import { ClComponentTypes, IClBaseComponentProperties } from "@clay/ui-components/shared";
export interface ClDynamicTreeViewNode {
    id: number;
    depth?: number;
    formValue?: any;
    template?: any;
    properties?: any;
    nodes?: ClDynamicTreeViewNode[];
    showAddChildrenButton?: boolean;
    childAddButtonProperties?: ClButtonProperties;
}
export interface IClDynamicTreeViewProperties extends IClBaseComponentProperties {
    nodes?: ClDynamicTreeViewNode[];
    addButtonProperties?: ClButtonProperties;
}
export declare class ClDynamicTreeViewProperties implements IClDynamicTreeViewProperties {
    id: string;
    type: ClComponentTypes;
    nodes?: ClDynamicTreeViewNode[];
    addButtonProperties?: ClButtonProperties;
    constructor();
}
