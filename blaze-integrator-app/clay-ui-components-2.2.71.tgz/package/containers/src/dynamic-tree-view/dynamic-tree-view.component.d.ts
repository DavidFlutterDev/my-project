import { OnInit, AfterContentChecked } from '@angular/core';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import { ClDynamicTreeViewProperties } from './dynamic-tree-view.properties';
import * as i0 from "@angular/core";
export declare class ClDynamicTreeViewComponent extends ClBaseContainerComponent implements OnInit, AfterContentChecked {
    properties: ClDynamicTreeViewProperties;
    ngForm: any;
    private afterContentCheckedCalled;
    private dynamicTreeService;
    constructor();
    ngOnInit(): void;
    ngAfterContentChecked(): void;
    ngDoCheck(): void;
    /**
     * this function is used to add depth to the tree view for managing the width of the children
     *
     * @param treeNode - array of objects
     *
     * @param depth - depth of the tree node
     */
    private addDepth;
    private setButtonProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClDynamicTreeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClDynamicTreeViewComponent, "cl-dynamic-tree-view", never, { "properties": { "alias": "properties"; "required": true; }; "ngForm": { "alias": "ngForm"; "required": false; }; }, {}, never, never, true, never>;
}
