import { OnInit } from '@angular/core';
import { MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { ClBottomSheetProperties } from '../bottom-sheet.properties';
import { ClIconProperties } from '@clay/ui-components/basic';
import * as i0 from "@angular/core";
export declare class ClBottomSheetComponent implements OnInit {
    private data;
    private _bottomSheetRef;
    properties: ClBottomSheetProperties;
    closeIconProperties: ClIconProperties;
    constructor(data: any, _bottomSheetRef: MatBottomSheetRef<ClBottomSheetComponent>);
    ngOnInit(): void;
    private setIconProperties;
    private closeBottomSheet;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBottomSheetComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClBottomSheetComponent, "cl-bottom-sheet", never, {}, {}, never, never, true, never>;
}
