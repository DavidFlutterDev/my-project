import { MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { ClBottomSheetProperties } from "./bottom-sheet.properties";
import { ClBottomSheetComponent } from "./sheet/bottom-sheet.component";
import * as i0 from "@angular/core";
export declare class ClBottomSheetService {
    private _bottomSheet;
    open(config: ClBottomSheetProperties): MatBottomSheetRef<ClBottomSheetComponent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBottomSheetService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClBottomSheetService>;
}
