import { ComponentType } from '@angular/cdk/portal';
import { ClComponentInjectProperties } from '@clay/ui-components/shared';
import { ClIconProperties, ClTextBlockProperties } from "@clay/ui-components/basic";
export interface ClBottomSheetProperties {
    id?: string;
    autoFocus?: boolean;
    hasBackdrop?: boolean;
    dismissible?: boolean;
    title: ClTextBlockProperties;
    component: ComponentType<any>;
    actionIcons?: ClIconProperties[];
    style?: ClBottomSheetStyleProperties;
    componentProperties?: ClComponentInjectProperties;
}
export interface ClBottomSheetStyleProperties {
    cssClasses?: string;
    panelClass?: string;
    backdropClass?: string;
    closeIconCssClasses?: string;
}
