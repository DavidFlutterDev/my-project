import { BooleanInput } from '@angular/cdk/coercion';
import { OnChanges, SimpleChanges } from '@angular/core';
import { ClCardFace, ClCardProperties } from './card.properties';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export declare class ClCardComponent extends ClBaseContainerComponent implements OnChanges {
    expanded: boolean;
    face: ClCardFace;
    flippable: boolean;
    properties: ClCardProperties;
    static readonly ngAcceptInputType_expanded: BooleanInput;
    static readonly ngAcceptInputType_flippable: BooleanInput;
    constructor();
    ngOnInit(): void;
    /**
     * Host binding for component classes
     */
    get classList(): any;
    /**
     * On changes
     *
     * @param changes
     */
    ngOnChanges(changes: SimpleChanges): void;
    onCardClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClCardComponent, "cl-card", ["clCard"], { "expanded": { "alias": "expanded"; "required": false; }; "face": { "alias": "face"; "required": false; }; "flippable": { "alias": "flippable"; "required": false; }; "properties": { "alias": "properties"; "required": false; }; }, {}, never, ["[clFlipCardTitle]", "[clCardFront]", "[clCardBack]", "[clCardTitle]", "[clCardActions]", "*", "[clCardExpansion]"], true, never>;
}
