import { ClBaseVisual, ClBaseBehavior, ClComponentTypes, IClBaseStyleProperties, IClBaseComponentProperties } from '@clay/ui-components/shared';
export type ClCardFace = 'front' | 'back';
export interface IClCardProperties extends IClBaseComponentProperties {
    children?: any;
    cardTitle?: string;
    flippable?: boolean;
    routerLink?: string;
    flipOnHover?: boolean;
    onCardClicked?: () => void;
}
export declare class ClCardStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
    labelCssClasses?: string;
}
export declare class ClCardProperties implements IClCardProperties {
    id: string;
    label?: string;
    children?: any;
    cardTitle?: string;
    flippable?: boolean;
    routerLink?: string;
    flipOnHover?: boolean;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    onCardClicked?: () => void;
    behaviorType?: ClBaseBehavior;
    style?: ClCardStyleProperties;
    constructor();
}
