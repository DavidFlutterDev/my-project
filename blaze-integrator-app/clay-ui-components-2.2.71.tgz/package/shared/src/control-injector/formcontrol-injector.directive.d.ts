import { ControlValueAccessor, FormControlName } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class FormControlInjector {
    constructor(formControlName: FormControlName, accessors: ControlValueAccessor[]);
    static ɵfac: i0.ɵɵFactoryDeclaration<FormControlInjector, [null, { optional: true; }]>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormControlInjector, "[formControlName]", never, {}, {}, never, never, true, never>;
}
