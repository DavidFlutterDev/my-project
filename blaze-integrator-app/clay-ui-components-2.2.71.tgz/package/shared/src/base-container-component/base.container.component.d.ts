import { ClBaseComponent } from '../base-component/base.component';
import * as i0 from "@angular/core";
export declare abstract class ClBaseContainerComponent extends ClBaseComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBaseContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClBaseContainerComponent, "ng-component", never, {}, {}, never, never, false, never>;
}
