import { ClBaseComponentProperties } from '../base-component/base.properties';
export declare class ClBaseContainerComponentProperties extends ClBaseComponentProperties {
}
