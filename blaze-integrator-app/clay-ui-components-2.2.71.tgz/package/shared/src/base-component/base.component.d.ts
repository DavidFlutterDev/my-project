import { FormControlName, NgModel } from '@angular/forms';
import { IClBaseComponentProperties } from './base.properties';
import { ClComponentRegistryService } from '../component-registry';
import { ElementRef, OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare abstract class ClBaseComponent implements IClBaseComponent, OnInit, OnDestroy {
    protected elem?: ElementRef;
    protected componentRegistry: ClComponentRegistryService;
    templateControl?: NgModel;
    reactiveControl?: FormControlName;
    private valueSub?;
    properties: IClBaseComponentProperties;
    loopIndex?: any;
    setElementRef(elem: ElementRef): void;
    ngOnDestroy(): void;
    ngOnInit(): void;
    handleAnalytics(): void;
    setTemplateControl(ngModel: NgModel): void;
    subscribeToValueChanges(callbackFunction: any): void;
    setReactiveControl(formControlName: FormControlName): void;
    getTemplateControl(): NgModel | undefined;
    getReactiveControl(): FormControlName | undefined;
    setProperties(properties: IClBaseComponentProperties): void;
    getProperties(): IClBaseComponentProperties | undefined;
    getLoopIndex(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClBaseComponent, "ng-component", never, { "properties": { "alias": "properties"; "required": true; }; "loopIndex": { "alias": "loopIndex"; "required": false; }; }, {}, never, never, false, never>;
}
export interface IClBaseComponent {
    handleAnalytics(): void;
    setElementRef(elem: ElementRef): void;
    setTemplateControl(ngModel: NgModel): void;
    setReactiveControl(formControlName: FormControlName): void;
    getTemplateControl(): NgModel | undefined;
    getReactiveControl(): FormControlName | undefined;
    setProperties(properties: IClBaseComponentProperties): void;
    getProperties(): IClBaseComponentProperties | undefined;
    getLoopIndex(): any | undefined;
}
