export interface ClOptions {
    text: string;
    value: string;
    hidden?: boolean;
    selected?: boolean;
    parentValue?: string;
}
export interface IClBaseComponentProperties {
    id: string;
    name?: string;
    label?: string;
    type: ClComponentTypes;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: IClBaseStyleProperties;
}
export declare enum ClBaseBehavior {
    default = "default"
}
export declare enum ClBaseVisual {
    default = "default"
}
export interface IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    alignContent?: string;
    justifyContent?: string;
}
export declare enum ClComponentTypes {
    chip = "chip",
    icon = "icon",
    form = "form",
    tabs = "tabs",
    card = "card",
    menu = "menu",
    email = "email",
    input = "input",
    label = "label",
    radio = "radio",
    timer = "timer",
    image = "image",
    toast = "toast",
    switch = "switch",
    select = "select",
    button = "button",
    wizard = "wizard",
    default = "default",
    stepper = "stepper",
    spinner = "spinner",
    codeView = "codeView",
    dataGrid = "dataGrid",
    textarea = "textarea",
    checkbox = "checkbox",
    chipList = "chipList",
    treeView = "treeView",
    carousel = "carousel",
    accordion = "accordion",
    chipInput = "chipInput",
    iconsList = "iconsList",
    textBlock = "textBlock",
    uploadTile = "uploadTile",
    timepicker = "timepicker",
    datePicker = "datePicker",
    progressBar = "progressBar",
    multiselect = "multiselect",
    contactInput = "contactInput",
    autocomplete = "autocomplete",
    toggleButton = "toggleButton",
    dualSortList = "dualSortList",
    nestedLayout = "nestedLayout",
    resizableGrid = "resizableGrid",
    hyperLinkText = "hyperLinkText",
    dragDropUpload = "dragDropUpload",
    selectWithGroup = "selectWithGroup",
    dynamicTreeView = "dynamicTreeView",
    multiLevelSelect = "multiLevelSelect",
    timelineActivity = "timelineActivity",
    multiAutocomplete = "multiAutocomplete",
    nestedAutoComplete = "nestedAutoComplete",
    nestedSelect = "nestedSelect",
    filePreview = "filePreview"
}
export declare class ClBaseComponentProperties implements IClBaseComponentProperties {
    id: string;
    name?: string;
    label?: string;
    visualType?: ClBaseVisual;
    behaviorType?: ClBaseBehavior;
    style?: IClBaseStyleProperties;
    type: ClComponentTypes;
}
export interface ClCountry {
    id: string;
    name: string;
    code: string;
}
export declare enum ClValidationTypes {
    required = "required",
    min = "min",
    max = "max",
    minLength = "minlength",
    maxLength = "maxlength",
    custom = "custom"
}
export type ClErrorHandler = {
    [key in ClValidationTypes]: string;
};
