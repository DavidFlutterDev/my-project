export interface ClComponentInjectProperties {
    inputs?: ClInput[];
    outputs?: ClOutput[];
}
export interface ClInput {
    key: any;
    value: any;
    isSignal?: boolean;
}
export interface ClOutput {
    functionName: any;
}
