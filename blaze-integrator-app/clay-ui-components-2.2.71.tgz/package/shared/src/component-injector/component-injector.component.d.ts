import { ComponentType } from '@angular/cdk/portal';
import { EventEmitter, OnChanges, SimpleChanges, ViewContainerRef } from '@angular/core';
import { ClComponentInjectProperties } from './component-injector.properties';
import * as i0 from "@angular/core";
export declare class ClComponentInjectorComponent implements OnChanges {
    component: ComponentType<any>;
    properties?: ClComponentInjectProperties;
    changeEvent: EventEmitter<any>;
    viewContainerRef: ViewContainerRef;
    private _componentRef;
    private _clNgComponentFactory;
    ngOnChanges(changes: SimpleChanges): void;
    private createComponent;
    private _setInputParameters;
    private _setOutputParameters;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClComponentInjectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClComponentInjectorComponent, "cl-component-injector", never, { "component": { "alias": "component"; "required": true; }; "properties": { "alias": "properties"; "required": false; }; }, { "changeEvent": "changeEvent"; }, never, never, true, never>;
}
