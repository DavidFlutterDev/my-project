import { Signal, TemplateRef } from "@angular/core";
import { MatCalendarView } from "@angular/material/datepicker";
import { FloatLabelType, MatFormFieldAppearance, SubscriptSizing } from "@angular/material/form-field";
import { ClBaseBehavior, ClBaseVisual, ClComponentTypes, IClBaseComponentProperties, IClBaseStyleProperties } from "@clay/ui-components/shared";
export interface IClDatePickerProperties extends IClBaseComponentProperties {
    minDate?: Date | string;
    maxDate?: Date | string;
    name?: string;
    range?: boolean;
    format?: string;
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    showTime?: boolean;
    optional?: boolean;
    suffixIcon?: string;
    prefixIcon?: string;
    placeholder?: string;
    onValueChange?: Function;
    startView?: MatCalendarView;
    showOnlyMonthYear?: boolean;
    appearance?: MatFormFieldAppearance;
    subscriptSizing?: SubscriptSizing;
    fromDate?: string;
    toDate?: string;
    floatLabel?: FloatLabelType;
}
export declare class ClDatePickerStyleProperties implements IClBaseStyleProperties {
    cssClasses?: string;
    contentWidth?: string;
    justifyContent?: string;
    alignContent?: string;
}
export declare class ClDatePickerProperties implements IClDatePickerProperties {
    minDate?: Date | string;
    maxDate?: Date | string;
    name?: string;
    range?: boolean;
    format?: string;
    infoMsg?: string | TemplateRef<any>;
    showInfoMsg?: Signal<boolean> | boolean;
    hintText?: string;
    showTime?: boolean;
    optional?: boolean;
    suffixIcon?: string;
    prefixIcon?: string;
    placeholder?: string;
    onValueChange?: Function;
    startView?: MatCalendarView;
    showOnlyMonthYear?: boolean;
    appearance?: MatFormFieldAppearance;
    id: string;
    type: ClComponentTypes;
    label?: string;
    style?: ClDatePickerStyleProperties;
    behaviorType?: ClBaseBehavior;
    visualType?: ClBaseVisual;
    fromDate?: string;
    toDate?: string;
    subscriptSizing?: SubscriptSizing;
    floatLabel?: FloatLabelType;
    constructor();
}
