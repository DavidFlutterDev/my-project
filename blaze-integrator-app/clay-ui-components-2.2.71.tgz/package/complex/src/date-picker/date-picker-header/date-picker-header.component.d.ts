import { DatePipe } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { DateAdapter, MatDateFormats } from '@angular/material/core';
import { MatCalendar } from '@angular/material/datepicker';
import { DatePickerService } from '../datepicker.service';
import * as i0 from "@angular/core";
export declare class DatePickerHeaderComponent {
    private datePipe;
    private cdr;
    private calendar;
    private _dateAdapter;
    private datepickerService;
    private _dateFormats;
    private subscription;
    private _destroyed;
    range: boolean;
    toLabel: string;
    fromLabel: string;
    private displayFormat;
    endDate: string;
    endDateTime: string;
    startDate: string;
    startDateTime: string;
    showTime: boolean;
    showYearAndMonth: boolean;
    constructor(datePipe: DatePipe, cdr: ChangeDetectorRef, calendar: MatCalendar<any>, _dateAdapter: DateAdapter<any>, datepickerService: DatePickerService, _dateFormats: MatDateFormats);
    /** Handles user clicks on the period label. */
    currentPeriodClicked(): void;
    /** Handles user clicks on the previous button. */
    customPrev(): void;
    /** Handles user clicks on the next button. */
    customNext(): void;
    previousClicked(mode: 'month' | 'year'): void;
    nextClicked(mode: 'month' | 'year'): void;
    get periodLabel(): string;
    parseData(data: any): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatePickerHeaderComponent, "cl-date-picker-header", never, {}, {}, never, never, true, never>;
}
