import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class DatePickerService {
    dataSubject: BehaviorSubject<any>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePickerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DatePickerService>;
}
