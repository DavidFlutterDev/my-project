import { EventEmitter } from '@angular/core';
import { ClTreeViewChildProperties, ClTreeViewProperties } from '../tree-view.properties';
import * as i0 from "@angular/core";
export declare class ClChildTreeViewComponent {
    treeViewConfig: ClTreeViewProperties;
    properties: ClTreeViewChildProperties[];
    addClicked: EventEmitter<any>;
    editClicked: EventEmitter<any>;
    viewClicked: EventEmitter<any>;
    deleteClicked: EventEmitter<any>;
    actionClicked: EventEmitter<any>;
    treeNodeClicked: EventEmitter<any>;
    /**
     * this function will calculate the width for tree nodes
     *
     * @param depth - depth of the tree node
     *
     * @returns - style with width properties calculated
     */
    getTreeNodeWidth(depth: number): {
        width: string;
    };
    /**
     * this function will be triggered when the tree node was clicked
     * this function also calls expand collapse tree function
     *
     * @param treeNode - tree node where clicked and needs to be expanded or collapsed
     */
    onTreeNodeClicked(treeNode: ClTreeViewChildProperties): void;
    /**
     * this function is the call back function for add button
     *
     * @param treeNode - tree node where clicked
     */
    onAddClicked(treeNode: ClTreeViewChildProperties): void;
    /**
     * this function is the call back function for edit button
     *
     * @param treeNode - tree node where clicked
     */
    onEditClicked(treeNode: ClTreeViewChildProperties): void;
    /**
     * this function is the call back function for view button
     *
     * @param treeNode - tree node where clicked
     */
    onViewClicked(treeNode: ClTreeViewChildProperties): void;
    /**
     * this function is the call back function for delete button
     *
     * @param treeNode - tree node where clicked
     */
    onDeleteClicked(treeNode: ClTreeViewChildProperties): void;
    onActionIconClicked(treeNode: ClTreeViewChildProperties, selectedAction: string, index: number): void;
    onMouseHoverFunction(tree: ClTreeViewChildProperties): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClChildTreeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClChildTreeViewComponent, "cl-child-tree-view", never, { "treeViewConfig": { "alias": "treeViewConfig"; "required": true; }; "properties": { "alias": "properties"; "required": true; }; }, { "addClicked": "addClicked"; "editClicked": "editClicked"; "viewClicked": "viewClicked"; "deleteClicked": "deleteClicked"; "actionClicked": "actionClicked"; "treeNodeClicked": "treeNodeClicked"; }, never, never, true, never>;
}
