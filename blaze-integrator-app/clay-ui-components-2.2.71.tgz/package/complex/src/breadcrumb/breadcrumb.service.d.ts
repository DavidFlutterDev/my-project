import { ClButtonProperties } from '@clay/ui-components/basic';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import * as i0 from "@angular/core";
export declare class ClBreadCrumbService {
    pageTitle: BehaviorSubject<string>;
    breadcrumbString: BehaviorSubject<string>;
    breadcrumbActionButtons: BehaviorSubject<ClButtonProperties[]>;
    /**
     * this function will set the page title and replace it with breadcrumb
     *
     * @param value title of the page
     */
    setPageTitle(value: string): void;
    /**
     * this function will reset the page title
     */
    resetPageTitle(): void;
    /**
     * this function will add a custom string at the end of breadcrumb
     *
     * @param string to be added
     */
    setBreadCrumbString(value: string): void;
    /**
     * this function will reset the custom string
     */
    resetBreadCrumbString(): void;
    /**
     * this function will add action buttons at the extreme end of breadcrumb row
     *
     * @param button properties
     */
    setBreadCrumbActionButtons(actionButtons: ClButtonProperties[]): void;
    /**
     * this function will reset the action buttons
     */
    resetBreadCrumbActionButtons(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBreadCrumbService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClBreadCrumbService>;
}
