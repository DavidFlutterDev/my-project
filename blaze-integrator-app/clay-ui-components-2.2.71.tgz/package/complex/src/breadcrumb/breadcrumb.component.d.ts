import { ActivatedRoute, Router } from '@angular/router';
import { ClButtonProperties } from '@clay/ui-components/basic';
import { ClBreadCrumbService } from './breadcrumb.service';
import * as i0 from "@angular/core";
export interface ClBreadCrumb {
    route: string;
    label: string;
    clickable: boolean;
    urlSegment: string;
}
export declare class ClBreadcrumbComponent {
    private router;
    private activatedRoute;
    private breadCrumbService;
    pageTitle: string;
    breadcrumbString: string;
    breadcrumbs: ClBreadCrumb[];
    breadcrumbActionButtons: ClButtonProperties[];
    constructor(router: Router, activatedRoute: ActivatedRoute, breadCrumbService: ClBreadCrumbService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    private _buildBreadcrumbs;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClBreadcrumbComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClBreadcrumbComponent, "cl-breadcrumb", never, {}, {}, never, never, true, never>;
}
