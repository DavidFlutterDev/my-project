import { OnInit } from '@angular/core';
import { UserModel } from '../sign-up/sign-up.model';
import { ClCardFace } from '@clay/ui-components/containers';
import * as i0 from "@angular/core";
export declare class ClAuthComponent implements OnInit {
    userList: UserModel[];
    protected showSigInForm: boolean;
    cardFace: ClCardFace;
    /**
     * Constructor
     */
    constructor();
    /**
     * On init
     */
    ngOnInit(): void;
    toggleCard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClAuthComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClAuthComponent, "cl-auth", never, { "userList": { "alias": "userList"; "required": true; }; }, {}, never, never, true, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ClAuthComponent>;
}
