import { AfterViewInit, OnDestroy } from '@angular/core';
import { NgModel, NgModelGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class ControlWrapperComponent implements AfterViewInit, OnDestroy {
    ngModel?: NgModel;
    readonly ngModelGroup: NgModelGroup | null;
    private readonly destroy$$;
    private readonly cdRef;
    private readonly formDirective;
    private previousError?;
    get invalid(): false | string[] | undefined;
    get errors(): string[] | undefined;
    private get control();
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ControlWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ControlWrapperComponent, "[cl-control-wrapper]", never, {}, {}, ["ngModel"], ["*"], true, never>;
}
