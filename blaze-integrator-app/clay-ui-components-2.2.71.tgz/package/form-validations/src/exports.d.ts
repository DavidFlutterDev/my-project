import { ControlContainer, FormsModule, NgForm } from '@angular/forms';
import { ValidateRootFormDirective } from './directives/validate-root-form.directive';
import { ControlWrapperComponent } from './components/control-wrapper/control-wrapper.component';
import { FormDirective } from './directives/form.directive';
import { FormModelDirective } from './directives/form-model.directive';
import { FormModelGroupDirective } from './directives/form-model-group.directive';
/**
 * The providers we need in every child component that holds an ngModelGroup
 */
export declare const vestFormsViewProviders: (import("@angular/core").FactoryProvider | {
    provide: typeof ControlContainer;
    useExisting: typeof NgForm;
})[];
/**
 * Exports all the stuff we need to use the template driven forms
 */
export declare const vestForms: readonly [typeof ValidateRootFormDirective, typeof ControlWrapperComponent, typeof FormDirective, typeof FormsModule, typeof FormModelDirective, typeof FormModelGroupDirective];
