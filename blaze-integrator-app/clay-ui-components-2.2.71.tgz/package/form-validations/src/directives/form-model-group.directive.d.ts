import { AbstractControl, AsyncValidator, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';
import { ValidationOptions } from './validation-options';
import * as i0 from "@angular/core";
/**
 * Hooks into the ngModelGroup selector and triggers an asynchronous validation for a form group
 * It will use a vest suite behind the scenes
 */
export declare class FormModelGroupDirective implements AsyncValidator {
    validationOptions: import("@angular/core").InputSignal<ValidationOptions>;
    private readonly formDirective;
    validate(control: AbstractControl): Observable<ValidationErrors | null>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormModelGroupDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormModelGroupDirective, "[ngModelGroup]", never, { "validationOptions": { "alias": "validationOptions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
