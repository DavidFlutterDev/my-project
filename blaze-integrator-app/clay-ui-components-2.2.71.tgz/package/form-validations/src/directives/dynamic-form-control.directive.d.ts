import { Injector } from '@angular/core';
import { AbstractControl, ControlValueAccessor, FormControl, FormGroup, NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class DynamicFormControlDirective extends NgControl {
    private injector;
    controlName: string;
    formGroup?: FormGroup;
    formControl: FormControl;
    validators?: [];
    valueAccessor: ControlValueAccessor | null;
    constructor(injector: Injector);
    ngOnInit(): void;
    ngOnDestroy(): void;
    get path(): string[] | null;
    get control(): AbstractControl;
    viewToModelUpdate(newValue: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicFormControlDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<DynamicFormControlDirective, "[clDynamicFormControl]", never, { "controlName": { "alias": "dynamicFormControl"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "validators": { "alias": "validators"; "required": false; }; }, {}, never, never, true, never>;
}
