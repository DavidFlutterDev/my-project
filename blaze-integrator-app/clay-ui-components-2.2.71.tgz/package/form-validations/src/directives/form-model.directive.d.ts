import { AbstractControl, AsyncValidator, ValidationErrors } from '@angular/forms';
import { Observable } from 'rxjs';
import { ValidationOptions } from './validation-options';
import * as i0 from "@angular/core";
/**
 * Hooks into the ngModel selector and triggers an asynchronous validation for a form model
 * It will use a vest suite behind the scenes
 */
export declare class FormModelDirective implements AsyncValidator {
    validationOptions: import("@angular/core").InputSignal<ValidationOptions>;
    dynamicControlOptions: any;
    private readonly formDirective;
    validate(control: AbstractControl): Observable<ValidationErrors | null>;
    addDynamicTreeControls(control: AbstractControl, ngForm: any, dynamicControlOptions: any): void;
    findTheFormGroup(fmArray: any, parentIds: any): any;
    getNestedFormControlPath(ngForm: any, dynamicControlOptions: any): string;
    getNestedControlPath(formArr: any[], parentId: string, controlPath: any, addNode: boolean): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormModelDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormModelDirective, "[ngModel]", never, { "validationOptions": { "alias": "validationOptions"; "required": false; "isSignal": true; }; "dynamicControlOptions": { "alias": "dynamicControlOptions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
