import { OnDestroy } from '@angular/core';
import { AsyncValidatorFn, NgForm } from '@angular/forms';
import { Observable } from 'rxjs';
import { StaticSuite } from 'vest';
import { DeepRequired } from '../utils/deep-required';
import { ValidationOptions } from './validation-options';
import * as i0 from "@angular/core";
export declare class FormDirective<T extends Record<string, any>> implements OnDestroy {
    readonly ngForm: NgForm;
    /**
     * The value of the form, this is needed for the validation part
     */
    readonly formValue: import("@angular/core").InputSignal<T | null>;
    /**
     * Static vest suite that will be used to feed our angular validators
     */
    readonly suite: import("@angular/core").InputSignal<StaticSuite<string, string, (model: T, field: string, id?: string) => void> | null>;
    /**
     * The shape of our form model. This is a deep required version of the form model
     * The goal is to add default values to the shape so when the template-driven form
     * contains values that shouldn't be there (typo's) that the developer gets run-time
     * errors in dev mode
     */
    readonly formShape: import("@angular/core").InputSignal<DeepRequired<T> | null>;
    /**
     * Updates the validation config which is a dynamic object that will be used to
     * trigger validations on the dependant fields
     * Eg: ```typescript
     * validationConfig = {
     *     'passwords.password': ['passwords.confirmPassword']
     * }
     * ```
     *
     * This will trigger the updateValueAndValidity on passwords.confirmPassword every time the passwords.password gets a new value
     *
     * @param v
     */
    readonly validationConfig: import("@angular/core").InputSignal<{
        [key: string]: string[];
    } | null>;
    private readonly pending$;
    /**
     * Emits every time the form status changes in a state
     * that is not PENDING
     * We need this to assure that the form is in 'idle' state
     */
    readonly idle$: Observable<import("@angular/forms").FormControlStatus>;
    /**
     * Triggered as soon as the form value changes
     * Also every time Angular creates a new control or group
     * It also contains the disabled values (raw values)
     */
    readonly formValueChange: Observable<T>;
    /**
     * Emits an object with all the errors of the form
     * every time a form control or form groups changes its status to valid or invalid
     */
    readonly errorsChange: Observable<Record<string, string>>;
    /**
     * Triggered as soon as the form becomes dirty
     */
    readonly dirtyChange: Observable<boolean>;
    private readonly destroy$$;
    /**
     * Fired when the status of the root form changes.
     */
    private readonly statusChanges$;
    /**
     * Triggered When the form becomes valid but waits until the form is idle
     */
    readonly validChange: Observable<boolean>;
    /**
     * Used to debounce formValues to make sure vest isn't triggered all the time
     */
    private readonly formValueCache;
    constructor();
    /**
     * This will feed the formValueCache, debounce it till the next tick
     * and create an asynchronous validator that runs a vest suite
     * @param field
     * @param validationOptions
     * @returns an asynchronous validator function
     */
    createAsyncValidator(field: string, validationOptions: ValidationOptions, dynamicControlOptions?: any): AsyncValidatorFn;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormDirective<any>, "form[clValidationForm]", never, { "formValue": { "alias": "formValue"; "required": false; "isSignal": true; }; "suite": { "alias": "suite"; "required": false; "isSignal": true; }; "formShape": { "alias": "formShape"; "required": false; "isSignal": true; }; "validationConfig": { "alias": "validationConfig"; "required": false; "isSignal": true; }; }, { "formValueChange": "formValueChange"; "errorsChange": "errorsChange"; "dirtyChange": "dirtyChange"; "validChange": "validChange"; }, never, never, true, never>;
}
