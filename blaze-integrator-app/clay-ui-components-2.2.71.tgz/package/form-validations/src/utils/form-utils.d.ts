import { AbstractControl, FormGroup } from '@angular/forms';
import { ClErrorHandler } from '@clay/ui-components/shared';
/**
 * Calculates the field name of a form control: Eg: addresses.shippingAddress.street
 * @param rootForm
 * @param control
 */
export declare function getFormControlField(rootForm: FormGroup, control: AbstractControl): string;
/**
 * Calcuates the field name of a form group Eg: addresses.shippingAddress
 * @param rootForm
 * @param control
 */
export declare function getFormGroupField(rootForm: FormGroup, control: AbstractControl): string;
/**
 * This RxJS operator merges the value of the form with the raw value.
 * By doing this we can assure that we don't lose values of disabled form fields
 * @param form
 */
export declare function mergeValuesAndRawValues<T>(form: FormGroup): T;
/**
 * Performs a deep-clone of an object
 * @param obj
 */
export declare function cloneDeep<T>(obj: T): T;
/**
 * Sets a value in an object in the correct path
 * @param obj
 * @param path
 * @param value
 */
export declare function set(obj: object, path: string, value: any): void;
/**
 * Sets a value in an nested object in the correct path
 * @param obj
 * @param path
 * @param value
 */
export declare function setNested(obj: any, path: string, value: any): void;
/**
 * Traverses the form and returns the errors by path
 * @param form
 */
export declare function getAllFormErrors(form?: AbstractControl): Record<string, string>;
export declare function getErrorMessage(key: keyof ClErrorHandler, errorList: ClErrorHandler): any;
