export declare function arrayToObject<T>(arr: T[]): {
    [key: number]: T;
};
