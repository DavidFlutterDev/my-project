import { ClTextBlockComponent, ClTextBlockProperties } from '@clay/ui-components/basic';
import { Component, Input, Output, ViewChild, ViewContainerRef, EventEmitter, input } from '@angular/core';
import * as i0 from "@angular/core";
export class ClDataGridInjectorComponent {
    constructor() {
        this.isComponentDragged = input(false);
        this.valueChange = new EventEmitter();
        this.textBlockProperties = new ClTextBlockProperties();
    }
    ngOnChanges() {
        this.createComponent();
    }
    createComponent() {
        if (!this.isComponentDragged()) {
            this.componentRef = this.viewContainer.createComponent(this.component ?? ClTextBlockComponent);
        }
        else {
            this.componentRef = this.viewContainer.createComponent(ClTextBlockComponent);
        }
        if (this.componentRef) {
            if (this.component && !this.isComponentDragged()) {
                this.componentRef.instance._value = this.value;
                this.componentRef.instance._rowValue = this.rowDetail;
                this.componentRef.instance.properties = this.properties;
                this.componentRef.instance.onChange = (value) => {
                    this.valueChange.emit(value);
                };
            }
            else {
                this.textBlockProperties.label = this.value;
                this.componentRef.instance.properties = this.textBlockProperties;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridInjectorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "18.2.8", type: ClDataGridInjectorComponent, isStandalone: true, selector: "cl-data-grid-injector", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: false, isRequired: false, transformFunction: null }, rowDetail: { classPropertyName: "rowDetail", publicName: "rowDetail", isSignal: false, isRequired: false, transformFunction: null }, component: { classPropertyName: "component", publicName: "component", isSignal: false, isRequired: false, transformFunction: null }, properties: { classPropertyName: "properties", publicName: "properties", isSignal: false, isRequired: false, transformFunction: null }, isComponentDragged: { classPropertyName: "isComponentDragged", publicName: "isComponentDragged", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, viewQueries: [{ propertyName: "viewContainer", first: true, predicate: ["viewContainerRef"], descendants: true, read: ViewContainerRef, static: true }], usesOnChanges: true, ngImport: i0, template: "<ng-container #viewContainerRef></ng-container>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDataGridInjectorComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-data-grid-injector', template: "<ng-container #viewContainerRef></ng-container>\n" }]
        }], propDecorators: { value: [{
                type: Input
            }], rowDetail: [{
                type: Input
            }], component: [{
                type: Input
            }], properties: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], viewContainer: [{
                type: ViewChild,
                args: ['viewContainerRef', { read: ViewContainerRef, static: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0YS1ncmlkLWluamVjdG9yLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9kYXRhLWdyaWQvY29udGVudC9kYXRhLWdyaWQtaW5qZWN0b3IuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL2RhdGEtZ3JpZC9jb250ZW50L2RhdGEtZ3JpZC1pbmplY3Rvci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsb0JBQW9CLEVBQUUscUJBQXFCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUN4RixPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFLGdCQUFnQixFQUFFLFlBQVksRUFBRSxLQUFLLEVBQTBCLE1BQU0sZUFBZSxDQUFDOztBQU9uSSxNQUFNLE9BQU8sMkJBQTJCO0lBTHhDO1FBV1MsdUJBQWtCLEdBQXlCLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyRCxnQkFBVyxHQUFzQixJQUFJLFlBQVksRUFBRSxDQUFDO1FBS3RELHdCQUFtQixHQUEwQixJQUFJLHFCQUFxQixFQUFFLENBQUM7S0E0QmxGO0lBekJDLFdBQVc7UUFDVCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7SUFDeEIsQ0FBQztJQUVPLGVBQWU7UUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLG9CQUFvQixDQUFDLENBQUM7UUFDakcsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDL0UsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUM7Z0JBQ2pELElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUMvQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDdEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxDQUFDLEtBQVUsRUFBRSxFQUFFO29CQUNuRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDL0IsQ0FBQyxDQUFBO1lBQ0gsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFDNUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQztZQUNuRSxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7OEdBdkNVLDJCQUEyQjtrR0FBM0IsMkJBQTJCLDg0QkFTQyxnQkFBZ0IsZ0VDakJ6RCxtREFDQTs7MkZET2EsMkJBQTJCO2tCQUx2QyxTQUFTO2lDQUNJLElBQUksWUFDTix1QkFBdUI7OEJBSWpCLEtBQUs7c0JBQXBCLEtBQUs7Z0JBQ1UsU0FBUztzQkFBeEIsS0FBSztnQkFDVSxTQUFTO3NCQUF4QixLQUFLO2dCQUNVLFVBQVU7c0JBQXpCLEtBQUs7Z0JBR0ksV0FBVztzQkFBcEIsTUFBTTtnQkFHQSxhQUFhO3NCQURuQixTQUFTO3VCQUFDLGtCQUFrQixFQUFFLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDbFRleHRCbG9ja0NvbXBvbmVudCwgQ2xUZXh0QmxvY2tQcm9wZXJ0aWVzIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9iYXNpYyc7XG5pbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPdXRwdXQsIFZpZXdDaGlsZCwgVmlld0NvbnRhaW5lclJlZiwgRXZlbnRFbWl0dGVyLCBpbnB1dCwgSW5wdXRTaWduYWwsIE9uQ2hhbmdlcyB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1kYXRhLWdyaWQtaW5qZWN0b3InLFxuICB0ZW1wbGF0ZVVybDogJy4vZGF0YS1ncmlkLWluamVjdG9yLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgQ2xEYXRhR3JpZEluamVjdG9yQ29tcG9uZW50IGltcGxlbWVudHMgT25DaGFuZ2VzIHtcbiAgQElucHV0KCkgcHVibGljIHZhbHVlOiBhbnk7XG4gIEBJbnB1dCgpIHB1YmxpYyByb3dEZXRhaWw6IGFueTtcbiAgQElucHV0KCkgcHVibGljIGNvbXBvbmVudDogYW55O1xuICBASW5wdXQoKSBwdWJsaWMgcHJvcGVydGllczogYW55O1xuXG4gIHB1YmxpYyBpc0NvbXBvbmVudERyYWdnZWQ6IElucHV0U2lnbmFsPGJvb2xlYW4+ID0gaW5wdXQoZmFsc2UpO1xuICBAT3V0cHV0KCkgdmFsdWVDaGFuZ2U6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIEBWaWV3Q2hpbGQoJ3ZpZXdDb250YWluZXJSZWYnLCB7IHJlYWQ6IFZpZXdDb250YWluZXJSZWYsIHN0YXRpYzogdHJ1ZSB9KVxuICBwdWJsaWMgdmlld0NvbnRhaW5lciE6IFZpZXdDb250YWluZXJSZWY7XG5cbiAgcHJpdmF0ZSB0ZXh0QmxvY2tQcm9wZXJ0aWVzOiBDbFRleHRCbG9ja1Byb3BlcnRpZXMgPSBuZXcgQ2xUZXh0QmxvY2tQcm9wZXJ0aWVzKCk7XG4gIHByaXZhdGUgY29tcG9uZW50UmVmOiBhbnk7XG5cbiAgbmdPbkNoYW5nZXMoKSB7XG4gICAgdGhpcy5jcmVhdGVDb21wb25lbnQoKVxuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVDb21wb25lbnQoKSB7XG4gICAgaWYgKCF0aGlzLmlzQ29tcG9uZW50RHJhZ2dlZCgpKSB7XG4gICAgICB0aGlzLmNvbXBvbmVudFJlZiA9IHRoaXMudmlld0NvbnRhaW5lci5jcmVhdGVDb21wb25lbnQodGhpcy5jb21wb25lbnQgPz8gQ2xUZXh0QmxvY2tDb21wb25lbnQpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmNvbXBvbmVudFJlZiA9IHRoaXMudmlld0NvbnRhaW5lci5jcmVhdGVDb21wb25lbnQoQ2xUZXh0QmxvY2tDb21wb25lbnQpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmNvbXBvbmVudFJlZikge1xuICAgICAgaWYgKHRoaXMuY29tcG9uZW50ICYmICF0aGlzLmlzQ29tcG9uZW50RHJhZ2dlZCgpKSB7XG4gICAgICAgIHRoaXMuY29tcG9uZW50UmVmLmluc3RhbmNlLl92YWx1ZSA9IHRoaXMudmFsdWU7XG4gICAgICAgIHRoaXMuY29tcG9uZW50UmVmLmluc3RhbmNlLl9yb3dWYWx1ZSA9IHRoaXMucm93RGV0YWlsO1xuICAgICAgICB0aGlzLmNvbXBvbmVudFJlZi5pbnN0YW5jZS5wcm9wZXJ0aWVzID0gdGhpcy5wcm9wZXJ0aWVzO1xuICAgICAgICB0aGlzLmNvbXBvbmVudFJlZi5pbnN0YW5jZS5vbkNoYW5nZSA9ICh2YWx1ZTogYW55KSA9PiB7XG4gICAgICAgICAgdGhpcy52YWx1ZUNoYW5nZS5lbWl0KHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy50ZXh0QmxvY2tQcm9wZXJ0aWVzLmxhYmVsID0gdGhpcy52YWx1ZTtcbiAgICAgICAgdGhpcy5jb21wb25lbnRSZWYuaW5zdGFuY2UucHJvcGVydGllcyA9IHRoaXMudGV4dEJsb2NrUHJvcGVydGllcztcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiIsIjxuZy1jb250YWluZXIgI3ZpZXdDb250YWluZXJSZWY+PC9uZy1jb250YWluZXI+XG4iXX0=