import { MatIconModule } from "@angular/material/icon";
import { Component, Inject, computed, signal } from "@angular/core";
import { MAT_DIALOG_DATA } from "@angular/material/dialog";
import { ClComponentTypes } from "@clay/ui-components/shared";
import { ClButtonComponent, ClChipListComponent } from "@clay/ui-components/basic";
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/dialog";
import * as i2 from "@angular/material/icon";
export class TableMultiFilterDialogComponent {
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.data = data;
        this.selectedMultiFilter = [];
        this.defaultState = signal(true);
        this.isDisabled = computed(() => {
            return this.defaultState();
        });
        this.multiProperties = [];
        this.options = { value: '', options: [], indexValue: '' };
        this.chipProperties = {
            id: '',
            label: 'temp',
            multiple: true,
            disabled: false,
            direction: 'col',
            showOptionAll: true,
            optionsSelected: (selectedChips) => { },
            type: ClComponentTypes.chipList,
            options: [
                {
                    text: '',
                    value: '',
                    disabled: false,
                    isSelected: false,
                }
            ],
        };
        // Primary button properties
        this.primaryButtonProperties = {
            label: 'Apply',
            disabled: this.isDisabled,
            id: 'btnPrimarySubmit',
            type: ClComponentTypes.button,
            onSubmit: this.applyFilter.bind(this)
        };
        // Stroked primary button properties
        this.strokedButtonProperties = {
            label: 'Reset',
            disabled: this.isDisabled,
            id: 'btnPrimarySubmit',
            type: ClComponentTypes.button,
            onSubmit: this.resetToAll.bind(this)
        };
        this.propertiesData = data;
    }
    ngOnInit() {
        this.selectionForm();
        if (this.propertiesData) {
            for (let properties of this.propertiesData) {
                let index = this.propertiesData.indexOf(properties);
                if (properties.optionAllProperties?.isSelected == true) {
                    this.selectedMultiFilter.push({ ...this.options });
                    this.selectedMultiFilter[index].indexValue = index.toString();
                    this.selectedMultiFilter[index].value = properties.value;
                }
                if (properties.optionAllProperties?.isSelected == false) {
                    this.selectedMultiFilter.push({ ...this.options });
                    this.selectedMultiFilter[index].indexValue = index.toString();
                    this.selectedMultiFilter[index].value = properties.value;
                    // Filter the options based on the isSelected property
                    this.selectedMultiFilter[index].options = properties.options.filter((option) => option.isSelected === true);
                }
            }
        }
    }
    resetToAll() {
        for (let eachFilter of this.multiProperties) {
            const index = this.multiProperties.indexOf(eachFilter);
            eachFilter.optionAllProperties.isSelected = true;
            eachFilter.options = eachFilter.options;
            for (let option of eachFilter.options) {
                const subIndex = this.multiProperties[index].options.indexOf(option);
                option.isSelected = false;
            }
            this.selectedMultiFilter[index].options = [];
        }
    }
    selectionForm() {
        for (let eachFilter of this.propertiesData) {
            const index = this.propertiesData.indexOf(eachFilter);
            let data = { ...this.chipProperties };
            data.id = eachFilter.id;
            data.label = eachFilter.label;
            if (eachFilter.optionAllProperties) {
                data.showOptionAll = true,
                    data.optionAllProperties = eachFilter.optionAllProperties;
            }
            if (!eachFilter.optionAllProperties) {
                data.showOptionAll = false;
            }
            data.options = eachFilter.options;
            data.optionsSelected = this.selectedMultiFilterList.bind(this, index, 'option', eachFilter.value);
            this.multiProperties.push(data);
        }
    }
    selectedMultiFilterList(index, type, key, data) {
        this.defaultState.set(false);
        if (index >= 0 && index >= this.selectedMultiFilter.length) {
            for (let dataIndex = this.selectedMultiFilter.length; dataIndex <= index; dataIndex++) {
                this.selectedMultiFilter.push({ ...this.options });
                this.selectedMultiFilter[dataIndex].indexValue = dataIndex.toString();
                this.selectedMultiFilter[dataIndex].value = key;
            }
        }
        if (type == 'option') {
            this.selectedMultiFilter[index].options = data;
            if (this.selectedMultiFilter[index].options.length == this.multiProperties[index].options.length) {
                this.selectedMultiFilter[index].options = [];
                this.selectedMultiFilter[index].value = key;
            }
        }
        if (type == 'optionAll') {
            this.selectedMultiFilter[index].options = [];
            this.selectedMultiFilter[index].value = key;
        }
        if (this.selectedMultiFilter.length < this.multiProperties.length) {
            for (let list = this.selectedMultiFilter.length; list < this.multiProperties.length; list++) {
                this.selectedMultiFilter.push({ ...this.options });
                this.selectedMultiFilter[list].indexValue = list.toString();
                this.selectedMultiFilter[list].value = key;
            }
        }
    }
    applyFilter() {
        const modifiedData = this.selectedMultiFilter.map(item => {
            return {
                ...item,
                options: item.options.map((option) => option.value)
            };
        });
        let applyData = {
            selectedData: modifiedData,
            properties: this.propertiesData
        };
        this.dialogRef.close({ result: applyData });
    }
    filterClose() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: TableMultiFilterDialogComponent, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: TableMultiFilterDialogComponent, isStandalone: true, selector: "cl-table-multi-filter-dialog", ngImport: i0, template: "<div class=\"row-auto border-b-2 w-full\">\n  <div class=\"flex items-center justify-between mx-4 my-1.5\">\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:filter-tuning'\"></mat-icon>\n      <span class=\"text-sky-900 text-2xl\">Filters</span>\n    </div>\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:close-icon'\" class=\"cursor-pointer\" (click)=\"filterClose()\"></mat-icon>\n    </div>\n  </div>\n</div>\n\n<div class=\"mx-6\">\n  @for (properties of multiProperties; track properties; let i = $index) {\n    <cl-chip-list class=\"mt-2 mb-2 ml-3 mr-3\" [properties]=\"properties\"></cl-chip-list>\n  }\n</div>\n\n<div class=\"row-auto border-t-2 w-full bg-gray-100\">\n  <div class=\"flex items-center justify-end px-4 py-3.5 gap-2\">\n    <cl-button [properties]=\"strokedButtonProperties\"></cl-button>\n    <cl-button [properties]=\"primaryButtonProperties\"></cl-button>\n  </div>\n</div>\n", styles: ["::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0rem!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClChipListComponent, selector: "cl-chip-list", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: TableMultiFilterDialogComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-table-multi-filter-dialog', imports: [
                        MatIconModule,
                        ClButtonComponent,
                        ClChipListComponent,
                    ], template: "<div class=\"row-auto border-b-2 w-full\">\n  <div class=\"flex items-center justify-between mx-4 my-1.5\">\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:filter-tuning'\"></mat-icon>\n      <span class=\"text-sky-900 text-2xl\">Filters</span>\n    </div>\n    <div class=\"flex items-center\">\n      <mat-icon [svgIcon]=\"'fss_icons:close-icon'\" class=\"cursor-pointer\" (click)=\"filterClose()\"></mat-icon>\n    </div>\n  </div>\n</div>\n\n<div class=\"mx-6\">\n  @for (properties of multiProperties; track properties; let i = $index) {\n    <cl-chip-list class=\"mt-2 mb-2 ml-3 mr-3\" [properties]=\"properties\"></cl-chip-list>\n  }\n</div>\n\n<div class=\"row-auto border-t-2 w-full bg-gray-100\">\n  <div class=\"flex items-center justify-end px-4 py-3.5 gap-2\">\n    <cl-button [properties]=\"strokedButtonProperties\"></cl-button>\n    <cl-button [properties]=\"primaryButtonProperties\"></cl-button>\n  </div>\n</div>\n", styles: ["::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0rem!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFibGUtbXVsdGktZmlsdGVyLWRpYWxvZy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvZGF0YS1ncmlkL3RhYmxlLW11bHRpLWZpbHRlci1kaWFsb2cvdGFibGUtbXVsdGktZmlsdGVyLWRpYWxvZy5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvZGF0YS1ncmlkL3RhYmxlLW11bHRpLWZpbHRlci1kaWFsb2cvdGFibGUtbXVsdGktZmlsdGVyLWRpYWxvZy5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNwRSxPQUFPLEVBQWdCLGVBQWUsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBR3pFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBRTlELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxtQkFBbUIsRUFBNEMsTUFBTSwyQkFBMkIsQ0FBQzs7OztBQWM3SCxNQUFNLE9BQU8sK0JBQStCO0lBUTFDLFlBQ1UsU0FBNEIsRUFDSixJQUF3QjtRQURoRCxjQUFTLEdBQVQsU0FBUyxDQUFtQjtRQUNKLFNBQUksR0FBSixJQUFJLENBQW9CO1FBUjFELHdCQUFtQixHQUF3QixFQUFFLENBQUM7UUFDOUMsaUJBQVksR0FBRyxNQUFNLENBQVUsSUFBSSxDQUFDLENBQUM7UUFDN0IsZUFBVSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7WUFDakMsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDN0IsQ0FBQyxDQUFDLENBQUM7UUFTSSxvQkFBZSxHQUEyQixFQUFFLENBQUM7UUFFN0MsWUFBTyxHQUFzQixFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFLENBQUM7UUEyQnhFLG1CQUFjLEdBQXlCO1lBQzVDLEVBQUUsRUFBRSxFQUFFO1lBQ04sS0FBSyxFQUFFLE1BQU07WUFDYixRQUFRLEVBQUUsSUFBSTtZQUNkLFFBQVEsRUFBRSxLQUFLO1lBQ2YsU0FBUyxFQUFFLEtBQUs7WUFDaEIsYUFBYSxFQUFFLElBQUk7WUFDbkIsZUFBZSxFQUFFLENBQUMsYUFBa0IsRUFBRSxFQUFFLEdBQUcsQ0FBQztZQUM1QyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsUUFBUTtZQUMvQixPQUFPLEVBQUU7Z0JBQ1A7b0JBQ0UsSUFBSSxFQUFFLEVBQUU7b0JBQ1IsS0FBSyxFQUFFLEVBQUU7b0JBQ1QsUUFBUSxFQUFFLEtBQUs7b0JBQ2YsVUFBVSxFQUFFLEtBQUs7aUJBQ2xCO2FBQ0Y7U0FDRixDQUFDO1FBRUYsNEJBQTRCO1FBQ3JCLDRCQUF1QixHQUF1QjtZQUNuRCxLQUFLLEVBQUUsT0FBTztZQUNkLFFBQVEsRUFBRSxJQUFJLENBQUMsVUFBVTtZQUN6QixFQUFFLEVBQUUsa0JBQWtCO1lBQ3RCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxNQUFNO1lBQzdCLFFBQVEsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDdEMsQ0FBQztRQUVGLG9DQUFvQztRQUM3Qiw0QkFBdUIsR0FBdUI7WUFDbkQsS0FBSyxFQUFFLE9BQU87WUFDZCxRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDekIsRUFBRSxFQUFFLGtCQUFrQjtZQUN0QixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsTUFBTTtZQUM3QixRQUFRLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ3JDLENBQUM7UUFuRUEsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUM7SUFDN0IsQ0FBQztJQU1ELFFBQVE7UUFDTixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDeEIsS0FBSyxJQUFJLFVBQVUsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQzNDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFBO2dCQUVuRCxJQUFJLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxVQUFVLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ3ZELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDOUQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDO2dCQUMzRCxDQUFDO2dCQUVELElBQUksVUFBVSxDQUFDLG1CQUFtQixFQUFFLFVBQVUsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDeEQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7b0JBQ25ELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUM5RCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7b0JBRXpELHNEQUFzRDtvQkFDdEQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQVcsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQztnQkFDbkgsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQXVDRCxVQUFVO1FBQ1IsS0FBSyxJQUFJLFVBQVUsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDNUMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7WUFFdkQsVUFBVSxDQUFDLG1CQUFvQixDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDbEQsVUFBVSxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBRXhDLEtBQUssSUFBSSxNQUFNLElBQUksVUFBVSxDQUFDLE9BQVEsRUFBRSxDQUFDO2dCQUN2QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRXRFLE1BQU0sQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1lBQzVCLENBQUM7WUFFRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztRQUMvQyxDQUFDO0lBQ0gsQ0FBQztJQUVELGFBQWE7UUFDWCxLQUFLLElBQUksVUFBVSxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUMzQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUN0RCxJQUFJLElBQUksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBRXRDLElBQUksQ0FBQyxFQUFFLEdBQUcsVUFBVSxDQUFDLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFFOUIsSUFBSSxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJO29CQUN2QixJQUFJLENBQUMsbUJBQW1CLEdBQUcsVUFBVSxDQUFDLG1CQUFtQixDQUFDO1lBQzlELENBQUM7WUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLENBQUM7Z0JBQ3BDLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1lBQzdCLENBQUM7WUFFRCxJQUFJLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUM7WUFDbEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVsRyxJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNsQyxDQUFDO0lBQ0gsQ0FBQztJQUVELHVCQUF1QixDQUFDLEtBQVUsRUFBRSxJQUFTLEVBQUUsR0FBVyxFQUFFLElBQVM7UUFDbkUsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFN0IsSUFBSSxLQUFLLElBQUksQ0FBQyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDM0QsS0FBSyxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLFNBQVMsSUFBSSxLQUFLLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQztnQkFDdEYsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQ25ELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDO2dCQUN0RSxJQUFJLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUNsRCxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksSUFBSSxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1lBRS9DLElBQUksSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2xHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO2dCQUM3QyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztZQUM5QyxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksSUFBSSxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQzdDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQzlDLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNsRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLENBQUM7Z0JBQzVGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUNuRCxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDNUQsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDN0MsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsV0FBVztRQUNULE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDdkQsT0FBTztnQkFDTCxHQUFHLElBQUk7Z0JBQ1AsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ3pELENBQUM7UUFDSixDQUFDLENBQUMsQ0FBQztRQUVILElBQUksU0FBUyxHQUFHO1lBQ2QsWUFBWSxFQUFFLFlBQVk7WUFDMUIsVUFBVSxFQUFFLElBQUksQ0FBQyxjQUFjO1NBQ2hDLENBQUE7UUFFRCxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQzlDLENBQUM7SUFFRCxXQUFXO1FBQ1QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUN6QixDQUFDOzhHQTlLVSwrQkFBK0IsOENBVWhDLGVBQWU7a0dBVmQsK0JBQStCLHdGQ3JCNUMsczhCQXdCQSwySURUSSxhQUFhLG9MQUViLGlCQUFpQixzSUFDakIsbUJBQW1COzsyRkFHViwrQkFBK0I7a0JBWjNDLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLDhCQUE4QixXQUcvQjt3QkFDUCxhQUFhO3dCQUViLGlCQUFpQjt3QkFDakIsbUJBQW1CO3FCQUNwQjs7MEJBWUUsTUFBTTsyQkFBQyxlQUFlIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9tYXRlcmlhbC9pY29uXCI7XG5pbXBvcnQgeyBDb21wb25lbnQsIEluamVjdCwgY29tcHV0ZWQsIHNpZ25hbCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBNYXREaWFsb2dSZWYsIE1BVF9ESUFMT0dfREFUQSB9IGZyb20gXCJAYW5ndWxhci9tYXRlcmlhbC9kaWFsb2dcIjtcblxuaW1wb3J0IHsgQ2xGaWx0ZXJDaGlwTGlzdCB9IGZyb20gXCIuLi9kYXRhLWdyaWQucHJvcGVydGllc1wiO1xuaW1wb3J0IHsgQ2xDb21wb25lbnRUeXBlcyB9IGZyb20gXCJAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZFwiO1xuaW1wb3J0IHsgQXBwbHlPcHRpb25GaWx0ZXIgfSBmcm9tIFwiLi90YWJsZS1tdWx0aS1maWx0ZXItZGlhbG9nLnByb3BlcnRpZXNcIjtcbmltcG9ydCB7IENsQnV0dG9uQ29tcG9uZW50LCBDbENoaXBMaXN0Q29tcG9uZW50LCBDbENoaXBMaXN0UHJvcGVydGllcywgQ2xCdXR0b25Qcm9wZXJ0aWVzIH0gZnJvbSBcIkBjbGF5L3VpLWNvbXBvbmVudHMvYmFzaWNcIjtcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtdGFibGUtbXVsdGktZmlsdGVyLWRpYWxvZycsXG4gIHN0eWxlVXJsOiAnLi90YWJsZS1tdWx0aS1maWx0ZXItZGlhbG9nLmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3RhYmxlLW11bHRpLWZpbHRlci1kaWFsb2cuY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbXG4gICAgTWF0SWNvbk1vZHVsZSxcblxuICAgIENsQnV0dG9uQ29tcG9uZW50LFxuICAgIENsQ2hpcExpc3RDb21wb25lbnQsXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIFRhYmxlTXVsdGlGaWx0ZXJEaWFsb2dDb21wb25lbnQge1xuICBwcm9wZXJ0aWVzRGF0YTogQ2xGaWx0ZXJDaGlwTGlzdFtdO1xuICBzZWxlY3RlZE11bHRpRmlsdGVyOiBBcHBseU9wdGlvbkZpbHRlcltdID0gW107XG4gIGRlZmF1bHRTdGF0ZSA9IHNpZ25hbDxib29sZWFuPih0cnVlKTtcbiAgcHJpdmF0ZSBpc0Rpc2FibGVkID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmRlZmF1bHRTdGF0ZSgpO1xuICB9KTtcblxuICBjb25zdHJ1Y3RvciAoXG4gICAgcHJpdmF0ZSBkaWFsb2dSZWY6IE1hdERpYWxvZ1JlZjxhbnk+LFxuICAgIEBJbmplY3QoTUFUX0RJQUxPR19EQVRBKSBwdWJsaWMgZGF0YTogQ2xGaWx0ZXJDaGlwTGlzdFtdLFxuICApIHtcbiAgICB0aGlzLnByb3BlcnRpZXNEYXRhID0gZGF0YTtcbiAgfVxuXG4gIHB1YmxpYyBtdWx0aVByb3BlcnRpZXM6IENsQ2hpcExpc3RQcm9wZXJ0aWVzW10gPSBbXTtcblxuICBwdWJsaWMgb3B0aW9uczogQXBwbHlPcHRpb25GaWx0ZXIgPSB7IHZhbHVlOiAnJywgb3B0aW9uczogW10sIGluZGV4VmFsdWU6ICcnIH07XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgdGhpcy5zZWxlY3Rpb25Gb3JtKCk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzRGF0YSkge1xuICAgICAgZm9yIChsZXQgcHJvcGVydGllcyBvZiB0aGlzLnByb3BlcnRpZXNEYXRhKSB7XG4gICAgICAgIGxldCBpbmRleCA9IHRoaXMucHJvcGVydGllc0RhdGEuaW5kZXhPZihwcm9wZXJ0aWVzKVxuXG4gICAgICAgIGlmIChwcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXM/LmlzU2VsZWN0ZWQgPT0gdHJ1ZSkge1xuICAgICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlci5wdXNoKHsgLi4udGhpcy5vcHRpb25zIH0pO1xuICAgICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltpbmRleF0uaW5kZXhWYWx1ZSA9IGluZGV4LnRvU3RyaW5nKCk7XG4gICAgICAgICAgdGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyW2luZGV4XS52YWx1ZSA9IHByb3BlcnRpZXMudmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAocHJvcGVydGllcy5vcHRpb25BbGxQcm9wZXJ0aWVzPy5pc1NlbGVjdGVkID09IGZhbHNlKSB7XG4gICAgICAgICAgdGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyLnB1c2goeyAuLi50aGlzLm9wdGlvbnMgfSk7XG4gICAgICAgICAgdGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyW2luZGV4XS5pbmRleFZhbHVlID0gaW5kZXgudG9TdHJpbmcoKTtcbiAgICAgICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbaW5kZXhdLnZhbHVlID0gcHJvcGVydGllcy52YWx1ZTtcblxuICAgICAgICAgIC8vIEZpbHRlciB0aGUgb3B0aW9ucyBiYXNlZCBvbiB0aGUgaXNTZWxlY3RlZCBwcm9wZXJ0eVxuICAgICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltpbmRleF0ub3B0aW9ucyA9IHByb3BlcnRpZXMub3B0aW9ucy5maWx0ZXIoKG9wdGlvbjogYW55KSA9PiBvcHRpb24uaXNTZWxlY3RlZCA9PT0gdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwdWJsaWMgY2hpcFByb3BlcnRpZXM6IENsQ2hpcExpc3RQcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAnJyxcbiAgICBsYWJlbDogJ3RlbXAnLFxuICAgIG11bHRpcGxlOiB0cnVlLFxuICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICBkaXJlY3Rpb246ICdjb2wnLFxuICAgIHNob3dPcHRpb25BbGw6IHRydWUsXG4gICAgb3B0aW9uc1NlbGVjdGVkOiAoc2VsZWN0ZWRDaGlwczogYW55KSA9PiB7IH0sXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5jaGlwTGlzdCxcbiAgICBvcHRpb25zOiBbXG4gICAgICB7XG4gICAgICAgIHRleHQ6ICcnLFxuICAgICAgICB2YWx1ZTogJycsXG4gICAgICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICAgICAgaXNTZWxlY3RlZDogZmFsc2UsXG4gICAgICB9XG4gICAgXSxcbiAgfTtcblxuICAvLyBQcmltYXJ5IGJ1dHRvbiBwcm9wZXJ0aWVzXG4gIHB1YmxpYyBwcmltYXJ5QnV0dG9uUHJvcGVydGllczogQ2xCdXR0b25Qcm9wZXJ0aWVzID0ge1xuICAgIGxhYmVsOiAnQXBwbHknLFxuICAgIGRpc2FibGVkOiB0aGlzLmlzRGlzYWJsZWQsXG4gICAgaWQ6ICdidG5QcmltYXJ5U3VibWl0JyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmJ1dHRvbixcbiAgICBvblN1Ym1pdDogdGhpcy5hcHBseUZpbHRlci5iaW5kKHRoaXMpXG4gIH07XG5cbiAgLy8gU3Ryb2tlZCBwcmltYXJ5IGJ1dHRvbiBwcm9wZXJ0aWVzXG4gIHB1YmxpYyBzdHJva2VkQnV0dG9uUHJvcGVydGllczogQ2xCdXR0b25Qcm9wZXJ0aWVzID0ge1xuICAgIGxhYmVsOiAnUmVzZXQnLFxuICAgIGRpc2FibGVkOiB0aGlzLmlzRGlzYWJsZWQsXG4gICAgaWQ6ICdidG5QcmltYXJ5U3VibWl0JyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmJ1dHRvbixcbiAgICBvblN1Ym1pdDogdGhpcy5yZXNldFRvQWxsLmJpbmQodGhpcylcbiAgfTtcblxuICByZXNldFRvQWxsKCkge1xuICAgIGZvciAobGV0IGVhY2hGaWx0ZXIgb2YgdGhpcy5tdWx0aVByb3BlcnRpZXMpIHtcbiAgICAgIGNvbnN0IGluZGV4ID0gdGhpcy5tdWx0aVByb3BlcnRpZXMuaW5kZXhPZihlYWNoRmlsdGVyKTtcblxuICAgICAgZWFjaEZpbHRlci5vcHRpb25BbGxQcm9wZXJ0aWVzIS5pc1NlbGVjdGVkID0gdHJ1ZTtcbiAgICAgIGVhY2hGaWx0ZXIub3B0aW9ucyA9IGVhY2hGaWx0ZXIub3B0aW9ucztcblxuICAgICAgZm9yIChsZXQgb3B0aW9uIG9mIGVhY2hGaWx0ZXIub3B0aW9ucyEpIHtcbiAgICAgICAgY29uc3Qgc3ViSW5kZXggPSB0aGlzLm11bHRpUHJvcGVydGllc1tpbmRleF0ub3B0aW9ucyEuaW5kZXhPZihvcHRpb24pO1xuXG4gICAgICAgIG9wdGlvbi5pc1NlbGVjdGVkID0gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltpbmRleF0ub3B0aW9ucyA9IFtdO1xuICAgIH1cbiAgfVxuXG4gIHNlbGVjdGlvbkZvcm0oKSB7XG4gICAgZm9yIChsZXQgZWFjaEZpbHRlciBvZiB0aGlzLnByb3BlcnRpZXNEYXRhKSB7XG4gICAgICBjb25zdCBpbmRleCA9IHRoaXMucHJvcGVydGllc0RhdGEuaW5kZXhPZihlYWNoRmlsdGVyKTtcbiAgICAgIGxldCBkYXRhID0geyAuLi50aGlzLmNoaXBQcm9wZXJ0aWVzIH07XG5cbiAgICAgIGRhdGEuaWQgPSBlYWNoRmlsdGVyLmlkO1xuICAgICAgZGF0YS5sYWJlbCA9IGVhY2hGaWx0ZXIubGFiZWw7XG5cbiAgICAgIGlmIChlYWNoRmlsdGVyLm9wdGlvbkFsbFByb3BlcnRpZXMpIHtcbiAgICAgICAgZGF0YS5zaG93T3B0aW9uQWxsID0gdHJ1ZSxcbiAgICAgICAgICBkYXRhLm9wdGlvbkFsbFByb3BlcnRpZXMgPSBlYWNoRmlsdGVyLm9wdGlvbkFsbFByb3BlcnRpZXM7XG4gICAgICB9XG5cbiAgICAgIGlmICghZWFjaEZpbHRlci5vcHRpb25BbGxQcm9wZXJ0aWVzKSB7XG4gICAgICAgIGRhdGEuc2hvd09wdGlvbkFsbCA9IGZhbHNlO1xuICAgICAgfVxuXG4gICAgICBkYXRhLm9wdGlvbnMgPSBlYWNoRmlsdGVyLm9wdGlvbnM7XG4gICAgICBkYXRhLm9wdGlvbnNTZWxlY3RlZCA9IHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlckxpc3QuYmluZCh0aGlzLCBpbmRleCwgJ29wdGlvbicsIGVhY2hGaWx0ZXIudmFsdWUpO1xuXG4gICAgICB0aGlzLm11bHRpUHJvcGVydGllcy5wdXNoKGRhdGEpO1xuICAgIH1cbiAgfVxuXG4gIHNlbGVjdGVkTXVsdGlGaWx0ZXJMaXN0KGluZGV4OiBhbnksIHR5cGU6IGFueSwga2V5OiBzdHJpbmcsIGRhdGE6IGFueSkge1xuICAgIHRoaXMuZGVmYXVsdFN0YXRlLnNldChmYWxzZSk7XG5cbiAgICBpZiAoaW5kZXggPj0gMCAmJiBpbmRleCA+PSB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXIubGVuZ3RoKSB7XG4gICAgICBmb3IgKGxldCBkYXRhSW5kZXggPSB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXIubGVuZ3RoOyBkYXRhSW5kZXggPD0gaW5kZXg7IGRhdGFJbmRleCsrKSB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlci5wdXNoKHsgLi4udGhpcy5vcHRpb25zIH0pO1xuICAgICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbZGF0YUluZGV4XS5pbmRleFZhbHVlID0gZGF0YUluZGV4LnRvU3RyaW5nKCk7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltkYXRhSW5kZXhdLnZhbHVlID0ga2V5O1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0eXBlID09ICdvcHRpb24nKSB7XG4gICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbaW5kZXhdLm9wdGlvbnMgPSBkYXRhO1xuXG4gICAgICBpZiAodGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyW2luZGV4XS5vcHRpb25zLmxlbmd0aCA9PSB0aGlzLm11bHRpUHJvcGVydGllc1tpbmRleF0ub3B0aW9ucyEubGVuZ3RoKSB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltpbmRleF0ub3B0aW9ucyA9IFtdO1xuICAgICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbaW5kZXhdLnZhbHVlID0ga2V5O1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0eXBlID09ICdvcHRpb25BbGwnKSB7XG4gICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbaW5kZXhdLm9wdGlvbnMgPSBbXTtcbiAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltpbmRleF0udmFsdWUgPSBrZXk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlci5sZW5ndGggPCB0aGlzLm11bHRpUHJvcGVydGllcy5sZW5ndGgpIHtcbiAgICAgIGZvciAobGV0IGxpc3QgPSB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXIubGVuZ3RoOyBsaXN0IDwgdGhpcy5tdWx0aVByb3BlcnRpZXMubGVuZ3RoOyBsaXN0KyspIHtcbiAgICAgICAgdGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyLnB1c2goeyAuLi50aGlzLm9wdGlvbnMgfSk7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRNdWx0aUZpbHRlcltsaXN0XS5pbmRleFZhbHVlID0gbGlzdC50b1N0cmluZygpO1xuICAgICAgICB0aGlzLnNlbGVjdGVkTXVsdGlGaWx0ZXJbbGlzdF0udmFsdWUgPSBrZXk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgYXBwbHlGaWx0ZXIoKSB7XG4gICAgY29uc3QgbW9kaWZpZWREYXRhID0gdGhpcy5zZWxlY3RlZE11bHRpRmlsdGVyLm1hcChpdGVtID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLml0ZW0sXG4gICAgICAgIG9wdGlvbnM6IGl0ZW0ub3B0aW9ucy5tYXAoKG9wdGlvbjogYW55KSA9PiBvcHRpb24udmFsdWUpXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgbGV0IGFwcGx5RGF0YSA9IHtcbiAgICAgIHNlbGVjdGVkRGF0YTogbW9kaWZpZWREYXRhLFxuICAgICAgcHJvcGVydGllczogdGhpcy5wcm9wZXJ0aWVzRGF0YVxuICAgIH1cblxuICAgIHRoaXMuZGlhbG9nUmVmLmNsb3NlKHsgcmVzdWx0OiBhcHBseURhdGEgfSk7XG4gIH1cblxuICBmaWx0ZXJDbG9zZSgpIHtcbiAgICB0aGlzLmRpYWxvZ1JlZi5jbG9zZSgpO1xuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwicm93LWF1dG8gYm9yZGVyLWItMiB3LWZ1bGxcIj5cbiAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBteC00IG15LTEuNVwiPlxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPG1hdC1pY29uIFtzdmdJY29uXT1cIidmc3NfaWNvbnM6ZmlsdGVyLXR1bmluZydcIj48L21hdC1pY29uPlxuICAgICAgPHNwYW4gY2xhc3M9XCJ0ZXh0LXNreS05MDAgdGV4dC0yeGxcIj5GaWx0ZXJzPC9zcGFuPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPG1hdC1pY29uIFtzdmdJY29uXT1cIidmc3NfaWNvbnM6Y2xvc2UtaWNvbidcIiBjbGFzcz1cImN1cnNvci1wb2ludGVyXCIgKGNsaWNrKT1cImZpbHRlckNsb3NlKClcIj48L21hdC1pY29uPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvZGl2PlxuXG48ZGl2IGNsYXNzPVwibXgtNlwiPlxuICBAZm9yIChwcm9wZXJ0aWVzIG9mIG11bHRpUHJvcGVydGllczsgdHJhY2sgcHJvcGVydGllczsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICA8Y2wtY2hpcC1saXN0IGNsYXNzPVwibXQtMiBtYi0yIG1sLTMgbXItM1wiIFtwcm9wZXJ0aWVzXT1cInByb3BlcnRpZXNcIj48L2NsLWNoaXAtbGlzdD5cbiAgfVxuPC9kaXY+XG5cbjxkaXYgY2xhc3M9XCJyb3ctYXV0byBib3JkZXItdC0yIHctZnVsbCBiZy1ncmF5LTEwMFwiPlxuICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHgtNCBweS0zLjUgZ2FwLTJcIj5cbiAgICA8Y2wtYnV0dG9uIFtwcm9wZXJ0aWVzXT1cInN0cm9rZWRCdXR0b25Qcm9wZXJ0aWVzXCI+PC9jbC1idXR0b24+XG4gICAgPGNsLWJ1dHRvbiBbcHJvcGVydGllc109XCJwcmltYXJ5QnV0dG9uUHJvcGVydGllc1wiPjwvY2wtYnV0dG9uPlxuICA8L2Rpdj5cbjwvZGl2PlxuIl19