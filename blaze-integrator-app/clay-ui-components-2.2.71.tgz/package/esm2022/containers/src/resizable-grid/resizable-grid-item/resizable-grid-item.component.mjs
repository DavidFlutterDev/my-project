import { Component, ViewChild, TemplateRef, Input } from '@angular/core';
import * as i0 from "@angular/core";
export class ClResizableGridItemComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClResizableGridItemComponent, isStandalone: true, selector: "cl-resizable-grid-item", inputs: { id: "id" }, viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clResizableGrid>\n  <ng-content></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClResizableGridItemComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-resizable-grid-item', template: "<ng-template #clResizableGrid>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { id: [{
                type: Input,
                args: [{ required: true }]
            }], contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzaXphYmxlLWdyaWQtaXRlbS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvcmVzaXphYmxlLWdyaWQvcmVzaXphYmxlLWdyaWQtaXRlbS9yZXNpemFibGUtZ3JpZC1pdGVtLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9yZXNpemFibGUtZ3JpZC9yZXNpemFibGUtZ3JpZC1pdGVtL3Jlc2l6YWJsZS1ncmlkLWl0ZW0uY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFPekUsTUFBTSxPQUFPLDRCQUE0Qjs4R0FBNUIsNEJBQTRCO2tHQUE1Qiw0QkFBNEIseUpBSTVCLFdBQVcsZ0RDWHhCLCtFQUdBOzsyRkRJYSw0QkFBNEI7a0JBTHhDLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLHdCQUF3Qjs4QkFLM0IsRUFBRTtzQkFEUixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsZUFBZTtzQkFEckIsU0FBUzt1QkFBQyxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBWaWV3Q2hpbGQsIFRlbXBsYXRlUmVmLCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1yZXNpemFibGUtZ3JpZC1pdGVtJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3Jlc2l6YWJsZS1ncmlkLWl0ZW0uY29tcG9uZW50Lmh0bWwnLFxufSlcbmV4cG9ydCBjbGFzcyBDbFJlc2l6YWJsZUdyaWRJdGVtQ29tcG9uZW50IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIGlkITogc3RyaW5nO1xuXG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBjb250ZW50VGVtcGxhdGUhOiBUZW1wbGF0ZVJlZjxhbnk+O1xufVxuIiwiPG5nLXRlbXBsYXRlICNjbFJlc2l6YWJsZUdyaWQ+XG4gIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbjwvbmctdGVtcGxhdGU+XG4iXX0=