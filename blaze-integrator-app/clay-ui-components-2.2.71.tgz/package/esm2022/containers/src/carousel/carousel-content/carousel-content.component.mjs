import { ViewChild, Component, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export class ClCarouselContentComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClCarouselContentComponent, isStandalone: true, selector: "cl-carousel-content", viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template #clCarouselContent>\n  <ng-content></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCarouselContentComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-carousel-content', template: "<ng-template #clCarouselContent>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2Fyb3VzZWwtY29udGVudC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvY2Fyb3VzZWwvY2Fyb3VzZWwtY29udGVudC9jYXJvdXNlbC1jb250ZW50LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9jYXJvdXNlbC9jYXJvdXNlbC1jb250ZW50L2Nhcm91c2VsLWNvbnRlbnQuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQVFsRSxNQUFNLE9BQU8sMEJBQTBCOzhHQUExQiwwQkFBMEI7a0dBQTFCLDBCQUEwQixnSUFDMUIsV0FBVyxnRENUeEIsaUZBR0E7OzJGREthLDBCQUEwQjtrQkFOdEMsU0FBUztpQ0FDSSxJQUFJLFlBQ04scUJBQXFCOzhCQU14QixlQUFlO3NCQURyQixTQUFTO3VCQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBWaWV3Q2hpbGQsIENvbXBvbmVudCwgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtY2Fyb3VzZWwtY29udGVudCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9jYXJvdXNlbC1jb250ZW50LmNvbXBvbmVudC5odG1sJyxcbn0pXG5cbmV4cG9ydCBjbGFzcyBDbENhcm91c2VsQ29udGVudENvbXBvbmVudCB7XG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBjb250ZW50VGVtcGxhdGUhOiBUZW1wbGF0ZVJlZjxhbnk+O1xufVxuIiwiPG5nLXRlbXBsYXRlICNjbENhcm91c2VsQ29udGVudD5cbiAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxuPC9uZy10ZW1wbGF0ZT5cbiJdfQ==