import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import * as i0 from "@angular/core";
export class ClExpansionPanelDescriptionComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelDescriptionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClExpansionPanelDescriptionComponent, isStandalone: true, selector: "cl-expansion-panel-description", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "descriptionTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-content></ng-content>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClExpansionPanelDescriptionComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-expansion-panel-description', template: "<ng-content></ng-content>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], descriptionTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhwYW5zaW9uLXBhbmVsLWRlc2NyaXB0aW9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9hY2NvcmRpb24vZXhwYW5zaW9uLXBhbmVsLWRlc2NyaXB0aW9uL2V4cGFuc2lvbi1wYW5lbC1kZXNjcmlwdGlvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvYWNjb3JkaW9uL2V4cGFuc2lvbi1wYW5lbC1kZXNjcmlwdGlvbi9leHBhbnNpb24tcGFuZWwtZGVzY3JpcHRpb24uY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFRekUsTUFBTSxPQUFPLG9DQUFvQzs4R0FBcEMsb0NBQW9DO2tHQUFwQyxvQ0FBb0MscUxBSXBDLFdBQVcsZ0RDWnhCLDZCQUNBOzsyRkRPYSxvQ0FBb0M7a0JBTGhELFNBQVM7aUNBQ0ksSUFBSSxZQUNOLGdDQUFnQzs4QkFLbkMsVUFBVTtzQkFEaEIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBSWxCLG1CQUFtQjtzQkFEekIsU0FBUzt1QkFBQyxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgVGVtcGxhdGVSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ2xFeHBhbnNpb25QYW5lbERlc2NyaXB0aW9uUHJvcGVydGllcyB9IGZyb20gJy4vZXhwYW5zaW9uLXBhbmVsLWRlc2NyaXB0aW9uLnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1leHBhbnNpb24tcGFuZWwtZGVzY3JpcHRpb24nLFxuICB0ZW1wbGF0ZVVybDogJy4vZXhwYW5zaW9uLXBhbmVsLWRlc2NyaXB0aW9uLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgQ2xFeHBhbnNpb25QYW5lbERlc2NyaXB0aW9uQ29tcG9uZW50IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIHByb3BlcnRpZXMhOiBDbEV4cGFuc2lvblBhbmVsRGVzY3JpcHRpb25Qcm9wZXJ0aWVzO1xuXG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBkZXNjcmlwdGlvblRlbXBsYXRlITogVGVtcGxhdGVSZWY8YW55PiB8IG51bGw7XG59XG4iLCI8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4iXX0=