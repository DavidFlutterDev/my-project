import { ClComponentTypes, } from '@clay/ui-components/shared';
export class ClAccordionStyleProperties {
}
export class ClAccordionProperties {
    constructor() {
        this.id = 'default0';
        this.hideToggle = true;
        this.openMultiple = false;
        this.type = ClComponentTypes.accordion;
        this.style = new ClAccordionStyleProperties();
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.style.contentWidth = 'w-full';
        this.style.iconCssClasses = 'icon-size-5';
        this.style.cssClasses = 'w-full flex-auto';
        this.style.titleCssClasses = 'text-xl font-normal text-primary-800';
        this.collapsedIcon = 'fss_icons:chevron-circle-down';
        this.expandedIcon = 'fss_icons:chevron-circle-up-filled';
        this.expansionPanelProperties = [
            {
                expansionPanelHeaderProperties: { label: 'Accordion1', panelOpenState: true, actionIcons: [], actionButtons: [] },
                expansionPanelContentProperties: [
                    {
                        "id": "column_999998",
                        "selector": "div",
                        "name": "Column",
                        "layout": "column",
                        "type": "container",
                        "hideDelete": true,
                        "import": "@clay/ui/components/container",
                        "properties": {
                            "cssClass": "flex w-full flex-col"
                        },
                        "defaultProperties": {
                            "cssClass": "flex w-full flex-col border border-dashed rounded-md border-purple-400"
                        },
                        "children": []
                    }
                ]
            },
            {
                expansionPanelHeaderProperties: { label: 'Accordion2', panelOpenState: false, actionIcons: [], actionButtons: [] },
                expansionPanelContentProperties: [
                    {
                        "id": "column_999999",
                        "selector": "div",
                        "name": "Column",
                        "layout": "column",
                        "type": "container",
                        "hideDelete": true,
                        "import": "@clay/ui/components/container",
                        "properties": {
                            "cssClass": "flex w-full flex-col"
                        },
                        "defaultProperties": {
                            "cssClass": "flex w-full flex-col border border-dashed rounded-md border-purple-400"
                        },
                        "children": []
                    }
                ]
            }
        ];
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWNjb3JkaW9uLnByb3BlcnRpZXMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvYWNjb3JkaW9uL2FjY29yZGlvbi5wcm9wZXJ0aWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBLE9BQU8sRUFHTCxnQkFBZ0IsR0FJakIsTUFBTSw0QkFBNEIsQ0FBQztBQWtCcEMsTUFBTSxPQUFPLDBCQUEwQjtDQVd0QztBQUVELE1BQU0sT0FBTyxxQkFBcUI7SUFjaEM7UUFDRSxJQUFJLENBQUMsRUFBRSxHQUFHLFVBQVUsQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLGdCQUFnQixDQUFDLFNBQVMsQ0FBQztRQUV2QyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksMEJBQTBCLEVBQUUsQ0FBQztRQUM5QyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQy9CLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxHQUFHLFFBQVEsQ0FBQztRQUNuQyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxhQUFhLENBQUM7UUFDMUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsa0JBQWtCLENBQUM7UUFDM0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsc0NBQXNDLENBQUM7UUFFcEUsSUFBSSxDQUFDLGFBQWEsR0FBRywrQkFBK0IsQ0FBQztRQUNyRCxJQUFJLENBQUMsWUFBWSxHQUFHLG9DQUFvQyxDQUFDO1FBRXpELElBQUksQ0FBQyx3QkFBd0IsR0FBRztZQUM5QjtnQkFDRSw4QkFBOEIsRUFBRSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLElBQUksRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxFQUFFLEVBQUU7Z0JBQ2pILCtCQUErQixFQUFFO29CQUMvQjt3QkFDRSxJQUFJLEVBQUUsZUFBZTt3QkFDckIsVUFBVSxFQUFFLEtBQUs7d0JBQ2pCLE1BQU0sRUFBRSxRQUFRO3dCQUNoQixRQUFRLEVBQUUsUUFBUTt3QkFDbEIsTUFBTSxFQUFFLFdBQVc7d0JBQ25CLFlBQVksRUFBRSxJQUFJO3dCQUNsQixRQUFRLEVBQUUsK0JBQStCO3dCQUN6QyxZQUFZLEVBQUU7NEJBQ1osVUFBVSxFQUFFLHNCQUFzQjt5QkFDbkM7d0JBQ0QsbUJBQW1CLEVBQUU7NEJBQ25CLFVBQVUsRUFBRSx3RUFBd0U7eUJBQ3JGO3dCQUNELFVBQVUsRUFBRSxFQUFFO3FCQUNmO2lCQUNGO2FBQ0Y7WUFDRDtnQkFDRSw4QkFBOEIsRUFBRSxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxFQUFFLEVBQUU7Z0JBQ2xILCtCQUErQixFQUFFO29CQUMvQjt3QkFDRSxJQUFJLEVBQUUsZUFBZTt3QkFDckIsVUFBVSxFQUFFLEtBQUs7d0JBQ2pCLE1BQU0sRUFBRSxRQUFRO3dCQUNoQixRQUFRLEVBQUUsUUFBUTt3QkFDbEIsTUFBTSxFQUFFLFdBQVc7d0JBQ25CLFlBQVksRUFBRSxJQUFJO3dCQUNsQixRQUFRLEVBQUUsK0JBQStCO3dCQUN6QyxZQUFZLEVBQUU7NEJBQ1osVUFBVSxFQUFFLHNCQUFzQjt5QkFDbkM7d0JBQ0QsbUJBQW1CLEVBQUU7NEJBQ25CLFVBQVUsRUFBRSx3RUFBd0U7eUJBQ3JGO3dCQUNELFVBQVUsRUFBRSxFQUFFO3FCQUNmO2lCQUNGO2FBQ0Y7U0FDRixDQUFDO0lBQ0osQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xFeHBhbnNpb25QYW5lbEhlYWRlclByb3BlcnRpZXMgfSBmcm9tICcuL2V4cGFuc2lvbi1wYW5lbC1oZWFkZXInO1xuaW1wb3J0IHsgQ2xFeHBhbnNpb25QYW5lbERlc2NyaXB0aW9uUHJvcGVydGllcyB9IGZyb20gJy4vZXhwYW5zaW9uLXBhbmVsLWRlc2NyaXB0aW9uJztcblxuaW1wb3J0IHtcbiAgQ2xCYXNlVmlzdWFsLFxuICBDbEJhc2VCZWhhdmlvcixcbiAgQ2xDb21wb25lbnRUeXBlcyxcbiAgSUNsQmFzZVN0eWxlUHJvcGVydGllcyxcbiAgQ2xDb21wb25lbnRJbmplY3RQcm9wZXJ0aWVzLFxuICBDbEJhc2VDb250YWluZXJDb21wb25lbnRQcm9wZXJ0aWVzLFxufSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSUNsQWNjb3JkaW9uUHJvcGVydGllcyBleHRlbmRzIENsQmFzZUNvbnRhaW5lckNvbXBvbmVudFByb3BlcnRpZXMge1xuICBoaWRlVG9nZ2xlPzogYm9vbGVhbjtcbiAgZXhwYW5kZWRJY29uPzogc3RyaW5nO1xuICBvcGVuTXVsdGlwbGU/OiBib29sZWFuO1xuICBjb2xsYXBzZWRJY29uPzogc3RyaW5nO1xuICBvbkV4cGFuc2lvblBhbmVsU2VsZWN0ZWQ/OiAocGFuZWxJbmRleDogYW55KSA9PiB2b2lkO1xuICBleHBhbnNpb25QYW5lbFByb3BlcnRpZXM/OiBDbEV4cGFuc2lvblBhbmVsUHJvcGVydGllc1tdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENsRXhwYW5zaW9uUGFuZWxQcm9wZXJ0aWVzIHtcbiAgZXhwYW5zaW9uUGFuZWxDb250ZW50UHJvcGVydGllczogYW55O1xuICBleHBhbnNpb25QYW5lbEhlYWRlclByb3BlcnRpZXM6IENsRXhwYW5zaW9uUGFuZWxIZWFkZXJQcm9wZXJ0aWVzO1xuICBleHBhbnNpb25QYW5lbENvbnRlbnRDb21wb25lbnRQcm9wZXJ0aWVzPzogQ2xDb21wb25lbnRJbmplY3RQcm9wZXJ0aWVzO1xuICBleHBhbnNpb25QYW5lbERlc2NyaXB0aW9uUHJvcGVydGllcz86IENsRXhwYW5zaW9uUGFuZWxEZXNjcmlwdGlvblByb3BlcnRpZXM7XG59XG5cbmV4cG9ydCBjbGFzcyBDbEFjY29yZGlvblN0eWxlUHJvcGVydGllcyBpbXBsZW1lbnRzIElDbEJhc2VTdHlsZVByb3BlcnRpZXMge1xuICBjc3NDbGFzc2VzPzogc3RyaW5nO1xuICBjb250ZW50V2lkdGg/OiBzdHJpbmc7XG4gIGFsaWduQ29udGVudD86IHN0cmluZztcbiAgaWNvbkNzc0NsYXNzZXM/OiBzdHJpbmc7XG4gIGJvZHlDc3NDbGFzc2VzPzogc3RyaW5nO1xuICBqdXN0aWZ5Q29udGVudD86IHN0cmluZztcbiAgZGVzY0Nzc0NsYXNzZXM/OiBzdHJpbmc7XG4gIHBhbmVsQ3NzQ2xhc3Nlcz86IHN0cmluZztcbiAgdGl0bGVDc3NDbGFzc2VzPzogc3RyaW5nO1xuICBoZWFkZXJDc3NDbGFzc2VzPzogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgQ2xBY2NvcmRpb25Qcm9wZXJ0aWVzIGltcGxlbWVudHMgSUNsQWNjb3JkaW9uUHJvcGVydGllcyB7XG4gIGlkOiBzdHJpbmc7XG4gIGxhYmVsPzogc3RyaW5nO1xuICBoaWRlVG9nZ2xlPzogYm9vbGVhbjtcbiAgZXhwYW5kZWRJY29uPzogc3RyaW5nO1xuICB0eXBlOiBDbENvbXBvbmVudFR5cGVzO1xuICBvcGVuTXVsdGlwbGU/OiBib29sZWFuO1xuICBjb2xsYXBzZWRJY29uPzogc3RyaW5nO1xuICB2aXN1YWxUeXBlPzogQ2xCYXNlVmlzdWFsO1xuICBiZWhhdmlvclR5cGU/OiBDbEJhc2VCZWhhdmlvcjtcbiAgc3R5bGU/OiBDbEFjY29yZGlvblN0eWxlUHJvcGVydGllcztcbiAgb25FeHBhbnNpb25QYW5lbFNlbGVjdGVkPzogKHBhbmVsSW5kZXg6IGFueSkgPT4gdm9pZDtcbiAgZXhwYW5zaW9uUGFuZWxQcm9wZXJ0aWVzPzogQ2xFeHBhbnNpb25QYW5lbFByb3BlcnRpZXNbXTtcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgdGhpcy5pZCA9ICdkZWZhdWx0MCc7XG4gICAgdGhpcy5oaWRlVG9nZ2xlID0gdHJ1ZTtcbiAgICB0aGlzLm9wZW5NdWx0aXBsZSA9IGZhbHNlO1xuICAgIHRoaXMudHlwZSA9IENsQ29tcG9uZW50VHlwZXMuYWNjb3JkaW9uO1xuXG4gICAgdGhpcy5zdHlsZSA9IG5ldyBDbEFjY29yZGlvblN0eWxlUHJvcGVydGllcygpO1xuICAgIHRoaXMuc3R5bGUuYWxpZ25Db250ZW50ID0gJyc7XG4gICAgdGhpcy5zdHlsZS5qdXN0aWZ5Q29udGVudCA9ICcnO1xuICAgIHRoaXMuc3R5bGUuY29udGVudFdpZHRoID0gJ3ctZnVsbCc7XG4gICAgdGhpcy5zdHlsZS5pY29uQ3NzQ2xhc3NlcyA9ICdpY29uLXNpemUtNSc7XG4gICAgdGhpcy5zdHlsZS5jc3NDbGFzc2VzID0gJ3ctZnVsbCBmbGV4LWF1dG8nO1xuICAgIHRoaXMuc3R5bGUudGl0bGVDc3NDbGFzc2VzID0gJ3RleHQteGwgZm9udC1ub3JtYWwgdGV4dC1wcmltYXJ5LTgwMCc7XG5cbiAgICB0aGlzLmNvbGxhcHNlZEljb24gPSAnZnNzX2ljb25zOmNoZXZyb24tY2lyY2xlLWRvd24nO1xuICAgIHRoaXMuZXhwYW5kZWRJY29uID0gJ2Zzc19pY29uczpjaGV2cm9uLWNpcmNsZS11cC1maWxsZWQnO1xuXG4gICAgdGhpcy5leHBhbnNpb25QYW5lbFByb3BlcnRpZXMgPSBbXG4gICAgICB7XG4gICAgICAgIGV4cGFuc2lvblBhbmVsSGVhZGVyUHJvcGVydGllczogeyBsYWJlbDogJ0FjY29yZGlvbjEnLCBwYW5lbE9wZW5TdGF0ZTogdHJ1ZSwgYWN0aW9uSWNvbnM6IFtdLCBhY3Rpb25CdXR0b25zOiBbXSB9LFxuICAgICAgICBleHBhbnNpb25QYW5lbENvbnRlbnRQcm9wZXJ0aWVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcImNvbHVtbl85OTk5OThcIixcbiAgICAgICAgICAgIFwic2VsZWN0b3JcIjogXCJkaXZcIixcbiAgICAgICAgICAgIFwibmFtZVwiOiBcIkNvbHVtblwiLFxuICAgICAgICAgICAgXCJsYXlvdXRcIjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgIFwidHlwZVwiOiBcImNvbnRhaW5lclwiLFxuICAgICAgICAgICAgXCJoaWRlRGVsZXRlXCI6IHRydWUsXG4gICAgICAgICAgICBcImltcG9ydFwiOiBcIkBjbGF5L3VpL2NvbXBvbmVudHMvY29udGFpbmVyXCIsXG4gICAgICAgICAgICBcInByb3BlcnRpZXNcIjoge1xuICAgICAgICAgICAgICBcImNzc0NsYXNzXCI6IFwiZmxleCB3LWZ1bGwgZmxleC1jb2xcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZGVmYXVsdFByb3BlcnRpZXNcIjoge1xuICAgICAgICAgICAgICBcImNzc0NsYXNzXCI6IFwiZmxleCB3LWZ1bGwgZmxleC1jb2wgYm9yZGVyIGJvcmRlci1kYXNoZWQgcm91bmRlZC1tZCBib3JkZXItcHVycGxlLTQwMFwiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXVxuICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgZXhwYW5zaW9uUGFuZWxIZWFkZXJQcm9wZXJ0aWVzOiB7IGxhYmVsOiAnQWNjb3JkaW9uMicsIHBhbmVsT3BlblN0YXRlOiBmYWxzZSwgYWN0aW9uSWNvbnM6IFtdLCBhY3Rpb25CdXR0b25zOiBbXSB9LFxuICAgICAgICBleHBhbnNpb25QYW5lbENvbnRlbnRQcm9wZXJ0aWVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgXCJpZFwiOiBcImNvbHVtbl85OTk5OTlcIixcbiAgICAgICAgICAgIFwic2VsZWN0b3JcIjogXCJkaXZcIixcbiAgICAgICAgICAgIFwibmFtZVwiOiBcIkNvbHVtblwiLFxuICAgICAgICAgICAgXCJsYXlvdXRcIjogXCJjb2x1bW5cIixcbiAgICAgICAgICAgIFwidHlwZVwiOiBcImNvbnRhaW5lclwiLFxuICAgICAgICAgICAgXCJoaWRlRGVsZXRlXCI6IHRydWUsXG4gICAgICAgICAgICBcImltcG9ydFwiOiBcIkBjbGF5L3VpL2NvbXBvbmVudHMvY29udGFpbmVyXCIsXG4gICAgICAgICAgICBcInByb3BlcnRpZXNcIjoge1xuICAgICAgICAgICAgICBcImNzc0NsYXNzXCI6IFwiZmxleCB3LWZ1bGwgZmxleC1jb2xcIlxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZGVmYXVsdFByb3BlcnRpZXNcIjoge1xuICAgICAgICAgICAgICBcImNzc0NsYXNzXCI6IFwiZmxleCB3LWZ1bGwgZmxleC1jb2wgYm9yZGVyIGJvcmRlci1kYXNoZWQgcm91bmRlZC1tZCBib3JkZXItcHVycGxlLTQwMFwiXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJjaGlsZHJlblwiOiBbXVxuICAgICAgICAgIH1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIF07XG4gIH1cbn1cbiJdfQ==