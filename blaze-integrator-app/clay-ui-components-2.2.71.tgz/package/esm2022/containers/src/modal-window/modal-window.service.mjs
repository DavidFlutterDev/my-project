import { inject, Injectable } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { ClModalWindowComponent } from "./window/modal-window.component";
import * as i0 from "@angular/core";
export class ClModalWindowService {
    constructor() {
        this._dialog = inject(MatDialog);
    }
    open(config) {
        // Open the dialog
        return this._dialog.open(ClModalWindowComponent, {
            data: config,
            closeOnNavigation: true,
            position: config.position,
            width: config.style?.width,
            height: config.style?.height,
            minWidth: config.style?.minWidth,
            maxWidth: config.style?.maxWidth,
            disableClose: !config.dismissible,
            minHeight: config.style?.minHeight,
            maxHeight: config.style?.maxHeight,
            autoFocus: config.autoFocus ?? false,
            panelClass: config.style?.panelClass,
            hasBackdrop: config.hasBackdrop ?? true,
            backdropClass: 'cl-modal-window-backdrop'
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClModalWindowService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwtd2luZG93LnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvbW9kYWwtd2luZG93L21vZGFsLXdpbmRvdy5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxTQUFTLEVBQWdCLE1BQU0sMEJBQTBCLENBQUM7QUFFbkUsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0saUNBQWlDLENBQUM7O0FBR3pFLE1BQU0sT0FBTyxvQkFBb0I7SUFEakM7UUFFVSxZQUFPLEdBQWMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBd0JoRDtJQXRCUSxJQUFJLENBQUMsTUFBK0I7UUFDekMsa0JBQWtCO1FBQ2xCLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQ3RCLHNCQUFzQixFQUN0QjtZQUNFLElBQUksRUFBRSxNQUFNO1lBQ1osaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVE7WUFDekIsS0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsS0FBSztZQUMxQixNQUFNLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNO1lBQzVCLFFBQVEsRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLFFBQVE7WUFDaEMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsUUFBUTtZQUNoQyxZQUFZLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVztZQUNqQyxTQUFTLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxTQUFTO1lBQ2xDLFNBQVMsRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLFNBQVM7WUFDbEMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTLElBQUksS0FBSztZQUNwQyxVQUFVLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFVO1lBQ3BDLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxJQUFJLElBQUk7WUFDdkMsYUFBYSxFQUFFLDBCQUEwQjtTQUMxQyxDQUNGLENBQUM7SUFDSixDQUFDOzhHQXhCVSxvQkFBb0I7a0hBQXBCLG9CQUFvQixjQURQLE1BQU07OzJGQUNuQixvQkFBb0I7a0JBRGhDLFVBQVU7bUJBQUMsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaW5qZWN0LCBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcbmltcG9ydCB7IE1hdERpYWxvZywgTWF0RGlhbG9nUmVmIH0gZnJvbSBcIkBhbmd1bGFyL21hdGVyaWFsL2RpYWxvZ1wiO1xuaW1wb3J0IHsgQ2xNb2RhbFdpbmRvd1Byb3BlcnRpZXMgfSBmcm9tIFwiLi9tb2RhbC13aW5kb3cucHJvcGVydGllc1wiO1xuaW1wb3J0IHsgQ2xNb2RhbFdpbmRvd0NvbXBvbmVudCB9IGZyb20gXCIuL3dpbmRvdy9tb2RhbC13aW5kb3cuY29tcG9uZW50XCI7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5leHBvcnQgY2xhc3MgQ2xNb2RhbFdpbmRvd1NlcnZpY2Uge1xuICBwcml2YXRlIF9kaWFsb2c6IE1hdERpYWxvZyA9IGluamVjdChNYXREaWFsb2cpO1xuXG4gIHB1YmxpYyBvcGVuKGNvbmZpZzogQ2xNb2RhbFdpbmRvd1Byb3BlcnRpZXMpOiBNYXREaWFsb2dSZWY8Q2xNb2RhbFdpbmRvd0NvbXBvbmVudD4ge1xuICAgIC8vIE9wZW4gdGhlIGRpYWxvZ1xuICAgIHJldHVybiB0aGlzLl9kaWFsb2cub3BlbihcbiAgICAgIENsTW9kYWxXaW5kb3dDb21wb25lbnQsXG4gICAgICB7XG4gICAgICAgIGRhdGE6IGNvbmZpZyxcbiAgICAgICAgY2xvc2VPbk5hdmlnYXRpb246IHRydWUsXG4gICAgICAgIHBvc2l0aW9uOiBjb25maWcucG9zaXRpb24sXG4gICAgICAgIHdpZHRoOiBjb25maWcuc3R5bGU/LndpZHRoLFxuICAgICAgICBoZWlnaHQ6IGNvbmZpZy5zdHlsZT8uaGVpZ2h0LFxuICAgICAgICBtaW5XaWR0aDogY29uZmlnLnN0eWxlPy5taW5XaWR0aCxcbiAgICAgICAgbWF4V2lkdGg6IGNvbmZpZy5zdHlsZT8ubWF4V2lkdGgsXG4gICAgICAgIGRpc2FibGVDbG9zZTogIWNvbmZpZy5kaXNtaXNzaWJsZSxcbiAgICAgICAgbWluSGVpZ2h0OiBjb25maWcuc3R5bGU/Lm1pbkhlaWdodCxcbiAgICAgICAgbWF4SGVpZ2h0OiBjb25maWcuc3R5bGU/Lm1heEhlaWdodCxcbiAgICAgICAgYXV0b0ZvY3VzOiBjb25maWcuYXV0b0ZvY3VzID8/IGZhbHNlLFxuICAgICAgICBwYW5lbENsYXNzOiBjb25maWcuc3R5bGU/LnBhbmVsQ2xhc3MsXG4gICAgICAgIGhhc0JhY2tkcm9wOiBjb25maWcuaGFzQmFja2Ryb3AgPz8gdHJ1ZSxcbiAgICAgICAgYmFja2Ryb3BDbGFzczogJ2NsLW1vZGFsLXdpbmRvdy1iYWNrZHJvcCdcbiAgICAgIH1cbiAgICApO1xuICB9XG59XG4iXX0=