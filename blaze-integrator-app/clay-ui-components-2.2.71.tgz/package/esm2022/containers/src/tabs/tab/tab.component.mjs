import { Component, ContentChild, TemplateRef, ViewChild } from '@angular/core';
import { ClTabHeaderComponent } from '../tab-header';
import * as i0 from "@angular/core";
export class ClTabComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClTabComponent, isStandalone: true, selector: "cl-tab", queries: [{ propertyName: "tabHeader", first: true, predicate: ClTabHeaderComponent, descendants: true }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template>\n  <ng-content select=\"cl-tab-content\"></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTabComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tab', template: "<ng-template>\n  <ng-content select=\"cl-tab-content\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], tabHeader: [{
                type: ContentChild,
                args: [ClTabHeaderComponent]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFiLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy90YWJzL3RhYi90YWIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3RhYnMvdGFiL3RhYi5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRWhGLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFPckQsTUFBTSxPQUFPLGNBQWM7OEdBQWQsY0FBYztrR0FBZCxjQUFjLHlHQUlYLG9CQUFvQixpR0FIdkIsV0FBVyxnRENWeEIsd0ZBR0E7OzJGRE1hLGNBQWM7a0JBTDFCLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLFFBQVE7OEJBS1gsZUFBZTtzQkFEckIsU0FBUzt1QkFBQyxXQUFXO2dCQUlmLFNBQVM7c0JBRGYsWUFBWTt1QkFBQyxvQkFBb0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIENvbnRlbnRDaGlsZCwgVGVtcGxhdGVSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDbFRhYkhlYWRlckNvbXBvbmVudCB9IGZyb20gJy4uL3RhYi1oZWFkZXInO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC10YWInLFxuICB0ZW1wbGF0ZVVybDogJy4vdGFiLmNvbXBvbmVudC5odG1sJ1xufSlcbmV4cG9ydCBjbGFzcyBDbFRhYkNvbXBvbmVudCB7XG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBjb250ZW50VGVtcGxhdGUhOiBUZW1wbGF0ZVJlZjxhbnk+IHwgbnVsbDtcblxuICBAQ29udGVudENoaWxkKENsVGFiSGVhZGVyQ29tcG9uZW50KVxuICBwdWJsaWMgdGFiSGVhZGVyITogQ2xUYWJIZWFkZXJDb21wb25lbnQgfCBudWxsO1xufVxuIiwiPG5nLXRlbXBsYXRlPlxuICA8bmctY29udGVudCBzZWxlY3Q9XCJjbC10YWItY29udGVudFwiPjwvbmctY29udGVudD5cbjwvbmctdGVtcGxhdGU+XG4iXX0=