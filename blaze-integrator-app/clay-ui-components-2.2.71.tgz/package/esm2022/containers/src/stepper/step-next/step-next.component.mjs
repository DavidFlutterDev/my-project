import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import { MatStepperModule } from '@angular/material/stepper';
import * as i0 from "@angular/core";
export class ClStepNextComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepNextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepNextComponent, isStandalone: true, selector: "cl-step-next", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "nextTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepperNext>\n  <ng-content></ng-content>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatStepperModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepNextComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-next', imports: [MatStepperModule], template: "<ng-template matStepperNext>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], nextTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcC1uZXh0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9zdGVwcGVyL3N0ZXAtbmV4dC9zdGVwLW5leHQuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3N0ZXBwZXIvc3RlcC1uZXh0L3N0ZXAtbmV4dC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXpFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDOztBQVM3RCxNQUFNLE9BQU8sbUJBQW1COzhHQUFuQixtQkFBbUI7a0dBQW5CLG1CQUFtQiw0SkFJbkIsV0FBVyxnRENmeEIsNkVBR0EsMkNETVksZ0JBQWdCOzsyRkFFZixtQkFBbUI7a0JBTi9CLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLGNBQWMsV0FFZixDQUFDLGdCQUFnQixDQUFDOzhCQUlwQixVQUFVO3NCQURoQixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxXQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgVGVtcGxhdGVSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBNYXRTdGVwcGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvc3RlcHBlcic7XG5pbXBvcnQgeyBDbFN0ZXBOZXh0UHJvcGVydGllcyB9IGZyb20gJy4vc3RlcC1uZXh0LnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1zdGVwLW5leHQnLFxuICB0ZW1wbGF0ZVVybDogJy4vc3RlcC1uZXh0LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW01hdFN0ZXBwZXJNb2R1bGVdLFxufSlcbmV4cG9ydCBjbGFzcyBDbFN0ZXBOZXh0Q29tcG9uZW50IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIHByb3BlcnRpZXMhOiBDbFN0ZXBOZXh0UHJvcGVydGllcztcblxuICBAVmlld0NoaWxkKFRlbXBsYXRlUmVmKVxuICBwdWJsaWMgbmV4dFRlbXBsYXRlITogVGVtcGxhdGVSZWY8YW55PiB8IG51bGw7XG59XG4iLCI8bmctdGVtcGxhdGUgbWF0U3RlcHBlck5leHQ+XG4gIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbjwvbmctdGVtcGxhdGU+XG4iXX0=