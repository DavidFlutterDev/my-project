import { MatIconModule } from '@angular/material/icon';
import { MatStepperModule } from '@angular/material/stepper';
import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/stepper";
export class ClStepHeaderComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepHeaderComponent, isStandalone: true, selector: "cl-step-header", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "headerTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepLabel>{{ properties.label }}</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatStepperModule }, { kind: "directive", type: i1.MatStepLabel, selector: "[matStepLabel]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepHeaderComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-header', imports: [MatIconModule, MatStepperModule], template: "<ng-template matStepLabel>{{ properties.label }}</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], headerTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcC1oZWFkZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3N0ZXBwZXIvc3RlcC1oZWFkZXIvc3RlcC1oZWFkZXIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3N0ZXBwZXIvc3RlcC1oZWFkZXIvc3RlcC1oZWFkZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7OztBQVV6RSxNQUFNLE9BQU8scUJBQXFCOzhHQUFyQixxQkFBcUI7a0dBQXJCLHFCQUFxQixnS0FJckIsV0FBVyxnRENoQnhCLGtFQUNBLDJDRFNZLGFBQWEsOEJBQUUsZ0JBQWdCOzsyRkFFOUIscUJBQXFCO2tCQU5qQyxTQUFTO2lDQUNJLElBQUksWUFDTixnQkFBZ0IsV0FFakIsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLENBQUM7OEJBSW5DLFVBQVU7c0JBRGhCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUlsQixjQUFjO3NCQURwQixTQUFTO3VCQUFDLFdBQVciLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBNYXRTdGVwcGVyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvc3RlcHBlcic7XG5pbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBUZW1wbGF0ZVJlZiwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsU3RlcEhlYWRlclByb3BlcnRpZXMgfSBmcm9tICcuL3N0ZXAtaGVhZGVyLnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1zdGVwLWhlYWRlcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9zdGVwLWhlYWRlci5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtNYXRJY29uTW9kdWxlLCBNYXRTdGVwcGVyTW9kdWxlXSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xTdGVwSGVhZGVyQ29tcG9uZW50IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIHByb3BlcnRpZXMhOiBDbFN0ZXBIZWFkZXJQcm9wZXJ0aWVzO1xuXG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBoZWFkZXJUZW1wbGF0ZSE6IFRlbXBsYXRlUmVmPGFueT4gfCBudWxsO1xufVxuIiwiPG5nLXRlbXBsYXRlIG1hdFN0ZXBMYWJlbD57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9uZy10ZW1wbGF0ZT5cbiJdfQ==