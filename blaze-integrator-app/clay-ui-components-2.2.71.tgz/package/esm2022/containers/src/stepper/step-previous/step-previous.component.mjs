import { MatStepperModule } from '@angular/material/stepper';
import { Component, Input, TemplateRef, ViewChild } from '@angular/core';
import * as i0 from "@angular/core";
export class StepPreviousComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: StepPreviousComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: StepPreviousComponent, isStandalone: true, selector: "cl-step-previous", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "previousTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template matStepperPrevious>\n  <ng-content></ng-content>\n</ng-template>\n", dependencies: [{ kind: "ngmodule", type: MatStepperModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: StepPreviousComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step-previous', imports: [MatStepperModule], template: "<ng-template matStepperPrevious>\n  <ng-content></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], previousTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcC1wcmV2aW91cy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvc3RlcHBlci9zdGVwLXByZXZpb3VzL3N0ZXAtcHJldmlvdXMuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3N0ZXBwZXIvc3RlcC1wcmV2aW91cy9zdGVwLXByZXZpb3VzLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBVXpFLE1BQU0sT0FBTyxxQkFBcUI7OEdBQXJCLHFCQUFxQjtrR0FBckIscUJBQXFCLG9LQUlyQixXQUFXLGdEQ2Z4QixpRkFHQSwyQ0RNWSxnQkFBZ0I7OzJGQUVmLHFCQUFxQjtrQkFOakMsU0FBUztpQ0FDSSxJQUFJLFlBQ04sa0JBQWtCLFdBRW5CLENBQUMsZ0JBQWdCLENBQUM7OEJBSXBCLFVBQVU7c0JBRGhCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUlsQixnQkFBZ0I7c0JBRHRCLFNBQVM7dUJBQUMsV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1hdFN0ZXBwZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9zdGVwcGVyJztcbmltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIFRlbXBsYXRlUmVmLCBWaWV3Q2hpbGQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ2xTdGVwUHJldmlvdXNQcm9wZXJ0aWVzIH0gZnJvbSAnLi9zdGVwLXByZXZpb3VzLnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1zdGVwLXByZXZpb3VzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3N0ZXAtcHJldmlvdXMuY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbTWF0U3RlcHBlck1vZHVsZV0sXG59KVxuZXhwb3J0IGNsYXNzIFN0ZXBQcmV2aW91c0NvbXBvbmVudCB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBwcm9wZXJ0aWVzITogQ2xTdGVwUHJldmlvdXNQcm9wZXJ0aWVzO1xuXG4gIEBWaWV3Q2hpbGQoVGVtcGxhdGVSZWYpXG4gIHB1YmxpYyBwcmV2aW91c1RlbXBsYXRlITogVGVtcGxhdGVSZWY8YW55PiB8IG51bGw7XG59XG4iLCI8bmctdGVtcGxhdGUgbWF0U3RlcHBlclByZXZpb3VzPlxuICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG48L25nLXRlbXBsYXRlPlxuIl19