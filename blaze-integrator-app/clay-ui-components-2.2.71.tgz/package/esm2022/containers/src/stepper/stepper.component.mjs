import { CommonModule } from '@angular/common';
import { Component, ContentChildren, Input } from '@angular/core';
import { MatStepperModule } from '@angular/material/stepper';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import { timer } from 'rxjs/internal/observable/timer';
import { ClStepComponent } from './step/step.component';
import { ClStepperProperties } from './stepper.properties';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/material/stepper";
export class ClStepperComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClStepperProperties();
        super.ngOnInit();
    }
    ngAfterContentInit() {
        timer(0).subscribe(() => {
            this.steppers = this.contentItems;
        });
    }
    selectionChange(event) {
        if (this.properties.onStepperSelected != undefined) {
            this.properties.onStepperSelected(event.selectedIndex);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClStepperComponent, isStandalone: true, selector: "cl-stepper", inputs: { properties: "properties" }, providers: [
            {
                provide: STEPPER_GLOBAL_OPTIONS,
                useValue: { displayDefaultIndicatorType: false },
            },
        ], queries: [{ propertyName: "contentItems", predicate: ClStepComponent }], usesInheritance: true, ngImport: i0, template: "<mat-stepper #stepper class=\"w-full\"\n  [linear]=\"properties.isLinear\"\n  [orientation]=\"properties.orientation!\"\n  [labelPosition]=\"properties.labelPosition!\"\n  [selectedIndex]=\"properties.selectedStepIndex!()\"\n  (selectionChange)=\"selectionChange($event)\">\n\n  @for (step of steppers; track step) {\n  <mat-step [completed]=\"step.stepHeader?.properties?.completed\" [optional]=\"step.stepHeader?.properties?.optional\"\n    [state]=\"step.stepHeader?.properties?.state!\">\n\n    <ng-template matStepLabel>\n      <ng-container *ngTemplateOutlet=\"step.stepHeader!.headerTemplate\"></ng-container>\n    </ng-template>\n\n    <ng-template matStepContent>\n      <ng-container *ngTemplateOutlet=\"step.contentTemplate\"></ng-container>\n    </ng-template>\n\n  </mat-step>\n  }\n</mat-stepper>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatStepperModule }, { kind: "component", type: i2.MatStep, selector: "mat-step", inputs: ["color"], exportAs: ["matStep"] }, { kind: "directive", type: i2.MatStepLabel, selector: "[matStepLabel]" }, { kind: "component", type: i2.MatStepper, selector: "mat-stepper, mat-vertical-stepper, mat-horizontal-stepper, [matStepper]", inputs: ["disableRipple", "color", "labelPosition", "headerPosition", "animationDuration"], outputs: ["animationDone"], exportAs: ["matStepper", "matVerticalStepper", "matHorizontalStepper"] }, { kind: "directive", type: i2.MatStepContent, selector: "ng-template[matStepContent]" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepperComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-stepper', providers: [
                        {
                            provide: STEPPER_GLOBAL_OPTIONS,
                            useValue: { displayDefaultIndicatorType: false },
                        },
                    ], imports: [
                        CommonModule,
                        MatStepperModule,
                    ], template: "<mat-stepper #stepper class=\"w-full\"\n  [linear]=\"properties.isLinear\"\n  [orientation]=\"properties.orientation!\"\n  [labelPosition]=\"properties.labelPosition!\"\n  [selectedIndex]=\"properties.selectedStepIndex!()\"\n  (selectionChange)=\"selectionChange($event)\">\n\n  @for (step of steppers; track step) {\n  <mat-step [completed]=\"step.stepHeader?.properties?.completed\" [optional]=\"step.stepHeader?.properties?.optional\"\n    [state]=\"step.stepHeader?.properties?.state!\">\n\n    <ng-template matStepLabel>\n      <ng-container *ngTemplateOutlet=\"step.stepHeader!.headerTemplate\"></ng-container>\n    </ng-template>\n\n    <ng-template matStepContent>\n      <ng-container *ngTemplateOutlet=\"step.contentTemplate\"></ng-container>\n    </ng-template>\n\n  </mat-step>\n  }\n</mat-stepper>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], contentItems: [{
                type: ContentChildren,
                args: [ClStepComponent]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcHBlci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvc3RlcHBlci9zdGVwcGVyLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9zdGVwcGVyL3N0ZXBwZXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBb0IsU0FBUyxFQUFFLGVBQWUsRUFBRSxLQUFLLEVBQWEsTUFBTSxlQUFlLENBQUM7QUFDL0YsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDN0QsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDdEUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ3ZELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUN4RCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUMzRCxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQzs7OztBQWlCOUQsTUFBTSxPQUFPLGtCQUFtQixTQUFRLHdCQUF3QjtJQVc5RDtRQUNFOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBQ1IsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO0lBQ3pHLENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLG1CQUFtQixFQUFFLENBQUM7UUFDOUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxrQkFBa0I7UUFDaEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDdEIsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLGVBQWUsQ0FBQyxLQUFVO1FBQy9CLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNuRCxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN6RCxDQUFDO0lBQ0gsQ0FBQzs4R0FwQ1Usa0JBQWtCO2tHQUFsQixrQkFBa0IsK0ZBWGxCO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLHNCQUFzQjtnQkFDL0IsUUFBUSxFQUFFLEVBQUMsMkJBQTJCLEVBQUUsS0FBSyxFQUFDO2FBQy9DO1NBQ0YsdURBWWdCLGVBQWUsb0RDOUJsQyw4eUJBc0JBLDJDREZJLFlBQVkscU1BQ1osZ0JBQWdCOzsyRkFHUCxrQkFBa0I7a0JBZjlCLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLFlBQVksYUFFWDt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsc0JBQXNCOzRCQUMvQixRQUFRLEVBQUUsRUFBQywyQkFBMkIsRUFBRSxLQUFLLEVBQUM7eUJBQy9DO3FCQUNGLFdBQ1E7d0JBQ1AsWUFBWTt3QkFDWixnQkFBZ0I7cUJBQ2pCO3dEQUtlLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUtqQixZQUFZO3NCQURuQixlQUFlO3VCQUFDLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQWZ0ZXJDb250ZW50SW5pdCwgQ29tcG9uZW50LCBDb250ZW50Q2hpbGRyZW4sIElucHV0LCBRdWVyeUxpc3QgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1hdFN0ZXBwZXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9zdGVwcGVyJztcbmltcG9ydCB7IENsQmFzZUNvbnRhaW5lckNvbXBvbmVudCB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IHRpbWVyIH0gZnJvbSAncnhqcy9pbnRlcm5hbC9vYnNlcnZhYmxlL3RpbWVyJztcbmltcG9ydCB7IENsU3RlcENvbXBvbmVudCB9IGZyb20gJy4vc3RlcC9zdGVwLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDbFN0ZXBwZXJQcm9wZXJ0aWVzIH0gZnJvbSAnLi9zdGVwcGVyLnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgU1RFUFBFUl9HTE9CQUxfT1BUSU9OUyB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9zdGVwcGVyJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtc3RlcHBlcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9zdGVwcGVyLmNvbXBvbmVudC5odG1sJyxcbiAgcHJvdmlkZXJzOiBbXG4gICAge1xuICAgICAgcHJvdmlkZTogU1RFUFBFUl9HTE9CQUxfT1BUSU9OUyxcbiAgICAgIHVzZVZhbHVlOiB7ZGlzcGxheURlZmF1bHRJbmRpY2F0b3JUeXBlOiBmYWxzZX0sXG4gICAgfSxcbiAgXSxcbiAgaW1wb3J0czogW1xuICAgIENvbW1vbk1vZHVsZSxcbiAgICBNYXRTdGVwcGVyTW9kdWxlLFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBDbFN0ZXBwZXJDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb250YWluZXJDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlckNvbnRlbnRJbml0IHtcbiAgLy8gUGxlYXNlIHB1dCBhbGwgdGhlIGFuZ3VsYXIgZGVjb3JhdGVkIHZhcmlhYmxlcyBiZWxvdyB0aGlzXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xTdGVwcGVyUHJvcGVydGllcztcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgQENvbnRlbnRDaGlsZHJlbihDbFN0ZXBDb21wb25lbnQpXG4gIHByaXZhdGUgY29udGVudEl0ZW1zITogUXVlcnlMaXN0PENsU3RlcENvbXBvbmVudD47XG5cbiAgcHVibGljIHN0ZXBwZXJzITogUXVlcnlMaXN0PENsU3RlcENvbXBvbmVudD47XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsU3RlcHBlclByb3BlcnRpZXMoKTtcbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgbmdBZnRlckNvbnRlbnRJbml0KCk6IHZvaWQge1xuICAgIHRpbWVyKDApLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICB0aGlzLnN0ZXBwZXJzID0gdGhpcy5jb250ZW50SXRlbXM7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgc2VsZWN0aW9uQ2hhbmdlKGV2ZW50OiBhbnkpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uU3RlcHBlclNlbGVjdGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uU3RlcHBlclNlbGVjdGVkKGV2ZW50LnNlbGVjdGVkSW5kZXgpO1xuICAgIH1cbiAgfVxufVxuIiwiPG1hdC1zdGVwcGVyICNzdGVwcGVyIGNsYXNzPVwidy1mdWxsXCJcbiAgW2xpbmVhcl09XCJwcm9wZXJ0aWVzLmlzTGluZWFyXCJcbiAgW29yaWVudGF0aW9uXT1cInByb3BlcnRpZXMub3JpZW50YXRpb24hXCJcbiAgW2xhYmVsUG9zaXRpb25dPVwicHJvcGVydGllcy5sYWJlbFBvc2l0aW9uIVwiXG4gIFtzZWxlY3RlZEluZGV4XT1cInByb3BlcnRpZXMuc2VsZWN0ZWRTdGVwSW5kZXghKClcIlxuICAoc2VsZWN0aW9uQ2hhbmdlKT1cInNlbGVjdGlvbkNoYW5nZSgkZXZlbnQpXCI+XG5cbiAgQGZvciAoc3RlcCBvZiBzdGVwcGVyczsgdHJhY2sgc3RlcCkge1xuICA8bWF0LXN0ZXAgW2NvbXBsZXRlZF09XCJzdGVwLnN0ZXBIZWFkZXI/LnByb3BlcnRpZXM/LmNvbXBsZXRlZFwiIFtvcHRpb25hbF09XCJzdGVwLnN0ZXBIZWFkZXI/LnByb3BlcnRpZXM/Lm9wdGlvbmFsXCJcbiAgICBbc3RhdGVdPVwic3RlcC5zdGVwSGVhZGVyPy5wcm9wZXJ0aWVzPy5zdGF0ZSFcIj5cblxuICAgIDxuZy10ZW1wbGF0ZSBtYXRTdGVwTGFiZWw+XG4gICAgICA8bmctY29udGFpbmVyICpuZ1RlbXBsYXRlT3V0bGV0PVwic3RlcC5zdGVwSGVhZGVyIS5oZWFkZXJUZW1wbGF0ZVwiPjwvbmctY29udGFpbmVyPlxuICAgIDwvbmctdGVtcGxhdGU+XG5cbiAgICA8bmctdGVtcGxhdGUgbWF0U3RlcENvbnRlbnQ+XG4gICAgICA8bmctY29udGFpbmVyICpuZ1RlbXBsYXRlT3V0bGV0PVwic3RlcC5jb250ZW50VGVtcGxhdGVcIj48L25nLWNvbnRhaW5lcj5cbiAgICA8L25nLXRlbXBsYXRlPlxuXG4gIDwvbWF0LXN0ZXA+XG4gIH1cbjwvbWF0LXN0ZXBwZXI+XG4iXX0=