import { Component, ContentChild, TemplateRef, ViewChild } from '@angular/core';
import { ClStepHeaderComponent } from '../step-header';
import * as i0 from "@angular/core";
export class ClStepComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClStepComponent, isStandalone: true, selector: "cl-step", queries: [{ propertyName: "stepHeader", first: true, predicate: ClStepHeaderComponent, descendants: true }], viewQueries: [{ propertyName: "contentTemplate", first: true, predicate: TemplateRef, descendants: true }], ngImport: i0, template: "<ng-template>\n  <ng-content select=\"cl-step-content\"></ng-content>\n</ng-template>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClStepComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-step', template: "<ng-template>\n  <ng-content select=\"cl-step-content\"></ng-content>\n</ng-template>\n" }]
        }], propDecorators: { contentTemplate: [{
                type: ViewChild,
                args: [TemplateRef]
            }], stepHeader: [{
                type: ContentChild,
                args: [ClStepHeaderComponent]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RlcC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvc3RlcHBlci9zdGVwL3N0ZXAuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL3N0ZXBwZXIvc3RlcC9zdGVwLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFaEYsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7O0FBT3ZELE1BQU0sT0FBTyxlQUFlOzhHQUFmLGVBQWU7a0dBQWYsZUFBZSwyR0FJWixxQkFBcUIsaUdBSHhCLFdBQVcsZ0RDVnhCLHlGQUdBOzsyRkRNYSxlQUFlO2tCQUwzQixTQUFTO2lDQUNJLElBQUksWUFDTixTQUFTOzhCQUtaLGVBQWU7c0JBRHJCLFNBQVM7dUJBQUMsV0FBVztnQkFJZixVQUFVO3NCQURoQixZQUFZO3VCQUFDLHFCQUFxQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgQ29udGVudENoaWxkLCBUZW1wbGF0ZVJlZiwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsU3RlcEhlYWRlckNvbXBvbmVudCB9IGZyb20gJy4uL3N0ZXAtaGVhZGVyJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtc3RlcCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9zdGVwLmNvbXBvbmVudC5odG1sJyxcbn0pXG5leHBvcnQgY2xhc3MgQ2xTdGVwQ29tcG9uZW50IHtcbiAgQFZpZXdDaGlsZChUZW1wbGF0ZVJlZilcbiAgcHVibGljIGNvbnRlbnRUZW1wbGF0ZSE6IFRlbXBsYXRlUmVmPGFueT4gfCBudWxsO1xuXG4gIEBDb250ZW50Q2hpbGQoQ2xTdGVwSGVhZGVyQ29tcG9uZW50KVxuICBwdWJsaWMgc3RlcEhlYWRlciE6IENsU3RlcEhlYWRlckNvbXBvbmVudCB8IG51bGw7XG59XG4iLCI8bmctdGVtcGxhdGU+XG4gIDxuZy1jb250ZW50IHNlbGVjdD1cImNsLXN0ZXAtY29udGVudFwiPjwvbmctY29udGVudD5cbjwvbmctdGVtcGxhdGU+XG4iXX0=