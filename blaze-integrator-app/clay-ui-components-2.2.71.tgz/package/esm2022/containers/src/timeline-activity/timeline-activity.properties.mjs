import { ClComponentTypes } from '@clay/ui-components/shared';
export var ClTimelineActivityStatus;
(function (ClTimelineActivityStatus) {
    ClTimelineActivityStatus["pending"] = "pending";
    ClTimelineActivityStatus["approved"] = "approved";
    ClTimelineActivityStatus["rejected"] = "rejected";
    ClTimelineActivityStatus["cancelled"] = "cancelled";
    ClTimelineActivityStatus["completed"] = "completed";
    ClTimelineActivityStatus["notStarted"] = "Not Started";
})(ClTimelineActivityStatus || (ClTimelineActivityStatus = {}));
export class ClTimelineActivityStyleProperties {
}
export class ClTimelineActivityProperties {
    constructor() {
        this.id = 'default0';
        this.itemsPerRow = 5;
        this.type = ClComponentTypes.timelineActivity;
        this.style = new ClTimelineActivityStyleProperties();
        this.style.cssClasses = '';
        this.style.contentWidth = '';
        this.style.alignContent = '';
        this.style.justifyContent = '';
        this.activities = [
            {
                id: '493190c9-5b61-4912-afe5-78c21f1044d7',
                icon: 'heroicons_solid:arrow-top-right-on-square',
                title: 'Transfer Request',
                date: 'Jan 4th 2023 05:00pm',
                status: ClTimelineActivityStatus.completed,
                description: 'by Arjun Das',
                stepStatus: {
                    id: '',
                    label: '',
                    hidden: true,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: '',
                        labelCssClasses: ''
                    }
                }
            },
            {
                id: '6e3e97e5-effc-4fb7-b730-52a151f0b641',
                icon: 'heroicons_solid:star',
                title: 'Approve / Reject',
                date: 'Jan 4th 2023 05:00pm',
                status: 'pending',
                stepStatus: {
                    id: 'chip',
                    label: "test",
                    hidden: false,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: 'mt-3 mb-4 color-orange-chip shadow-md',
                        labelCssClasses: ''
                    }
                }
            },
            {
                id: 'b91ccb58-b06c-413b-b389-87010e03a120',
                icon: 'heroicons_solid:envelope',
                title: 'Card Process',
                date: 'Jan 4th 2023 05:00pm',
                status: 'rejected',
                stepStatus: {
                    id: '',
                    label: '',
                    hidden: true,
                    type: ClComponentTypes.chip,
                    style: {
                        cssClasses: '',
                        labelCssClasses: ''
                    }
                }
            }
        ];
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZWxpbmUtYWN0aXZpdHkucHJvcGVydGllcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy90aW1lbGluZS1hY3Rpdml0eS90aW1lbGluZS1hY3Rpdml0eS5wcm9wZXJ0aWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBa0IsZ0JBQWdCLEVBQTRFLE1BQU0sNEJBQTRCLENBQUM7QUFFeEosTUFBTSxDQUFOLElBQVksd0JBT1g7QUFQRCxXQUFZLHdCQUF3QjtJQUNsQywrQ0FBbUIsQ0FBQTtJQUNuQixpREFBcUIsQ0FBQTtJQUNyQixpREFBcUIsQ0FBQTtJQUNyQixtREFBdUIsQ0FBQTtJQUN2QixtREFBdUIsQ0FBQTtJQUN2QixzREFBMEIsQ0FBQTtBQUM1QixDQUFDLEVBUFcsd0JBQXdCLEtBQXhCLHdCQUF3QixRQU9uQztBQWtCRCxNQUFNLE9BQU8saUNBQWlDO0NBSzdDO0FBRUQsTUFBTSxPQUFPLDRCQUE0QjtJQVV2QztRQUNFLElBQUksQ0FBQyxFQUFFLEdBQUcsVUFBVSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUM7UUFDOUMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLGlDQUFpQyxFQUFFLENBQUM7UUFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsRUFBRSxDQUFDO1FBQzNCLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7UUFDN0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBRS9CLElBQUksQ0FBQyxVQUFVLEdBQUc7WUFDaEI7Z0JBQ0UsRUFBRSxFQUFFLHNDQUFzQztnQkFDMUMsSUFBSSxFQUFFLDJDQUEyQztnQkFDakQsS0FBSyxFQUFFLGtCQUFrQjtnQkFDekIsSUFBSSxFQUFFLHNCQUFzQjtnQkFDNUIsTUFBTSxFQUFFLHdCQUF3QixDQUFDLFNBQVM7Z0JBQzFDLFdBQVcsRUFBRSxjQUFjO2dCQUMzQixVQUFVLEVBQUM7b0JBQ1QsRUFBRSxFQUFDLEVBQUU7b0JBQ0wsS0FBSyxFQUFDLEVBQUU7b0JBQ1IsTUFBTSxFQUFDLElBQUk7b0JBQ1gsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7b0JBQzNCLEtBQUssRUFBQzt3QkFDSixVQUFVLEVBQUMsRUFBRTt3QkFDYixlQUFlLEVBQUMsRUFBRTtxQkFDbkI7aUJBQ0Y7YUFDRjtZQUNEO2dCQUNFLEVBQUUsRUFBRSxzQ0FBc0M7Z0JBQzFDLElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLEtBQUssRUFBRSxrQkFBa0I7Z0JBQ3pCLElBQUksRUFBRSxzQkFBc0I7Z0JBQzVCLE1BQU0sRUFBRSxTQUFxQztnQkFDN0MsVUFBVSxFQUFFO29CQUNWLEVBQUUsRUFBRSxNQUFNO29CQUNWLEtBQUssRUFBRSxNQUFNO29CQUNiLE1BQU0sRUFBRSxLQUFLO29CQUNiLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO29CQUMzQixLQUFLLEVBQUU7d0JBQ0wsVUFBVSxFQUFFLHVDQUF1Qzt3QkFDbkQsZUFBZSxFQUFDLEVBQUU7cUJBQ25CO2lCQUNGO2FBQ0Y7WUFDRDtnQkFDRSxFQUFFLEVBQUUsc0NBQXNDO2dCQUMxQyxJQUFJLEVBQUUsMEJBQTBCO2dCQUNoQyxLQUFLLEVBQUUsY0FBYztnQkFDckIsSUFBSSxFQUFFLHNCQUFzQjtnQkFDNUIsTUFBTSxFQUFFLFVBQXNDO2dCQUM5QyxVQUFVLEVBQUM7b0JBQ1QsRUFBRSxFQUFDLEVBQUU7b0JBQ0wsS0FBSyxFQUFDLEVBQUU7b0JBQ1IsTUFBTSxFQUFDLElBQUk7b0JBQ1gsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7b0JBQzNCLEtBQUssRUFBQzt3QkFDSixVQUFVLEVBQUMsRUFBRTt3QkFDYixlQUFlLEVBQUMsRUFBRTtxQkFDbkI7aUJBQ0Y7YUFDRjtTQUNGLENBQUM7SUFDSixDQUFDO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDbENoaXBQcm9wZXJ0aWVzIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9iYXNpYyc7XG5pbXBvcnQgeyBDbEJhc2VCZWhhdmlvciwgQ2xDb21wb25lbnRUeXBlcywgSUNsQmFzZVN0eWxlUHJvcGVydGllcywgQ2xCYXNlQ29udGFpbmVyQ29tcG9uZW50UHJvcGVydGllcywgQ2xCYXNlVmlzdWFsIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuXG5leHBvcnQgZW51bSBDbFRpbWVsaW5lQWN0aXZpdHlTdGF0dXMge1xuICBwZW5kaW5nID0gJ3BlbmRpbmcnLFxuICBhcHByb3ZlZCA9ICdhcHByb3ZlZCcsXG4gIHJlamVjdGVkID0gJ3JlamVjdGVkJyxcbiAgY2FuY2VsbGVkID0gJ2NhbmNlbGxlZCcsXG4gIGNvbXBsZXRlZCA9ICdjb21wbGV0ZWQnLFxuICBub3RTdGFydGVkID0gJ05vdCBTdGFydGVkJ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIENsVGltZWxpbmVBY3Rpdml0eSB7XG4gIGlkPzogc3RyaW5nO1xuICBkYXRlOiBzdHJpbmc7XG4gIGljb24/OiBzdHJpbmc7XG4gIGltYWdlPzogc3RyaW5nO1xuICB0aXRsZT86IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIHN0YXR1czogQ2xUaW1lbGluZUFjdGl2aXR5U3RhdHVzO1xuICBzdGVwU3RhdHVzPzogQ2xDaGlwUHJvcGVydGllcztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJQ2xUaW1lbGluZUFjdGl2aXR5UHJvcGVydGllcyBleHRlbmRzIENsQmFzZUNvbnRhaW5lckNvbXBvbmVudFByb3BlcnRpZXMge1xuICBpdGVtc1BlclJvdzogbnVtYmVyO1xuICBhY3Rpdml0aWVzOiBDbFRpbWVsaW5lQWN0aXZpdHlbXTtcbn1cblxuZXhwb3J0IGNsYXNzIENsVGltZWxpbmVBY3Rpdml0eVN0eWxlUHJvcGVydGllcyBpbXBsZW1lbnRzIElDbEJhc2VTdHlsZVByb3BlcnRpZXMge1xuICBjc3NDbGFzc2VzPzogc3RyaW5nO1xuICBjb250ZW50V2lkdGg/OiBzdHJpbmc7XG4gIGFsaWduQ29udGVudD86IHN0cmluZztcbiAganVzdGlmeUNvbnRlbnQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjbGFzcyBDbFRpbWVsaW5lQWN0aXZpdHlQcm9wZXJ0aWVzIGltcGxlbWVudHMgSUNsVGltZWxpbmVBY3Rpdml0eVByb3BlcnRpZXMge1xuICBpdGVtc1BlclJvdzogbnVtYmVyO1xuICBhY3Rpdml0aWVzOiBDbFRpbWVsaW5lQWN0aXZpdHlbXTtcbiAgaWQ6IHN0cmluZztcbiAgbGFiZWw/OiBzdHJpbmc7XG4gIHZpc3VhbFR5cGU/OiBDbEJhc2VWaXN1YWw7XG4gIGJlaGF2aW9yVHlwZT86IENsQmFzZUJlaGF2aW9yO1xuICBzdHlsZT86IENsVGltZWxpbmVBY3Rpdml0eVN0eWxlUHJvcGVydGllcztcbiAgdHlwZTogQ2xDb21wb25lbnRUeXBlcztcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgdGhpcy5pZCA9ICdkZWZhdWx0MCc7XG4gICAgdGhpcy5pdGVtc1BlclJvdyA9IDU7XG4gICAgdGhpcy50eXBlID0gQ2xDb21wb25lbnRUeXBlcy50aW1lbGluZUFjdGl2aXR5O1xuICAgIHRoaXMuc3R5bGUgPSBuZXcgQ2xUaW1lbGluZUFjdGl2aXR5U3R5bGVQcm9wZXJ0aWVzKCk7XG4gICAgdGhpcy5zdHlsZS5jc3NDbGFzc2VzID0gJyc7XG4gICAgdGhpcy5zdHlsZS5jb250ZW50V2lkdGggPSAnJztcbiAgICB0aGlzLnN0eWxlLmFsaWduQ29udGVudCA9ICcnO1xuICAgIHRoaXMuc3R5bGUuanVzdGlmeUNvbnRlbnQgPSAnJztcblxuICAgIHRoaXMuYWN0aXZpdGllcyA9IFtcbiAgICAgIHtcbiAgICAgICAgaWQ6ICc0OTMxOTBjOS01YjYxLTQ5MTItYWZlNS03OGMyMWYxMDQ0ZDcnLFxuICAgICAgICBpY29uOiAnaGVyb2ljb25zX3NvbGlkOmFycm93LXRvcC1yaWdodC1vbi1zcXVhcmUnLFxuICAgICAgICB0aXRsZTogJ1RyYW5zZmVyIFJlcXVlc3QnLFxuICAgICAgICBkYXRlOiAnSmFuIDR0aCAyMDIzIDA1OjAwcG0nLFxuICAgICAgICBzdGF0dXM6IENsVGltZWxpbmVBY3Rpdml0eVN0YXR1cy5jb21wbGV0ZWQsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnYnkgQXJqdW4gRGFzJyxcbiAgICAgICAgc3RlcFN0YXR1czp7XG4gICAgICAgICAgaWQ6JycsXG4gICAgICAgICAgbGFiZWw6JycsXG4gICAgICAgICAgaGlkZGVuOnRydWUsXG4gICAgICAgICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5jaGlwLFxuICAgICAgICAgIHN0eWxlOntcbiAgICAgICAgICAgIGNzc0NsYXNzZXM6JycsXG4gICAgICAgICAgICBsYWJlbENzc0NsYXNzZXM6JydcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGlkOiAnNmUzZTk3ZTUtZWZmYy00ZmI3LWI3MzAtNTJhMTUxZjBiNjQxJyxcbiAgICAgICAgaWNvbjogJ2hlcm9pY29uc19zb2xpZDpzdGFyJyxcbiAgICAgICAgdGl0bGU6ICdBcHByb3ZlIC8gUmVqZWN0JyxcbiAgICAgICAgZGF0ZTogJ0phbiA0dGggMjAyMyAwNTowMHBtJyxcbiAgICAgICAgc3RhdHVzOiAncGVuZGluZycgYXMgQ2xUaW1lbGluZUFjdGl2aXR5U3RhdHVzLFxuICAgICAgICBzdGVwU3RhdHVzOiB7XG4gICAgICAgICAgaWQ6ICdjaGlwJyxcbiAgICAgICAgICBsYWJlbDogXCJ0ZXN0XCIsXG4gICAgICAgICAgaGlkZGVuOiBmYWxzZSxcbiAgICAgICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmNoaXAsXG4gICAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAgIGNzc0NsYXNzZXM6ICdtdC0zIG1iLTQgY29sb3Itb3JhbmdlLWNoaXAgc2hhZG93LW1kJyxcbiAgICAgICAgICAgIGxhYmVsQ3NzQ2xhc3NlczonJ1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdiOTFjY2I1OC1iMDZjLTQxM2ItYjM4OS04NzAxMGUwM2ExMjAnLFxuICAgICAgICBpY29uOiAnaGVyb2ljb25zX3NvbGlkOmVudmVsb3BlJyxcbiAgICAgICAgdGl0bGU6ICdDYXJkIFByb2Nlc3MnLFxuICAgICAgICBkYXRlOiAnSmFuIDR0aCAyMDIzIDA1OjAwcG0nLFxuICAgICAgICBzdGF0dXM6ICdyZWplY3RlZCcgYXMgQ2xUaW1lbGluZUFjdGl2aXR5U3RhdHVzLFxuICAgICAgICBzdGVwU3RhdHVzOntcbiAgICAgICAgICBpZDonJyxcbiAgICAgICAgICBsYWJlbDonJyxcbiAgICAgICAgICBoaWRkZW46dHJ1ZSxcbiAgICAgICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmNoaXAsXG4gICAgICAgICAgc3R5bGU6e1xuICAgICAgICAgICAgY3NzQ2xhc3NlczonJyxcbiAgICAgICAgICAgIGxhYmVsQ3NzQ2xhc3NlczonJ1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIF07XG4gIH1cbn1cbiJdfQ==