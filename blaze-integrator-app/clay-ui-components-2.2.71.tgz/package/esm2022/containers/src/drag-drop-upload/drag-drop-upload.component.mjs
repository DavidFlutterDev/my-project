import { NgStyle } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { Component, Input, forwardRef } from '@angular/core';
import { ClCardComponent } from '../card';
import { ClDragDropDirective } from './drag-drop-upload.directive';
import { ClBaseComponent, ClComponentTypes } from '@clay/ui-components/shared';
import { ClIconComponent, ClLabelComponent, ClUploadService } from '@clay/ui-components/basic';
import * as i0 from "@angular/core";
import * as i1 from "@clay/ui-components/basic";
import * as i2 from "@angular/material/icon";
export class ClDragDropUploadComponent extends ClBaseComponent {
    getImageUrl() {
        if (this.stackLayoutProperties !== undefined && this.stackLayoutProperties.isBackgroundImage !== undefined) {
            return `url(${this.stackLayoutProperties?.backgroundImageUrl})`;
        }
        else {
            return 'none';
        }
    }
    constructor(uploadService) {
        super();
        this.uploadService = uploadService;
        this.accept = '';
        this.localUrl = [];
        this.selectedFiles = [];
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        //--------------------------------------------
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
        this.errorTextProperties = {
            label: '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm text-failed justify-center' },
            id: 'dragDropUploadErrorText',
        };
        this.duplicateErrorTextProperties = {
            label: '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm text-failed justify-start' },
            id: 'dragDropUploadDuplicateErrorText',
        };
        this.deleteIconProperties = {
            id: 'dragDropDeleteIcon',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5 text-red-400' },
            iconName: 'heroicons_outline:trash',
        };
        this.dragDropTextProperties = {
            label: 'Drag and drop files here',
            type: ClComponentTypes.label,
            style: { cssClasses: 'mt-2 text-base leading-6 font-semibold text-neutral-600' },
            id: 'labelDragDropText',
        };
        this.orTextProperties = {
            label: 'or',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-md leading-6 font-semibold text-neutral-600' },
            id: 'labelOrText',
        };
        this.browseFileTextProperties = {
            label: 'Browse file',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-base leading-6 font-normal text-primary-300' },
            id: 'labelBrowseText',
        };
        this.fileUploadIconProperties = {
            id: 'uploadTileIcon',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-6 text-primary' },
            iconName: 'fss_icons:file-upload',
        };
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnChanges(changes) {
        if (this.preLoadImageProperties != undefined) {
            // calling set preview image properties method
            this.setPreviewImageProperties(this.preLoadImageProperties.imageUrl);
        }
        if (this.preLoadMultiFileProperties != undefined && this.properties.isMultiple) {
            let listUpdate = this.preLoadMultiFileProperties.map((file) => file = { name: file.fileName, base64: `data:${file.base64DataType};base64,${file.base64val}` });
            this.pushBase64Files(listUpdate);
        }
    }
    ngOnInit() {
        // calling set default property value function
        this.setDefaultPropertyValue();
        this.properties.uploadIcon ??= 'fss_icons:cloud-upload';
        if (this.properties.preLoadImageProperties) {
            this.setPreviewImageProperties(this.properties.preLoadImageProperties.imageUrl);
        }
        this.dimensionTitleProperties = {
            label: this.properties.dimensionTitle ?? 'Supported dimensions:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelDimensionsTitleText',
        };
        this.dimensionDescProperties = {
            label: this.properties.dimension ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelDimensionsDescText',
        };
        this.supportedTitleProperties = {
            label: this.properties.supportedFileTitle ?? 'Supported formats:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelSupportedTitleText',
        };
        this.supportedDescProperties = {
            label: this.properties.supportedFile ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelDimensionsDescText',
        };
        this.maxLimitTitleProperties = {
            label: this.properties.maxLimitTitle ?? 'Dimension',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelMaxLimitTitleText',
        };
        this.maxLimitDescProperties = {
            label: this.properties.maxLimit ?? '',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelMaxLimitDescText',
        };
        this.maxAllowedFileTitleTextProperties = {
            label: this.properties.maxAllowedFileHintTitleText ?? 'Max Allowed File:',
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-600' },
            id: 'labelAllowedFileTitleText',
        };
        this.maxAllowedFileDescTextProperties = {
            label: this.properties.maxAllowedFileHintDescText,
            type: ClComponentTypes.label,
            style: { cssClasses: 'text-sm font-normal text-neutral-700' },
            id: 'labelAllowedFileDescText',
        };
        this.fileDisplayGridProperties = {
            colsPerRow: 2,
        };
        if (this.properties.allowedFileTypes !== undefined) {
            this.accept = this.properties.allowedFileTypes.join(',');
        }
    }
    /**
     * onFileUpload
     *
     * This function will call the service to upload the file
     *
     * @param event
     */
    onFileUpload(event) {
        // calling upload file method
        const result = this.uploadService.uploadFile(event, this.accept, this.properties.maxLimitInKb ? this.properties.maxLimitInKb : 0, this.properties.uploadError, this.properties.fileGridView);
        if (this.properties.maxAllowedFiles && ((Number(result().length) + Number(this.selectedFiles.length)) > this.properties.maxAllowedFiles)) {
            this.fileResult[0].errorMessage = this.properties.uploadError?.maxFileAllowedErrorMsg ?? 'File count exceeds allowed limit';
            this.errorTextProperties.label = this.fileResult[0].errorMessage;
            return;
        }
        // .pipe(take(1))
        // .subscribe((result: File[]) => {
        // calling reset view method
        if (result.length == 0 && this.selectedFiles.length == 0) {
            this.resetView();
        }
        result().forEach((x) => {
            if (x.extension == undefined) {
                const fileNameParts = x.name.split('.');
                const fileExtension = fileNameParts[fileNameParts.length - 1].toLowerCase();
                x.extension = fileExtension;
            }
        });
        this.selectedFiles = [...this.selectedFiles, ...result()];
        // this.selectedFiles = result;
        // calling get file size method
        // this.fileResult = this.uploadService.getFileSize(this.selectedFiles[0]);
        // this.fileResult = this.uploadService.fileResult.length>0 ?this.uploadService.fileResult : this.fileResult.push( { fileSize: 0, fileSizeDesc: '', errorMessage: undefined }) ;
        if (this.uploadService.fileResult.length > 0) {
            this.fileResult = this.uploadService.fileResult;
        }
        else {
            this.fileResult.push({ fileSize: 0, fileSizeDesc: '', errorMessage: undefined });
        }
        if (this.fileResult != undefined && this.fileResult.length > 0) {
            this.errorTextProperties.label = this.fileResult[0].errorMessage;
        }
        // calling show preview image method
        // this.showPreviewImage();
        // calling push selected files method
        this.pushSelectedFiles();
        // });
    }
    /**
     * resetView
     *
     * This function will reset the entire view
     */
    resetView() {
        this.localUrl = [];
        this.selectedFiles = [];
        this.preLoadImageProperties = undefined;
        this.properties.preLoadImageProperties = undefined;
        this.fileResult = [
            { fileSize: 0, fileSizeDesc: '', errorMessage: undefined },
        ];
    }
    /**
     * show preview image
     *
     * This method will generate the url of the selected file for preview
     *
     * @param files - array of files
     */
    showPreviewImage() {
        for (const file of this.selectedFiles) {
            const reader = new FileReader();
            reader.onload = (e) => {
                // calling set preview image properties method
                this.setPreviewImageProperties(e.target.result);
            };
            reader.readAsDataURL(file);
        }
    }
    setPreviewImageProperties(value) {
        this.localUrl.push(value);
        this.stackLayoutProperties = {
            isBackgroundImage: true,
            id: 'stackLayoutDragDrop',
            backgroundImageUrl: this.localUrl[0],
            styleProperties: {
                cornerRadius: 'rounded-md',
                width: this.properties.width,
                height: this.properties.height,
                bgColor: this.properties.afterUploadBgColor,
            },
            child: {
                layout: 'button',
            },
        };
    }
    /**
     * files dropped
     *
     * This function is called when the file is dropped in the UI
     *
     * @param selectedFiles - selected Files array which were dropped
     */
    filesDropped(selectedFiles) {
        this.selectedFiles = selectedFiles;
        // calling show preview image method
        // this.showPreviewImage(this.selectedFiles);
        // calling push selected files method
        this.pushSelectedFiles();
    }
    /**
     * on delete file
     *
     * this function will delete the selected file
     */
    onDeleteFile() {
        // calling reset view method
        this.resetView();
        // calling push selected files method
        this.pushSelectedFiles();
    }
    pushBase64Files(base64Files) {
        if (!Array.isArray(base64Files) || base64Files.length === 0) {
            return;
        }
        const processedFiles = base64Files.map(file => {
            const byteString = atob(file.base64.split(',')[1]); // Decode Base64
            const mimeString = file.base64.split(',')[0].split(':')[1].split(';')[0]; // Extract MIME type
            const arrayBuffer = new ArrayBuffer(byteString.length);
            const uintArray = new Uint8Array(arrayBuffer);
            for (let i = 0; i < byteString.length; i++) {
                uintArray[i] = byteString.charCodeAt(i);
            }
            const blob = new Blob([uintArray], { type: mimeString });
            const newFile = new File([blob], file.name, { type: mimeString });
            // Add extension manually if it's not already set
            if (!newFile.extension) {
                const fileNameParts = newFile.name.split('.');
                const fileExtension = fileNameParts[fileNameParts.length - 1].toLowerCase();
                newFile.extension = fileExtension;
            }
            return newFile;
        });
        // Push to selectedFiles
        this.selectedFiles.push(...processedFiles);
        // Call existing method to handle further processing
        this.pushSelectedFiles();
    }
    /**
     * push selected files
     *
     * this function will call the callback function
     */
    pushSelectedFiles() {
        // calling show preview image method
        this.showPreviewImage();
        // calling on file upload method
        if (this.properties.onFileUpload) {
            this.properties.onFileUpload(this.selectedFiles);
        }
        const uniqueFileNames = new Set();
        if (Array.isArray(this.selectedFiles)) {
            this.selectedFiles.forEach((selectedFile) => {
                const fileName = selectedFile.name;
                selectedFile.error = undefined;
                // Check if the file name is already in the set
                if (uniqueFileNames.has(fileName)) {
                    selectedFile.error = 'duplicate';
                    // File name is a duplicate
                    this.fileResult.push({
                        fileSize: 0,
                        fileSizeDesc: fileName,
                        errorMessage: 'Duplicate file',
                    });
                }
                else {
                    // File name is unique, add it to the set
                    uniqueFileNames.add(fileName);
                }
            });
        }
        if (this.fileResult != undefined && this.fileResult.length > 0) {
            this.duplicateErrorTextProperties.label = this.fileResult[this.fileResult.length - 1].errorMessage;
        }
    }
    setDefaultPropertyValue() {
        this.properties.isMultiple ??= true;
    }
    onDeleteEachFile(index) {
        if (index >= 0 && index < this.selectedFiles.length) {
            // Remove the element at the specified index
            const deletedFile = this.selectedFiles.splice(index, 1)[0];
            // Find the first occurrence of the file with the same name in the selectedFiles array
            const matchingFileIndex = this.selectedFiles.findIndex(file => file.name === deletedFile.name);
            // If found, remove the 'duplicate' error
            if (matchingFileIndex !== -1) {
                this.selectedFiles[matchingFileIndex].error = undefined;
            }
            if (this.selectedFiles.length == 1) {
                this.localUrl = [];
                this.showPreviewImage();
            }
            if (this.properties.onFileUpload) {
                this.properties.onFileUpload(this.selectedFiles);
            }
        }
    }
    onFileClicked(fileName) {
        if (this.properties.onFileClicked) {
            this.properties.onFileClicked(fileName);
        }
    }
    displaySize(sizeInBytes) {
        const sizeInKB = this.convertBytesToKB(sizeInBytes);
        const sizeInMB = this.convertBytesToMB(sizeInBytes);
        if (sizeInMB >= 1) {
            return `${sizeInMB.toFixed(2)} MB`;
        }
        else {
            return `${sizeInKB.toFixed(2)} KB`;
        }
    }
    convertBytesToMB(bytes) {
        return bytes / (1024 * 1024);
    }
    convertBytesToKB(bytes) {
        return bytes / 1024;
    }
    createIconProperties(id, iconName) {
        return {
            id: `${id}TileIcon`,
            type: ClComponentTypes.icon,
            iconName: `fss_icons:${iconName}`,
        };
    }
    getFileIconProperties(file) {
        const error = file.error !== undefined;
        const extension = error ? undefined : file.extension;
        const iconPropertiesMap = {
            'csv': this.createIconProperties('csv', 'csv-file'),
            'txt': this.createIconProperties('txt', 'txt-file'),
            'docx': this.createIconProperties('docx', 'doc-file'),
            'xlsx': this.createIconProperties('xlsx', 'xlx-file'),
            'xls': this.createIconProperties('xls', 'xls-file'),
            'pdf': this.createIconProperties('pdf', 'pdf-file'),
            'png': this.createIconProperties('png', 'png-file'),
            'jpg': this.createIconProperties('jpg', 'jpg-file'),
            'jfif': this.createIconProperties('jfif', 'gif-file'),
            'svg': this.createIconProperties('svg', 'svg-file'),
            'json': this.createIconProperties('json', 'json-file'),
            'html': this.createIconProperties('html', 'html-file'),
        };
        return iconPropertiesMap[extension] || this.fileUploadIconProperties;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropUploadComponent, deps: [{ token: i1.ClUploadService }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDragDropUploadComponent, isStandalone: true, selector: "cl-drag-drop-upload", inputs: { properties: "properties", updatedUploadIconProperties: "updatedUploadIconProperties", preLoadImageProperties: "preLoadImageProperties", preLoadMultiFileProperties: "preLoadMultiFileProperties" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClDragDropUploadComponent),
                multi: true
            },
            ClUploadService
        ], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "  @if ((properties.preLoadImageProperties == undefined && selectedFiles.length <=0) && (properties.fileGridView == undefined || properties.fileGridView == false)){\n  <div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if (fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flex-col mt-1 gap-1 justify-center\">\n     @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n  </div>\n  }\n<!-- Image preview -->\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==undefined || properties.fileGridView==false)){\n<div>\n  <div id=\"stackLayoutProperties.id\" class=\"stack-layout-container {{stackLayoutProperties?.styleProperties?.bgColor}} {{stackLayoutProperties?.styleProperties?.height}} {{stackLayoutProperties?.styleProperties?.width}} {{stackLayoutProperties?.styleProperties?.cornerRadius}}\" [ngStyle]=\"{'background-image': getImageUrl()}\">\n      <div class=\"flex flex-row justify-end\">\n\n      <button mat-raised-button type=\"button\"\n        (click)=\"fileUpload.value = ''; stackLayoutProperties.backgroundImageUrl = ''; onDeleteFile()\"\n        class=\"py-2 px-3 mt-4 mr-4 bg-white rounded-xl items-center justify-center\">\n\n        <cl-icon [properties]=\"deleteIconProperties\"></cl-icon>\n      </button>\n    </div>\n  </div>\n</div>\n}\n\n@if((properties.preLoadImageProperties == undefined && selectedFiles.length >=0) &&  (properties.fileGridView==true)){\n<div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if(fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flow-row mt-1 gap-1 justify-center\">\n\n    @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n</div>\n}\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==true)){\n<div\n  class=\"mt-8\">\n  <div class=\"grid w-full items-center sm:grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 {{fileDisplayGridProperties?.styleProperties?.gap || 'gap-4'}}\">\n    @for (file of selectedFiles; track file; let fileIndex = $index;) {\n    <div>\n      <div\n        class=\" {{ (fileResult[fileResult.length-1].errorMessage != undefined && file?.error=='duplicate' ) ? 'dashed-border-failed rounded-lg margin-top-error' : 'custom-background rounded-lg' }}\">\n\n        <div class=\"flex flex-row gap-4 justify-between\">\n          <!-- <div> -->\n          <div class=\"flex flex-row gap-1 justify-center mouse-pointer\" (click)=\"onFileClicked(file.name)\">\n            <ng-container>\n              <cl-icon [properties]=\"getFileIconProperties(file)\"\n                class=\" ml-1 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </ng-container>\n            <div class=\"flex flex-col gap-1 w-fit mt-2\">\n              <label class=\"text-primary font-normal text-[16px]\">{{ file.name }}</label>\n              <label class=\"text-xs text-neutral\">Size: {{ displaySize(file.size) }}</label>\n            </div>\n          </div>\n          <!-- </div> -->\n          <div>\n            <button mat-raised-button type=\"button\" (click)=\"fileUpload.value = ''; onDeleteEachFile(fileIndex)\"\n              class=\"rounded-xl items-center justify-center\">\n              <cl-icon [properties]=\"deleteIconProperties\"\n                class=\" ml-2 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </button>\n          </div>\n        </div>\n      </div>\n      <!-- Error message -->\n      @if((fileResult.length > 0 && fileResult[fileResult.length-1] != undefined) && file?.error=='duplicate'){\n      <ng-container>\n        <cl-label [properties]=\"duplicateErrorTextProperties\"></cl-label>\n      </ng-container>\n      }\n      <!-- Error message -->\n    </div>\n    }\n  </div>\n</div>\n}\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"properties.isMultiple\" (change)=\"onFileUpload($event)\" class=\"hidden pointer-events-none\" />\n", styles: [".container{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='%23333' stroke-width='1' stroke-dasharray='6' stroke-dashoffset='0' stroke-linecap='round'/%3e%3c/svg%3e\")!important}.custom-background{background-color:#f3f8ff}.margin-top-error{margin-top:16px}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "directive", type: ClDragDropDirective, selector: "[clDragDropUpload]", outputs: ["selectedFiles"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropUploadComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-drag-drop-upload', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClDragDropUploadComponent),
                            multi: true
                        },
                        ClUploadService
                    ], imports: [
                        NgStyle,
                        MatIconModule,
                        ClIconComponent,
                        ClCardComponent,
                        ClLabelComponent,
                        ClDragDropDirective,
                    ], template: "  @if ((properties.preLoadImageProperties == undefined && selectedFiles.length <=0) && (properties.fileGridView == undefined || properties.fileGridView == false)){\n  <div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if (fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flex-col mt-1 gap-1 justify-center\">\n     @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n  </div>\n  }\n<!-- Image preview -->\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==undefined || properties.fileGridView==false)){\n<div>\n  <div id=\"stackLayoutProperties.id\" class=\"stack-layout-container {{stackLayoutProperties?.styleProperties?.bgColor}} {{stackLayoutProperties?.styleProperties?.height}} {{stackLayoutProperties?.styleProperties?.width}} {{stackLayoutProperties?.styleProperties?.cornerRadius}}\" [ngStyle]=\"{'background-image': getImageUrl()}\">\n      <div class=\"flex flex-row justify-end\">\n\n      <button mat-raised-button type=\"button\"\n        (click)=\"fileUpload.value = ''; stackLayoutProperties.backgroundImageUrl = ''; onDeleteFile()\"\n        class=\"py-2 px-3 mt-4 mr-4 bg-white rounded-xl items-center justify-center\">\n\n        <cl-icon [properties]=\"deleteIconProperties\"></cl-icon>\n      </button>\n    </div>\n  </div>\n</div>\n}\n\n@if((properties.preLoadImageProperties == undefined && selectedFiles.length >=0) &&  (properties.fileGridView==true)){\n<div class=\"flex flex-col gap-1 {{properties.width}} {{properties.height}}\">\n  <div clDragDropUpload (selectedFiles)=\"filesDropped($event)\"\n    class=\"flex p-4 flex-col rounded-md items-center {{(fileResult.length &gt; 0 && fileResult[0].errorMessage != undefined) ? 'dashed-border-failed' : 'dashed-border'}}\">\n\n    <mat-icon [svgIcon]=\"properties.uploadIcon!\"\n    class=\"{{ properties.style?.uploadIconCssClasses ?? 'icon-size-16 text-primary'}}\">\n    </mat-icon>\n\n    <cl-label class=\"mt-2\" [properties]=\"dragDropTextProperties\"></cl-label>\n\n    <div class=\"flex flex-row\">\n      <cl-label [properties]=\"orTextProperties\"></cl-label>\n\n      <cl-label class=\"ml-1 cursor-pointer\" (click)=\"fileUpload.click()\" [properties]=\"browseFileTextProperties\">\n      </cl-label>\n    </div>\n  </div>\n  @if(fileResult.length > 0 && fileResult[0].errorMessage == undefined){\n  <div class=\"flex flow-row mt-1 gap-1 justify-center\">\n\n    @if(properties.dimension){\n      <cl-label [properties]=\"dimensionTitleProperties\"></cl-label>\n      <cl-label [properties]=\"dimensionDescProperties\"></cl-label>\n     }\n\n     @if(properties.supportedFile){\n      <cl-label [properties]=\"supportedTitleProperties\"></cl-label>\n      <cl-label [properties]=\"supportedDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxLimit){\n      <cl-label [properties]=\"maxLimitTitleProperties\"></cl-label>\n      <cl-label [properties]=\"maxLimitDescProperties\"></cl-label>\n     }\n\n     @if(properties.maxAllowedFileHintDescText){\n      <cl-label [properties]=\"maxAllowedFileTitleTextProperties\"></cl-label>\n      <cl-label [properties]=\"maxAllowedFileDescTextProperties\"></cl-label>\n     }\n  </div>\n  }\n  <!-- Error message -->\n  @if(fileResult.length > 0 && fileResult[0].errorMessage != undefined){\n  <ng-container>\n    <cl-label [properties]=\"errorTextProperties\"></cl-label>\n  </ng-container>\n  }\n  <!-- Error message -->\n</div>\n}\n@if(properties.preLoadImageProperties != undefined || (selectedFiles && selectedFiles.length > 0) && (properties.fileGridView==true)){\n<div\n  class=\"mt-8\">\n  <div class=\"grid w-full items-center sm:grid-cols-1 xl:grid-cols-2 lg:grid-cols-2 md:grid-cols-2 {{fileDisplayGridProperties?.styleProperties?.gap || 'gap-4'}}\">\n    @for (file of selectedFiles; track file; let fileIndex = $index;) {\n    <div>\n      <div\n        class=\" {{ (fileResult[fileResult.length-1].errorMessage != undefined && file?.error=='duplicate' ) ? 'dashed-border-failed rounded-lg margin-top-error' : 'custom-background rounded-lg' }}\">\n\n        <div class=\"flex flex-row gap-4 justify-between\">\n          <!-- <div> -->\n          <div class=\"flex flex-row gap-1 justify-center mouse-pointer\" (click)=\"onFileClicked(file.name)\">\n            <ng-container>\n              <cl-icon [properties]=\"getFileIconProperties(file)\"\n                class=\" ml-1 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </ng-container>\n            <div class=\"flex flex-col gap-1 w-fit mt-2\">\n              <label class=\"text-primary font-normal text-[16px]\">{{ file.name }}</label>\n              <label class=\"text-xs text-neutral\">Size: {{ displaySize(file.size) }}</label>\n            </div>\n          </div>\n          <!-- </div> -->\n          <div>\n            <button mat-raised-button type=\"button\" (click)=\"fileUpload.value = ''; onDeleteEachFile(fileIndex)\"\n              class=\"rounded-xl items-center justify-center\">\n              <cl-icon [properties]=\"deleteIconProperties\"\n                class=\" ml-2 w-14 h-14 flex min-w-14 min-h-14 items-center justify-center border-r-neutral-400\"></cl-icon>\n            </button>\n          </div>\n        </div>\n      </div>\n      <!-- Error message -->\n      @if((fileResult.length > 0 && fileResult[fileResult.length-1] != undefined) && file?.error=='duplicate'){\n      <ng-container>\n        <cl-label [properties]=\"duplicateErrorTextProperties\"></cl-label>\n      </ng-container>\n      }\n      <!-- Error message -->\n    </div>\n    }\n  </div>\n</div>\n}\n\n<input #fileUpload type=\"file\" id=\"file-upload\" [accept]=\"accept\" [multiple]=\"properties.isMultiple\" (change)=\"onFileUpload($event)\" class=\"hidden pointer-events-none\" />\n", styles: [".container{background-image:url(\"data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='%23333' stroke-width='1' stroke-dasharray='6' stroke-dashoffset='0' stroke-linecap='round'/%3e%3c/svg%3e\")!important}.custom-background{background-color:#f3f8ff}.margin-top-error{margin-top:16px}\n"] }]
        }], ctorParameters: () => [{ type: i1.ClUploadService }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], updatedUploadIconProperties: [{
                type: Input
            }], preLoadImageProperties: [{
                type: Input
            }], preLoadMultiFileProperties: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJhZy1kcm9wLXVwbG9hZC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvZHJhZy1kcm9wLXVwbG9hZC9kcmFnLWRyb3AtdXBsb2FkLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9kcmFnLWRyb3AtdXBsb2FkL2RyYWctZHJvcC11cGxvYWQuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQXdCLGlCQUFpQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDekUsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUU1RSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sU0FBUyxDQUFDO0FBQzFDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ25FLE9BQU8sRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUUvRSxPQUFPLEVBQWdCLGVBQWUsRUFBb0IsZ0JBQWdCLEVBQXFCLGVBQWUsRUFBRSxNQUFNLDJCQUEyQixDQUFDOzs7O0FBMEJsSixNQUFNLE9BQU8seUJBQTBCLFNBQVEsZUFBZTtJQXNGckQsV0FBVztRQUNoQixJQUFJLElBQUksQ0FBQyxxQkFBcUIsS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLHFCQUFxQixDQUFDLGlCQUFpQixLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzNHLE9BQU8sT0FBUSxJQUFJLENBQUMscUJBQXFCLEVBQUUsa0JBQW1CLEdBQUcsQ0FBQztRQUNwRSxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sTUFBTSxDQUFDO1FBQ2hCLENBQUM7SUFDSCxDQUFDO0lBRUQsWUFBcUIsYUFBOEI7UUFDakQsS0FBSyxFQUFFLENBQUM7UUFEVyxrQkFBYSxHQUFiLGFBQWEsQ0FBaUI7UUFuRjVDLFdBQU0sR0FBRyxFQUFFLENBQUM7UUFDWixhQUFRLEdBQWEsRUFBRSxDQUFDO1FBQ3hCLGtCQUFhLEdBQWlCLEVBQUUsQ0FBQztRQWdCeEMsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDNUIsOENBQThDO1FBRXZDLGVBQVUsR0FBbUI7WUFDbEMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRTtTQUMzRCxDQUFDO1FBRUssd0JBQW1CLEdBQXNCO1lBQzlDLEtBQUssRUFBRSxFQUFFO1lBQ1QsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLG9DQUFvQyxFQUFFO1lBQzNELEVBQUUsRUFBRSx5QkFBeUI7U0FDOUIsQ0FBQztRQUVLLGlDQUE0QixHQUFzQjtZQUN2RCxLQUFLLEVBQUUsRUFBRTtZQUNULElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxtQ0FBbUMsRUFBRTtZQUMxRCxFQUFFLEVBQUUsa0NBQWtDO1NBQ3ZDLENBQUM7UUFFSyx5QkFBb0IsR0FBcUI7WUFDOUMsRUFBRSxFQUFFLG9CQUFvQjtZQUN4QixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsMEJBQTBCLEVBQUU7WUFDakQsUUFBUSxFQUFFLHlCQUF5QjtTQUNwQyxDQUFDO1FBRUssMkJBQXNCLEdBQXNCO1lBQ2pELEtBQUssRUFBRSwwQkFBMEI7WUFDakMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHlEQUF5RCxFQUFFO1lBQ2hGLEVBQUUsRUFBRSxtQkFBbUI7U0FDeEIsQ0FBQztRQUVLLHFCQUFnQixHQUFzQjtZQUMzQyxLQUFLLEVBQUUsSUFBSTtZQUNYLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxrREFBa0QsRUFBRTtZQUN6RSxFQUFFLEVBQUUsYUFBYTtTQUNsQixDQUFDO1FBRUssNkJBQXdCLEdBQXNCO1lBQ25ELEtBQUssRUFBRSxhQUFhO1lBQ3BCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxrREFBa0QsRUFBRTtZQUN6RSxFQUFFLEVBQUUsaUJBQWlCO1NBQ3RCLENBQUM7UUFFSyw2QkFBd0IsR0FBcUI7WUFDbEQsRUFBRSxFQUFFLGdCQUFnQjtZQUNwQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsMEJBQTBCLEVBQUU7WUFDakQsUUFBUSxFQUFFLHVCQUF1QjtTQUNsQyxDQUFDO0lBWUYsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFrQjtRQUNqQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBa0I7UUFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUE7SUFDckIsQ0FBQztJQUVELElBQUksS0FBSztRQUNQLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQTtJQUNwQixDQUFDO0lBRUQsV0FBVyxDQUFDLE9BQXNCO1FBQ2hDLElBQUksSUFBSSxDQUFDLHNCQUFzQixJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzdDLDhDQUE4QztZQUM5QyxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZFLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQywwQkFBMEIsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUMvRSxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBUSxFQUFFLEVBQUUsQ0FBQyxJQUFJLEdBQUcsRUFBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsUUFBUSxJQUFJLENBQUMsY0FBYyxXQUFXLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBQyxDQUFDLENBQUM7WUFDakssSUFBSSxDQUFDLGVBQWUsQ0FBQyxVQUFVLENBQUMsQ0FBQTtRQUNsQyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZiw4Q0FBOEM7UUFDOUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7UUFDL0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVLEtBQUssd0JBQXdCLENBQUE7UUFFdkQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLHNCQUFzQixFQUFFLENBQUM7WUFDM0MsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEYsQ0FBQztRQUVELElBQUksQ0FBQyx3QkFBd0IsR0FBRztZQUM5QixLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLElBQUksdUJBQXVCO1lBQ2hFLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxzQ0FBc0MsRUFBRTtZQUM3RCxFQUFFLEVBQUUsMEJBQTBCO1NBQy9CLENBQUM7UUFFRixJQUFJLENBQUMsdUJBQXVCLEdBQUc7WUFDN0IsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxJQUFJLEVBQUU7WUFDdEMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHNDQUFzQyxFQUFFO1lBQzdELEVBQUUsRUFBRSx5QkFBeUI7U0FDOUIsQ0FBQztRQUVGLElBQUksQ0FBQyx3QkFBd0IsR0FBRztZQUM5QixLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsSUFBSSxvQkFBb0I7WUFDakUsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHNDQUFzQyxFQUFFO1lBQzdELEVBQUUsRUFBRSx5QkFBeUI7U0FDOUIsQ0FBQztRQUVGLElBQUksQ0FBQyx1QkFBdUIsR0FBRztZQUM3QixLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksRUFBRTtZQUMxQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsS0FBSztZQUM1QixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsc0NBQXNDLEVBQUU7WUFDN0QsRUFBRSxFQUFFLHlCQUF5QjtTQUM5QixDQUFDO1FBRUYsSUFBSSxDQUFDLHVCQUF1QixHQUFHO1lBQzdCLEtBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsSUFBSSxXQUFXO1lBQ25ELElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxLQUFLO1lBQzVCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxzQ0FBc0MsRUFBRTtZQUM3RCxFQUFFLEVBQUUsd0JBQXdCO1NBQzdCLENBQUM7UUFFRixJQUFJLENBQUMsc0JBQXNCLEdBQUc7WUFDNUIsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLEVBQUU7WUFDckMsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHNDQUFzQyxFQUFFO1lBQzdELEVBQUUsRUFBRSx1QkFBdUI7U0FDNUIsQ0FBQztRQUVGLElBQUksQ0FBQyxpQ0FBaUMsR0FBRztZQUN2QyxLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQywyQkFBMkIsSUFBSSxtQkFBbUI7WUFDekUsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHNDQUFzQyxFQUFFO1lBQzdELEVBQUUsRUFBRSwyQkFBMkI7U0FDaEMsQ0FBQTtRQUVELElBQUksQ0FBQyxnQ0FBZ0MsR0FBRztZQUN0QyxLQUFLLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQywwQkFBMEI7WUFDakQsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHNDQUFzQyxFQUFFO1lBQzdELEVBQUUsRUFBRSwwQkFBMEI7U0FDL0IsQ0FBQTtRQUVELElBQUksQ0FBQyx5QkFBeUIsR0FBRztZQUMvQixVQUFVLEVBQUUsQ0FBQztTQUNkLENBQUE7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZ0JBQWdCLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDbkQsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUMzRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNJLFlBQVksQ0FBQyxLQUFjO1FBRWhDLDZCQUE2QjtRQUM3QixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFBO1FBRTVMLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxlQUFlLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQztZQUN6SSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxzQkFBc0IsSUFBSSxrQ0FBa0MsQ0FBQztZQUM1SCxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQ2pFLE9BQU07UUFDUixDQUFDO1FBQ0QsaUJBQWlCO1FBQ2pCLG1DQUFtQztRQUNuQyw0QkFBNEI7UUFDNUIsSUFBSSxNQUFNLENBQUMsTUFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN6RCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbkIsQ0FBQztRQUVELE1BQU0sRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFO1lBQzFCLElBQUksQ0FBQyxDQUFDLFNBQVMsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDN0IsTUFBTSxhQUFhLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3hDLE1BQU0sYUFBYSxHQUFHLGFBQWEsQ0FBQyxhQUFhLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUM1RSxDQUFDLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQztZQUM5QixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsYUFBYSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFLEdBQUcsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUUxRCwrQkFBK0I7UUFDL0IsK0JBQStCO1FBQy9CLDJFQUEyRTtRQUMzRSxnTEFBZ0w7UUFFaEwsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDN0MsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQztRQUNsRCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUUsRUFBRSxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ25GLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQy9ELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFhLENBQUM7UUFDcEUsQ0FBQztRQUVELG9DQUFvQztRQUNwQywyQkFBMkI7UUFFM0IscUNBQXFDO1FBQ3JDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pCLE1BQU07SUFDUixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNLLFNBQVM7UUFDZixJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztRQUNuQixJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUV4QixJQUFJLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLEdBQUcsU0FBUyxDQUFDO1FBR25ELElBQUksQ0FBQyxVQUFVLEdBQUc7WUFDaEIsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBRSxFQUFFLEVBQUUsWUFBWSxFQUFFLFNBQVMsRUFBRTtTQUMzRCxDQUFDO0lBQ0osQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNLLGdCQUFnQjtRQUN0QixLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN0QyxNQUFNLE1BQU0sR0FBRyxJQUFJLFVBQVUsRUFBRSxDQUFDO1lBRWhDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRTtnQkFDekIsOENBQThDO2dCQUM5QyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNsRCxDQUFDLENBQUM7WUFFRixNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdCLENBQUM7SUFDSCxDQUFDO0lBRU8seUJBQXlCLENBQUMsS0FBVTtRQUMxQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUxQixJQUFJLENBQUMscUJBQXFCLEdBQUc7WUFDM0IsaUJBQWlCLEVBQUUsSUFBSTtZQUN2QixFQUFFLEVBQUUscUJBQXFCO1lBQ3pCLGtCQUFrQixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLGVBQWUsRUFBRTtnQkFDZixZQUFZLEVBQUUsWUFBWTtnQkFDMUIsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSztnQkFDNUIsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTTtnQkFDOUIsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsa0JBQWtCO2FBQzVDO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLE1BQU0sRUFBRSxRQUFRO2FBQ2pCO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7Ozs7O09BTUc7SUFDSSxZQUFZLENBQUMsYUFBc0I7UUFDeEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxhQUF1QixDQUFDO1FBRTdDLG9DQUFvQztRQUNwQyw2Q0FBNkM7UUFFN0MscUNBQXFDO1FBQ3JDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksWUFBWTtRQUNqQiw0QkFBNEI7UUFDNUIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRWpCLHFDQUFxQztRQUNyQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0sZUFBZSxDQUFDLFdBQStDO1FBQ3BFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDNUQsT0FBTztRQUNULENBQUM7UUFFRCxNQUFNLGNBQWMsR0FBVyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3BELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO1lBQ3BFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7WUFFOUYsTUFBTSxXQUFXLEdBQUcsSUFBSSxXQUFXLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sU0FBUyxHQUFHLElBQUksVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRTlDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQzNDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFDLENBQUM7WUFFRCxNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFDekQsTUFBTSxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFFbEUsaURBQWlEO1lBQ2pELElBQUksQ0FBRSxPQUFzQixDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUN4QyxNQUFNLGFBQWEsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDOUMsTUFBTSxhQUFhLEdBQUcsYUFBYSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzNFLE9BQXNCLENBQUMsU0FBUyxHQUFHLGFBQWEsQ0FBQztZQUNuRCxDQUFDO1lBR0QsT0FBTyxPQUFxQixDQUFDO1FBQy9CLENBQUMsQ0FBQyxDQUFDO1FBRUgsd0JBQXdCO1FBQ3hCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsY0FBYyxDQUFDLENBQUM7UUFFM0Msb0RBQW9EO1FBQ3BELElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksaUJBQWlCO1FBQ3RCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUV4QixnQ0FBZ0M7UUFDaEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNuRCxDQUFDO1FBRUQsTUFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLEVBQVUsQ0FBQztRQUMxQyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUM7WUFDdEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFpQixFQUFFLEVBQUU7Z0JBQy9DLE1BQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxJQUFJLENBQUM7Z0JBQ25DLFlBQVksQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO2dCQUUvQiwrQ0FBK0M7Z0JBQy9DLElBQUksZUFBZSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO29CQUNsQyxZQUFZLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQztvQkFFakMsMkJBQTJCO29CQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzt3QkFDbkIsUUFBUSxFQUFFLENBQUM7d0JBQ1gsWUFBWSxFQUFFLFFBQVE7d0JBQ3RCLFlBQVksRUFBRSxnQkFBZ0I7cUJBQy9CLENBQUMsQ0FBQztnQkFDTCxDQUFDO3FCQUFNLENBQUM7b0JBQ04seUNBQXlDO29CQUN6QyxlQUFlLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUMvRCxJQUFJLENBQUMsNEJBQTRCLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBYSxDQUFDO1FBQ3RHLENBQUM7SUFDSCxDQUFDO0lBRU8sdUJBQXVCO1FBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxLQUFLLElBQUksQ0FBQztJQUN0QyxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsS0FBVTtRQUNoQyxJQUFJLEtBQUssSUFBSSxDQUFDLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDcEQsNENBQTRDO1lBQzVDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMzRCxzRkFBc0Y7WUFDdEYsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRS9GLHlDQUF5QztZQUN6QyxJQUFJLGlCQUFpQixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO1lBQzFELENBQUM7WUFFRCxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNuQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDMUIsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDakMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ25ELENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVTLGFBQWEsQ0FBQyxRQUFnQjtRQUN0QyxJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFDLENBQUM7WUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDMUMsQ0FBQztJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsV0FBbUI7UUFDN0IsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3BELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUVwRCxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNsQixPQUFPLEdBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUUsS0FBSyxDQUFDO1FBQ3ZDLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxHQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFFLEtBQUssQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELGdCQUFnQixDQUFDLEtBQWE7UUFDNUIsT0FBTyxLQUFLLEdBQUcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDL0IsQ0FBQztJQUVELGdCQUFnQixDQUFDLEtBQWE7UUFDNUIsT0FBTyxLQUFLLEdBQUcsSUFBSSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxvQkFBb0IsQ0FBQyxFQUFVLEVBQUUsUUFBZ0I7UUFDL0MsT0FBTztZQUNMLEVBQUUsRUFBRSxHQUFJLEVBQUcsVUFBVTtZQUNyQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixRQUFRLEVBQUUsYUFBYyxRQUFTLEVBQUU7U0FDcEMsQ0FBQztJQUNKLENBQUM7SUFFRCxxQkFBcUIsQ0FBQyxJQUFTO1FBQzdCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEtBQUssU0FBUyxDQUFDO1FBQ3ZDLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ3JELE1BQU0saUJBQWlCLEdBQXdDO1lBQzdELEtBQUssRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQztZQUNuRCxLQUFLLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxVQUFVLENBQUM7WUFDbkQsTUFBTSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDO1lBQ3JELE1BQU0sRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQztZQUNyRCxLQUFLLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxVQUFVLENBQUM7WUFDbkQsS0FBSyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDO1lBQ25ELEtBQUssRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQztZQUNuRCxLQUFLLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssRUFBRSxVQUFVLENBQUM7WUFDbkQsTUFBTSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxDQUFDO1lBQ3JELEtBQUssRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQztZQUNuRCxNQUFNLEVBQUUsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUM7WUFDdEQsTUFBTSxFQUFFLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDO1NBQ3ZELENBQUM7UUFFRixPQUFPLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztJQUN2RSxDQUFDOzhHQXJmVSx5QkFBeUI7a0dBQXpCLHlCQUF5QixnUkFwQnpCO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLGlCQUFpQjtnQkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyx5QkFBeUIsQ0FBQztnQkFDeEQsS0FBSyxFQUFFLElBQUk7YUFDWjtZQUNELGVBQWU7U0FDaEIsc0VDdEJILG04T0FvS0EsMmJEMUlJLE9BQU8sMEVBQ1AsYUFBYSxvTEFDYixlQUFlLDRFQUVmLGdCQUFnQiw2RUFDaEIsbUJBQW1COzsyRkFJVix5QkFBeUI7a0JBdkJyQyxTQUFTO2lDQUNJLElBQUksWUFDTixxQkFBcUIsYUFDcEI7d0JBQ1Q7NEJBQ0UsT0FBTyxFQUFFLGlCQUFpQjs0QkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsMEJBQTBCLENBQUM7NEJBQ3hELEtBQUssRUFBRSxJQUFJO3lCQUNaO3dCQUNELGVBQWU7cUJBQ2hCLFdBR1E7d0JBQ1AsT0FBTzt3QkFDUCxhQUFhO3dCQUNiLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZixnQkFBZ0I7d0JBQ2hCLG1CQUFtQjtxQkFDcEI7b0ZBS2UsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBRVQsMkJBQTJCO3NCQUExQyxLQUFLO2dCQUdDLHNCQUFzQjtzQkFENUIsS0FBSztnQkFJQywwQkFBMEI7c0JBRGhDLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ1N0eWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIGZvcndhcmRSZWYsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ2xDYXJkQ29tcG9uZW50IH0gZnJvbSAnLi4vY2FyZCc7XG5pbXBvcnQgeyBDbERyYWdEcm9wRGlyZWN0aXZlIH0gZnJvbSAnLi9kcmFnLWRyb3AtdXBsb2FkLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQsIENsQ29tcG9uZW50VHlwZXMgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbERyYWdEcm9wUHJvcGVydGllcywgQ2xQcmVMb2FkSW1hZ2VQcm9wZXJ0aWVzLCBDdXN0b21GaWxlLCBDbFByZUxvYWRNdWx0aUZpbGVQcm9wZXJ0aWVzIH0gZnJvbSAnLi9kcmFnLWRyb3AtdXBsb2FkLnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xGaWxlUmVzdWx0LCBDbEljb25Db21wb25lbnQsIENsSWNvblByb3BlcnRpZXMsIENsTGFiZWxDb21wb25lbnQsIENsTGFiZWxQcm9wZXJ0aWVzLCBDbFVwbG9hZFNlcnZpY2UgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL2Jhc2ljJztcbmltcG9ydCB7IGJhc2U2NHN0cmluZyB9IGZyb20gJy4vYmFzZTY0LWRhdGEnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1kcmFnLWRyb3AtdXBsb2FkJyxcbiAgcHJvdmlkZXJzOiBbXG4gICAge1xuICAgICAgcHJvdmlkZTogTkdfVkFMVUVfQUNDRVNTT1IsXG4gICAgICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBDbERyYWdEcm9wVXBsb2FkQ29tcG9uZW50KSxcbiAgICAgIG11bHRpOiB0cnVlXG4gICAgfSxcbiAgICBDbFVwbG9hZFNlcnZpY2VcbiAgXSxcbiAgdGVtcGxhdGVVcmw6ICcuL2RyYWctZHJvcC11cGxvYWQuY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9kcmFnLWRyb3AtdXBsb2FkLmNvbXBvbmVudC5zY3NzJ10sXG4gIGltcG9ydHM6IFtcbiAgICBOZ1N0eWxlLFxuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgQ2xJY29uQ29tcG9uZW50LFxuICAgIENsQ2FyZENvbXBvbmVudCxcbiAgICBDbExhYmVsQ29tcG9uZW50LFxuICAgIENsRHJhZ0Ryb3BEaXJlY3RpdmUsXG4gIF0sXG59KVxuXG5leHBvcnQgY2xhc3MgQ2xEcmFnRHJvcFVwbG9hZENvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbERyYWdEcm9wUHJvcGVydGllcztcbiAgQElucHV0KCkgcHVibGljIHVwZGF0ZWRVcGxvYWRJY29uUHJvcGVydGllcz86IHN0cmluZztcblxuICBASW5wdXQoKVxuICBwdWJsaWMgcHJlTG9hZEltYWdlUHJvcGVydGllcz86IENsUHJlTG9hZEltYWdlUHJvcGVydGllcztcblxuICBASW5wdXQoKVxuICBwdWJsaWMgcHJlTG9hZE11bHRpRmlsZVByb3BlcnRpZXM/OiBDbFByZUxvYWRNdWx0aUZpbGVQcm9wZXJ0aWVzW107XG5cbiAgcHVibGljIGFjY2VwdCA9ICcnO1xuICBwdWJsaWMgbG9jYWxVcmw6IHN0cmluZ1tdID0gW107XG4gIHB1YmxpYyBzZWxlY3RlZEZpbGVzOiBDdXN0b21GaWxlW10gPSBbXTtcblxuICBwdWJsaWMgbWF4TGltaXREZXNjUHJvcGVydGllcyE6IENsTGFiZWxQcm9wZXJ0aWVzO1xuICBwdWJsaWMgbWF4TGltaXRUaXRsZVByb3BlcnRpZXMhOiBDbExhYmVsUHJvcGVydGllcztcbiAgcHVibGljIG1heEFsbG93ZWRGaWxlVGl0bGVUZXh0UHJvcGVydGllcyE6IENsTGFiZWxQcm9wZXJ0aWVzO1xuICBwdWJsaWMgbWF4QWxsb3dlZEZpbGVEZXNjVGV4dFByb3BlcnRpZXMhOiBDbExhYmVsUHJvcGVydGllcztcbiAgcHVibGljIGRpbWVuc2lvbkRlc2NQcm9wZXJ0aWVzITogQ2xMYWJlbFByb3BlcnRpZXM7XG4gIHB1YmxpYyBkaW1lbnNpb25UaXRsZVByb3BlcnRpZXMhOiBDbExhYmVsUHJvcGVydGllcztcbiAgcHVibGljIHN1cHBvcnRlZERlc2NQcm9wZXJ0aWVzITogQ2xMYWJlbFByb3BlcnRpZXM7XG4gIHB1YmxpYyBzdXBwb3J0ZWRUaXRsZVByb3BlcnRpZXMhOiBDbExhYmVsUHJvcGVydGllcztcbiAgcHVibGljIHN0YWNrTGF5b3V0UHJvcGVydGllcyE6IGFueTtcbiAgcHVibGljIGZpbGVEaXNwbGF5R3JpZFByb3BlcnRpZXMhOiBhbnk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIFJlcXVpcmVkIHRvIGltcGxlbWVudCBDb250cm9sVmFsdWVBY2Nlc3NvclxuICBwcm90ZWN0ZWQgX3ZhbHVlOiBhbnk7XG4gIG9uQ2hhbmdlID0gKF86IGFueSkgPT4geyB9O1xuICBvblRvdWNoZWQgPSAoXzogYW55KSA9PiB7IH07XG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBwdWJsaWMgZmlsZVJlc3VsdDogQ2xGaWxlUmVzdWx0W10gPSBbXG4gICAgeyBmaWxlU2l6ZTogMCwgZmlsZVNpemVEZXNjOiAnJywgZXJyb3JNZXNzYWdlOiB1bmRlZmluZWQgfSxcbiAgXTtcblxuICBwdWJsaWMgZXJyb3JUZXh0UHJvcGVydGllczogQ2xMYWJlbFByb3BlcnRpZXMgPSB7XG4gICAgbGFiZWw6ICcnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ3RleHQtc20gdGV4dC1mYWlsZWQganVzdGlmeS1jZW50ZXInIH0sXG4gICAgaWQ6ICdkcmFnRHJvcFVwbG9hZEVycm9yVGV4dCcsXG4gIH07XG5cbiAgcHVibGljIGR1cGxpY2F0ZUVycm9yVGV4dFByb3BlcnRpZXM6IENsTGFiZWxQcm9wZXJ0aWVzID0ge1xuICAgIGxhYmVsOiAnJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmxhYmVsLFxuICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICd0ZXh0LXNtIHRleHQtZmFpbGVkIGp1c3RpZnktc3RhcnQnIH0sXG4gICAgaWQ6ICdkcmFnRHJvcFVwbG9hZER1cGxpY2F0ZUVycm9yVGV4dCcsXG4gIH07XG5cbiAgcHVibGljIGRlbGV0ZUljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAnZHJhZ0Ryb3BEZWxldGVJY29uJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmljb24sXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS01IHRleHQtcmVkLTQwMCcgfSxcbiAgICBpY29uTmFtZTogJ2hlcm9pY29uc19vdXRsaW5lOnRyYXNoJyxcbiAgfTtcblxuICBwdWJsaWMgZHJhZ0Ryb3BUZXh0UHJvcGVydGllczogQ2xMYWJlbFByb3BlcnRpZXMgPSB7XG4gICAgbGFiZWw6ICdEcmFnIGFuZCBkcm9wIGZpbGVzIGhlcmUnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ210LTIgdGV4dC1iYXNlIGxlYWRpbmctNiBmb250LXNlbWlib2xkIHRleHQtbmV1dHJhbC02MDAnIH0sXG4gICAgaWQ6ICdsYWJlbERyYWdEcm9wVGV4dCcsXG4gIH07XG5cbiAgcHVibGljIG9yVGV4dFByb3BlcnRpZXM6IENsTGFiZWxQcm9wZXJ0aWVzID0ge1xuICAgIGxhYmVsOiAnb3InLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ3RleHQtbWQgbGVhZGluZy02IGZvbnQtc2VtaWJvbGQgdGV4dC1uZXV0cmFsLTYwMCcgfSxcbiAgICBpZDogJ2xhYmVsT3JUZXh0JyxcbiAgfTtcblxuICBwdWJsaWMgYnJvd3NlRmlsZVRleHRQcm9wZXJ0aWVzOiBDbExhYmVsUHJvcGVydGllcyA9IHtcbiAgICBsYWJlbDogJ0Jyb3dzZSBmaWxlJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmxhYmVsLFxuICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICd0ZXh0LWJhc2UgbGVhZGluZy02IGZvbnQtbm9ybWFsIHRleHQtcHJpbWFyeS0zMDAnIH0sXG4gICAgaWQ6ICdsYWJlbEJyb3dzZVRleHQnLFxuICB9O1xuXG4gIHB1YmxpYyBmaWxlVXBsb2FkSWNvblByb3BlcnRpZXM6IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICd1cGxvYWRUaWxlSWNvbicsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICdpY29uLXNpemUtNiB0ZXh0LXByaW1hcnknIH0sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6ZmlsZS11cGxvYWQnLFxuICB9O1xuXG4gIHB1YmxpYyBnZXRJbWFnZVVybCgpIHtcbiAgICBpZiAodGhpcy5zdGFja0xheW91dFByb3BlcnRpZXMgIT09IHVuZGVmaW5lZCAmJiB0aGlzLnN0YWNrTGF5b3V0UHJvcGVydGllcy5pc0JhY2tncm91bmRJbWFnZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gYHVybCgkeyB0aGlzLnN0YWNrTGF5b3V0UHJvcGVydGllcz8uYmFja2dyb3VuZEltYWdlVXJsIH0pYDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuICdub25lJztcbiAgICB9XG4gIH1cblxuICBjb25zdHJ1Y3RvciAocHJpdmF0ZSB1cGxvYWRTZXJ2aWNlOiBDbFVwbG9hZFNlcnZpY2UpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlXG4gIH1cblxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgaWYgKHRoaXMucHJlTG9hZEltYWdlUHJvcGVydGllcyAhPSB1bmRlZmluZWQpIHtcbiAgICAgIC8vIGNhbGxpbmcgc2V0IHByZXZpZXcgaW1hZ2UgcHJvcGVydGllcyBtZXRob2RcbiAgICAgIHRoaXMuc2V0UHJldmlld0ltYWdlUHJvcGVydGllcyh0aGlzLnByZUxvYWRJbWFnZVByb3BlcnRpZXMuaW1hZ2VVcmwpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByZUxvYWRNdWx0aUZpbGVQcm9wZXJ0aWVzICE9IHVuZGVmaW5lZCAmJiB0aGlzLnByb3BlcnRpZXMuaXNNdWx0aXBsZSkge1xuICAgICAgbGV0IGxpc3RVcGRhdGUgPSB0aGlzLnByZUxvYWRNdWx0aUZpbGVQcm9wZXJ0aWVzLm1hcCgoZmlsZTphbnkpID0+IGZpbGUgPSB7bmFtZTogZmlsZS5maWxlTmFtZSwgYmFzZTY0OiBgZGF0YToke2ZpbGUuYmFzZTY0RGF0YVR5cGV9O2Jhc2U2NCwke2ZpbGUuYmFzZTY0dmFsfWB9KTtcbiAgICAgIHRoaXMucHVzaEJhc2U2NEZpbGVzKGxpc3RVcGRhdGUpXG4gICAgfVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgLy8gY2FsbGluZyBzZXQgZGVmYXVsdCBwcm9wZXJ0eSB2YWx1ZSBmdW5jdGlvblxuICAgIHRoaXMuc2V0RGVmYXVsdFByb3BlcnR5VmFsdWUoKTtcbiAgICB0aGlzLnByb3BlcnRpZXMudXBsb2FkSWNvbiA/Pz0gJ2Zzc19pY29uczpjbG91ZC11cGxvYWQnXG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnByZUxvYWRJbWFnZVByb3BlcnRpZXMpIHtcbiAgICAgIHRoaXMuc2V0UHJldmlld0ltYWdlUHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMucHJlTG9hZEltYWdlUHJvcGVydGllcy5pbWFnZVVybCk7XG4gICAgfVxuXG4gICAgdGhpcy5kaW1lbnNpb25UaXRsZVByb3BlcnRpZXMgPSB7XG4gICAgICBsYWJlbDogdGhpcy5wcm9wZXJ0aWVzLmRpbWVuc2lvblRpdGxlID8/ICdTdXBwb3J0ZWQgZGltZW5zaW9uczonLFxuICAgICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5sYWJlbCxcbiAgICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICd0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtbmV1dHJhbC02MDAnIH0sXG4gICAgICBpZDogJ2xhYmVsRGltZW5zaW9uc1RpdGxlVGV4dCcsXG4gICAgfTtcblxuICAgIHRoaXMuZGltZW5zaW9uRGVzY1Byb3BlcnRpZXMgPSB7XG4gICAgICBsYWJlbDogdGhpcy5wcm9wZXJ0aWVzLmRpbWVuc2lvbiA/PyAnJyxcbiAgICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAndGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LW5ldXRyYWwtNzAwJyB9LFxuICAgICAgaWQ6ICdsYWJlbERpbWVuc2lvbnNEZXNjVGV4dCcsXG4gICAgfTtcblxuICAgIHRoaXMuc3VwcG9ydGVkVGl0bGVQcm9wZXJ0aWVzID0ge1xuICAgICAgbGFiZWw6IHRoaXMucHJvcGVydGllcy5zdXBwb3J0ZWRGaWxlVGl0bGUgPz8gJ1N1cHBvcnRlZCBmb3JtYXRzOicsXG4gICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmxhYmVsLFxuICAgICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ3RleHQtc20gZm9udC1ub3JtYWwgdGV4dC1uZXV0cmFsLTYwMCcgfSxcbiAgICAgIGlkOiAnbGFiZWxTdXBwb3J0ZWRUaXRsZVRleHQnLFxuICAgIH07XG5cbiAgICB0aGlzLnN1cHBvcnRlZERlc2NQcm9wZXJ0aWVzID0ge1xuICAgICAgbGFiZWw6IHRoaXMucHJvcGVydGllcy5zdXBwb3J0ZWRGaWxlID8/ICcnLFxuICAgICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5sYWJlbCxcbiAgICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICd0ZXh0LXNtIGZvbnQtbm9ybWFsIHRleHQtbmV1dHJhbC03MDAnIH0sXG4gICAgICBpZDogJ2xhYmVsRGltZW5zaW9uc0Rlc2NUZXh0JyxcbiAgICB9O1xuXG4gICAgdGhpcy5tYXhMaW1pdFRpdGxlUHJvcGVydGllcyA9IHtcbiAgICAgIGxhYmVsOiB0aGlzLnByb3BlcnRpZXMubWF4TGltaXRUaXRsZSA/PyAnRGltZW5zaW9uJyxcbiAgICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAndGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LW5ldXRyYWwtNjAwJyB9LFxuICAgICAgaWQ6ICdsYWJlbE1heExpbWl0VGl0bGVUZXh0JyxcbiAgICB9O1xuXG4gICAgdGhpcy5tYXhMaW1pdERlc2NQcm9wZXJ0aWVzID0ge1xuICAgICAgbGFiZWw6IHRoaXMucHJvcGVydGllcy5tYXhMaW1pdCA/PyAnJyxcbiAgICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMubGFiZWwsXG4gICAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAndGV4dC1zbSBmb250LW5vcm1hbCB0ZXh0LW5ldXRyYWwtNzAwJyB9LFxuICAgICAgaWQ6ICdsYWJlbE1heExpbWl0RGVzY1RleHQnLFxuICAgIH07XG5cbiAgICB0aGlzLm1heEFsbG93ZWRGaWxlVGl0bGVUZXh0UHJvcGVydGllcyA9IHtcbiAgICAgIGxhYmVsOiB0aGlzLnByb3BlcnRpZXMubWF4QWxsb3dlZEZpbGVIaW50VGl0bGVUZXh0ID8/ICdNYXggQWxsb3dlZCBGaWxlOicsXG4gICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmxhYmVsLFxuICAgICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ3RleHQtc20gZm9udC1ub3JtYWwgdGV4dC1uZXV0cmFsLTYwMCcgfSxcbiAgICAgIGlkOiAnbGFiZWxBbGxvd2VkRmlsZVRpdGxlVGV4dCcsXG4gICAgfVxuXG4gICAgdGhpcy5tYXhBbGxvd2VkRmlsZURlc2NUZXh0UHJvcGVydGllcyA9IHtcbiAgICAgIGxhYmVsOiB0aGlzLnByb3BlcnRpZXMubWF4QWxsb3dlZEZpbGVIaW50RGVzY1RleHQsXG4gICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmxhYmVsLFxuICAgICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ3RleHQtc20gZm9udC1ub3JtYWwgdGV4dC1uZXV0cmFsLTcwMCcgfSxcbiAgICAgIGlkOiAnbGFiZWxBbGxvd2VkRmlsZURlc2NUZXh0JyxcbiAgICB9XG5cbiAgICB0aGlzLmZpbGVEaXNwbGF5R3JpZFByb3BlcnRpZXMgPSB7XG4gICAgICBjb2xzUGVyUm93OiAyLFxuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuYWxsb3dlZEZpbGVUeXBlcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLmFjY2VwdCA9IHRoaXMucHJvcGVydGllcy5hbGxvd2VkRmlsZVR5cGVzLmpvaW4oJywnKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogb25GaWxlVXBsb2FkXG4gICAqXG4gICAqIFRoaXMgZnVuY3Rpb24gd2lsbCBjYWxsIHRoZSBzZXJ2aWNlIHRvIHVwbG9hZCB0aGUgZmlsZVxuICAgKlxuICAgKiBAcGFyYW0gZXZlbnRcbiAgICovXG4gIHB1YmxpYyBvbkZpbGVVcGxvYWQoZXZlbnQ6IHVua25vd24pIHtcblxuICAgIC8vIGNhbGxpbmcgdXBsb2FkIGZpbGUgbWV0aG9kXG4gICAgY29uc3QgcmVzdWx0ID0gdGhpcy51cGxvYWRTZXJ2aWNlLnVwbG9hZEZpbGUoZXZlbnQsIHRoaXMuYWNjZXB0LCB0aGlzLnByb3BlcnRpZXMubWF4TGltaXRJbktiID8gdGhpcy5wcm9wZXJ0aWVzLm1heExpbWl0SW5LYiA6IDAsIHRoaXMucHJvcGVydGllcy51cGxvYWRFcnJvciwgdGhpcy5wcm9wZXJ0aWVzLmZpbGVHcmlkVmlldylcblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMubWF4QWxsb3dlZEZpbGVzICYmICgoTnVtYmVyKHJlc3VsdCgpLmxlbmd0aCkgKyBOdW1iZXIodGhpcy5zZWxlY3RlZEZpbGVzLmxlbmd0aCkpID4gdGhpcy5wcm9wZXJ0aWVzLm1heEFsbG93ZWRGaWxlcykpIHtcbiAgICAgIHRoaXMuZmlsZVJlc3VsdFswXS5lcnJvck1lc3NhZ2UgPSB0aGlzLnByb3BlcnRpZXMudXBsb2FkRXJyb3I/Lm1heEZpbGVBbGxvd2VkRXJyb3JNc2cgPz8gJ0ZpbGUgY291bnQgZXhjZWVkcyBhbGxvd2VkIGxpbWl0JztcbiAgICAgIHRoaXMuZXJyb3JUZXh0UHJvcGVydGllcy5sYWJlbCA9IHRoaXMuZmlsZVJlc3VsdFswXS5lcnJvck1lc3NhZ2U7XG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgLy8gLnBpcGUodGFrZSgxKSlcbiAgICAvLyAuc3Vic2NyaWJlKChyZXN1bHQ6IEZpbGVbXSkgPT4ge1xuICAgIC8vIGNhbGxpbmcgcmVzZXQgdmlldyBtZXRob2RcbiAgICBpZiAocmVzdWx0Lmxlbmd0aCA9PSAwICYmIHRoaXMuc2VsZWN0ZWRGaWxlcy5sZW5ndGggPT0gMCkge1xuICAgICAgdGhpcy5yZXNldFZpZXcoKTtcbiAgICB9XG5cbiAgICByZXN1bHQoKS5mb3JFYWNoKCh4OiBhbnkpID0+IHtcbiAgICAgIGlmICh4LmV4dGVuc2lvbiA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgY29uc3QgZmlsZU5hbWVQYXJ0cyA9IHgubmFtZS5zcGxpdCgnLicpO1xuICAgICAgICBjb25zdCBmaWxlRXh0ZW5zaW9uID0gZmlsZU5hbWVQYXJ0c1tmaWxlTmFtZVBhcnRzLmxlbmd0aCAtIDFdLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIHguZXh0ZW5zaW9uID0gZmlsZUV4dGVuc2lvbjtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMuc2VsZWN0ZWRGaWxlcyA9IFsuLi50aGlzLnNlbGVjdGVkRmlsZXMsIC4uLnJlc3VsdCgpXTtcblxuICAgIC8vIHRoaXMuc2VsZWN0ZWRGaWxlcyA9IHJlc3VsdDtcbiAgICAvLyBjYWxsaW5nIGdldCBmaWxlIHNpemUgbWV0aG9kXG4gICAgLy8gdGhpcy5maWxlUmVzdWx0ID0gdGhpcy51cGxvYWRTZXJ2aWNlLmdldEZpbGVTaXplKHRoaXMuc2VsZWN0ZWRGaWxlc1swXSk7XG4gICAgLy8gdGhpcy5maWxlUmVzdWx0ID0gdGhpcy51cGxvYWRTZXJ2aWNlLmZpbGVSZXN1bHQubGVuZ3RoPjAgP3RoaXMudXBsb2FkU2VydmljZS5maWxlUmVzdWx0IDogdGhpcy5maWxlUmVzdWx0LnB1c2goIHsgZmlsZVNpemU6IDAsIGZpbGVTaXplRGVzYzogJycsIGVycm9yTWVzc2FnZTogdW5kZWZpbmVkIH0pIDtcblxuICAgIGlmICh0aGlzLnVwbG9hZFNlcnZpY2UuZmlsZVJlc3VsdC5sZW5ndGggPiAwKSB7XG4gICAgICB0aGlzLmZpbGVSZXN1bHQgPSB0aGlzLnVwbG9hZFNlcnZpY2UuZmlsZVJlc3VsdDtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5maWxlUmVzdWx0LnB1c2goeyBmaWxlU2l6ZTogMCwgZmlsZVNpemVEZXNjOiAnJywgZXJyb3JNZXNzYWdlOiB1bmRlZmluZWQgfSk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuZmlsZVJlc3VsdCAhPSB1bmRlZmluZWQgJiYgdGhpcy5maWxlUmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgIHRoaXMuZXJyb3JUZXh0UHJvcGVydGllcy5sYWJlbCA9IHRoaXMuZmlsZVJlc3VsdFswXS5lcnJvck1lc3NhZ2UhO1xuICAgIH1cblxuICAgIC8vIGNhbGxpbmcgc2hvdyBwcmV2aWV3IGltYWdlIG1ldGhvZFxuICAgIC8vIHRoaXMuc2hvd1ByZXZpZXdJbWFnZSgpO1xuXG4gICAgLy8gY2FsbGluZyBwdXNoIHNlbGVjdGVkIGZpbGVzIG1ldGhvZFxuICAgIHRoaXMucHVzaFNlbGVjdGVkRmlsZXMoKTtcbiAgICAvLyB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiByZXNldFZpZXdcbiAgICpcbiAgICogVGhpcyBmdW5jdGlvbiB3aWxsIHJlc2V0IHRoZSBlbnRpcmUgdmlld1xuICAgKi9cbiAgcHJpdmF0ZSByZXNldFZpZXcoKSB7XG4gICAgdGhpcy5sb2NhbFVybCA9IFtdO1xuICAgIHRoaXMuc2VsZWN0ZWRGaWxlcyA9IFtdO1xuXG4gICAgdGhpcy5wcmVMb2FkSW1hZ2VQcm9wZXJ0aWVzID0gdW5kZWZpbmVkO1xuICAgIHRoaXMucHJvcGVydGllcy5wcmVMb2FkSW1hZ2VQcm9wZXJ0aWVzID0gdW5kZWZpbmVkO1xuXG5cbiAgICB0aGlzLmZpbGVSZXN1bHQgPSBbXG4gICAgICB7IGZpbGVTaXplOiAwLCBmaWxlU2l6ZURlc2M6ICcnLCBlcnJvck1lc3NhZ2U6IHVuZGVmaW5lZCB9LFxuICAgIF07XG4gIH1cblxuICAvKipcbiAgICogc2hvdyBwcmV2aWV3IGltYWdlXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHdpbGwgZ2VuZXJhdGUgdGhlIHVybCBvZiB0aGUgc2VsZWN0ZWQgZmlsZSBmb3IgcHJldmlld1xuICAgKlxuICAgKiBAcGFyYW0gZmlsZXMgLSBhcnJheSBvZiBmaWxlc1xuICAgKi9cbiAgcHJpdmF0ZSBzaG93UHJldmlld0ltYWdlKCkge1xuICAgIGZvciAoY29uc3QgZmlsZSBvZiB0aGlzLnNlbGVjdGVkRmlsZXMpIHtcbiAgICAgIGNvbnN0IHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKCk7XG5cbiAgICAgIHJlYWRlci5vbmxvYWQgPSAoZTogYW55KSA9PiB7XG4gICAgICAgIC8vIGNhbGxpbmcgc2V0IHByZXZpZXcgaW1hZ2UgcHJvcGVydGllcyBtZXRob2RcbiAgICAgICAgdGhpcy5zZXRQcmV2aWV3SW1hZ2VQcm9wZXJ0aWVzKGUudGFyZ2V0LnJlc3VsdCk7XG4gICAgICB9O1xuXG4gICAgICByZWFkZXIucmVhZEFzRGF0YVVSTChmaWxlKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldFByZXZpZXdJbWFnZVByb3BlcnRpZXModmFsdWU6IGFueSkge1xuICAgIHRoaXMubG9jYWxVcmwucHVzaCh2YWx1ZSk7XG5cbiAgICB0aGlzLnN0YWNrTGF5b3V0UHJvcGVydGllcyA9IHtcbiAgICAgIGlzQmFja2dyb3VuZEltYWdlOiB0cnVlLFxuICAgICAgaWQ6ICdzdGFja0xheW91dERyYWdEcm9wJyxcbiAgICAgIGJhY2tncm91bmRJbWFnZVVybDogdGhpcy5sb2NhbFVybFswXSxcbiAgICAgIHN0eWxlUHJvcGVydGllczoge1xuICAgICAgICBjb3JuZXJSYWRpdXM6ICdyb3VuZGVkLW1kJyxcbiAgICAgICAgd2lkdGg6IHRoaXMucHJvcGVydGllcy53aWR0aCxcbiAgICAgICAgaGVpZ2h0OiB0aGlzLnByb3BlcnRpZXMuaGVpZ2h0LFxuICAgICAgICBiZ0NvbG9yOiB0aGlzLnByb3BlcnRpZXMuYWZ0ZXJVcGxvYWRCZ0NvbG9yLFxuICAgICAgfSxcbiAgICAgIGNoaWxkOiB7XG4gICAgICAgIGxheW91dDogJ2J1dHRvbicsXG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogZmlsZXMgZHJvcHBlZFxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aGVuIHRoZSBmaWxlIGlzIGRyb3BwZWQgaW4gdGhlIFVJXG4gICAqXG4gICAqIEBwYXJhbSBzZWxlY3RlZEZpbGVzIC0gc2VsZWN0ZWQgRmlsZXMgYXJyYXkgd2hpY2ggd2VyZSBkcm9wcGVkXG4gICAqL1xuICBwdWJsaWMgZmlsZXNEcm9wcGVkKHNlbGVjdGVkRmlsZXM6IHVua25vd24pOiB2b2lkIHtcbiAgICB0aGlzLnNlbGVjdGVkRmlsZXMgPSBzZWxlY3RlZEZpbGVzIGFzIEZpbGVbXTtcblxuICAgIC8vIGNhbGxpbmcgc2hvdyBwcmV2aWV3IGltYWdlIG1ldGhvZFxuICAgIC8vIHRoaXMuc2hvd1ByZXZpZXdJbWFnZSh0aGlzLnNlbGVjdGVkRmlsZXMpO1xuXG4gICAgLy8gY2FsbGluZyBwdXNoIHNlbGVjdGVkIGZpbGVzIG1ldGhvZFxuICAgIHRoaXMucHVzaFNlbGVjdGVkRmlsZXMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBvbiBkZWxldGUgZmlsZVxuICAgKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgZGVsZXRlIHRoZSBzZWxlY3RlZCBmaWxlXG4gICAqL1xuICBwdWJsaWMgb25EZWxldGVGaWxlKCk6IHZvaWQge1xuICAgIC8vIGNhbGxpbmcgcmVzZXQgdmlldyBtZXRob2RcbiAgICB0aGlzLnJlc2V0VmlldygpO1xuXG4gICAgLy8gY2FsbGluZyBwdXNoIHNlbGVjdGVkIGZpbGVzIG1ldGhvZFxuICAgIHRoaXMucHVzaFNlbGVjdGVkRmlsZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyBwdXNoQmFzZTY0RmlsZXMoYmFzZTY0RmlsZXM6IHsgbmFtZTogc3RyaW5nOyBiYXNlNjQ6IHN0cmluZyB9W10pIHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoYmFzZTY0RmlsZXMpIHx8IGJhc2U2NEZpbGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IHByb2Nlc3NlZEZpbGVzOiBGaWxlW10gPSBiYXNlNjRGaWxlcy5tYXAoZmlsZSA9PiB7XG4gICAgICBjb25zdCBieXRlU3RyaW5nID0gYXRvYihmaWxlLmJhc2U2NC5zcGxpdCgnLCcpWzFdKTsgLy8gRGVjb2RlIEJhc2U2NFxuICAgICAgY29uc3QgbWltZVN0cmluZyA9IGZpbGUuYmFzZTY0LnNwbGl0KCcsJylbMF0uc3BsaXQoJzonKVsxXS5zcGxpdCgnOycpWzBdOyAvLyBFeHRyYWN0IE1JTUUgdHlwZVxuXG4gICAgICBjb25zdCBhcnJheUJ1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihieXRlU3RyaW5nLmxlbmd0aCk7XG4gICAgICBjb25zdCB1aW50QXJyYXkgPSBuZXcgVWludDhBcnJheShhcnJheUJ1ZmZlcik7XG5cbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZVN0cmluZy5sZW5ndGg7IGkrKykge1xuICAgICAgICB1aW50QXJyYXlbaV0gPSBieXRlU3RyaW5nLmNoYXJDb2RlQXQoaSk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGJsb2IgPSBuZXcgQmxvYihbdWludEFycmF5XSwgeyB0eXBlOiBtaW1lU3RyaW5nIH0pO1xuICAgICAgY29uc3QgbmV3RmlsZSA9IG5ldyBGaWxlKFtibG9iXSwgZmlsZS5uYW1lLCB7IHR5cGU6IG1pbWVTdHJpbmcgfSk7XG5cbiAgICAgIC8vIEFkZCBleHRlbnNpb24gbWFudWFsbHkgaWYgaXQncyBub3QgYWxyZWFkeSBzZXRcbiAgICAgIGlmICghKG5ld0ZpbGUgYXMgQ3VzdG9tRmlsZSkuZXh0ZW5zaW9uKSB7XG4gICAgICAgY29uc3QgZmlsZU5hbWVQYXJ0cyA9IG5ld0ZpbGUubmFtZS5zcGxpdCgnLicpO1xuICAgICAgIGNvbnN0IGZpbGVFeHRlbnNpb24gPSBmaWxlTmFtZVBhcnRzW2ZpbGVOYW1lUGFydHMubGVuZ3RoIC0gMV0udG9Mb3dlckNhc2UoKTtcbiAgICAgICAobmV3RmlsZSBhcyBDdXN0b21GaWxlKS5leHRlbnNpb24gPSBmaWxlRXh0ZW5zaW9uO1xuICAgICAgfVxuXG5cbiAgICAgIHJldHVybiBuZXdGaWxlIGFzIEN1c3RvbUZpbGU7XG4gICAgfSk7XG5cbiAgICAvLyBQdXNoIHRvIHNlbGVjdGVkRmlsZXNcbiAgICB0aGlzLnNlbGVjdGVkRmlsZXMucHVzaCguLi5wcm9jZXNzZWRGaWxlcyk7XG5cbiAgICAvLyBDYWxsIGV4aXN0aW5nIG1ldGhvZCB0byBoYW5kbGUgZnVydGhlciBwcm9jZXNzaW5nXG4gICAgdGhpcy5wdXNoU2VsZWN0ZWRGaWxlcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIHB1c2ggc2VsZWN0ZWQgZmlsZXNcbiAgICpcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIGNhbGwgdGhlIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAqL1xuICBwdWJsaWMgcHVzaFNlbGVjdGVkRmlsZXMoKSB7XG4gICAgLy8gY2FsbGluZyBzaG93IHByZXZpZXcgaW1hZ2UgbWV0aG9kXG4gICAgdGhpcy5zaG93UHJldmlld0ltYWdlKCk7XG5cbiAgICAvLyBjYWxsaW5nIG9uIGZpbGUgdXBsb2FkIG1ldGhvZFxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25GaWxlVXBsb2FkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25GaWxlVXBsb2FkKHRoaXMuc2VsZWN0ZWRGaWxlcyk7XG4gICAgfVxuXG4gICAgY29uc3QgdW5pcXVlRmlsZU5hbWVzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodGhpcy5zZWxlY3RlZEZpbGVzKSkge1xuICAgICAgdGhpcy5zZWxlY3RlZEZpbGVzLmZvckVhY2goKHNlbGVjdGVkRmlsZTogYW55KSA9PiB7XG4gICAgICAgIGNvbnN0IGZpbGVOYW1lID0gc2VsZWN0ZWRGaWxlLm5hbWU7XG4gICAgICAgIHNlbGVjdGVkRmlsZS5lcnJvciA9IHVuZGVmaW5lZDtcblxuICAgICAgICAvLyBDaGVjayBpZiB0aGUgZmlsZSBuYW1lIGlzIGFscmVhZHkgaW4gdGhlIHNldFxuICAgICAgICBpZiAodW5pcXVlRmlsZU5hbWVzLmhhcyhmaWxlTmFtZSkpIHtcbiAgICAgICAgICBzZWxlY3RlZEZpbGUuZXJyb3IgPSAnZHVwbGljYXRlJztcblxuICAgICAgICAgIC8vIEZpbGUgbmFtZSBpcyBhIGR1cGxpY2F0ZVxuICAgICAgICAgIHRoaXMuZmlsZVJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgIGZpbGVTaXplOiAwLFxuICAgICAgICAgICAgZmlsZVNpemVEZXNjOiBmaWxlTmFtZSxcbiAgICAgICAgICAgIGVycm9yTWVzc2FnZTogJ0R1cGxpY2F0ZSBmaWxlJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBGaWxlIG5hbWUgaXMgdW5pcXVlLCBhZGQgaXQgdG8gdGhlIHNldFxuICAgICAgICAgIHVuaXF1ZUZpbGVOYW1lcy5hZGQoZmlsZU5hbWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5maWxlUmVzdWx0ICE9IHVuZGVmaW5lZCAmJiB0aGlzLmZpbGVSZXN1bHQubGVuZ3RoID4gMCkge1xuICAgICAgdGhpcy5kdXBsaWNhdGVFcnJvclRleHRQcm9wZXJ0aWVzLmxhYmVsID0gdGhpcy5maWxlUmVzdWx0W3RoaXMuZmlsZVJlc3VsdC5sZW5ndGggLSAxXS5lcnJvck1lc3NhZ2UhO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0RGVmYXVsdFByb3BlcnR5VmFsdWUoKSB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzLmlzTXVsdGlwbGUgPz89IHRydWU7XG4gIH1cblxuICBwdWJsaWMgb25EZWxldGVFYWNoRmlsZShpbmRleDogYW55KSB7XG4gICAgaWYgKGluZGV4ID49IDAgJiYgaW5kZXggPCB0aGlzLnNlbGVjdGVkRmlsZXMubGVuZ3RoKSB7XG4gICAgICAvLyBSZW1vdmUgdGhlIGVsZW1lbnQgYXQgdGhlIHNwZWNpZmllZCBpbmRleFxuICAgICAgY29uc3QgZGVsZXRlZEZpbGUgPSB0aGlzLnNlbGVjdGVkRmlsZXMuc3BsaWNlKGluZGV4LCAxKVswXTtcbiAgICAgIC8vIEZpbmQgdGhlIGZpcnN0IG9jY3VycmVuY2Ugb2YgdGhlIGZpbGUgd2l0aCB0aGUgc2FtZSBuYW1lIGluIHRoZSBzZWxlY3RlZEZpbGVzIGFycmF5XG4gICAgICBjb25zdCBtYXRjaGluZ0ZpbGVJbmRleCA9IHRoaXMuc2VsZWN0ZWRGaWxlcy5maW5kSW5kZXgoZmlsZSA9PiBmaWxlLm5hbWUgPT09IGRlbGV0ZWRGaWxlLm5hbWUpO1xuXG4gICAgICAvLyBJZiBmb3VuZCwgcmVtb3ZlIHRoZSAnZHVwbGljYXRlJyBlcnJvclxuICAgICAgaWYgKG1hdGNoaW5nRmlsZUluZGV4ICE9PSAtMSkge1xuICAgICAgICB0aGlzLnNlbGVjdGVkRmlsZXNbbWF0Y2hpbmdGaWxlSW5kZXhdLmVycm9yID0gdW5kZWZpbmVkO1xuICAgICAgfVxuXG4gICAgICBpZiAodGhpcy5zZWxlY3RlZEZpbGVzLmxlbmd0aCA9PSAxKSB7XG4gICAgICAgIHRoaXMubG9jYWxVcmwgPSBbXTtcbiAgICAgICAgdGhpcy5zaG93UHJldmlld0ltYWdlKCk7XG4gICAgICB9XG4gICAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uRmlsZVVwbG9hZCkge1xuICAgICAgICB0aGlzLnByb3BlcnRpZXMub25GaWxlVXBsb2FkKHRoaXMuc2VsZWN0ZWRGaWxlcyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIG9uRmlsZUNsaWNrZWQoZmlsZU5hbWU6IHN0cmluZyl7XG4gICAgaWYodGhpcy5wcm9wZXJ0aWVzLm9uRmlsZUNsaWNrZWQpe1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uRmlsZUNsaWNrZWQoZmlsZU5hbWUpO1xuICAgIH1cbiAgfVxuXG4gIGRpc3BsYXlTaXplKHNpemVJbkJ5dGVzOiBudW1iZXIpOiBzdHJpbmcge1xuICAgIGNvbnN0IHNpemVJbktCID0gdGhpcy5jb252ZXJ0Qnl0ZXNUb0tCKHNpemVJbkJ5dGVzKTtcbiAgICBjb25zdCBzaXplSW5NQiA9IHRoaXMuY29udmVydEJ5dGVzVG9NQihzaXplSW5CeXRlcyk7XG5cbiAgICBpZiAoc2l6ZUluTUIgPj0gMSkge1xuICAgICAgcmV0dXJuIGAkeyBzaXplSW5NQi50b0ZpeGVkKDIpIH0gTUJgO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYCR7IHNpemVJbktCLnRvRml4ZWQoMikgfSBLQmA7XG4gICAgfVxuICB9XG5cbiAgY29udmVydEJ5dGVzVG9NQihieXRlczogbnVtYmVyKTogbnVtYmVyIHtcbiAgICByZXR1cm4gYnl0ZXMgLyAoMTAyNCAqIDEwMjQpO1xuICB9XG5cbiAgY29udmVydEJ5dGVzVG9LQihieXRlczogbnVtYmVyKTogbnVtYmVyIHtcbiAgICByZXR1cm4gYnl0ZXMgLyAxMDI0O1xuICB9XG5cbiAgY3JlYXRlSWNvblByb3BlcnRpZXMoaWQ6IHN0cmluZywgaWNvbk5hbWU6IHN0cmluZyk6IENsSWNvblByb3BlcnRpZXMge1xuICAgIHJldHVybiB7XG4gICAgICBpZDogYCR7IGlkIH1UaWxlSWNvbmAsXG4gICAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmljb24sXG4gICAgICBpY29uTmFtZTogYGZzc19pY29uczokeyBpY29uTmFtZSB9YCxcbiAgICB9O1xuICB9XG5cbiAgZ2V0RmlsZUljb25Qcm9wZXJ0aWVzKGZpbGU6IGFueSk6IENsSWNvblByb3BlcnRpZXMge1xuICAgIGNvbnN0IGVycm9yID0gZmlsZS5lcnJvciAhPT0gdW5kZWZpbmVkO1xuICAgIGNvbnN0IGV4dGVuc2lvbiA9IGVycm9yID8gdW5kZWZpbmVkIDogZmlsZS5leHRlbnNpb247XG4gICAgY29uc3QgaWNvblByb3BlcnRpZXNNYXA6IHsgW2tleTogc3RyaW5nXTogQ2xJY29uUHJvcGVydGllcyB9ID0ge1xuICAgICAgJ2Nzdic6IHRoaXMuY3JlYXRlSWNvblByb3BlcnRpZXMoJ2NzdicsICdjc3YtZmlsZScpLFxuICAgICAgJ3R4dCc6IHRoaXMuY3JlYXRlSWNvblByb3BlcnRpZXMoJ3R4dCcsICd0eHQtZmlsZScpLFxuICAgICAgJ2RvY3gnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdkb2N4JywgJ2RvYy1maWxlJyksXG4gICAgICAneGxzeCc6IHRoaXMuY3JlYXRlSWNvblByb3BlcnRpZXMoJ3hsc3gnLCAneGx4LWZpbGUnKSxcbiAgICAgICd4bHMnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCd4bHMnLCAneGxzLWZpbGUnKSxcbiAgICAgICdwZGYnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdwZGYnLCAncGRmLWZpbGUnKSxcbiAgICAgICdwbmcnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdwbmcnLCAncG5nLWZpbGUnKSxcbiAgICAgICdqcGcnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdqcGcnLCAnanBnLWZpbGUnKSxcbiAgICAgICdqZmlmJzogdGhpcy5jcmVhdGVJY29uUHJvcGVydGllcygnamZpZicsICdnaWYtZmlsZScpLFxuICAgICAgJ3N2Zyc6IHRoaXMuY3JlYXRlSWNvblByb3BlcnRpZXMoJ3N2ZycsICdzdmctZmlsZScpLFxuICAgICAgJ2pzb24nOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdqc29uJywgJ2pzb24tZmlsZScpLFxuICAgICAgJ2h0bWwnOiB0aGlzLmNyZWF0ZUljb25Qcm9wZXJ0aWVzKCdodG1sJywgJ2h0bWwtZmlsZScpLFxuICAgIH07XG5cbiAgICByZXR1cm4gaWNvblByb3BlcnRpZXNNYXBbZXh0ZW5zaW9uXSB8fCB0aGlzLmZpbGVVcGxvYWRJY29uUHJvcGVydGllcztcbiAgfVxufVxuIiwiICBAaWYgKChwcm9wZXJ0aWVzLnByZUxvYWRJbWFnZVByb3BlcnRpZXMgPT0gdW5kZWZpbmVkICYmIHNlbGVjdGVkRmlsZXMubGVuZ3RoIDw9MCkgJiYgKHByb3BlcnRpZXMuZmlsZUdyaWRWaWV3ID09IHVuZGVmaW5lZCB8fCBwcm9wZXJ0aWVzLmZpbGVHcmlkVmlldyA9PSBmYWxzZSkpe1xuICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMSB7e3Byb3BlcnRpZXMud2lkdGh9fSB7e3Byb3BlcnRpZXMuaGVpZ2h0fX1cIj5cblxuICA8ZGl2IGNsRHJhZ0Ryb3BVcGxvYWQgKHNlbGVjdGVkRmlsZXMpPVwiZmlsZXNEcm9wcGVkKCRldmVudClcIlxuICAgIGNsYXNzPVwiZmxleCBwLTQgZmxleC1jb2wgcm91bmRlZC1tZCBpdGVtcy1jZW50ZXIge3soZmlsZVJlc3VsdC5sZW5ndGggJmd0OyAwICYmIGZpbGVSZXN1bHRbMF0uZXJyb3JNZXNzYWdlICE9IHVuZGVmaW5lZCkgPyAnZGFzaGVkLWJvcmRlci1mYWlsZWQnIDogJ2Rhc2hlZC1ib3JkZXInfX1cIj5cblxuICAgIDxtYXQtaWNvbiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnVwbG9hZEljb24hXCJcbiAgICBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LnVwbG9hZEljb25Dc3NDbGFzc2VzID8/ICdpY29uLXNpemUtMTYgdGV4dC1wcmltYXJ5J319XCI+XG4gICAgPC9tYXQtaWNvbj5cblxuICAgIDxjbC1sYWJlbCBjbGFzcz1cIm10LTJcIiBbcHJvcGVydGllc109XCJkcmFnRHJvcFRleHRQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cblxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtcm93XCI+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwib3JUZXh0UHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG5cbiAgICAgIDxjbC1sYWJlbCBjbGFzcz1cIm1sLTEgY3Vyc29yLXBvaW50ZXJcIiAoY2xpY2spPVwiZmlsZVVwbG9hZC5jbGljaygpXCIgW3Byb3BlcnRpZXNdPVwiYnJvd3NlRmlsZVRleHRQcm9wZXJ0aWVzXCI+XG4gICAgICA8L2NsLWxhYmVsPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbiAgQGlmIChmaWxlUmVzdWx0Lmxlbmd0aCA+IDAgJiYgZmlsZVJlc3VsdFswXS5lcnJvck1lc3NhZ2UgPT0gdW5kZWZpbmVkKXtcbiAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1jb2wgbXQtMSBnYXAtMSBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICBAaWYocHJvcGVydGllcy5kaW1lbnNpb24pe1xuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cImRpbWVuc2lvblRpdGxlUHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwiZGltZW5zaW9uRGVzY1Byb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG5cbiAgICAgQGlmKHByb3BlcnRpZXMuc3VwcG9ydGVkRmlsZSl7XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwic3VwcG9ydGVkVGl0bGVQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cbiAgICAgIDxjbC1sYWJlbCBbcHJvcGVydGllc109XCJzdXBwb3J0ZWREZXNjUHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgIH1cblxuICAgICBAaWYocHJvcGVydGllcy5tYXhMaW1pdCl7XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwibWF4TGltaXRUaXRsZVByb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cIm1heExpbWl0RGVzY1Byb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG5cbiAgICAgQGlmKHByb3BlcnRpZXMubWF4QWxsb3dlZEZpbGVIaW50RGVzY1RleHQpe1xuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cIm1heEFsbG93ZWRGaWxlVGl0bGVUZXh0UHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwibWF4QWxsb3dlZEZpbGVEZXNjVGV4dFByb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG4gIDwvZGl2PlxuICB9XG4gIDwhLS0gRXJyb3IgbWVzc2FnZSAtLT5cbiAgQGlmKGZpbGVSZXN1bHQubGVuZ3RoID4gMCAmJiBmaWxlUmVzdWx0WzBdLmVycm9yTWVzc2FnZSAhPSB1bmRlZmluZWQpe1xuICA8bmctY29udGFpbmVyPlxuICAgIDxjbC1sYWJlbCBbcHJvcGVydGllc109XCJlcnJvclRleHRQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cbiAgPC9uZy1jb250YWluZXI+XG4gIH1cbiAgPCEtLSBFcnJvciBtZXNzYWdlIC0tPlxuICA8L2Rpdj5cbiAgfVxuPCEtLSBJbWFnZSBwcmV2aWV3IC0tPlxuQGlmKHByb3BlcnRpZXMucHJlTG9hZEltYWdlUHJvcGVydGllcyAhPSB1bmRlZmluZWQgfHwgKHNlbGVjdGVkRmlsZXMgJiYgc2VsZWN0ZWRGaWxlcy5sZW5ndGggPiAwKSAmJiAocHJvcGVydGllcy5maWxlR3JpZFZpZXc9PXVuZGVmaW5lZCB8fCBwcm9wZXJ0aWVzLmZpbGVHcmlkVmlldz09ZmFsc2UpKXtcbjxkaXY+XG4gIDxkaXYgaWQ9XCJzdGFja0xheW91dFByb3BlcnRpZXMuaWRcIiBjbGFzcz1cInN0YWNrLWxheW91dC1jb250YWluZXIge3tzdGFja0xheW91dFByb3BlcnRpZXM/LnN0eWxlUHJvcGVydGllcz8uYmdDb2xvcn19IHt7c3RhY2tMYXlvdXRQcm9wZXJ0aWVzPy5zdHlsZVByb3BlcnRpZXM/LmhlaWdodH19IHt7c3RhY2tMYXlvdXRQcm9wZXJ0aWVzPy5zdHlsZVByb3BlcnRpZXM/LndpZHRofX0ge3tzdGFja0xheW91dFByb3BlcnRpZXM/LnN0eWxlUHJvcGVydGllcz8uY29ybmVyUmFkaXVzfX1cIiBbbmdTdHlsZV09XCJ7J2JhY2tncm91bmQtaW1hZ2UnOiBnZXRJbWFnZVVybCgpfVwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1yb3cganVzdGlmeS1lbmRcIj5cblxuICAgICAgPGJ1dHRvbiBtYXQtcmFpc2VkLWJ1dHRvbiB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgKGNsaWNrKT1cImZpbGVVcGxvYWQudmFsdWUgPSAnJzsgc3RhY2tMYXlvdXRQcm9wZXJ0aWVzLmJhY2tncm91bmRJbWFnZVVybCA9ICcnOyBvbkRlbGV0ZUZpbGUoKVwiXG4gICAgICAgIGNsYXNzPVwicHktMiBweC0zIG10LTQgbXItNCBiZy13aGl0ZSByb3VuZGVkLXhsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuXG4gICAgICAgIDxjbC1pY29uIFtwcm9wZXJ0aWVzXT1cImRlbGV0ZUljb25Qcm9wZXJ0aWVzXCI+PC9jbC1pY29uPlxuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC9kaXY+XG59XG5cbkBpZigocHJvcGVydGllcy5wcmVMb2FkSW1hZ2VQcm9wZXJ0aWVzID09IHVuZGVmaW5lZCAmJiBzZWxlY3RlZEZpbGVzLmxlbmd0aCA+PTApICYmICAocHJvcGVydGllcy5maWxlR3JpZFZpZXc9PXRydWUpKXtcbjxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGdhcC0xIHt7cHJvcGVydGllcy53aWR0aH19IHt7cHJvcGVydGllcy5oZWlnaHR9fVwiPlxuICA8ZGl2IGNsRHJhZ0Ryb3BVcGxvYWQgKHNlbGVjdGVkRmlsZXMpPVwiZmlsZXNEcm9wcGVkKCRldmVudClcIlxuICAgIGNsYXNzPVwiZmxleCBwLTQgZmxleC1jb2wgcm91bmRlZC1tZCBpdGVtcy1jZW50ZXIge3soZmlsZVJlc3VsdC5sZW5ndGggJmd0OyAwICYmIGZpbGVSZXN1bHRbMF0uZXJyb3JNZXNzYWdlICE9IHVuZGVmaW5lZCkgPyAnZGFzaGVkLWJvcmRlci1mYWlsZWQnIDogJ2Rhc2hlZC1ib3JkZXInfX1cIj5cblxuICAgIDxtYXQtaWNvbiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnVwbG9hZEljb24hXCJcbiAgICBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LnVwbG9hZEljb25Dc3NDbGFzc2VzID8/ICdpY29uLXNpemUtMTYgdGV4dC1wcmltYXJ5J319XCI+XG4gICAgPC9tYXQtaWNvbj5cblxuICAgIDxjbC1sYWJlbCBjbGFzcz1cIm10LTJcIiBbcHJvcGVydGllc109XCJkcmFnRHJvcFRleHRQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cblxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtcm93XCI+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwib3JUZXh0UHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG5cbiAgICAgIDxjbC1sYWJlbCBjbGFzcz1cIm1sLTEgY3Vyc29yLXBvaW50ZXJcIiAoY2xpY2spPVwiZmlsZVVwbG9hZC5jbGljaygpXCIgW3Byb3BlcnRpZXNdPVwiYnJvd3NlRmlsZVRleHRQcm9wZXJ0aWVzXCI+XG4gICAgICA8L2NsLWxhYmVsPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbiAgQGlmKGZpbGVSZXN1bHQubGVuZ3RoID4gMCAmJiBmaWxlUmVzdWx0WzBdLmVycm9yTWVzc2FnZSA9PSB1bmRlZmluZWQpe1xuICA8ZGl2IGNsYXNzPVwiZmxleCBmbG93LXJvdyBtdC0xIGdhcC0xIGp1c3RpZnktY2VudGVyXCI+XG5cbiAgICBAaWYocHJvcGVydGllcy5kaW1lbnNpb24pe1xuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cImRpbWVuc2lvblRpdGxlUHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwiZGltZW5zaW9uRGVzY1Byb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG5cbiAgICAgQGlmKHByb3BlcnRpZXMuc3VwcG9ydGVkRmlsZSl7XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwic3VwcG9ydGVkVGl0bGVQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cbiAgICAgIDxjbC1sYWJlbCBbcHJvcGVydGllc109XCJzdXBwb3J0ZWREZXNjUHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgIH1cblxuICAgICBAaWYocHJvcGVydGllcy5tYXhMaW1pdCl7XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwibWF4TGltaXRUaXRsZVByb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cIm1heExpbWl0RGVzY1Byb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG5cbiAgICAgQGlmKHByb3BlcnRpZXMubWF4QWxsb3dlZEZpbGVIaW50RGVzY1RleHQpe1xuICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cIm1heEFsbG93ZWRGaWxlVGl0bGVUZXh0UHJvcGVydGllc1wiPjwvY2wtbGFiZWw+XG4gICAgICA8Y2wtbGFiZWwgW3Byb3BlcnRpZXNdPVwibWF4QWxsb3dlZEZpbGVEZXNjVGV4dFByb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICB9XG4gIDwvZGl2PlxuICB9XG4gIDwhLS0gRXJyb3IgbWVzc2FnZSAtLT5cbiAgQGlmKGZpbGVSZXN1bHQubGVuZ3RoID4gMCAmJiBmaWxlUmVzdWx0WzBdLmVycm9yTWVzc2FnZSAhPSB1bmRlZmluZWQpe1xuICA8bmctY29udGFpbmVyPlxuICAgIDxjbC1sYWJlbCBbcHJvcGVydGllc109XCJlcnJvclRleHRQcm9wZXJ0aWVzXCI+PC9jbC1sYWJlbD5cbiAgPC9uZy1jb250YWluZXI+XG4gIH1cbiAgPCEtLSBFcnJvciBtZXNzYWdlIC0tPlxuPC9kaXY+XG59XG5AaWYocHJvcGVydGllcy5wcmVMb2FkSW1hZ2VQcm9wZXJ0aWVzICE9IHVuZGVmaW5lZCB8fCAoc2VsZWN0ZWRGaWxlcyAmJiBzZWxlY3RlZEZpbGVzLmxlbmd0aCA+IDApICYmIChwcm9wZXJ0aWVzLmZpbGVHcmlkVmlldz09dHJ1ZSkpe1xuPGRpdlxuICBjbGFzcz1cIm10LThcIj5cbiAgPGRpdiBjbGFzcz1cImdyaWQgdy1mdWxsIGl0ZW1zLWNlbnRlciBzbTpncmlkLWNvbHMtMSB4bDpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMiBtZDpncmlkLWNvbHMtMiB7e2ZpbGVEaXNwbGF5R3JpZFByb3BlcnRpZXM/LnN0eWxlUHJvcGVydGllcz8uZ2FwIHx8ICdnYXAtNCd9fVwiPlxuICAgIEBmb3IgKGZpbGUgb2Ygc2VsZWN0ZWRGaWxlczsgdHJhY2sgZmlsZTsgbGV0IGZpbGVJbmRleCA9ICRpbmRleDspIHtcbiAgICA8ZGl2PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzcz1cIiB7eyAoZmlsZVJlc3VsdFtmaWxlUmVzdWx0Lmxlbmd0aC0xXS5lcnJvck1lc3NhZ2UgIT0gdW5kZWZpbmVkICYmIGZpbGU/LmVycm9yPT0nZHVwbGljYXRlJyApID8gJ2Rhc2hlZC1ib3JkZXItZmFpbGVkIHJvdW5kZWQtbGcgbWFyZ2luLXRvcC1lcnJvcicgOiAnY3VzdG9tLWJhY2tncm91bmQgcm91bmRlZC1sZycgfX1cIj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXJvdyBnYXAtNCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8IS0tIDxkaXY+IC0tPlxuICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtcm93IGdhcC0xIGp1c3RpZnktY2VudGVyIG1vdXNlLXBvaW50ZXJcIiAoY2xpY2spPVwib25GaWxlQ2xpY2tlZChmaWxlLm5hbWUpXCI+XG4gICAgICAgICAgICA8bmctY29udGFpbmVyPlxuICAgICAgICAgICAgICA8Y2wtaWNvbiBbcHJvcGVydGllc109XCJnZXRGaWxlSWNvblByb3BlcnRpZXMoZmlsZSlcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiIG1sLTEgdy0xNCBoLTE0IGZsZXggbWluLXctMTQgbWluLWgtMTQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJvcmRlci1yLW5ldXRyYWwtNDAwXCI+PC9jbC1pY29uPlxuICAgICAgICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbCBnYXAtMSB3LWZpdCBtdC0yXCI+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQtcHJpbWFyeSBmb250LW5vcm1hbCB0ZXh0LVsxNnB4XVwiPnt7IGZpbGUubmFtZSB9fTwvbGFiZWw+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQteHMgdGV4dC1uZXV0cmFsXCI+U2l6ZToge3sgZGlzcGxheVNpemUoZmlsZS5zaXplKSB9fTwvbGFiZWw+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8IS0tIDwvZGl2PiAtLT5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGJ1dHRvbiBtYXQtcmFpc2VkLWJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgKGNsaWNrKT1cImZpbGVVcGxvYWQudmFsdWUgPSAnJzsgb25EZWxldGVFYWNoRmlsZShmaWxlSW5kZXgpXCJcbiAgICAgICAgICAgICAgY2xhc3M9XCJyb3VuZGVkLXhsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICA8Y2wtaWNvbiBbcHJvcGVydGllc109XCJkZWxldGVJY29uUHJvcGVydGllc1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCIgbWwtMiB3LTE0IGgtMTQgZmxleCBtaW4tdy0xNCBtaW4taC0xNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYm9yZGVyLXItbmV1dHJhbC00MDBcIj48L2NsLWljb24+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDwhLS0gRXJyb3IgbWVzc2FnZSAtLT5cbiAgICAgIEBpZigoZmlsZVJlc3VsdC5sZW5ndGggPiAwICYmIGZpbGVSZXN1bHRbZmlsZVJlc3VsdC5sZW5ndGgtMV0gIT0gdW5kZWZpbmVkKSAmJiBmaWxlPy5lcnJvcj09J2R1cGxpY2F0ZScpe1xuICAgICAgPG5nLWNvbnRhaW5lcj5cbiAgICAgICAgPGNsLWxhYmVsIFtwcm9wZXJ0aWVzXT1cImR1cGxpY2F0ZUVycm9yVGV4dFByb3BlcnRpZXNcIj48L2NsLWxhYmVsPlxuICAgICAgPC9uZy1jb250YWluZXI+XG4gICAgICB9XG4gICAgICA8IS0tIEVycm9yIG1lc3NhZ2UgLS0+XG4gICAgPC9kaXY+XG4gICAgfVxuICA8L2Rpdj5cbjwvZGl2PlxufVxuXG48aW5wdXQgI2ZpbGVVcGxvYWQgdHlwZT1cImZpbGVcIiBpZD1cImZpbGUtdXBsb2FkXCIgW2FjY2VwdF09XCJhY2NlcHRcIiBbbXVsdGlwbGVdPVwicHJvcGVydGllcy5pc011bHRpcGxlXCIgKGNoYW5nZSk9XCJvbkZpbGVVcGxvYWQoJGV2ZW50KVwiIGNsYXNzPVwiaGlkZGVuIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuIl19