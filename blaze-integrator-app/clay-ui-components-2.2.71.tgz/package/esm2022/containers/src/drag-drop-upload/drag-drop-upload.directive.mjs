import { Directive, EventEmitter, HostBinding, HostListener, Output } from "@angular/core";
import * as i0 from "@angular/core";
export class ClDragDropDirective {
    constructor() {
        this.selectedFiles = new EventEmitter();
        this._background = '';
    }
    onDragOver(event) {
        event.preventDefault();
        event.stopPropagation();
        this._background = "#E7E9EA";
    }
    onDragLeave(event) {
        event.preventDefault();
        event.stopPropagation();
        this._background = "";
    }
    onDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        const files = event.dataTransfer?.files;
        this.selectedFiles.emit(files);
        this._background = "";
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: ClDragDropDirective, isStandalone: true, selector: "[clDragDropUpload]", outputs: { selectedFiles: "selectedFiles" }, host: { listeners: { "dragover": "onDragOver($event)", "dragleave": "onDragLeave($event)", "drop": "onDrop($event)" }, properties: { "style.background": "this._background" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDragDropDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: '[clDragDropUpload]',
                }]
        }], propDecorators: { selectedFiles: [{
                type: Output
            }], _background: [{
                type: HostBinding,
                args: ["style.background"]
            }], onDragOver: [{
                type: HostListener,
                args: ["dragover", ["$event"]]
            }], onDragLeave: [{
                type: HostListener,
                args: ["dragleave", ["$event"]]
            }], onDrop: [{
                type: HostListener,
                args: ["drop", ["$event"]]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJhZy1kcm9wLXVwbG9hZC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvZHJhZy1kcm9wLXVwbG9hZC9kcmFnLWRyb3AtdXBsb2FkLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFPM0YsTUFBTSxPQUFPLG1CQUFtQjtJQUxoQztRQU9TLGtCQUFhLEdBQTBCLElBQUksWUFBWSxFQUFFLENBQUM7UUFHekQsZ0JBQVcsR0FBRyxFQUFFLENBQUM7S0E0QjFCO0lBekJRLFVBQVUsQ0FBQyxLQUFnQjtRQUNoQyxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDdkIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxXQUFXLEdBQUcsU0FBUyxDQUFDO0lBQy9CLENBQUM7SUFHTSxXQUFXLENBQUMsS0FBZ0I7UUFDakMsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3ZCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUV4QixJQUFJLENBQUMsV0FBVyxHQUFHLEVBQUUsQ0FBQztJQUN4QixDQUFDO0lBR00sTUFBTSxDQUFDLEtBQWdCO1FBQzVCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFeEIsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7UUFFeEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7SUFDeEIsQ0FBQzs4R0FoQ1UsbUJBQW1CO2tHQUFuQixtQkFBbUI7OzJGQUFuQixtQkFBbUI7a0JBTC9CLFNBQVM7bUJBQUM7b0JBQ1QsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFFBQVEsRUFBRSxvQkFBb0I7aUJBQy9COzhCQUlRLGFBQWE7c0JBRG5CLE1BQU07Z0JBSUMsV0FBVztzQkFEbEIsV0FBVzt1QkFBQyxrQkFBa0I7Z0JBSXhCLFVBQVU7c0JBRGhCLFlBQVk7dUJBQUMsVUFBVSxFQUFFLENBQUMsUUFBUSxDQUFDO2dCQVM3QixXQUFXO3NCQURqQixZQUFZO3VCQUFDLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQztnQkFTOUIsTUFBTTtzQkFEWixZQUFZO3VCQUFDLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSwgRXZlbnRFbWl0dGVyLCBIb3N0QmluZGluZywgSG9zdExpc3RlbmVyLCBPdXRwdXQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuXG5ARGlyZWN0aXZlKHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdbY2xEcmFnRHJvcFVwbG9hZF0nLFxufSlcblxuZXhwb3J0IGNsYXNzIENsRHJhZ0Ryb3BEaXJlY3RpdmUge1xuICBAT3V0cHV0KClcbiAgcHVibGljIHNlbGVjdGVkRmlsZXM6IEV2ZW50RW1pdHRlcjx1bmtub3duPiA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBASG9zdEJpbmRpbmcoXCJzdHlsZS5iYWNrZ3JvdW5kXCIpXG4gIHByaXZhdGUgX2JhY2tncm91bmQgPSAnJztcblxuICBASG9zdExpc3RlbmVyKFwiZHJhZ292ZXJcIiwgW1wiJGV2ZW50XCJdKVxuICBwdWJsaWMgb25EcmFnT3ZlcihldmVudDogRHJhZ0V2ZW50KSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcblxuICAgIHRoaXMuX2JhY2tncm91bmQgPSBcIiNFN0U5RUFcIjtcbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoXCJkcmFnbGVhdmVcIiwgW1wiJGV2ZW50XCJdKVxuICBwdWJsaWMgb25EcmFnTGVhdmUoZXZlbnQ6IERyYWdFdmVudCkge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICB0aGlzLl9iYWNrZ3JvdW5kID0gXCJcIjtcbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoXCJkcm9wXCIsIFtcIiRldmVudFwiXSlcbiAgcHVibGljIG9uRHJvcChldmVudDogRHJhZ0V2ZW50KSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcblxuICAgIGNvbnN0IGZpbGVzID0gZXZlbnQuZGF0YVRyYW5zZmVyPy5maWxlcztcblxuICAgIHRoaXMuc2VsZWN0ZWRGaWxlcy5lbWl0KGZpbGVzKTtcbiAgICB0aGlzLl9iYWNrZ3JvdW5kID0gXCJcIjtcbiAgfVxufVxuIl19