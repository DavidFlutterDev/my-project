import { NgStyle, NgTemplateOutlet } from '@angular/common';
import { Input, Component, ViewEncapsulation, inject } from '@angular/core';
import { ClButtonComponent } from '@clay/ui-components/basic';
import { ClDynamicComponent } from '../../dynamic';
import { DynamicTreeViewService } from '../dynamic-tree-view.service';
import * as i0 from "@angular/core";
export class ClDynamicTreeViewChildComponent {
    constructor() {
        this.dynamicTreeService = inject(DynamicTreeViewService);
        this.dynamicTreeOptions = {};
        this.parentNodeIds = [];
    }
    /**
     * this function will calculate the width for tree nodes
     *
     * @param depth - depth of the tree node
     *
     * @returns - style with width properties calculated
     */
    getTreeNodeWidth(depth) {
        return { 'width': `calc(100% - ${4}px)` };
        // return { 'width': `calc(100% - ${ 4 + depth }px)` };
    }
    ngOnInit() {
        this.parentNodeIds = this.dynamicTreeService.getAllParentIds(this.node.id);
        this.setDynamicTreeOptions();
    }
    setDynamicTreeOptions() {
        this.dynamicTreeOptions = {
            "dynamicTreeId": this.dynamicTreeId,
            "parentNodeIds": this.parentNodeIds,
            "nodeId": this.node.id,
            "dynamicTree": true,
            "deletedNodeIds": this.dynamicTreeService.deletedNodeIds
        };
    }
    ngAfterViewInit() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = () => {
                this.addChildNode();
            };
        }
    }
    ngOnChanges() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = this.addChildNode.bind(this);
        }
    }
    ngDoCheck() {
        if (this.node.childAddButtonProperties?.onSubmit != undefined) {
            this.addChildFunction = this.node.childAddButtonProperties.onSubmit;
            this.node.childAddButtonProperties.onSubmit = this.addChildNode.bind(this);
        }
    }
    addChildNode() {
        // if(this.addChildFunction) {
        //   this.addChildFunction({ index: this.index , node: this.node});
        // }
        this.dynamicTreeService.addChildNode.next({ index: this.index, node: this.node });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewChildComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDynamicTreeViewChildComponent, isStandalone: true, selector: "cl-dynamic-tree-view-child", inputs: { index: "index", node: "node", childAddButtonProperties: "childAddButtonProperties", dynamicTreeId: "dynamicTreeId" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"flex w-full flex-col\">\n  <cl-dynamic-renderer class=\"w-full\" [properties]=\"node.properties\" [isDynamicTree]=\"true\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"true\"></cl-dynamic-renderer>\n\n  <!-- Render child nodes recursively -->\n  @if (node.nodes?.length) {\n    @for (childNode of node.nodes; track node; let index = $index) {\n      <div class=\"flex connector\" [ngStyle]=\"{'--connector-height': index == node.nodes!.length - 1 ? '0px' : '100%'}\">\n        <div class=\"z-10 size-2 mt-[17px] rotate-45 bg-primary text-primary\"></div>\n\n        <cl-dynamic-tree-view-child [node]=\"childNode\" [index]=\"index\" class=\"flex -m-1\"\n          [ngStyle]=\"getTreeNodeWidth(childNode.depth!)\" [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"dynamicTreeId\">\n        </cl-dynamic-tree-view-child>\n      </div>\n    }\n  }\n\n  @if (node.showAddChildrenButton) {\n    <cl-button class=\"mt-4 ml-8 mb-4\" [properties]=\"node.childAddButtonProperties!\"></cl-button>\n  }\n</div>\n", dependencies: [{ kind: "component", type: ClDynamicTreeViewChildComponent, selector: "cl-dynamic-tree-view-child", inputs: ["index", "node", "childAddButtonProperties", "dynamicTreeId"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClDynamicComponent, selector: "cl-dynamic-renderer", inputs: ["properties", "ngForm", "isDynamicTree", "dynamicTreeOptions", "dynamicTreeValidation"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewChildComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, encapsulation: ViewEncapsulation.None, selector: 'cl-dynamic-tree-view-child', imports: [
                        NgStyle,
                        NgTemplateOutlet,
                        ClButtonComponent,
                        ClDynamicComponent
                    ], template: "<div class=\"flex w-full flex-col\">\n  <cl-dynamic-renderer class=\"w-full\" [properties]=\"node.properties\" [isDynamicTree]=\"true\" [dynamicTreeOptions]=\"dynamicTreeOptions\" [dynamicTreeValidation]=\"true\"></cl-dynamic-renderer>\n\n  <!-- Render child nodes recursively -->\n  @if (node.nodes?.length) {\n    @for (childNode of node.nodes; track node; let index = $index) {\n      <div class=\"flex connector\" [ngStyle]=\"{'--connector-height': index == node.nodes!.length - 1 ? '0px' : '100%'}\">\n        <div class=\"z-10 size-2 mt-[17px] rotate-45 bg-primary text-primary\"></div>\n\n        <cl-dynamic-tree-view-child [node]=\"childNode\" [index]=\"index\" class=\"flex -m-1\"\n          [ngStyle]=\"getTreeNodeWidth(childNode.depth!)\" [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"dynamicTreeId\">\n        </cl-dynamic-tree-view-child>\n      </div>\n    }\n  }\n\n  @if (node.showAddChildrenButton) {\n    <cl-button class=\"mt-4 ml-8 mb-4\" [properties]=\"node.childAddButtonProperties!\"></cl-button>\n  }\n</div>\n" }]
        }], propDecorators: { index: [{
                type: Input,
                args: [{ required: true }]
            }], node: [{
                type: Input,
                args: [{ required: true }]
            }], childAddButtonProperties: [{
                type: Input
            }], dynamicTreeId: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy10cmVlLXZpZXctY2hpbGQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL2R5bmFtaWMtdHJlZS12aWV3L2R5bmFtaWMtdHJlZS12aWV3LWNoaWxkL2R5bmFtaWMtdHJlZS12aWV3LWNoaWxkLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9keW5hbWljLXRyZWUtdmlldy9keW5hbWljLXRyZWUtdmlldy1jaGlsZC9keW5hbWljLXRyZWUtdmlldy1jaGlsZC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQVksT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDdEUsT0FBTyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFhLE1BQU0sZUFBZSxDQUFDO0FBR3ZGLE9BQU8sRUFBRSxpQkFBaUIsRUFBc0IsTUFBTSwyQkFBMkIsQ0FBQztBQUNsRixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbkQsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sOEJBQThCLENBQUM7O0FBZ0J0RSxNQUFNLE9BQU8sK0JBQStCO0lBZDVDO1FBMkJVLHVCQUFrQixHQUFRLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBRTFELHVCQUFrQixHQUFRLEVBQUUsQ0FBQztRQUk1QixrQkFBYSxHQUFHLEVBQUUsQ0FBQztLQTZENUI7SUEzREM7Ozs7OztPQU1HO0lBQ08sZ0JBQWdCLENBQUMsS0FBYTtRQUN0QyxPQUFPLEVBQUUsT0FBTyxFQUFFLGVBQWdCLENBQUUsS0FBSyxFQUFFLENBQUM7UUFDNUMsdURBQXVEO0lBQ3pELENBQUM7SUFFRCxRQUFRO1FBQ04sSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDM0UsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7SUFDL0IsQ0FBQztJQUdELHFCQUFxQjtRQUNuQixJQUFJLENBQUMsa0JBQWtCLEdBQUc7WUFDeEIsZUFBZSxFQUFFLElBQUksQ0FBQyxhQUFhO1lBQ25DLGVBQWUsRUFBRSxJQUFJLENBQUMsYUFBYTtZQUNuQyxRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ3RCLGFBQWEsRUFBRSxJQUFJO1lBQ25CLGdCQUFnQixFQUFFLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxjQUFjO1NBQ3pELENBQUE7SUFDSCxDQUFDO0lBRUQsZUFBZTtRQUNiLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxDQUFDO1lBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxHQUFHLEdBQUcsRUFBRTtnQkFDbEQsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQTtRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsV0FBVztRQUNULElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxDQUFDO1lBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlFLENBQUM7SUFDSCxDQUFDO0lBRUQsU0FBUztRQUNQLElBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxDQUFDO1lBQ3JFLElBQUksQ0FBQyxJQUFJLENBQUMsd0JBQXlCLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlFLENBQUM7SUFDSCxDQUFDO0lBRU0sWUFBWTtRQUNqQiw4QkFBOEI7UUFDOUIsbUVBQW1FO1FBQ25FLElBQUk7UUFFSixJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxFQUFHLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsQ0FBQztJQUNwRixDQUFDOzhHQTlFVSwrQkFBK0I7a0dBQS9CLCtCQUErQiwyT0N0QjVDLDhpQ0FvQkEsNENERWEsK0JBQStCLCtJQVJ4QyxPQUFPLDJFQUlQLGlCQUFpQixzSUFDakIsa0JBQWtCOzsyRkFHVCwrQkFBK0I7a0JBZDNDLFNBQVM7aUNBQ0ksSUFBSSxpQkFDRCxpQkFBaUIsQ0FBQyxJQUFJLFlBQzNCLDRCQUE0QixXQUU3Qjt3QkFDUCxPQUFPO3dCQUVQLGdCQUFnQjt3QkFFaEIsaUJBQWlCO3dCQUNqQixrQkFBa0I7cUJBQ25COzhCQUlNLEtBQUs7c0JBRFgsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBSWxCLElBQUk7c0JBRFYsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBSWxCLHdCQUF3QjtzQkFEOUIsS0FBSztnQkFJQyxhQUFhO3NCQURuQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSnNvblBpcGUsIE5nU3R5bGUsIE5nVGVtcGxhdGVPdXRsZXQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgSW5wdXQsIENvbXBvbmVudCwgVmlld0VuY2Fwc3VsYXRpb24sIGluamVjdCwgT25DaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsRHluYW1pY1RyZWVWaWV3Tm9kZSB9IGZyb20gJy4uL2R5bmFtaWMtdHJlZS12aWV3LnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xCdXR0b25Db21wb25lbnQsIENsQnV0dG9uUHJvcGVydGllcyB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMnO1xuaW1wb3J0IHsgQ2xEeW5hbWljQ29tcG9uZW50IH0gZnJvbSAnLi4vLi4vZHluYW1pYyc7XG5pbXBvcnQgeyBEeW5hbWljVHJlZVZpZXdTZXJ2aWNlIH0gZnJvbSAnLi4vZHluYW1pYy10cmVlLXZpZXcuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lLFxuICBzZWxlY3RvcjogJ2NsLWR5bmFtaWMtdHJlZS12aWV3LWNoaWxkJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2R5bmFtaWMtdHJlZS12aWV3LWNoaWxkLmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE5nU3R5bGUsXG5cbiAgICBOZ1RlbXBsYXRlT3V0bGV0LFxuXG4gICAgQ2xCdXR0b25Db21wb25lbnQsXG4gICAgQ2xEeW5hbWljQ29tcG9uZW50XG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIENsRHluYW1pY1RyZWVWaWV3Q2hpbGRDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgaW5kZXghOiBudW1iZXI7XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG5vZGUhOiBDbER5bmFtaWNUcmVlVmlld05vZGU7XG5cbiAgQElucHV0KClcbiAgcHVibGljIGNoaWxkQWRkQnV0dG9uUHJvcGVydGllcz86IENsQnV0dG9uUHJvcGVydGllcztcblxuICBASW5wdXQoKVxuICBwdWJsaWMgZHluYW1pY1RyZWVJZCE6IHN0cmluZztcblxuICBwcml2YXRlIGR5bmFtaWNUcmVlU2VydmljZSA6YW55ID0gaW5qZWN0KER5bmFtaWNUcmVlVmlld1NlcnZpY2UpO1xuXG4gIHB1YmxpYyBkeW5hbWljVHJlZU9wdGlvbnM6IGFueSA9IHt9O1xuXG4gIHByaXZhdGUgYWRkQ2hpbGRGdW5jdGlvbjogYW55O1xuXG4gIHByaXZhdGUgcGFyZW50Tm9kZUlkcyA9IFtdO1xuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgY2FsY3VsYXRlIHRoZSB3aWR0aCBmb3IgdHJlZSBub2Rlc1xuICAgKlxuICAgKiBAcGFyYW0gZGVwdGggLSBkZXB0aCBvZiB0aGUgdHJlZSBub2RlXG4gICAqXG4gICAqIEByZXR1cm5zIC0gc3R5bGUgd2l0aCB3aWR0aCBwcm9wZXJ0aWVzIGNhbGN1bGF0ZWRcbiAgICovXG4gIHByb3RlY3RlZCBnZXRUcmVlTm9kZVdpZHRoKGRlcHRoOiBudW1iZXIpIHtcbiAgICByZXR1cm4geyAnd2lkdGgnOiBgY2FsYygxMDAlIC0gJHsgNCB9cHgpYCB9O1xuICAgIC8vIHJldHVybiB7ICd3aWR0aCc6IGBjYWxjKDEwMCUgLSAkeyA0ICsgZGVwdGggfXB4KWAgfTtcbiAgfVxuXG4gIG5nT25Jbml0KCkge1xuICAgIHRoaXMucGFyZW50Tm9kZUlkcyA9IHRoaXMuZHluYW1pY1RyZWVTZXJ2aWNlLmdldEFsbFBhcmVudElkcyh0aGlzLm5vZGUuaWQpO1xuICAgIHRoaXMuc2V0RHluYW1pY1RyZWVPcHRpb25zKCk7XG4gIH1cblxuXG4gIHNldER5bmFtaWNUcmVlT3B0aW9ucygpIHtcbiAgICB0aGlzLmR5bmFtaWNUcmVlT3B0aW9ucyA9IHtcbiAgICAgIFwiZHluYW1pY1RyZWVJZFwiOiB0aGlzLmR5bmFtaWNUcmVlSWQsXG4gICAgICBcInBhcmVudE5vZGVJZHNcIjogdGhpcy5wYXJlbnROb2RlSWRzLFxuICAgICAgXCJub2RlSWRcIjogdGhpcy5ub2RlLmlkLFxuICAgICAgXCJkeW5hbWljVHJlZVwiOiB0cnVlLFxuICAgICAgXCJkZWxldGVkTm9kZUlkc1wiOiB0aGlzLmR5bmFtaWNUcmVlU2VydmljZS5kZWxldGVkTm9kZUlkc1xuICAgIH1cbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBpZih0aGlzLm5vZGUuY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzPy5vblN1Ym1pdCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuYWRkQ2hpbGRGdW5jdGlvbiA9IHRoaXMubm9kZS5jaGlsZEFkZEJ1dHRvblByb3BlcnRpZXMhLm9uU3VibWl0O1xuICAgICAgdGhpcy5ub2RlLmNoaWxkQWRkQnV0dG9uUHJvcGVydGllcyEub25TdWJtaXQgPSAoKSA9PiAge1xuICAgICAgICB0aGlzLmFkZENoaWxkTm9kZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG5nT25DaGFuZ2VzKCkge1xuICAgIGlmKHRoaXMubm9kZS5jaGlsZEFkZEJ1dHRvblByb3BlcnRpZXM/Lm9uU3VibWl0ICE9IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5hZGRDaGlsZEZ1bmN0aW9uID0gdGhpcy5ub2RlLmNoaWxkQWRkQnV0dG9uUHJvcGVydGllcyEub25TdWJtaXQ7XG4gICAgICB0aGlzLm5vZGUuY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzIS5vblN1Ym1pdCA9IHRoaXMuYWRkQ2hpbGROb2RlLmJpbmQodGhpcyk7XG4gICAgfVxuICB9XG5cbiAgbmdEb0NoZWNrKCkge1xuICAgIGlmKHRoaXMubm9kZS5jaGlsZEFkZEJ1dHRvblByb3BlcnRpZXM/Lm9uU3VibWl0ICE9IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5hZGRDaGlsZEZ1bmN0aW9uID0gdGhpcy5ub2RlLmNoaWxkQWRkQnV0dG9uUHJvcGVydGllcyEub25TdWJtaXQ7XG4gICAgICB0aGlzLm5vZGUuY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzIS5vblN1Ym1pdCA9IHRoaXMuYWRkQ2hpbGROb2RlLmJpbmQodGhpcyk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGFkZENoaWxkTm9kZSgpIHtcbiAgICAvLyBpZih0aGlzLmFkZENoaWxkRnVuY3Rpb24pIHtcbiAgICAvLyAgIHRoaXMuYWRkQ2hpbGRGdW5jdGlvbih7IGluZGV4OiB0aGlzLmluZGV4ICwgbm9kZTogdGhpcy5ub2RlfSk7XG4gICAgLy8gfVxuXG4gICAgdGhpcy5keW5hbWljVHJlZVNlcnZpY2UuYWRkQ2hpbGROb2RlLm5leHQoeyBpbmRleDogdGhpcy5pbmRleCAsIG5vZGU6IHRoaXMubm9kZX0pO1xuICB9XG5cbn1cbiIsIjxkaXYgY2xhc3M9XCJmbGV4IHctZnVsbCBmbGV4LWNvbFwiPlxuICA8Y2wtZHluYW1pYy1yZW5kZXJlciBjbGFzcz1cInctZnVsbFwiIFtwcm9wZXJ0aWVzXT1cIm5vZGUucHJvcGVydGllc1wiIFtpc0R5bmFtaWNUcmVlXT1cInRydWVcIiBbZHluYW1pY1RyZWVPcHRpb25zXT1cImR5bmFtaWNUcmVlT3B0aW9uc1wiIFtkeW5hbWljVHJlZVZhbGlkYXRpb25dPVwidHJ1ZVwiPjwvY2wtZHluYW1pYy1yZW5kZXJlcj5cblxuICA8IS0tIFJlbmRlciBjaGlsZCBub2RlcyByZWN1cnNpdmVseSAtLT5cbiAgQGlmIChub2RlLm5vZGVzPy5sZW5ndGgpIHtcbiAgICBAZm9yIChjaGlsZE5vZGUgb2Ygbm9kZS5ub2RlczsgdHJhY2sgbm9kZTsgbGV0IGluZGV4ID0gJGluZGV4KSB7XG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBjb25uZWN0b3JcIiBbbmdTdHlsZV09XCJ7Jy0tY29ubmVjdG9yLWhlaWdodCc6IGluZGV4ID09IG5vZGUubm9kZXMhLmxlbmd0aCAtIDEgPyAnMHB4JyA6ICcxMDAlJ31cIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cInotMTAgc2l6ZS0yIG10LVsxN3B4XSByb3RhdGUtNDUgYmctcHJpbWFyeSB0ZXh0LXByaW1hcnlcIj48L2Rpdj5cblxuICAgICAgICA8Y2wtZHluYW1pYy10cmVlLXZpZXctY2hpbGQgW25vZGVdPVwiY2hpbGROb2RlXCIgW2luZGV4XT1cImluZGV4XCIgY2xhc3M9XCJmbGV4IC1tLTFcIlxuICAgICAgICAgIFtuZ1N0eWxlXT1cImdldFRyZWVOb2RlV2lkdGgoY2hpbGROb2RlLmRlcHRoISlcIiBbY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzXT1cIm5vZGUuY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzXCIgW2R5bmFtaWNUcmVlSWRdPVwiZHluYW1pY1RyZWVJZFwiPlxuICAgICAgICA8L2NsLWR5bmFtaWMtdHJlZS12aWV3LWNoaWxkPlxuICAgICAgPC9kaXY+XG4gICAgfVxuICB9XG5cbiAgQGlmIChub2RlLnNob3dBZGRDaGlsZHJlbkJ1dHRvbikge1xuICAgIDxjbC1idXR0b24gY2xhc3M9XCJtdC00IG1sLTggbWItNFwiIFtwcm9wZXJ0aWVzXT1cIm5vZGUuY2hpbGRBZGRCdXR0b25Qcm9wZXJ0aWVzIVwiPjwvY2wtYnV0dG9uPlxuICB9XG48L2Rpdj5cbiJdfQ==