import { Subject } from 'rxjs';
import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class DynamicTreeViewService {
    constructor() {
        this.addChildNode = new Subject();
        this.deletedNodeIds = [];
    }
    getAllParentIds(nodeId) {
        let parentIds = [];
        if (this.properties.nodes.length) {
            parentIds = this.getParentIds(this.properties.nodes, nodeId);
        }
        return parentIds;
    }
    getParentIds(tree, targetId, path = []) {
        for (const node of tree) {
            // Check if the current node is the target
            if (node.id === targetId) {
                return path; // Return the path of parent IDs
            }
            // If the current node has children, recursively search them
            if (node.nodes) {
                const result = this.getParentIds(node.nodes, targetId, [...path, node.id]);
                if (result.length > 0) {
                    return result; // If the target is found in a subtree, return the result
                }
            }
        }
        return []; // Return an empty array if the target is not found
    }
    // deleteNodeFormGroup(id: string, parentNodeIds: string[]) {
    //   // delete the formGroup which has the id as a control
    //   let formArr = this.ngForm.form.get('nodes').controls;
    //   // let parentNodeIds = this.getAllParentIds(id);
    //  if(parentNodeIds.length) {
    //   let parentFormArr = formArr;
    //   let obj: any;
    //   parentNodeIds.forEach((parentId:string) => {
    //     obj = this.findFormGroup(parentFormArr, parentId);
    //     parentFormArr =  obj?.formGroup.get('nodes').controls;
    //   });
    //   let nodeObj = this.findFormGroup(parentFormArr, id);
    //   parentFormArr.splice(nodeObj?.index, 1);
    //  } else {
    //   //find the formGroup and delete it from the formArray
    //   let obj = this.findFormGroup(formArr, id);
    //   formArr.splice(obj!.index, 1);
    //  }
    //  this.ngForm.form.updateValueAndValidity();
    //  console.log(61, this.ngForm.form);
    // }
    // findFormGroup(formArr: any[], id :string) {
    //   if(formArr.length) {
    //     for(let i=0; i < formArr.length; i++) {
    //       let fmGroup = formArr[i];
    //       if(fmGroup.controls.hasOwnProperty(id)) {
    //         return { index: i, formGroup: fmGroup};
    //       }
    //     }
    //   }
    //   return null;
    // }
    deleteNodeFormGroup(id, parentNodeIds) {
        const formArr = this.ngForm.form.get('nodes');
        // const parentNodeIds = this.getAllParentIds(id);
        if (parentNodeIds.length) {
            let parentFormArr = formArr;
            let obj;
            parentNodeIds.forEach((parentId) => {
                obj = this.findFormGroup(parentFormArr.controls, parentId);
                parentFormArr = obj?.formGroup.get('nodes');
            });
            const nodeObj = this.findFormGroup(parentFormArr.controls, id);
            if (nodeObj) {
                // parentFormArr.removeAt(nodeObj.index);
                parentFormArr.controls.splice(nodeObj.index, 1);
            }
        }
        else {
            // Find the formGroup and delete it from the formArray
            const obj = this.findFormGroup(formArr.controls, id);
            if (obj) {
                formArr.removeAt(obj.index);
            }
        }
        this.ngForm.form.updateValueAndValidity();
    }
    findFormGroup(formArr, id) {
        for (let i = 0; i < formArr.length; i++) {
            const fmGroup = formArr[i];
            if (fmGroup.get(id.toString())) {
                return { index: i, formGroup: fmGroup };
            }
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicTreeViewService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy10cmVlLXZpZXcuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9keW5hbWljLXRyZWUtdmlldy9keW5hbWljLXRyZWUtdmlldy5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDL0IsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFLM0MsTUFBTSxPQUFPLHNCQUFzQjtJQVFqQztRQU5PLGlCQUFZLEdBQWlCLElBQUksT0FBTyxFQUFPLENBQUM7UUFHaEQsbUJBQWMsR0FBYSxFQUFFLENBQUM7SUFHcEIsQ0FBQztJQUVYLGVBQWUsQ0FBQyxNQUFXO1FBQ2hDLElBQUksU0FBUyxHQUFhLEVBQUUsQ0FBQztRQUU3QixJQUFJLElBQUksQ0FBQyxVQUFXLENBQUMsS0FBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ25DLFNBQVMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFXLENBQUMsS0FBTSxFQUFFLE1BQU0sQ0FBQyxDQUFBO1FBQ2hFLENBQUM7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNuQixDQUFDO0lBRUQsWUFBWSxDQUFDLElBQVcsRUFBRSxRQUFnQixFQUFFLE9BQWlCLEVBQUU7UUFDN0QsS0FBSyxNQUFNLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUN4QiwwQ0FBMEM7WUFDMUMsSUFBSSxJQUFJLENBQUMsRUFBRSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUN6QixPQUFPLElBQUksQ0FBQyxDQUFDLGdDQUFnQztZQUMvQyxDQUFDO1lBRUQsNERBQTREO1lBQzVELElBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNmLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsQ0FBQyxHQUFHLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFM0UsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO29CQUN0QixPQUFPLE1BQU0sQ0FBQyxDQUFDLHlEQUF5RDtnQkFDMUUsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTyxFQUFFLENBQUMsQ0FBQyxtREFBbUQ7SUFDaEUsQ0FBQztJQUVELDZEQUE2RDtJQUM3RCwwREFBMEQ7SUFDMUQsMERBQTBEO0lBQzFELHFEQUFxRDtJQUNyRCw4QkFBOEI7SUFDOUIsaUNBQWlDO0lBQ2pDLGtCQUFrQjtJQUNsQixpREFBaUQ7SUFDakQseURBQXlEO0lBQ3pELDZEQUE2RDtJQUM3RCxRQUFRO0lBQ1IseURBQXlEO0lBQ3pELDZDQUE2QztJQUM3QyxZQUFZO0lBQ1osMERBQTBEO0lBQzFELCtDQUErQztJQUMvQyxtQ0FBbUM7SUFDbkMsS0FBSztJQUNMLDhDQUE4QztJQUM5QyxzQ0FBc0M7SUFDdEMsSUFBSTtJQUVKLDhDQUE4QztJQUM5Qyx5QkFBeUI7SUFDekIsOENBQThDO0lBQzlDLGtDQUFrQztJQUNsQyxrREFBa0Q7SUFDbEQsa0RBQWtEO0lBQ2xELFVBQVU7SUFDVixRQUFRO0lBQ1IsTUFBTTtJQUNOLGlCQUFpQjtJQUNqQixJQUFJO0lBRUosbUJBQW1CLENBQUMsRUFBVSxFQUFFLGFBQXVCO1FBQ3JELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQWMsQ0FBQztRQUMzRCxrREFBa0Q7UUFFbEQsSUFBSSxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDekIsSUFBSSxhQUFhLEdBQUcsT0FBTyxDQUFDO1lBQzVCLElBQUksR0FBUSxDQUFDO1lBRWIsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQWdCLEVBQUUsRUFBRTtnQkFDekMsR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQXVCLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQzFFLGFBQWEsR0FBRyxHQUFHLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQWMsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztZQUVILE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFFBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFFOUUsSUFBSSxPQUFPLEVBQUUsQ0FBQztnQkFDWix5Q0FBeUM7Z0JBQ3pDLGFBQWEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDbEQsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sc0RBQXNEO1lBQ3RELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLFFBQXVCLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFFcEUsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDUixPQUFPLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUM5QixDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7SUFDNUMsQ0FBQztJQUVELGFBQWEsQ0FBQyxPQUFvQixFQUFFLEVBQVU7UUFDNUMsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUN4QyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFM0IsSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQy9CLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsQ0FBQztZQUMxQyxDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQzs4R0FuSFUsc0JBQXNCO2tIQUF0QixzQkFBc0IsY0FEVCxNQUFNOzsyRkFDbkIsc0JBQXNCO2tCQURsQyxVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN1YmplY3QgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZvcm1BcnJheSwgRm9ybUdyb3VwIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ2xEeW5hbWljVHJlZVZpZXdQcm9wZXJ0aWVzIH0gZnJvbSAnLi9keW5hbWljLXRyZWUtdmlldy5wcm9wZXJ0aWVzJztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBEeW5hbWljVHJlZVZpZXdTZXJ2aWNlIHtcblxuICBwdWJsaWMgYWRkQ2hpbGROb2RlOiBTdWJqZWN0PGFueT4gPSBuZXcgU3ViamVjdDxhbnk+KCk7XG4gIHB1YmxpYyBuZ0Zvcm06IGFueTtcblxuICBwdWJsaWMgZGVsZXRlZE5vZGVJZHM6IHN0cmluZ1tdID0gW107XG5cbiAgcHVibGljIHByb3BlcnRpZXMhOiBDbER5bmFtaWNUcmVlVmlld1Byb3BlcnRpZXM7XG4gIGNvbnN0cnVjdG9yICgpIHsgfVxuXG4gIHB1YmxpYyBnZXRBbGxQYXJlbnRJZHMobm9kZUlkOiBhbnkpIHtcbiAgICBsZXQgcGFyZW50SWRzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcyEubm9kZXMhLmxlbmd0aCkge1xuICAgICAgcGFyZW50SWRzID0gdGhpcy5nZXRQYXJlbnRJZHModGhpcy5wcm9wZXJ0aWVzIS5ub2RlcyEsIG5vZGVJZClcbiAgICB9XG5cbiAgICByZXR1cm4gcGFyZW50SWRzO1xuICB9XG5cbiAgZ2V0UGFyZW50SWRzKHRyZWU6IGFueVtdLCB0YXJnZXRJZDogc3RyaW5nLCBwYXRoOiBzdHJpbmdbXSA9IFtdKTogc3RyaW5nW10ge1xuICAgIGZvciAoY29uc3Qgbm9kZSBvZiB0cmVlKSB7XG4gICAgICAvLyBDaGVjayBpZiB0aGUgY3VycmVudCBub2RlIGlzIHRoZSB0YXJnZXRcbiAgICAgIGlmIChub2RlLmlkID09PSB0YXJnZXRJZCkge1xuICAgICAgICByZXR1cm4gcGF0aDsgLy8gUmV0dXJuIHRoZSBwYXRoIG9mIHBhcmVudCBJRHNcbiAgICAgIH1cblxuICAgICAgLy8gSWYgdGhlIGN1cnJlbnQgbm9kZSBoYXMgY2hpbGRyZW4sIHJlY3Vyc2l2ZWx5IHNlYXJjaCB0aGVtXG4gICAgICBpZiAobm9kZS5ub2Rlcykge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmdldFBhcmVudElkcyhub2RlLm5vZGVzLCB0YXJnZXRJZCwgWy4uLnBhdGgsIG5vZGUuaWRdKTtcblxuICAgICAgICBpZiAocmVzdWx0Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICByZXR1cm4gcmVzdWx0OyAvLyBJZiB0aGUgdGFyZ2V0IGlzIGZvdW5kIGluIGEgc3VidHJlZSwgcmV0dXJuIHRoZSByZXN1bHRcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBbXTsgLy8gUmV0dXJuIGFuIGVtcHR5IGFycmF5IGlmIHRoZSB0YXJnZXQgaXMgbm90IGZvdW5kXG4gIH1cblxuICAvLyBkZWxldGVOb2RlRm9ybUdyb3VwKGlkOiBzdHJpbmcsIHBhcmVudE5vZGVJZHM6IHN0cmluZ1tdKSB7XG4gIC8vICAgLy8gZGVsZXRlIHRoZSBmb3JtR3JvdXAgd2hpY2ggaGFzIHRoZSBpZCBhcyBhIGNvbnRyb2xcbiAgLy8gICBsZXQgZm9ybUFyciA9IHRoaXMubmdGb3JtLmZvcm0uZ2V0KCdub2RlcycpLmNvbnRyb2xzO1xuICAvLyAgIC8vIGxldCBwYXJlbnROb2RlSWRzID0gdGhpcy5nZXRBbGxQYXJlbnRJZHMoaWQpO1xuICAvLyAgaWYocGFyZW50Tm9kZUlkcy5sZW5ndGgpIHtcbiAgLy8gICBsZXQgcGFyZW50Rm9ybUFyciA9IGZvcm1BcnI7XG4gIC8vICAgbGV0IG9iajogYW55O1xuICAvLyAgIHBhcmVudE5vZGVJZHMuZm9yRWFjaCgocGFyZW50SWQ6c3RyaW5nKSA9PiB7XG4gIC8vICAgICBvYmogPSB0aGlzLmZpbmRGb3JtR3JvdXAocGFyZW50Rm9ybUFyciwgcGFyZW50SWQpO1xuICAvLyAgICAgcGFyZW50Rm9ybUFyciA9ICBvYmo/LmZvcm1Hcm91cC5nZXQoJ25vZGVzJykuY29udHJvbHM7XG4gIC8vICAgfSk7XG4gIC8vICAgbGV0IG5vZGVPYmogPSB0aGlzLmZpbmRGb3JtR3JvdXAocGFyZW50Rm9ybUFyciwgaWQpO1xuICAvLyAgIHBhcmVudEZvcm1BcnIuc3BsaWNlKG5vZGVPYmo/LmluZGV4LCAxKTtcbiAgLy8gIH0gZWxzZSB7XG4gIC8vICAgLy9maW5kIHRoZSBmb3JtR3JvdXAgYW5kIGRlbGV0ZSBpdCBmcm9tIHRoZSBmb3JtQXJyYXlcbiAgLy8gICBsZXQgb2JqID0gdGhpcy5maW5kRm9ybUdyb3VwKGZvcm1BcnIsIGlkKTtcbiAgLy8gICBmb3JtQXJyLnNwbGljZShvYmohLmluZGV4LCAxKTtcbiAgLy8gIH1cbiAgLy8gIHRoaXMubmdGb3JtLmZvcm0udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xuICAvLyAgY29uc29sZS5sb2coNjEsIHRoaXMubmdGb3JtLmZvcm0pO1xuICAvLyB9XG5cbiAgLy8gZmluZEZvcm1Hcm91cChmb3JtQXJyOiBhbnlbXSwgaWQgOnN0cmluZykge1xuICAvLyAgIGlmKGZvcm1BcnIubGVuZ3RoKSB7XG4gIC8vICAgICBmb3IobGV0IGk9MDsgaSA8IGZvcm1BcnIubGVuZ3RoOyBpKyspIHtcbiAgLy8gICAgICAgbGV0IGZtR3JvdXAgPSBmb3JtQXJyW2ldO1xuICAvLyAgICAgICBpZihmbUdyb3VwLmNvbnRyb2xzLmhhc093blByb3BlcnR5KGlkKSkge1xuICAvLyAgICAgICAgIHJldHVybiB7IGluZGV4OiBpLCBmb3JtR3JvdXA6IGZtR3JvdXB9O1xuICAvLyAgICAgICB9XG4gIC8vICAgICB9XG4gIC8vICAgfVxuICAvLyAgIHJldHVybiBudWxsO1xuICAvLyB9XG5cbiAgZGVsZXRlTm9kZUZvcm1Hcm91cChpZDogc3RyaW5nLCBwYXJlbnROb2RlSWRzOiBzdHJpbmdbXSkge1xuICAgIGNvbnN0IGZvcm1BcnIgPSB0aGlzLm5nRm9ybS5mb3JtLmdldCgnbm9kZXMnKSBhcyBGb3JtQXJyYXk7XG4gICAgLy8gY29uc3QgcGFyZW50Tm9kZUlkcyA9IHRoaXMuZ2V0QWxsUGFyZW50SWRzKGlkKTtcblxuICAgIGlmIChwYXJlbnROb2RlSWRzLmxlbmd0aCkge1xuICAgICAgbGV0IHBhcmVudEZvcm1BcnIgPSBmb3JtQXJyO1xuICAgICAgbGV0IG9iajogYW55O1xuXG4gICAgICBwYXJlbnROb2RlSWRzLmZvckVhY2goKHBhcmVudElkOiBzdHJpbmcpID0+IHtcbiAgICAgICAgb2JqID0gdGhpcy5maW5kRm9ybUdyb3VwKHBhcmVudEZvcm1BcnIuY29udHJvbHMgYXMgRm9ybUdyb3VwW10sIHBhcmVudElkKTtcbiAgICAgICAgcGFyZW50Rm9ybUFyciA9IG9iaj8uZm9ybUdyb3VwLmdldCgnbm9kZXMnKSBhcyBGb3JtQXJyYXk7XG4gICAgICB9KTtcblxuICAgICAgY29uc3Qgbm9kZU9iaiA9IHRoaXMuZmluZEZvcm1Hcm91cChwYXJlbnRGb3JtQXJyLmNvbnRyb2xzIGFzIEZvcm1Hcm91cFtdLCBpZCk7XG5cbiAgICAgIGlmIChub2RlT2JqKSB7XG4gICAgICAgIC8vIHBhcmVudEZvcm1BcnIucmVtb3ZlQXQobm9kZU9iai5pbmRleCk7XG4gICAgICAgIHBhcmVudEZvcm1BcnIuY29udHJvbHMuc3BsaWNlKG5vZGVPYmouaW5kZXgsIDEpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBGaW5kIHRoZSBmb3JtR3JvdXAgYW5kIGRlbGV0ZSBpdCBmcm9tIHRoZSBmb3JtQXJyYXlcbiAgICAgIGNvbnN0IG9iaiA9IHRoaXMuZmluZEZvcm1Hcm91cChmb3JtQXJyLmNvbnRyb2xzIGFzIEZvcm1Hcm91cFtdLCBpZCk7XG5cbiAgICAgIGlmIChvYmopIHtcbiAgICAgICAgZm9ybUFyci5yZW1vdmVBdChvYmouaW5kZXgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHRoaXMubmdGb3JtLmZvcm0udXBkYXRlVmFsdWVBbmRWYWxpZGl0eSgpO1xuICB9XG5cbiAgZmluZEZvcm1Hcm91cChmb3JtQXJyOiBGb3JtR3JvdXBbXSwgaWQ6IHN0cmluZykge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm9ybUFyci5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZm1Hcm91cCA9IGZvcm1BcnJbaV07XG5cbiAgICAgIGlmIChmbUdyb3VwLmdldChpZC50b1N0cmluZygpKSkge1xuICAgICAgICByZXR1cm4geyBpbmRleDogaSwgZm9ybUdyb3VwOiBmbUdyb3VwIH07XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxufVxuIl19