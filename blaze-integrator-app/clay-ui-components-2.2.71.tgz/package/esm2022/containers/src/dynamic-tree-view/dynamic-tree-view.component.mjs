import { Input, Component, ViewEncapsulation, inject } from '@angular/core';
import { ClBaseContainerComponent } from '@clay/ui-components/shared';
import { ClDynamicTreeViewProperties } from './dynamic-tree-view.properties';
import { ClButtonBehavior, ClButtonComponent, ClButtonProperties } from '@clay/ui-components/basic';
import { ClDynamicTreeViewChildComponent } from './dynamic-tree-view-child/dynamic-tree-view-child.component';
import { DynamicTreeViewService } from './dynamic-tree-view.service';
import * as i0 from "@angular/core";
export class ClDynamicTreeViewComponent extends ClBaseContainerComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.afterContentCheckedCalled = false;
        this.dynamicTreeService = inject(DynamicTreeViewService);
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        // calling set default properties function
        this.properties ??= new ClDynamicTreeViewProperties();
        this.setButtonProperties();
        super.ngOnInit();
    }
    ngAfterContentChecked() {
        if (this.properties.nodes?.length && !this.afterContentCheckedCalled) {
            this.afterContentCheckedCalled = true;
            this.addDepth(this.properties.nodes);
        }
    }
    ngDoCheck() {
        this.dynamicTreeService.properties = this.properties;
        this.dynamicTreeService.ngForm = this.ngForm;
    }
    /**
     * this function is used to add depth to the tree view for managing the width of the children
     *
     * @param treeNode - array of objects
     *
     * @param depth - depth of the tree node
     */
    addDepth(treeNode, depth = 0) {
        treeNode.forEach((childTreeNode) => {
            childTreeNode.depth = depth;
            if (childTreeNode.nodes && childTreeNode.nodes.length > 0) {
                // calling add depth function
                this.addDepth(childTreeNode.nodes, depth + 1);
            }
        });
    }
    setButtonProperties() {
        if (this.properties.addButtonProperties === undefined) {
            this.properties.addButtonProperties = new ClButtonProperties();
            this.properties.addButtonProperties.label = 'Add New Parent';
            this.properties.addButtonProperties.style.cssClasses = 'p-0 bg-white';
            this.properties.addButtonProperties.icon = 'heroicons_outline:plus-circle';
            this.properties.addButtonProperties.buttonBehavior = ClButtonBehavior.flat;
            this.properties.addButtonProperties.style.iconCssClasses = 'p-0 text-primary';
            this.properties.addButtonProperties.style.labelCssClasses = 'p-0 text-primary';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDynamicTreeViewComponent, isStandalone: true, selector: "cl-dynamic-tree-view", inputs: { properties: "properties", ngForm: "ngForm" }, usesInheritance: true, ngImport: i0, template: "<div class=\"flex w-full flex-col\">\n  @for (node of properties.nodes!; track node; let index = $index) {\n    <cl-dynamic-tree-view-child [node]=\"node\" [index]=\"index\" class=\"flex w-full\"\n      [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"properties.id\">\n    </cl-dynamic-tree-view-child>\n  }\n\n  @if (properties.addButtonProperties) {\n    <cl-button class=\"mt-4\" [properties]=\"properties.addButtonProperties\"></cl-button>\n  }\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:38px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:not(:last-child):after{top:10px;left:-28px;content:\"\";height:var(--connector-height);position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}\n"], dependencies: [{ kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "component", type: ClDynamicTreeViewChildComponent, selector: "cl-dynamic-tree-view-child", inputs: ["index", "node", "childAddButtonProperties", "dynamicTreeId"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDynamicTreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-dynamic-tree-view', encapsulation: ViewEncapsulation.None, imports: [
                        ClButtonComponent,
                        ClDynamicTreeViewChildComponent
                    ], template: "<div class=\"flex w-full flex-col\">\n  @for (node of properties.nodes!; track node; let index = $index) {\n    <cl-dynamic-tree-view-child [node]=\"node\" [index]=\"index\" class=\"flex w-full\"\n      [childAddButtonProperties]=\"node.childAddButtonProperties\" [dynamicTreeId]=\"properties.id\">\n    </cl-dynamic-tree-view-child>\n  }\n\n  @if (properties.addButtonProperties) {\n    <cl-button class=\"mt-4\" [properties]=\"properties.addButtonProperties\"></cl-button>\n  }\n</div>\n", styles: [".connector{position:relative;margin-left:2.5rem}.connector:before{top:-16px;left:-28px;width:32px;content:\"\";height:38px;position:absolute;border-style:solid;color:var(--cl-primary);border-width:0 0 2px 2px;border-color:var(--cl-primary)}.connector:not(:last-child):after{top:10px;left:-28px;content:\"\";height:var(--connector-height);position:absolute;border-style:solid;border-width:0 0 0 2px;border-color:var(--cl-primary)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], ngForm: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy10cmVlLXZpZXcuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbnRhaW5lcnMvc3JjL2R5bmFtaWMtdHJlZS12aWV3L2R5bmFtaWMtdHJlZS12aWV3LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzL3NyYy9keW5hbWljLXRyZWUtdmlldy9keW5hbWljLXRyZWUtdmlldy5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsS0FBSyxFQUFVLFNBQVMsRUFBRSxpQkFBaUIsRUFBdUIsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBR3pHLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ3RFLE9BQU8sRUFBeUIsMkJBQTJCLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUNwRyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsaUJBQWlCLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUNwRyxPQUFPLEVBQUUsK0JBQStCLEVBQUUsTUFBTSw2REFBNkQsQ0FBQztBQUM5RyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSw2QkFBNkIsQ0FBQzs7QUFhckUsTUFBTSxPQUFPLDBCQUEyQixTQUFRLHdCQUF3QjtJQVV0RTtRQUNFOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBUkYsOEJBQXlCLEdBQVksS0FBSyxDQUFDO1FBRTNDLHVCQUFrQixHQUFRLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBTy9ELEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLDBDQUEwQztRQUMxQyxJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksMkJBQTJCLEVBQUUsQ0FBQztRQUV0RCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUUzQixLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELHFCQUFxQjtRQUNuQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxDQUFDO1lBQ3JFLElBQUksQ0FBQyx5QkFBeUIsR0FBRyxJQUFJLENBQUM7WUFFdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRUQsU0FBUztRQUNQLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNyRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDL0MsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNLLFFBQVEsQ0FBQyxRQUFpQyxFQUFFLEtBQUssR0FBRyxDQUFDO1FBQzNELFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxhQUFvQyxFQUFFLEVBQUU7WUFDeEQsYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFFNUIsSUFBSSxhQUFhLENBQUMsS0FBSyxJQUFJLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUMxRCw2QkFBNkI7Z0JBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLG1CQUFtQjtRQUN6QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDdEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLGtCQUFrQixFQUFFLENBQUM7WUFFL0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLEdBQUcsZ0JBQWdCLENBQUM7WUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFNLENBQUMsVUFBVSxHQUFHLGNBQWMsQ0FBQztZQUN2RSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLElBQUksR0FBRywrQkFBK0IsQ0FBQztZQUMzRSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7WUFDM0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFNLENBQUMsY0FBYyxHQUFHLGtCQUFrQixDQUFDO1lBQy9FLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsS0FBTSxDQUFDLGVBQWUsR0FBRyxrQkFBa0IsQ0FBQztRQUNsRixDQUFDO0lBQ0gsQ0FBQzs4R0F2RVUsMEJBQTBCO2tHQUExQiwwQkFBMEIsK0pDcEJ2QywyZUFXQSx5ZURLSSxpQkFBaUIsc0lBQ2pCLCtCQUErQjs7MkZBR3RCLDBCQUEwQjtrQkFYdEMsU0FBUztpQ0FDSSxJQUFJLFlBQ04sc0JBQXNCLGlCQUNqQixpQkFBaUIsQ0FBQyxJQUFJLFdBRzVCO3dCQUNQLGlCQUFpQjt3QkFDakIsK0JBQStCO3FCQUNoQzt3REFJZSxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsTUFBTTtzQkFEWixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5wdXQsIE9uSW5pdCwgQ29tcG9uZW50LCBWaWV3RW5jYXBzdWxhdGlvbiwgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IGNsb25lRGVlcCB9IGZyb20gJ2xvZGFzaCc7XG5pbXBvcnQgeyBDbEJhc2VDb250YWluZXJDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbER5bmFtaWNUcmVlVmlld05vZGUsIENsRHluYW1pY1RyZWVWaWV3UHJvcGVydGllcyB9IGZyb20gJy4vZHluYW1pYy10cmVlLXZpZXcucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbEJ1dHRvbkJlaGF2aW9yLCBDbEJ1dHRvbkNvbXBvbmVudCwgQ2xCdXR0b25Qcm9wZXJ0aWVzIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9iYXNpYyc7XG5pbXBvcnQgeyBDbER5bmFtaWNUcmVlVmlld0NoaWxkQ29tcG9uZW50IH0gZnJvbSAnLi9keW5hbWljLXRyZWUtdmlldy1jaGlsZC9keW5hbWljLXRyZWUtdmlldy1jaGlsZC5jb21wb25lbnQnO1xuaW1wb3J0IHsgRHluYW1pY1RyZWVWaWV3U2VydmljZSB9IGZyb20gJy4vZHluYW1pYy10cmVlLXZpZXcuc2VydmljZSc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWR5bmFtaWMtdHJlZS12aWV3JyxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZSxcbiAgc3R5bGVVcmw6ICcuL2R5bmFtaWMtdHJlZS12aWV3LmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2R5bmFtaWMtdHJlZS12aWV3LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIENsQnV0dG9uQ29tcG9uZW50LFxuICAgIENsRHluYW1pY1RyZWVWaWV3Q2hpbGRDb21wb25lbnRcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xEeW5hbWljVHJlZVZpZXdDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb250YWluZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyQ29udGVudENoZWNrZWQge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsRHluYW1pY1RyZWVWaWV3UHJvcGVydGllcztcblxuICBASW5wdXQoKVxuICBwdWJsaWMgbmdGb3JtOiBhbnk7XG5cbiAgcHJpdmF0ZSBhZnRlckNvbnRlbnRDaGVja2VkQ2FsbGVkOiBib29sZWFuID0gZmFsc2U7XG5cbiAgcHJpdmF0ZSBkeW5hbWljVHJlZVNlcnZpY2UgOmFueSA9IGluamVjdChEeW5hbWljVHJlZVZpZXdTZXJ2aWNlKTtcbiAgY29uc3RydWN0b3IgKCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAvLyBjYWxsaW5nIHNldCBkZWZhdWx0IHByb3BlcnRpZXMgZnVuY3Rpb25cbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbER5bmFtaWNUcmVlVmlld1Byb3BlcnRpZXMoKTtcblxuICAgIHRoaXMuc2V0QnV0dG9uUHJvcGVydGllcygpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm5vZGVzPy5sZW5ndGggJiYgIXRoaXMuYWZ0ZXJDb250ZW50Q2hlY2tlZENhbGxlZCkge1xuICAgICAgdGhpcy5hZnRlckNvbnRlbnRDaGVja2VkQ2FsbGVkID0gdHJ1ZTtcblxuICAgICAgdGhpcy5hZGREZXB0aCh0aGlzLnByb3BlcnRpZXMubm9kZXMpO1xuICAgIH1cbiAgfVxuXG4gIG5nRG9DaGVjaygpIHtcbiAgICB0aGlzLmR5bmFtaWNUcmVlU2VydmljZS5wcm9wZXJ0aWVzID0gdGhpcy5wcm9wZXJ0aWVzO1xuICAgIHRoaXMuZHluYW1pY1RyZWVTZXJ2aWNlLm5nRm9ybSA9IHRoaXMubmdGb3JtO1xuICB9XG5cbiAgLyoqXG4gICAqIHRoaXMgZnVuY3Rpb24gaXMgdXNlZCB0byBhZGQgZGVwdGggdG8gdGhlIHRyZWUgdmlldyBmb3IgbWFuYWdpbmcgdGhlIHdpZHRoIG9mIHRoZSBjaGlsZHJlblxuICAgKlxuICAgKiBAcGFyYW0gdHJlZU5vZGUgLSBhcnJheSBvZiBvYmplY3RzXG4gICAqXG4gICAqIEBwYXJhbSBkZXB0aCAtIGRlcHRoIG9mIHRoZSB0cmVlIG5vZGVcbiAgICovXG4gIHByaXZhdGUgYWRkRGVwdGgodHJlZU5vZGU6IENsRHluYW1pY1RyZWVWaWV3Tm9kZVtdLCBkZXB0aCA9IDApIHtcbiAgICB0cmVlTm9kZS5mb3JFYWNoKChjaGlsZFRyZWVOb2RlOiBDbER5bmFtaWNUcmVlVmlld05vZGUpID0+IHtcbiAgICAgIGNoaWxkVHJlZU5vZGUuZGVwdGggPSBkZXB0aDtcblxuICAgICAgaWYgKGNoaWxkVHJlZU5vZGUubm9kZXMgJiYgY2hpbGRUcmVlTm9kZS5ub2Rlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIC8vIGNhbGxpbmcgYWRkIGRlcHRoIGZ1bmN0aW9uXG4gICAgICAgIHRoaXMuYWRkRGVwdGgoY2hpbGRUcmVlTm9kZS5ub2RlcywgZGVwdGggKyAxKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0QnV0dG9uUHJvcGVydGllcygpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmFkZEJ1dHRvblByb3BlcnRpZXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLmFkZEJ1dHRvblByb3BlcnRpZXMgPSBuZXcgQ2xCdXR0b25Qcm9wZXJ0aWVzKCk7XG5cbiAgICAgIHRoaXMucHJvcGVydGllcy5hZGRCdXR0b25Qcm9wZXJ0aWVzLmxhYmVsID0gJ0FkZCBOZXcgUGFyZW50JztcbiAgICAgIHRoaXMucHJvcGVydGllcy5hZGRCdXR0b25Qcm9wZXJ0aWVzLnN0eWxlIS5jc3NDbGFzc2VzID0gJ3AtMCBiZy13aGl0ZSc7XG4gICAgICB0aGlzLnByb3BlcnRpZXMuYWRkQnV0dG9uUHJvcGVydGllcy5pY29uID0gJ2hlcm9pY29uc19vdXRsaW5lOnBsdXMtY2lyY2xlJztcbiAgICAgIHRoaXMucHJvcGVydGllcy5hZGRCdXR0b25Qcm9wZXJ0aWVzLmJ1dHRvbkJlaGF2aW9yID0gQ2xCdXR0b25CZWhhdmlvci5mbGF0O1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLmFkZEJ1dHRvblByb3BlcnRpZXMuc3R5bGUhLmljb25Dc3NDbGFzc2VzID0gJ3AtMCB0ZXh0LXByaW1hcnknO1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLmFkZEJ1dHRvblByb3BlcnRpZXMuc3R5bGUhLmxhYmVsQ3NzQ2xhc3NlcyA9ICdwLTAgdGV4dC1wcmltYXJ5JztcbiAgICB9XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJmbGV4IHctZnVsbCBmbGV4LWNvbFwiPlxuICBAZm9yIChub2RlIG9mIHByb3BlcnRpZXMubm9kZXMhOyB0cmFjayBub2RlOyBsZXQgaW5kZXggPSAkaW5kZXgpIHtcbiAgICA8Y2wtZHluYW1pYy10cmVlLXZpZXctY2hpbGQgW25vZGVdPVwibm9kZVwiIFtpbmRleF09XCJpbmRleFwiIGNsYXNzPVwiZmxleCB3LWZ1bGxcIlxuICAgICAgW2NoaWxkQWRkQnV0dG9uUHJvcGVydGllc109XCJub2RlLmNoaWxkQWRkQnV0dG9uUHJvcGVydGllc1wiIFtkeW5hbWljVHJlZUlkXT1cInByb3BlcnRpZXMuaWRcIj5cbiAgICA8L2NsLWR5bmFtaWMtdHJlZS12aWV3LWNoaWxkPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmFkZEJ1dHRvblByb3BlcnRpZXMpIHtcbiAgICA8Y2wtYnV0dG9uIGNsYXNzPVwibXQtNFwiIFtwcm9wZXJ0aWVzXT1cInByb3BlcnRpZXMuYWRkQnV0dG9uUHJvcGVydGllc1wiPjwvY2wtYnV0dG9uPlxuICB9XG48L2Rpdj5cbiJdfQ==