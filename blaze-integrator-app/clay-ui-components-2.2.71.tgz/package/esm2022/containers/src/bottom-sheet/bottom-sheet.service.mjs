import { Injectable, inject } from "@angular/core";
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { ClBottomSheetComponent } from "./sheet/bottom-sheet.component";
import * as i0 from "@angular/core";
export class ClBottomSheetService {
    constructor() {
        this._bottomSheet = inject(MatBottomSheet);
    }
    open(config) {
        // Open the dialog
        return this._bottomSheet.open(ClBottomSheetComponent, {
            data: config,
            disableClose: !config.dismissible,
            autoFocus: config.autoFocus ?? false,
            panelClass: config.style?.panelClass,
            hasBackdrop: config.hasBackdrop ?? false,
            backdropClass: config.style?.backdropClass,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBottomSheetService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYm90dG9tLXNoZWV0LnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29udGFpbmVycy9zcmMvYm90dG9tLXNoZWV0L2JvdHRvbS1zaGVldC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ25ELE9BQU8sRUFBRSxjQUFjLEVBQXFCLE1BQU0sZ0NBQWdDLENBQUM7QUFHbkYsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7O0FBR3hFLE1BQU0sT0FBTyxvQkFBb0I7SUFEakM7UUFFVSxpQkFBWSxHQUFtQixNQUFNLENBQUMsY0FBYyxDQUFDLENBQUM7S0FnQi9EO0lBZFEsSUFBSSxDQUFDLE1BQStCO1FBQ3pDLGtCQUFrQjtRQUNsQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUMzQixzQkFBc0IsRUFDdEI7WUFDRSxJQUFJLEVBQUUsTUFBTTtZQUNaLFlBQVksRUFBRSxDQUFDLE1BQU0sQ0FBQyxXQUFXO1lBQ2pDLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxJQUFJLEtBQUs7WUFDcEMsVUFBVSxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsVUFBVTtZQUNwQyxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFBSSxLQUFLO1lBQ3hDLGFBQWEsRUFBRSxNQUFNLENBQUMsS0FBSyxFQUFFLGFBQWE7U0FDM0MsQ0FDRixDQUFDO0lBQ0osQ0FBQzs4R0FoQlUsb0JBQW9CO2tIQUFwQixvQkFBb0IsY0FEUCxNQUFNOzsyRkFDbkIsb0JBQW9CO2tCQURoQyxVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIGluamVjdCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XG5pbXBvcnQgeyBNYXRCb3R0b21TaGVldCwgTWF0Qm90dG9tU2hlZXRSZWYgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9ib3R0b20tc2hlZXQnO1xuXG5pbXBvcnQgeyBDbEJvdHRvbVNoZWV0UHJvcGVydGllcyB9IGZyb20gXCIuL2JvdHRvbS1zaGVldC5wcm9wZXJ0aWVzXCI7XG5pbXBvcnQgeyBDbEJvdHRvbVNoZWV0Q29tcG9uZW50IH0gZnJvbSBcIi4vc2hlZXQvYm90dG9tLXNoZWV0LmNvbXBvbmVudFwiO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIENsQm90dG9tU2hlZXRTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBfYm90dG9tU2hlZXQ6IE1hdEJvdHRvbVNoZWV0ID0gaW5qZWN0KE1hdEJvdHRvbVNoZWV0KTtcblxuICBwdWJsaWMgb3Blbihjb25maWc6IENsQm90dG9tU2hlZXRQcm9wZXJ0aWVzKTogTWF0Qm90dG9tU2hlZXRSZWY8Q2xCb3R0b21TaGVldENvbXBvbmVudD4ge1xuICAgIC8vIE9wZW4gdGhlIGRpYWxvZ1xuICAgIHJldHVybiB0aGlzLl9ib3R0b21TaGVldC5vcGVuKFxuICAgICAgQ2xCb3R0b21TaGVldENvbXBvbmVudCxcbiAgICAgIHtcbiAgICAgICAgZGF0YTogY29uZmlnLFxuICAgICAgICBkaXNhYmxlQ2xvc2U6ICFjb25maWcuZGlzbWlzc2libGUsXG4gICAgICAgIGF1dG9Gb2N1czogY29uZmlnLmF1dG9Gb2N1cyA/PyBmYWxzZSxcbiAgICAgICAgcGFuZWxDbGFzczogY29uZmlnLnN0eWxlPy5wYW5lbENsYXNzLFxuICAgICAgICBoYXNCYWNrZHJvcDogY29uZmlnLmhhc0JhY2tkcm9wID8/IGZhbHNlLFxuICAgICAgICBiYWNrZHJvcENsYXNzOiBjb25maWcuc3R5bGU/LmJhY2tkcm9wQ2xhc3MsXG4gICAgICB9LFxuICAgICk7XG4gIH1cbn1cbiJdfQ==