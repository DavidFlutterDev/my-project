import { Component, EventEmitter, Input, Output, ViewChild, ViewContainerRef, inject } from '@angular/core';
import { ClNgComponentFactory } from '@clay/app-shell/shared';
import * as i0 from "@angular/core";
export class ClComponentInjectorComponent {
    constructor() {
        this.changeEvent = new EventEmitter();
        this._clNgComponentFactory = inject(ClNgComponentFactory);
    }
    ngOnChanges(changes) {
        this.viewContainerRef.remove();
        this.createComponent();
    }
    createComponent() {
        setTimeout(() => {
            this._componentRef = this._clNgComponentFactory.createComponent(this.component, this.viewContainerRef);
            this._setInputParameters();
            this._setOutputParameters();
        }, 0);
    }
    _setInputParameters() {
        if (this.properties?.inputs?.length) {
            for (const input of this.properties.inputs) {
                if (!input.isSignal) {
                    this._componentRef.instance[input.key] = input.value;
                }
                else {
                    this._componentRef.instance[input.key].set(input.value);
                }
            }
        }
    }
    _setOutputParameters() {
        if (this.properties?.outputs?.length) {
            for (const output of this.properties.outputs) {
                this._componentRef.instance[output.functionName] = (...params) => {
                    this.changeEvent.emit(params);
                };
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClComponentInjectorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClComponentInjectorComponent, isStandalone: true, selector: "cl-component-injector", inputs: { component: "component", properties: "properties" }, outputs: { changeEvent: "changeEvent" }, viewQueries: [{ propertyName: "viewContainerRef", first: true, predicate: ["viewContainerRef"], descendants: true, read: ViewContainerRef, static: true }], usesOnChanges: true, ngImport: i0, template: "<ng-container #viewContainerRef></ng-container>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClComponentInjectorComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-component-injector', template: "<ng-container #viewContainerRef></ng-container>\n" }]
        }], propDecorators: { component: [{
                type: Input,
                args: [{ required: true }]
            }], properties: [{
                type: Input
            }], changeEvent: [{
                type: Output
            }], viewContainerRef: [{
                type: ViewChild,
                args: ['viewContainerRef', { read: ViewContainerRef, static: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tcG9uZW50LWluamVjdG9yLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9zaGFyZWQvc3JjL2NvbXBvbmVudC1pbmplY3Rvci9jb21wb25lbnQtaW5qZWN0b3IuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL3NoYXJlZC9zcmMvY29tcG9uZW50LWluamVjdG9yL2NvbXBvbmVudC1pbmplY3Rvci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxLQUFLLEVBQWEsTUFBTSxFQUFpQixTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRXRJLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHdCQUF3QixDQUFDOztBQVE5RCxNQUFNLE9BQU8sNEJBQTRCO0lBTHpDO1FBYVMsZ0JBQVcsR0FBc0IsSUFBSSxZQUFZLEVBQU8sQ0FBQztRQU14RCwwQkFBcUIsR0FBeUIsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7S0F1Q3BGO0lBckNDLFdBQVcsQ0FBQyxPQUFzQjtRQUNoQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLENBQUM7UUFFL0IsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3pCLENBQUM7SUFFTyxlQUFlO1FBQ3JCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUV2RyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUUzQixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDUixDQUFDO0lBRU8sbUJBQW1CO1FBQ3pCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7WUFDcEMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUMzQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUNwQixJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDdkQsQ0FBQztxQkFBTSxDQUFDO29CQUNOLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUMxRCxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU8sb0JBQW9CO1FBQzFCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7WUFDckMsS0FBSyxNQUFNLE1BQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUM3QyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQWEsRUFBTyxFQUFFO29CQUMzRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDaEMsQ0FBQyxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDOzhHQXBEVSw0QkFBNEI7a0dBQTVCLDRCQUE0Qix5UkFVQSxnQkFBZ0IsZ0VDckJ6RCxtREFDQTs7MkZEVWEsNEJBQTRCO2tCQUx4QyxTQUFTO2lDQUNJLElBQUksWUFDTix1QkFBdUI7OEJBSzFCLFNBQVM7c0JBRGYsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBSWxCLFVBQVU7c0JBRGhCLEtBQUs7Z0JBSUMsV0FBVztzQkFEakIsTUFBTTtnQkFJQSxnQkFBZ0I7c0JBRHRCLFNBQVM7dUJBQUMsa0JBQWtCLEVBQUUsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudFR5cGUgfSBmcm9tICdAYW5ndWxhci9jZGsvcG9ydGFsJztcbmltcG9ydCB7IENvbXBvbmVudCwgRXZlbnRFbWl0dGVyLCBJbnB1dCwgT25DaGFuZ2VzLCBPdXRwdXQsIFNpbXBsZUNoYW5nZXMsIFZpZXdDaGlsZCwgVmlld0NvbnRhaW5lclJlZiwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsTmdDb21wb25lbnRGYWN0b3J5IH0gZnJvbSAnQGNsYXkvYXBwLXNoZWxsL3NoYXJlZCc7XG5pbXBvcnQgeyBDbENvbXBvbmVudEluamVjdFByb3BlcnRpZXMgfSBmcm9tICcuL2NvbXBvbmVudC1pbmplY3Rvci5wcm9wZXJ0aWVzJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtY29tcG9uZW50LWluamVjdG9yJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbXBvbmVudC1pbmplY3Rvci5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENsQ29tcG9uZW50SW5qZWN0b3JDb21wb25lbnQgaW1wbGVtZW50cyBPbkNoYW5nZXMge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgY29tcG9uZW50ITogQ29tcG9uZW50VHlwZTxhbnk+O1xuXG4gIEBJbnB1dCgpXG4gIHB1YmxpYyBwcm9wZXJ0aWVzPzogQ2xDb21wb25lbnRJbmplY3RQcm9wZXJ0aWVzO1xuXG4gIEBPdXRwdXQoKVxuICBwdWJsaWMgY2hhbmdlRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+ID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XG5cbiAgQFZpZXdDaGlsZCgndmlld0NvbnRhaW5lclJlZicsIHsgcmVhZDogVmlld0NvbnRhaW5lclJlZiwgc3RhdGljOiB0cnVlIH0pXG4gIHB1YmxpYyB2aWV3Q29udGFpbmVyUmVmITogVmlld0NvbnRhaW5lclJlZjtcblxuICBwcml2YXRlIF9jb21wb25lbnRSZWY6IGFueTtcbiAgcHJpdmF0ZSBfY2xOZ0NvbXBvbmVudEZhY3Rvcnk6IENsTmdDb21wb25lbnRGYWN0b3J5ID0gaW5qZWN0KENsTmdDb21wb25lbnRGYWN0b3J5KTtcblxuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgdGhpcy52aWV3Q29udGFpbmVyUmVmLnJlbW92ZSgpO1xuXG4gICAgdGhpcy5jcmVhdGVDb21wb25lbnQoKTtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlQ29tcG9uZW50KCkge1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5fY29tcG9uZW50UmVmID0gdGhpcy5fY2xOZ0NvbXBvbmVudEZhY3RvcnkuY3JlYXRlQ29tcG9uZW50KHRoaXMuY29tcG9uZW50LCB0aGlzLnZpZXdDb250YWluZXJSZWYpO1xuXG4gICAgICB0aGlzLl9zZXRJbnB1dFBhcmFtZXRlcnMoKTtcblxuICAgICAgdGhpcy5fc2V0T3V0cHV0UGFyYW1ldGVycygpO1xuICAgIH0sIDApO1xuICB9XG5cbiAgcHJpdmF0ZSBfc2V0SW5wdXRQYXJhbWV0ZXJzKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXM/LmlucHV0cz8ubGVuZ3RoKSB7XG4gICAgICBmb3IgKGNvbnN0IGlucHV0IG9mIHRoaXMucHJvcGVydGllcy5pbnB1dHMpIHtcbiAgICAgICAgaWYgKCFpbnB1dC5pc1NpZ25hbCkge1xuICAgICAgICAgIHRoaXMuX2NvbXBvbmVudFJlZi5pbnN0YW5jZVtpbnB1dC5rZXldID0gaW5wdXQudmFsdWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fY29tcG9uZW50UmVmLmluc3RhbmNlW2lucHV0LmtleV0uc2V0KGlucHV0LnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgX3NldE91dHB1dFBhcmFtZXRlcnMoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcz8ub3V0cHV0cz8ubGVuZ3RoKSB7XG4gICAgICBmb3IgKGNvbnN0IG91dHB1dCBvZiB0aGlzLnByb3BlcnRpZXMub3V0cHV0cykge1xuICAgICAgICB0aGlzLl9jb21wb25lbnRSZWYuaW5zdGFuY2Vbb3V0cHV0LmZ1bmN0aW9uTmFtZV0gPSAoLi4ucGFyYW1zOiBhbnlbXSk6IGFueSA9PiB7XG4gICAgICAgICAgdGhpcy5jaGFuZ2VFdmVudC5lbWl0KHBhcmFtcyk7XG4gICAgICAgIH07XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCI8bmctY29udGFpbmVyICN2aWV3Q29udGFpbmVyUmVmPjwvbmctY29udGFpbmVyPlxuIl19