import { Directive, Inject, Optional } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
export class NgModelInjector {
    constructor(ngModel, accessors) {
        if (accessors) {
            for (const accessor of accessors) {
                if (accessor.hasOwnProperty("componentRegistry")) {
                    let clb = accessor;
                    clb.setTemplateControl(ngModel);
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgModelInjector, deps: [{ token: NgModel }, { token: NG_VALUE_ACCESSOR, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: NgModelInjector, isStandalone: true, selector: "[injectModelReference]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: NgModelInjector, decorators: [{
            type: Directive,
            args: [{
                    selector: '[injectModelReference]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.NgModel, decorators: [{
                    type: Inject,
                    args: [NgModel]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmdtb2RlbC1pbmplY3Rvci5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkL3NyYy9jb250cm9sLWluamVjdG9yL25nbW9kZWwtaW5qZWN0b3IuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUU1RCxPQUFPLEVBQXdCLGlCQUFpQixFQUFFLE9BQU8sRUFBRSxNQUFNLGdCQUFnQixDQUFDOzs7QUFNbEYsTUFBTSxPQUFPLGVBQWU7SUFFMUIsWUFDbUIsT0FBZ0IsRUFDTSxTQUFpQztRQUV4RSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsS0FBSyxNQUFNLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDakMsSUFBSyxRQUFnQixDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUM7b0JBQzFELElBQUksR0FBRyxHQUFvQixRQUFrQyxDQUFBO29CQUM3RCxHQUFHLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ2xDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7OEdBZFUsZUFBZSxrQkFHaEIsT0FBTyxhQUNLLGlCQUFpQjtrR0FKNUIsZUFBZTs7MkZBQWYsZUFBZTtrQkFKM0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0JBQXdCO29CQUNsQyxVQUFVLEVBQUUsSUFBSTtpQkFDakI7OzBCQUlJLE1BQU07MkJBQUMsT0FBTzs7MEJBQ2QsUUFBUTs7MEJBQUksTUFBTTsyQkFBQyxpQkFBaUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIEluamVjdCwgT3B0aW9uYWwgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCB9IGZyb20gJy4vLi4vYmFzZS1jb21wb25lbnQvYmFzZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SLCBOZ01vZGVsIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbaW5qZWN0TW9kZWxSZWZlcmVuY2VdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgTmdNb2RlbEluamVjdG9yIHtcblxuICBjb25zdHJ1Y3RvciAoXG4gICAgQEluamVjdChOZ01vZGVsKSBuZ01vZGVsOiBOZ01vZGVsLFxuICAgIEBPcHRpb25hbCgpIEBJbmplY3QoTkdfVkFMVUVfQUNDRVNTT1IpIGFjY2Vzc29yczogQ29udHJvbFZhbHVlQWNjZXNzb3JbXVxuICApIHtcbiAgICBpZiAoYWNjZXNzb3JzKSB7XG4gICAgICBmb3IgKGNvbnN0IGFjY2Vzc29yIG9mIGFjY2Vzc29ycykge1xuICAgICAgICBpZiAoKGFjY2Vzc29yIGFzIGFueSkuaGFzT3duUHJvcGVydHkoXCJjb21wb25lbnRSZWdpc3RyeVwiKSkge1xuICAgICAgICAgIGxldCBjbGI6IENsQmFzZUNvbXBvbmVudCA9IGFjY2Vzc29yIGFzIGFueSBhcyBDbEJhc2VDb21wb25lbnRcbiAgICAgICAgICBjbGIuc2V0VGVtcGxhdGVDb250cm9sKG5nTW9kZWwpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0=