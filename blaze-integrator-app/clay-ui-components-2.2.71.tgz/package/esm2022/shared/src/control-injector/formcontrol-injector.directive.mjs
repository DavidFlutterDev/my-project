import { Directive, Inject, Optional } from '@angular/core';
import { FormControlName, NG_VALUE_ACCESSOR } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
export class FormControlInjector {
    constructor(formControlName, accessors) {
        if (accessors) {
            for (const accessor of accessors) {
                if (accessor.hasOwnProperty("componentRegistry")) {
                    let clb = accessor;
                    clb.setReactiveControl(formControlName);
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormControlInjector, deps: [{ token: FormControlName }, { token: NG_VALUE_ACCESSOR, optional: true }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: FormControlInjector, isStandalone: true, selector: "[formControlName]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormControlInjector, decorators: [{
            type: Directive,
            args: [{
                    selector: '[formControlName]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.FormControlName, decorators: [{
                    type: Inject,
                    args: [FormControlName]
                }] }, { type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [NG_VALUE_ACCESSOR]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybWNvbnRyb2wtaW5qZWN0b3IuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL3NoYXJlZC9zcmMvY29udHJvbC1pbmplY3Rvci9mb3JtY29udHJvbC1pbmplY3Rvci5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTVELE9BQU8sRUFBd0IsZUFBZSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7OztBQU0xRixNQUFNLE9BQU8sbUJBQW1CO0lBRTlCLFlBQzJCLGVBQWdDLEVBQ2xCLFNBQWlDO1FBRXhFLElBQUksU0FBUyxFQUFFLENBQUM7WUFDZCxLQUFLLE1BQU0sUUFBUSxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNqQyxJQUFLLFFBQWdCLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQztvQkFDMUQsSUFBSSxHQUFHLEdBQW9CLFFBQWtDLENBQUE7b0JBQzdELEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDMUMsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQzs4R0FkVSxtQkFBbUIsa0JBR3BCLGVBQWUsYUFDSCxpQkFBaUI7a0dBSjVCLG1CQUFtQjs7MkZBQW5CLG1CQUFtQjtrQkFKL0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsbUJBQW1CO29CQUM3QixVQUFVLEVBQUUsSUFBSTtpQkFDakI7OzBCQUlJLE1BQU07MkJBQUMsZUFBZTs7MEJBQ3RCLFFBQVE7OzBCQUFJLE1BQU07MkJBQUMsaUJBQWlCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBJbmplY3QsIE9wdGlvbmFsIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICcuLi9iYXNlLWNvbXBvbmVudC9iYXNlLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb250cm9sVmFsdWVBY2Nlc3NvciwgRm9ybUNvbnRyb2xOYW1lLCBOR19WQUxVRV9BQ0NFU1NPUiB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW2Zvcm1Db250cm9sTmFtZV0nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtQ29udHJvbEluamVjdG9yIHtcblxuICBjb25zdHJ1Y3RvciAoXG4gICAgQEluamVjdChGb3JtQ29udHJvbE5hbWUpIGZvcm1Db250cm9sTmFtZTogRm9ybUNvbnRyb2xOYW1lLFxuICAgIEBPcHRpb25hbCgpIEBJbmplY3QoTkdfVkFMVUVfQUNDRVNTT1IpIGFjY2Vzc29yczogQ29udHJvbFZhbHVlQWNjZXNzb3JbXVxuICApIHtcbiAgICBpZiAoYWNjZXNzb3JzKSB7XG4gICAgICBmb3IgKGNvbnN0IGFjY2Vzc29yIG9mIGFjY2Vzc29ycykge1xuICAgICAgICBpZiAoKGFjY2Vzc29yIGFzIGFueSkuaGFzT3duUHJvcGVydHkoXCJjb21wb25lbnRSZWdpc3RyeVwiKSkge1xuICAgICAgICAgIGxldCBjbGI6IENsQmFzZUNvbXBvbmVudCA9IGFjY2Vzc29yIGFzIGFueSBhcyBDbEJhc2VDb21wb25lbnRcbiAgICAgICAgICBjbGIuc2V0UmVhY3RpdmVDb250cm9sKGZvcm1Db250cm9sTmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ==