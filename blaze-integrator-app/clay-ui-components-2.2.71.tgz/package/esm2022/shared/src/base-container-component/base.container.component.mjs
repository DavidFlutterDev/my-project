import { Component } from '@angular/core';
import { ClBaseComponent } from '../base-component/base.component';
import * as i0 from "@angular/core";
export class ClBaseContainerComponent extends ClBaseComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBaseContainerComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClBaseContainerComponent, selector: "ng-component", usesInheritance: true, ngImport: i0, template: '', isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBaseContainerComponent, decorators: [{
            type: Component,
            args: [{ template: '' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5jb250YWluZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL3NoYXJlZC9zcmMvYmFzZS1jb250YWluZXItY29tcG9uZW50L2Jhc2UuY29udGFpbmVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFDLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQzs7QUFHbkUsTUFBTSxPQUFnQix3QkFBeUIsU0FBUSxlQUFlOzhHQUFoRCx3QkFBd0I7a0dBQXhCLHdCQUF3QiwyRUFEVCxFQUFFOzsyRkFDakIsd0JBQXdCO2tCQUQ3QyxTQUFTOytCQUEyQixFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICcuLi9iYXNlLWNvbXBvbmVudC9iYXNlLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoeyBzdHlsZXM6IFtgYF0sIHRlbXBsYXRlOiAnJyB9KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIENsQmFzZUNvbnRhaW5lckNvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCB7fVxuIl19