export var ClBaseBehavior;
(function (ClBaseBehavior) {
    ClBaseBehavior["default"] = "default";
})(ClBaseBehavior || (ClBaseBehavior = {}));
export var ClBaseVisual;
(function (ClBaseVisual) {
    ClBaseVisual["default"] = "default";
})(ClBaseVisual || (ClBaseVisual = {}));
export var ClComponentTypes;
(function (ClComponentTypes) {
    ClComponentTypes["chip"] = "chip";
    ClComponentTypes["icon"] = "icon";
    ClComponentTypes["form"] = "form";
    ClComponentTypes["tabs"] = "tabs";
    ClComponentTypes["card"] = "card";
    ClComponentTypes["menu"] = "menu";
    ClComponentTypes["email"] = "email";
    ClComponentTypes["input"] = "input";
    ClComponentTypes["label"] = "label";
    ClComponentTypes["radio"] = "radio";
    ClComponentTypes["timer"] = "timer";
    ClComponentTypes["image"] = "image";
    ClComponentTypes["toast"] = "toast";
    ClComponentTypes["switch"] = "switch";
    ClComponentTypes["select"] = "select";
    ClComponentTypes["button"] = "button";
    ClComponentTypes["wizard"] = "wizard";
    ClComponentTypes["default"] = "default";
    ClComponentTypes["stepper"] = "stepper";
    ClComponentTypes["spinner"] = "spinner";
    ClComponentTypes["codeView"] = "codeView";
    ClComponentTypes["dataGrid"] = "dataGrid";
    ClComponentTypes["textarea"] = "textarea";
    ClComponentTypes["checkbox"] = "checkbox";
    ClComponentTypes["chipList"] = "chipList";
    ClComponentTypes["treeView"] = "treeView";
    ClComponentTypes["carousel"] = "carousel";
    ClComponentTypes["accordion"] = "accordion";
    ClComponentTypes["chipInput"] = "chipInput";
    ClComponentTypes["iconsList"] = "iconsList";
    ClComponentTypes["textBlock"] = "textBlock";
    ClComponentTypes["uploadTile"] = "uploadTile";
    ClComponentTypes["timepicker"] = "timepicker";
    ClComponentTypes["datePicker"] = "datePicker";
    ClComponentTypes["progressBar"] = "progressBar";
    ClComponentTypes["multiselect"] = "multiselect";
    ClComponentTypes["contactInput"] = "contactInput";
    ClComponentTypes["autocomplete"] = "autocomplete";
    ClComponentTypes["toggleButton"] = "toggleButton";
    ClComponentTypes["dualSortList"] = "dualSortList";
    ClComponentTypes["nestedLayout"] = "nestedLayout";
    ClComponentTypes["resizableGrid"] = "resizableGrid";
    ClComponentTypes["hyperLinkText"] = "hyperLinkText";
    ClComponentTypes["dragDropUpload"] = "dragDropUpload";
    ClComponentTypes["selectWithGroup"] = "selectWithGroup";
    ClComponentTypes["dynamicTreeView"] = "dynamicTreeView";
    ClComponentTypes["multiLevelSelect"] = "multiLevelSelect";
    ClComponentTypes["timelineActivity"] = "timelineActivity";
    ClComponentTypes["multiAutocomplete"] = "multiAutocomplete";
    ClComponentTypes["nestedAutoComplete"] = "nestedAutoComplete";
    ClComponentTypes["nestedSelect"] = "nestedSelect";
    ClComponentTypes["filePreview"] = "filePreview";
})(ClComponentTypes || (ClComponentTypes = {}));
export class ClBaseComponentProperties {
    constructor() {
        this.id = 'Default00';
        this.type = ClComponentTypes.default;
    }
}
export var ClValidationTypes;
(function (ClValidationTypes) {
    ClValidationTypes["required"] = "required";
    ClValidationTypes["min"] = "min";
    ClValidationTypes["max"] = "max";
    ClValidationTypes["minLength"] = "minlength";
    ClValidationTypes["maxLength"] = "maxlength";
    ClValidationTypes["custom"] = "custom";
})(ClValidationTypes || (ClValidationTypes = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5wcm9wZXJ0aWVzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL3NoYXJlZC9zcmMvYmFzZS1jb21wb25lbnQvYmFzZS5wcm9wZXJ0aWVzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXFCQSxNQUFNLENBQU4sSUFBWSxjQUVYO0FBRkQsV0FBWSxjQUFjO0lBQ3hCLHFDQUFtQixDQUFBO0FBQ3JCLENBQUMsRUFGVyxjQUFjLEtBQWQsY0FBYyxRQUV6QjtBQUVELE1BQU0sQ0FBTixJQUFZLFlBRVg7QUFGRCxXQUFZLFlBQVk7SUFDdEIsbUNBQW1CLENBQUE7QUFDckIsQ0FBQyxFQUZXLFlBQVksS0FBWixZQUFZLFFBRXZCO0FBU0QsTUFBTSxDQUFOLElBQVksZ0JBcURYO0FBckRELFdBQVksZ0JBQWdCO0lBQzFCLGlDQUFhLENBQUE7SUFDYixpQ0FBYSxDQUFBO0lBQ2IsaUNBQWEsQ0FBQTtJQUNiLGlDQUFhLENBQUE7SUFDYixpQ0FBYSxDQUFBO0lBQ2IsaUNBQWEsQ0FBQTtJQUNiLG1DQUFlLENBQUE7SUFDZixtQ0FBZSxDQUFBO0lBQ2YsbUNBQWUsQ0FBQTtJQUNmLG1DQUFlLENBQUE7SUFDZixtQ0FBZSxDQUFBO0lBQ2YsbUNBQWUsQ0FBQTtJQUNmLG1DQUFlLENBQUE7SUFDZixxQ0FBaUIsQ0FBQTtJQUNqQixxQ0FBaUIsQ0FBQTtJQUNqQixxQ0FBaUIsQ0FBQTtJQUNqQixxQ0FBaUIsQ0FBQTtJQUNqQix1Q0FBbUIsQ0FBQTtJQUNuQix1Q0FBbUIsQ0FBQTtJQUNuQix1Q0FBbUIsQ0FBQTtJQUNuQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQix5Q0FBcUIsQ0FBQTtJQUNyQiwyQ0FBdUIsQ0FBQTtJQUN2QiwyQ0FBdUIsQ0FBQTtJQUN2QiwyQ0FBdUIsQ0FBQTtJQUN2QiwyQ0FBdUIsQ0FBQTtJQUN2Qiw2Q0FBeUIsQ0FBQTtJQUN6Qiw2Q0FBeUIsQ0FBQTtJQUN6Qiw2Q0FBeUIsQ0FBQTtJQUN6QiwrQ0FBMkIsQ0FBQTtJQUMzQiwrQ0FBMkIsQ0FBQTtJQUMzQixpREFBNkIsQ0FBQTtJQUM3QixpREFBNkIsQ0FBQTtJQUM3QixpREFBNkIsQ0FBQTtJQUM3QixpREFBNkIsQ0FBQTtJQUM3QixpREFBNkIsQ0FBQTtJQUM3QixtREFBK0IsQ0FBQTtJQUMvQixtREFBK0IsQ0FBQTtJQUMvQixxREFBaUMsQ0FBQTtJQUNqQyx1REFBbUMsQ0FBQTtJQUNuQyx1REFBbUMsQ0FBQTtJQUNuQyx5REFBcUMsQ0FBQTtJQUNyQyx5REFBcUMsQ0FBQTtJQUNyQywyREFBdUMsQ0FBQTtJQUN2Qyw2REFBeUMsQ0FBQTtJQUN6QyxpREFBNkIsQ0FBQTtJQUM3QiwrQ0FBMkIsQ0FBQTtBQUM3QixDQUFDLEVBckRXLGdCQUFnQixLQUFoQixnQkFBZ0IsUUFxRDNCO0FBRUQsTUFBTSxPQUFPLHlCQUF5QjtJQUF0QztRQUNFLE9BQUUsR0FBVyxXQUFXLENBQUM7UUFNekIsU0FBSSxHQUFxQixnQkFBZ0IsQ0FBQyxPQUFPLENBQUM7SUFDcEQsQ0FBQztDQUFBO0FBUUQsTUFBTSxDQUFOLElBQVksaUJBT1g7QUFQRCxXQUFZLGlCQUFpQjtJQUMzQiwwQ0FBcUIsQ0FBQTtJQUNyQixnQ0FBVyxDQUFBO0lBQ1gsZ0NBQVcsQ0FBQTtJQUNYLDRDQUF1QixDQUFBO0lBQ3ZCLDRDQUF1QixDQUFBO0lBQ3ZCLHNDQUFpQixDQUFBO0FBQ25CLENBQUMsRUFQVyxpQkFBaUIsS0FBakIsaUJBQWlCLFFBTzVCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVmFsaWRhdG9ycyB9IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIENsT3B0aW9ucyB7XG4gIHRleHQ6IHN0cmluZztcbiAgdmFsdWU6IHN0cmluZztcbiAgaGlkZGVuPzogYm9vbGVhbjtcbiAgc2VsZWN0ZWQ/OiBib29sZWFuO1xuICBwYXJlbnRWYWx1ZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJQ2xCYXNlQ29tcG9uZW50UHJvcGVydGllcyB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU/OiBzdHJpbmc7XG4gIGxhYmVsPzogc3RyaW5nO1xuICB0eXBlOiBDbENvbXBvbmVudFR5cGVzXG4gIHZpc3VhbFR5cGU/OiBDbEJhc2VWaXN1YWw7XG4gIGJlaGF2aW9yVHlwZT86IENsQmFzZUJlaGF2aW9yO1xuICBzdHlsZT86IElDbEJhc2VTdHlsZVByb3BlcnRpZXM7XG5cbn1cblxuZXhwb3J0IGVudW0gQ2xCYXNlQmVoYXZpb3Ige1xuICBkZWZhdWx0ID0gJ2RlZmF1bHQnXG59XG5cbmV4cG9ydCBlbnVtIENsQmFzZVZpc3VhbCB7XG4gIGRlZmF1bHQgPSAnZGVmYXVsdCdcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJQ2xCYXNlU3R5bGVQcm9wZXJ0aWVzIHtcbiAgY3NzQ2xhc3Nlcz86IHN0cmluZztcbiAgY29udGVudFdpZHRoPzogc3RyaW5nO1xuICBhbGlnbkNvbnRlbnQ/OiBzdHJpbmc7XG4gIGp1c3RpZnlDb250ZW50Pzogc3RyaW5nO1xufVxuXG5leHBvcnQgZW51bSBDbENvbXBvbmVudFR5cGVzIHtcbiAgY2hpcCA9ICdjaGlwJyxcbiAgaWNvbiA9ICdpY29uJyxcbiAgZm9ybSA9ICdmb3JtJyxcbiAgdGFicyA9ICd0YWJzJyxcbiAgY2FyZCA9ICdjYXJkJyxcbiAgbWVudSA9IFwibWVudVwiLFxuICBlbWFpbCA9ICdlbWFpbCcsXG4gIGlucHV0ID0gJ2lucHV0JyxcbiAgbGFiZWwgPSAnbGFiZWwnLFxuICByYWRpbyA9IFwicmFkaW9cIixcbiAgdGltZXIgPSBcInRpbWVyXCIsXG4gIGltYWdlID0gXCJpbWFnZVwiLFxuICB0b2FzdCA9IFwidG9hc3RcIixcbiAgc3dpdGNoID0gXCJzd2l0Y2hcIixcbiAgc2VsZWN0ID0gJ3NlbGVjdCcsXG4gIGJ1dHRvbiA9IFwiYnV0dG9uXCIsXG4gIHdpemFyZCA9ICd3aXphcmQnLFxuICBkZWZhdWx0ID0gJ2RlZmF1bHQnLFxuICBzdGVwcGVyID0gJ3N0ZXBwZXInLFxuICBzcGlubmVyID0gXCJzcGlubmVyXCIsXG4gIGNvZGVWaWV3ID0gXCJjb2RlVmlld1wiLFxuICBkYXRhR3JpZCA9ICdkYXRhR3JpZCcsXG4gIHRleHRhcmVhID0gJ3RleHRhcmVhJyxcbiAgY2hlY2tib3ggPSBcImNoZWNrYm94XCIsXG4gIGNoaXBMaXN0ID0gXCJjaGlwTGlzdFwiLFxuICB0cmVlVmlldyA9ICd0cmVlVmlldycsXG4gIGNhcm91c2VsID0gXCJjYXJvdXNlbFwiLFxuICBhY2NvcmRpb24gPSAnYWNjb3JkaW9uJyxcbiAgY2hpcElucHV0ID0gXCJjaGlwSW5wdXRcIixcbiAgaWNvbnNMaXN0ID0gXCJpY29uc0xpc3RcIixcbiAgdGV4dEJsb2NrID0gJ3RleHRCbG9jaycsXG4gIHVwbG9hZFRpbGUgPSAndXBsb2FkVGlsZScsXG4gIHRpbWVwaWNrZXIgPSBcInRpbWVwaWNrZXJcIixcbiAgZGF0ZVBpY2tlciA9ICdkYXRlUGlja2VyJyxcbiAgcHJvZ3Jlc3NCYXIgPSBcInByb2dyZXNzQmFyXCIsXG4gIG11bHRpc2VsZWN0ID0gJ211bHRpc2VsZWN0JyxcbiAgY29udGFjdElucHV0ID0gXCJjb250YWN0SW5wdXRcIixcbiAgYXV0b2NvbXBsZXRlID0gJ2F1dG9jb21wbGV0ZScsXG4gIHRvZ2dsZUJ1dHRvbiA9ICd0b2dnbGVCdXR0b24nLFxuICBkdWFsU29ydExpc3QgPSBcImR1YWxTb3J0TGlzdFwiLFxuICBuZXN0ZWRMYXlvdXQgPSBcIm5lc3RlZExheW91dFwiLFxuICByZXNpemFibGVHcmlkID0gXCJyZXNpemFibGVHcmlkXCIsXG4gIGh5cGVyTGlua1RleHQgPSAnaHlwZXJMaW5rVGV4dCcsXG4gIGRyYWdEcm9wVXBsb2FkID0gXCJkcmFnRHJvcFVwbG9hZFwiLFxuICBzZWxlY3RXaXRoR3JvdXAgPSBcInNlbGVjdFdpdGhHcm91cFwiLFxuICBkeW5hbWljVHJlZVZpZXcgPSBcImR5bmFtaWNUcmVlVmlld1wiLFxuICBtdWx0aUxldmVsU2VsZWN0ID0gXCJtdWx0aUxldmVsU2VsZWN0XCIsXG4gIHRpbWVsaW5lQWN0aXZpdHkgPSBcInRpbWVsaW5lQWN0aXZpdHlcIixcbiAgbXVsdGlBdXRvY29tcGxldGUgPSAnbXVsdGlBdXRvY29tcGxldGUnLFxuICBuZXN0ZWRBdXRvQ29tcGxldGUgPSBcIm5lc3RlZEF1dG9Db21wbGV0ZVwiLFxuICBuZXN0ZWRTZWxlY3QgPSBcIm5lc3RlZFNlbGVjdFwiLFxuICBmaWxlUHJldmlldyA9IFwiZmlsZVByZXZpZXdcIixcbn1cblxuZXhwb3J0IGNsYXNzIENsQmFzZUNvbXBvbmVudFByb3BlcnRpZXMgaW1wbGVtZW50cyBJQ2xCYXNlQ29tcG9uZW50UHJvcGVydGllcyB7XG4gIGlkOiBzdHJpbmcgPSAnRGVmYXVsdDAwJztcbiAgbmFtZT86IHN0cmluZztcbiAgbGFiZWw/OiBzdHJpbmc7XG4gIHZpc3VhbFR5cGU/OiBDbEJhc2VWaXN1YWw7XG4gIGJlaGF2aW9yVHlwZT86IENsQmFzZUJlaGF2aW9yO1xuICBzdHlsZT86IElDbEJhc2VTdHlsZVByb3BlcnRpZXM7XG4gIHR5cGU6IENsQ29tcG9uZW50VHlwZXMgPSBDbENvbXBvbmVudFR5cGVzLmRlZmF1bHQ7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2xDb3VudHJ5IHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBjb2RlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBlbnVtIENsVmFsaWRhdGlvblR5cGVzIHtcbiAgcmVxdWlyZWQgPSAncmVxdWlyZWQnLFxuICBtaW4gPSAnbWluJyxcbiAgbWF4ID0gJ21heCcsXG4gIG1pbkxlbmd0aCA9ICdtaW5sZW5ndGgnLFxuICBtYXhMZW5ndGggPSAnbWF4bGVuZ3RoJyxcbiAgY3VzdG9tID0gJ2N1c3RvbSdcbn1cblxuLy8gZXhwb3J0IGludGVyZmFjZSBDbEVycm9ySGFuZGxlciB7XG4vLyAgIGtleTogQ2xWYWxpZGF0aW9uVHlwZXM7XG4vLyAgIG1lc3NhZ2U6IHN0cmluZztcbi8vIH1cblxuLy8gZXhwb3J0IGludGVyZmFjZSBDbEVycm9ySGFuZGxlciB7XG4vLyAgIGtleTogQ2xWYWxpZGF0aW9uVHlwZXM7XG4vLyAgIG1lc3NhZ2U6IHN0cmluZztcbi8vIH1cbmV4cG9ydCB0eXBlIENsRXJyb3JIYW5kbGVyID0ge1xuICBba2V5IGluIENsVmFsaWRhdGlvblR5cGVzXTogc3RyaW5nO1xufTtcblxuXG5cbiJdfQ==