export var ClInputPattern;
(function (ClInputPattern) {
    ClInputPattern["numeric"] = "[0-9]+$";
    ClInputPattern["alphabetic"] = "[A-Za-z]+$";
    ClInputPattern["decimalNumber"] = "^[0-9.]+$";
    ClInputPattern["alphaNumeric"] = "^[a-zA-Z0-9]+$";
    ClInputPattern["mobileNoIndia"] = "[6-9]{1}[0-9]{9}";
    ClInputPattern["alphabeticWithSpace"] = "[A-Za-z ]+$";
    ClInputPattern["cardNumberWithSpace"] = "^\\d{4} \\d{4} \\d{4}$";
    ClInputPattern["cardNumberWithCustom"] = "(d{4})(?=d)-$";
    ClInputPattern["alphaNumericWithSpace"] = "^[a-zA-Z0-9 ]+$";
    ClInputPattern["ifsCodeIndia"] = "[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}";
    ClInputPattern["panIndia"] = "([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$";
    ClInputPattern["email"] = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[.][a-zA-Z]{2,}$";
    ClInputPattern["gstIndia"] = "[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}[0-9A-Z]{2}";
})(ClInputPattern || (ClInputPattern = {}));
export var ClInputPatternType;
(function (ClInputPatternType) {
    ClInputPatternType["numeric"] = "numeric";
    ClInputPatternType["alphabetic"] = "alphabetic";
    ClInputPatternType["decimalNumber"] = "decimalNumber";
    ClInputPatternType["alphaNumeric"] = "alphaNumeric";
    ClInputPatternType["mobileNoIndia"] = "mobileNoIndia";
    ClInputPatternType["alphabeticWithSpace"] = "alphabeticWithSpace";
    ClInputPatternType["cardNumberWithSpace"] = "cardNumberWithSpace";
    ClInputPatternType["cardNumberWithCustom"] = "cardNumberWithCustom";
    ClInputPatternType["alphaNumericWithSpace"] = "alphaNumericWithSpace";
    ClInputPatternType["ifsCodeIndia"] = "ifsCodeIndia";
    ClInputPatternType["panIndia"] = "panIndia";
    ClInputPatternType["email"] = "email";
    ClInputPatternType["gstIndia"] = "gstIndia";
    ClInputPatternType["custom"] = "custom";
})(ClInputPatternType || (ClInputPatternType = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQtcGF0dGVybnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkL3NyYy9iYXNlLWNvbXBvbmVudC9pbnB1dC1wYXR0ZXJucy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQU4sSUFBWSxjQWNYO0FBZEQsV0FBWSxjQUFjO0lBQ3hCLHFDQUFtQixDQUFBO0lBQ25CLDJDQUF5QixDQUFBO0lBQ3pCLDZDQUEyQixDQUFBO0lBQzNCLGlEQUErQixDQUFBO0lBQy9CLG9EQUFrQyxDQUFBO0lBQ2xDLHFEQUFtQyxDQUFBO0lBQ25DLGdFQUE4QyxDQUFBO0lBQzlDLHdEQUF3QyxDQUFBO0lBQ3hDLDJEQUF5QyxDQUFBO0lBQ3pDLGdFQUE4QyxDQUFBO0lBQzlDLHFFQUFtRCxDQUFBO0lBQ25ELDZFQUEyRCxDQUFBO0lBQzNELHFGQUFtRSxDQUFBO0FBQ3JFLENBQUMsRUFkVyxjQUFjLEtBQWQsY0FBYyxRQWN6QjtBQUVELE1BQU0sQ0FBTixJQUFZLGtCQWVYO0FBZkQsV0FBWSxrQkFBa0I7SUFDNUIseUNBQW1CLENBQUE7SUFDbkIsK0NBQXlCLENBQUE7SUFDekIscURBQStCLENBQUE7SUFDL0IsbURBQTZCLENBQUE7SUFDN0IscURBQStCLENBQUE7SUFDL0IsaUVBQTJDLENBQUE7SUFDM0MsaUVBQTJDLENBQUE7SUFDM0MsbUVBQTZDLENBQUE7SUFDN0MscUVBQStDLENBQUE7SUFDL0MsbURBQTZCLENBQUE7SUFDN0IsMkNBQXFCLENBQUE7SUFDckIscUNBQWUsQ0FBQTtJQUNmLDJDQUFxQixDQUFBO0lBQ3JCLHVDQUFpQixDQUFBO0FBQ25CLENBQUMsRUFmVyxrQkFBa0IsS0FBbEIsa0JBQWtCLFFBZTdCIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGVudW0gQ2xJbnB1dFBhdHRlcm4ge1xuICBudW1lcmljID0gXCJbMC05XSskXCIsXG4gIGFscGhhYmV0aWMgPSBcIltBLVphLXpdKyRcIixcbiAgZGVjaW1hbE51bWJlciA9IFwiXlswLTkuXSskXCIsXG4gIGFscGhhTnVtZXJpYyA9IFwiXlthLXpBLVowLTldKyRcIixcbiAgbW9iaWxlTm9JbmRpYSA9IFwiWzYtOV17MX1bMC05XXs5fVwiLFxuICBhbHBoYWJldGljV2l0aFNwYWNlID0gXCJbQS1aYS16IF0rJFwiLFxuICBjYXJkTnVtYmVyV2l0aFNwYWNlID0gXCJeXFxcXGR7NH0gXFxcXGR7NH0gXFxcXGR7NH0kXCIsXG4gIGNhcmROdW1iZXJXaXRoQ3VzdG9tID0gXCIoXFxkezR9KSg/PVxcZCktJFwiLFxuICBhbHBoYU51bWVyaWNXaXRoU3BhY2UgPSBcIl5bYS16QS1aMC05IF0rJFwiLFxuICBpZnNDb2RlSW5kaWEgPSBcIltBLVp8YS16XXs0fVswXVthLXpBLVowLTldezZ9XCIsXG4gIHBhbkluZGlhID0gXCIoW2EtekEtWl0pezV9KFswLTldKXs0fShbYS16QS1aXSl7MX0/JFwiLFxuICBlbWFpbCA9IFwiXlthLXpBLVowLTkuXyUrLV0rQFthLXpBLVowLTkuLV0rWy5dW2EtekEtWl17Mix9JFwiLFxuICBnc3RJbmRpYSA9IFwiWzAtOV17Mn1bQS1aXXs1fVswLTldezR9W0EtWl17MX1bMS05QS1aXXsxfVswLTlBLVpdezJ9XCJcbn1cblxuZXhwb3J0IGVudW0gQ2xJbnB1dFBhdHRlcm5UeXBlIHtcbiAgbnVtZXJpYyA9IFwibnVtZXJpY1wiLFxuICBhbHBoYWJldGljID0gXCJhbHBoYWJldGljXCIsXG4gIGRlY2ltYWxOdW1iZXIgPSBcImRlY2ltYWxOdW1iZXJcIixcbiAgYWxwaGFOdW1lcmljID0gXCJhbHBoYU51bWVyaWNcIixcbiAgbW9iaWxlTm9JbmRpYSA9IFwibW9iaWxlTm9JbmRpYVwiLFxuICBhbHBoYWJldGljV2l0aFNwYWNlID0gXCJhbHBoYWJldGljV2l0aFNwYWNlXCIsXG4gIGNhcmROdW1iZXJXaXRoU3BhY2UgPSBcImNhcmROdW1iZXJXaXRoU3BhY2VcIixcbiAgY2FyZE51bWJlcldpdGhDdXN0b20gPSBcImNhcmROdW1iZXJXaXRoQ3VzdG9tXCIsXG4gIGFscGhhTnVtZXJpY1dpdGhTcGFjZSA9IFwiYWxwaGFOdW1lcmljV2l0aFNwYWNlXCIsXG4gIGlmc0NvZGVJbmRpYSA9IFwiaWZzQ29kZUluZGlhXCIsXG4gIHBhbkluZGlhID0gXCJwYW5JbmRpYVwiLFxuICBlbWFpbCA9IFwiZW1haWxcIixcbiAgZ3N0SW5kaWEgPSBcImdzdEluZGlhXCIsXG4gIGN1c3RvbSA9ICdjdXN0b20nXG59XG4iXX0=