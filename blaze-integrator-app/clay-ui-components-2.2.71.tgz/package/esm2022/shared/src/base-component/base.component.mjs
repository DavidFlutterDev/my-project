import { ClComponentRegistryService } from '../component-registry';
import { Component, Input, inject } from '@angular/core';
import * as i0 from "@angular/core";
export class ClBaseComponent {
    constructor() {
        // Component service would track the component reference and it's count throughout it's lifecycle
        this.componentRegistry = inject(ClComponentRegistryService);
    }
    setElementRef(elem) {
        this.elem = elem;
    }
    ngOnDestroy() {
        // update the component count
        let currentCount = this.componentRegistry.getComponentCount(this.properties.type);
        currentCount = currentCount > 0 ? currentCount : 0;
        this.componentRegistry.setComponentCount(this.properties.type, currentCount);
        // register itself in registry
        this.componentRegistry.unRegisterComponent(this.properties.id);
        this.valueSub?.unsubscribe();
    }
    ngOnInit() {
        // check and assign id
        if (this.properties?.id === "default0" || this.componentRegistry.getComponentById(this.properties.id) !== undefined) {
            this.properties.id = this.componentRegistry.generateComponentId(this.properties.type);
        }
        // update the component count
        let currentCount = this.componentRegistry.getComponentCount(this.properties.type);
        currentCount++;
        this.componentRegistry.setComponentCount(this.properties.type, currentCount);
        // register itself in registry
        this.componentRegistry.registerComponent(this.properties.id, this);
    }
    handleAnalytics() {
        // add analytics code here
    }
    setTemplateControl(ngModel) {
        this.templateControl = ngModel;
    }
    subscribeToValueChanges(callbackFunction) {
        this.valueSub = this.templateControl?.valueChanges?.subscribe((value) => {
            callbackFunction(value);
        });
    }
    setReactiveControl(formControlName) {
        this.reactiveControl = formControlName;
    }
    getTemplateControl() {
        return this.templateControl;
    }
    getReactiveControl() {
        return this.reactiveControl;
    }
    setProperties(properties) {
        this.properties = properties;
    }
    getProperties() {
        return this.properties;
    }
    getLoopIndex() {
        return this.loopIndex;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBaseComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClBaseComponent, selector: "ng-component", inputs: { properties: "properties", loopIndex: "loopIndex" }, ngImport: i0, template: '', isInline: true, styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBaseComponent, decorators: [{
            type: Component,
            args: [{ template: '' }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], loopIndex: [{
                type: Input,
                args: [{ required: false }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkL3NyYy9iYXNlLWNvbXBvbmVudC9iYXNlLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQSxPQUFPLEVBQUUsMEJBQTBCLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNuRSxPQUFPLEVBQUUsU0FBUyxFQUFjLEtBQUssRUFBcUIsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQUd4RixNQUFNLE9BQWdCLGVBQWU7SUFEckM7UUFLRSxpR0FBaUc7UUFDdkYsc0JBQWlCLEdBQStCLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxDQUFBO0tBcUY3RjtJQXRFUSxhQUFhLENBQUMsSUFBZ0I7UUFDbkMsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7SUFDbkIsQ0FBQztJQUVELFdBQVc7UUFDVCw2QkFBNkI7UUFDN0IsSUFBSSxZQUFZLEdBQVcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFXLENBQUMsSUFBSSxDQUFFLENBQUM7UUFFNUYsWUFBWSxHQUFHLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVyxDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQztRQUU5RSw4QkFBOEI7UUFDOUIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxVQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFFaEUsSUFBSSxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsQ0FBQztJQUMvQixDQUFDO0lBRUQsUUFBUTtRQUNOLHNCQUFzQjtRQUN0QixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsRUFBRSxLQUFLLFVBQVUsSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUNwSCxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4RixDQUFDO1FBRUQsNkJBQTZCO1FBQzdCLElBQUksWUFBWSxHQUFXLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBRSxDQUFDO1FBQzNGLFlBQVksRUFBRSxDQUFDO1FBRWYsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBRTdFLDhCQUE4QjtRQUM5QixJQUFJLENBQUMsaUJBQWlCLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVNLGVBQWU7UUFDcEIsMEJBQTBCO0lBQzVCLENBQUM7SUFFTSxrQkFBa0IsQ0FBQyxPQUFnQjtRQUN4QyxJQUFJLENBQUMsZUFBZSxHQUFHLE9BQU8sQ0FBQztJQUNqQyxDQUFDO0lBRU0sdUJBQXVCLENBQUMsZ0JBQXFCO1FBQ2xELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7WUFDM0UsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sa0JBQWtCLENBQUMsZUFBZ0M7UUFDeEQsSUFBSSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUE7SUFDeEMsQ0FBQztJQUVNLGtCQUFrQjtRQUN2QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUVNLGtCQUFrQjtRQUN2QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUM7SUFDOUIsQ0FBQztJQUVNLGFBQWEsQ0FBQyxVQUFzQztRQUN6RCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztJQUMvQixDQUFDO0lBRU0sYUFBYTtRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDekIsQ0FBQztJQUVNLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFBO0lBQ3ZCLENBQUM7OEdBekZtQixlQUFlO2tHQUFmLGVBQWUsa0hBREEsRUFBRTs7MkZBQ2pCLGVBQWU7a0JBRHBDLFNBQVM7K0JBQTJCLEVBQUU7OEJBZ0I5QixVQUFVO3NCQURoQixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsU0FBUztzQkFEZixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgRm9ybUNvbnRyb2xOYW1lLCBOZ01vZGVsIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgSUNsQmFzZUNvbXBvbmVudFByb3BlcnRpZXMgfSBmcm9tICcuL2Jhc2UucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbENvbXBvbmVudFJlZ2lzdHJ5U2VydmljZSB9IGZyb20gJy4uL2NvbXBvbmVudC1yZWdpc3RyeSc7XG5pbXBvcnQgeyBDb21wb25lbnQsIEVsZW1lbnRSZWYsIElucHV0LCBPbkRlc3Ryb3ksIE9uSW5pdCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBDb21wb25lbnQoeyBzdHlsZXM6IFtgYF0sIHRlbXBsYXRlOiAnJyB9KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIElDbEJhc2VDb21wb25lbnQsIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgLy8gQWRkIEhUTUwgZWxlbWVudCByZWZlcmVuY2Ugb2YgdGhlIGN1cnJlbnQgY29tcG9uZW50XG4gIHByb3RlY3RlZCBlbGVtPzogRWxlbWVudFJlZlxuXG4gIC8vIENvbXBvbmVudCBzZXJ2aWNlIHdvdWxkIHRyYWNrIHRoZSBjb21wb25lbnQgcmVmZXJlbmNlIGFuZCBpdCdzIGNvdW50IHRocm91Z2hvdXQgaXQncyBsaWZlY3ljbGVcbiAgcHJvdGVjdGVkIGNvbXBvbmVudFJlZ2lzdHJ5OiBDbENvbXBvbmVudFJlZ2lzdHJ5U2VydmljZSA9IGluamVjdChDbENvbXBvbmVudFJlZ2lzdHJ5U2VydmljZSlcblxuICAvLyBUaGVzZSBhcmUgdG8gaG9sZCB0aGUgZm9ybSBjb250cm9sIHJlZmVyZW5jZXMgaWYgbmVlZGVkLiBUbyBnZXQgdGhlIHJlZmVyZW5jZXMsIHdlIG5lZWQgdG8gZW5hYmxlIHRoZVxuICAvLyBjb3JyZXNwb25kaW5nIGluamVjdG9yIGRpcmVjdGl2ZXMgaW4gdGhlIGNsaWVudC5cbiAgLy8gcmVmOiBjb250cm9sLWluamVjdG9yXG4gIHB1YmxpYyB0ZW1wbGF0ZUNvbnRyb2w/OiBOZ01vZGVsXG4gIHB1YmxpYyByZWFjdGl2ZUNvbnRyb2w/OiBGb3JtQ29udHJvbE5hbWU7XG4gIHByaXZhdGUgdmFsdWVTdWI/OiBTdWJzY3JpcHRpb247XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIHByb3BlcnRpZXMhOiBJQ2xCYXNlQ29tcG9uZW50UHJvcGVydGllcztcblxuICBASW5wdXQoeyByZXF1aXJlZDogZmFsc2UgfSlcbiAgcHVibGljIGxvb3BJbmRleD86IGFueTtcblxuICBwdWJsaWMgc2V0RWxlbWVudFJlZihlbGVtOiBFbGVtZW50UmVmKSB7XG4gICAgdGhpcy5lbGVtID0gZWxlbTtcbiAgfVxuXG4gIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIC8vIHVwZGF0ZSB0aGUgY29tcG9uZW50IGNvdW50XG4gICAgbGV0IGN1cnJlbnRDb3VudDogbnVtYmVyID0gdGhpcy5jb21wb25lbnRSZWdpc3RyeS5nZXRDb21wb25lbnRDb3VudCh0aGlzLnByb3BlcnRpZXMhLnR5cGUpITtcblxuICAgIGN1cnJlbnRDb3VudCA9IGN1cnJlbnRDb3VudCA+IDAgPyBjdXJyZW50Q291bnQgOiAwO1xuICAgIHRoaXMuY29tcG9uZW50UmVnaXN0cnkuc2V0Q29tcG9uZW50Q291bnQodGhpcy5wcm9wZXJ0aWVzIS50eXBlLCBjdXJyZW50Q291bnQpO1xuXG4gICAgLy8gcmVnaXN0ZXIgaXRzZWxmIGluIHJlZ2lzdHJ5XG4gICAgdGhpcy5jb21wb25lbnRSZWdpc3RyeS51blJlZ2lzdGVyQ29tcG9uZW50KHRoaXMucHJvcGVydGllcyEuaWQpO1xuXG4gICAgdGhpcy52YWx1ZVN1Yj8udW5zdWJzY3JpYmUoKTtcbiAgfVxuXG4gIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIC8vIGNoZWNrIGFuZCBhc3NpZ24gaWRcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzPy5pZCA9PT0gXCJkZWZhdWx0MFwiIHx8IHRoaXMuY29tcG9uZW50UmVnaXN0cnkuZ2V0Q29tcG9uZW50QnlJZCh0aGlzLnByb3BlcnRpZXMuaWQpICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5pZCA9IHRoaXMuY29tcG9uZW50UmVnaXN0cnkuZ2VuZXJhdGVDb21wb25lbnRJZCh0aGlzLnByb3BlcnRpZXMudHlwZSk7XG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIHRoZSBjb21wb25lbnQgY291bnRcbiAgICBsZXQgY3VycmVudENvdW50OiBudW1iZXIgPSB0aGlzLmNvbXBvbmVudFJlZ2lzdHJ5LmdldENvbXBvbmVudENvdW50KHRoaXMucHJvcGVydGllcy50eXBlKSE7XG4gICAgY3VycmVudENvdW50Kys7XG5cbiAgICB0aGlzLmNvbXBvbmVudFJlZ2lzdHJ5LnNldENvbXBvbmVudENvdW50KHRoaXMucHJvcGVydGllcy50eXBlLCBjdXJyZW50Q291bnQpO1xuXG4gICAgLy8gcmVnaXN0ZXIgaXRzZWxmIGluIHJlZ2lzdHJ5XG4gICAgdGhpcy5jb21wb25lbnRSZWdpc3RyeS5yZWdpc3RlckNvbXBvbmVudCh0aGlzLnByb3BlcnRpZXMuaWQsIHRoaXMpO1xuICB9XG5cbiAgcHVibGljIGhhbmRsZUFuYWx5dGljcygpIHtcbiAgICAvLyBhZGQgYW5hbHl0aWNzIGNvZGUgaGVyZVxuICB9XG5cbiAgcHVibGljIHNldFRlbXBsYXRlQ29udHJvbChuZ01vZGVsOiBOZ01vZGVsKTogdm9pZCB7XG4gICAgdGhpcy50ZW1wbGF0ZUNvbnRyb2wgPSBuZ01vZGVsO1xuICB9XG5cbiAgcHVibGljIHN1YnNjcmliZVRvVmFsdWVDaGFuZ2VzKGNhbGxiYWNrRnVuY3Rpb246IGFueSk6IHZvaWQge1xuICAgIHRoaXMudmFsdWVTdWIgPSB0aGlzLnRlbXBsYXRlQ29udHJvbD8udmFsdWVDaGFuZ2VzPy5zdWJzY3JpYmUoKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgIGNhbGxiYWNrRnVuY3Rpb24odmFsdWUpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHNldFJlYWN0aXZlQ29udHJvbChmb3JtQ29udHJvbE5hbWU6IEZvcm1Db250cm9sTmFtZSk6IHZvaWQge1xuICAgIHRoaXMucmVhY3RpdmVDb250cm9sID0gZm9ybUNvbnRyb2xOYW1lXG4gIH1cblxuICBwdWJsaWMgZ2V0VGVtcGxhdGVDb250cm9sKCk6IE5nTW9kZWwgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLnRlbXBsYXRlQ29udHJvbDtcbiAgfVxuXG4gIHB1YmxpYyBnZXRSZWFjdGl2ZUNvbnRyb2woKTogRm9ybUNvbnRyb2xOYW1lIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy5yZWFjdGl2ZUNvbnRyb2w7XG4gIH1cblxuICBwdWJsaWMgc2V0UHJvcGVydGllcyhwcm9wZXJ0aWVzOiBJQ2xCYXNlQ29tcG9uZW50UHJvcGVydGllcykge1xuICAgIHRoaXMucHJvcGVydGllcyA9IHByb3BlcnRpZXM7XG4gIH1cblxuICBwdWJsaWMgZ2V0UHJvcGVydGllcygpOiBJQ2xCYXNlQ29tcG9uZW50UHJvcGVydGllcyB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMucHJvcGVydGllcztcbiAgfVxuXG4gIHB1YmxpYyBnZXRMb29wSW5kZXgoKSB7XG4gICAgcmV0dXJuIHRoaXMubG9vcEluZGV4XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBJQ2xCYXNlQ29tcG9uZW50IHtcbiAgaGFuZGxlQW5hbHl0aWNzKCk6IHZvaWQ7XG4gIHNldEVsZW1lbnRSZWYoZWxlbTogRWxlbWVudFJlZik6IHZvaWQ7XG4gIHNldFRlbXBsYXRlQ29udHJvbChuZ01vZGVsOiBOZ01vZGVsKTogdm9pZDtcbiAgc2V0UmVhY3RpdmVDb250cm9sKGZvcm1Db250cm9sTmFtZTogRm9ybUNvbnRyb2xOYW1lKTogdm9pZDtcbiAgZ2V0VGVtcGxhdGVDb250cm9sKCk6IE5nTW9kZWwgfCB1bmRlZmluZWQ7XG4gIGdldFJlYWN0aXZlQ29udHJvbCgpOiBGb3JtQ29udHJvbE5hbWUgfCB1bmRlZmluZWQ7XG4gIHNldFByb3BlcnRpZXMocHJvcGVydGllczogSUNsQmFzZUNvbXBvbmVudFByb3BlcnRpZXMpOiB2b2lkO1xuICBnZXRQcm9wZXJ0aWVzKCk6IElDbEJhc2VDb21wb25lbnRQcm9wZXJ0aWVzIHwgdW5kZWZpbmVkXG4gIGdldExvb3BJbmRleCgpOiBhbnkgfCB1bmRlZmluZWRcbn1cbiJdfQ==