import { Input, Component } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClHyperLinkTextProperties } from './hyper-link-text.properties';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/form-field";
export class ClHyperLinkTextComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClHyperLinkTextProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClHyperLinkTextComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClHyperLinkTextComponent, isStandalone: true, selector: "cl-hyper-link-text", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div class=\"{{ properties.style?.cssClasses }}\">\n  <mat-label>\n    @for (child of properties.linkProperties; track child) {\n      @if (child.isLink) {\n        <a [href]=\"child.url\" class=\"text-primary {{ child.cssClasses }} cursor-pointer\">\n          {{ child.text }}\n        </a>\n      } @else {\n        <span class=\"{{ child.cssClasses }}\">{{ child.text }}</span>\n      }\n    }\n  </mat-label>\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClHyperLinkTextComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-hyper-link-text', imports: [
                        MatFormFieldModule
                    ], template: "<div class=\"{{ properties.style?.cssClasses }}\">\n  <mat-label>\n    @for (child of properties.linkProperties; track child) {\n      @if (child.isLink) {\n        <a [href]=\"child.url\" class=\"text-primary {{ child.cssClasses }} cursor-pointer\">\n          {{ child.text }}\n        </a>\n      } @else {\n        <span class=\"{{ child.cssClasses }}\">{{ child.text }}</span>\n      }\n    }\n  </mat-label>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaHlwZXItbGluay10ZXh0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvaHlwZXItbGluay10ZXh0L2h5cGVyLWxpbmstdGV4dC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2h5cGVyLWxpbmstdGV4dC9oeXBlci1saW5rLXRleHQuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLEtBQUssRUFBVSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFFbEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzdELE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDOzs7QUFVekUsTUFBTSxPQUFPLHdCQUF5QixTQUFRLGVBQWU7SUFLM0Q7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQVlWLGFBQVEsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLGNBQVMsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBWjFCLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSx5QkFBeUIsRUFBRSxDQUFDO1FBRXBELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDOzhHQW5CVSx3QkFBd0I7a0dBQXhCLHdCQUF3QiwySUNkckMseWFBYUEsMkNERkksa0JBQWtCOzsyRkFHVCx3QkFBd0I7a0JBUnBDLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLG9CQUFvQixXQUVyQjt3QkFDUCxrQkFBa0I7cUJBQ25CO3dEQUtlLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5wdXQsIE9uSW5pdCwgQ29tcG9uZW50IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9mb3JtLWZpZWxkJztcblxuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50IH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuaW1wb3J0IHsgQ2xIeXBlckxpbmtUZXh0UHJvcGVydGllcyB9IGZyb20gJy4vaHlwZXItbGluay10ZXh0LnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1oeXBlci1saW5rLXRleHQnLFxuICB0ZW1wbGF0ZVVybDogJy4vaHlwZXItbGluay10ZXh0LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE1hdEZvcm1GaWVsZE1vZHVsZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIENsSHlwZXJMaW5rVGV4dENvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbEh5cGVyTGlua1RleHRQcm9wZXJ0aWVzO1xuXG4gIGNvbnN0cnVjdG9yICgpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xIeXBlckxpbmtUZXh0UHJvcGVydGllcygpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxufVxuIiwiPGRpdiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIj5cbiAgPG1hdC1sYWJlbD5cbiAgICBAZm9yIChjaGlsZCBvZiBwcm9wZXJ0aWVzLmxpbmtQcm9wZXJ0aWVzOyB0cmFjayBjaGlsZCkge1xuICAgICAgQGlmIChjaGlsZC5pc0xpbmspIHtcbiAgICAgICAgPGEgW2hyZWZdPVwiY2hpbGQudXJsXCIgY2xhc3M9XCJ0ZXh0LXByaW1hcnkge3sgY2hpbGQuY3NzQ2xhc3NlcyB9fSBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgIHt7IGNoaWxkLnRleHQgfX1cbiAgICAgICAgPC9hPlxuICAgICAgfSBAZWxzZSB7XG4gICAgICAgIDxzcGFuIGNsYXNzPVwie3sgY2hpbGQuY3NzQ2xhc3NlcyB9fVwiPnt7IGNoaWxkLnRleHQgfX08L3NwYW4+XG4gICAgICB9XG4gICAgfVxuICA8L21hdC1sYWJlbD5cbjwvZGl2PlxuIl19