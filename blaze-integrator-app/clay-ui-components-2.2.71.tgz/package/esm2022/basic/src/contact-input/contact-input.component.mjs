import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatOptionModule } from '@angular/material/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSelectModule, MatSelectTrigger } from '@angular/material/select';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { Self, Input, Optional, Component, ViewChild } from '@angular/core';
import { ClContactInputProperties } from './contact-input.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/input";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/select";
import * as i6 from "@angular/material/core";
export class ClContactInputComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClContactInputProperties();
        this.selectedCountry = this.properties.selectedCountry;
        super.ngOnInit();
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    allowOnlyNumbers(event) {
        const input = event.key;
        const isNumeric = /^[0-9]$/.test(input);
        if (!isNumeric) {
            event.preventDefault();
        }
    }
    countryCodeSelection(selected) {
        const filteredValues = this.properties.countries?.filter((country) => country.code == selected);
        if (filteredValues?.length) {
            this.selectedCountry = filteredValues[0];
        }
        if (this.properties.onCountryChanged && this.selectedCountry) {
            this.properties.onCountryChanged(this.selectedCountry);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClContactInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClContactInputComponent, isStandalone: true, selector: "cl-contact-input", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n  <mat-label class=\"flex items-center\">\n    <span>{{ properties.label }}</span>\n\n    @if (properties.optional) {\n    <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n      class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input matInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" (keypress)=\"allowOnlyNumbers($event)\"\n    [placeholder]=\"properties.placeholder!\" (blur)=\"onTouched($any($event.target).value)\"\n    (input)=\"onChange(selectedCountry?.code + ' ' + $any($event.target).value)\" />\n\n  @if (properties.countries!.length > 0) {\n  <div matPrefix class=\"border-r border-solid border-neutral-500 pr-2 mr-1\">\n    <mat-select [value]=\"selectedCountry?.code\" [hideSingleSelectionIndicator]=\"true\"\n      (valueChange)=\"countryCodeSelection($event)\">\n\n      <mat-select-trigger>{{selectedCountry?.code}}</mat-select-trigger>\n\n      @for (country of properties.countries; track country) {\n      <mat-option [value]=\"country.code\" class=\"flex items-center justify-between cl-mat-select-option\">\n        {{country.code}} - {{country.name}}\n      </mat-option>\n      }\n    </mat-select>\n  </div>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i5.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i5.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClContactInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-contact-input', imports: [
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatSelectModule,
                        MatOptionModule,
                        MatSelectTrigger,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n  <mat-label class=\"flex items-center\">\n    <span>{{ properties.label }}</span>\n\n    @if (properties.optional) {\n    <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n      class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input matInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" (keypress)=\"allowOnlyNumbers($event)\"\n    [placeholder]=\"properties.placeholder!\" (blur)=\"onTouched($any($event.target).value)\"\n    (input)=\"onChange(selectedCountry?.code + ' ' + $any($event.target).value)\" />\n\n  @if (properties.countries!.length > 0) {\n  <div matPrefix class=\"border-r border-solid border-neutral-500 pr-2 mr-1\">\n    <mat-select [value]=\"selectedCountry?.code\" [hideSingleSelectionIndicator]=\"true\"\n      (valueChange)=\"countryCodeSelection($event)\">\n\n      <mat-select-trigger>{{selectedCountry?.code}}</mat-select-trigger>\n\n      @for (country of properties.countries; track country) {\n      <mat-option [value]=\"country.code\" class=\"flex items-center justify-between cl-mat-select-option\">\n        {{country.code}} - {{country.name}}\n      </mat-option>\n      }\n    </mat-select>\n  </div>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGFjdC1pbnB1dC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NvbnRhY3QtaW5wdXQvY29udGFjdC1pbnB1dC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NvbnRhY3QtaW5wdXQvY29udGFjdC1pbnB1dC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN6RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDN0UsT0FBTyxFQUFFLFlBQVksRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2hGLE9BQU8sRUFBYSxXQUFXLEVBQTBDLE1BQU0sZ0JBQWdCLENBQUM7QUFDaEcsT0FBTyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQVUsUUFBUSxFQUFhLFNBQVMsRUFBc0MsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRW5JLE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ3RFLE9BQU8sRUFBYSxlQUFlLEVBQWtCLE1BQU0sNEJBQTRCLENBQUM7QUFDeEYsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHNDQUFzQyxDQUFDOzs7Ozs7OztBQWtCdkUsTUFBTSxPQUFPLHVCQUF3QixTQUFRLGVBQWU7SUErQjFELFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFQNUQsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFZMUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO1FBRXZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksd0JBQXdCLEVBQUUsQ0FBQztRQUNuRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDO1FBRXZELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsSUFBVyxRQUFRO1FBQ2pCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDMUMsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ2xDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVELElBQVcsV0FBVztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzdDLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDcEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUNyQyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxlQUFlO1FBQ2Isb0dBQW9HO1FBQ3BHLDRFQUE0RTtRQUM1RSx5SUFBeUk7UUFFekksaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixLQUFLLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUUxRCxpREFBaUQ7UUFDakQsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQyxPQUFZLEVBQUUsRUFBRTtZQUNuRSxJQUFJLE9BQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixpQ0FBaUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQscUJBQXFCO1FBQ25CLHVGQUF1RjtRQUN2RixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsd0RBQXdEO1FBQ3hELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdkYsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sSUFBSSxHQUE2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUE2QixDQUFDO2dCQUN0RyxJQUFJLENBQUMsS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLENBQUMsQ0FBQztZQUNyRSxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM3RSxDQUFDO1lBRUQsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBRU8sV0FBVztRQUNqQix5RUFBeUU7UUFFekUsdUVBQXVFO1FBQ3ZFLDJFQUEyRTtRQUUzRSwyRUFBMkU7UUFDM0UsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU0sWUFBWSxDQUFDLEtBQVU7UUFDNUIsZ0RBQWdEO1FBRWhELHdFQUF3RTtRQUN4RSwwRUFBMEU7UUFFMUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNwRix3RUFBd0U7SUFDMUUsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBRUYsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUN4QixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsdUdBQXVHO0lBQ3pHLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0QsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDckIsQ0FBQztJQUVPLGFBQWE7UUFDbkIsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFBO1FBQ2xCLENBQUM7SUFDSCxDQUFDO0lBRU0sZ0JBQWdCLENBQUMsS0FBb0I7UUFDMUMsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FBQztRQUN4QixNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXhDLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNmLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN6QixDQUFDO0lBQ0gsQ0FBQztJQUVNLG9CQUFvQixDQUFDLFFBQWE7UUFDdkMsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsT0FBa0IsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUMsQ0FBQztRQUUzRyxJQUFJLGNBQWMsRUFBRSxNQUFNLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsZUFBZSxHQUFHLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzQyxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUM3RCxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUN6RCxDQUFDO0lBQ0gsQ0FBQzs4R0E1TFUsdUJBQXVCO2tHQUF2Qix1QkFBdUIsZ0tBU3ZCLFlBQVksdUVDeEN6Qixza0VBbURBLDJDRC9CSSxXQUFXLDhCQUNYLGFBQWEsbUxBQ2IsY0FBYyw0NkJBQ2QsZUFBZSxxd0JBQ2YsZUFBZSw4QkFFZixnQkFBZ0IsOEJBQ2hCLGtCQUFrQiwrQkFDbEIsa0JBQWtCOzsyRkFHVCx1QkFBdUI7a0JBaEJuQyxTQUFTO2lDQUNJLElBQUksWUFDTixrQkFBa0IsV0FFbkI7d0JBQ1AsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsZUFBZTt3QkFDZixlQUFlO3dCQUNmLGdCQUFnQjt3QkFDaEIsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBQ2xCLGtCQUFrQjtxQkFDbkI7OzBCQWlDYSxRQUFROzswQkFBSSxJQUFJO3lDQTVCZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFRbEIsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBNYXRJbnB1dE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2lucHV0JztcbmltcG9ydCB7IE1hdE9wdGlvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NvcmUnO1xuaW1wb3J0IHsgTWF0VG9vbHRpcE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Rvb2x0aXAnO1xuaW1wb3J0IHsgTWF0U2VsZWN0TW9kdWxlLCBNYXRTZWxlY3RUcmlnZ2VyIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvc2VsZWN0JztcbmltcG9ydCB7IE1hdEZvcm1GaWVsZCwgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZm9ybS1maWVsZCc7XG5pbXBvcnQgeyBOZ0NvbnRyb2wsIEZvcm1zTW9kdWxlLCBWYWxpZGF0aW9uRXJyb3JzLCBDb250cm9sVmFsdWVBY2Nlc3NvciB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IFNlbGYsIElucHV0LCBPbkluaXQsIE9wdGlvbmFsLCBPbkRlc3Ryb3ksIENvbXBvbmVudCwgQWZ0ZXJWaWV3SW5pdCwgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsQ29udGFjdElucHV0UHJvcGVydGllcyB9IGZyb20gJy4vY29udGFjdC1pbnB1dC5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENsQ291bnRyeSwgQ2xCYXNlQ29tcG9uZW50LCBDbEVycm9ySGFuZGxlciB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWNvbnRhY3QtaW5wdXQnLFxuICB0ZW1wbGF0ZVVybDogJy4vY29udGFjdC1pbnB1dC5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBNYXRJY29uTW9kdWxlLFxuICAgIE1hdElucHV0TW9kdWxlLFxuICAgIE1hdFNlbGVjdE1vZHVsZSxcbiAgICBNYXRPcHRpb25Nb2R1bGUsXG4gICAgTWF0U2VsZWN0VHJpZ2dlcixcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBDbFRvb2x0aXBEaXJlY3RpdmVcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xDb250YWN0SW5wdXRDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciwgT25Jbml0LCBPbkRlc3Ryb3ksIEFmdGVyVmlld0luaXQsIEFmdGVyQ29udGVudENoZWNrZWQge1xuICAvLyBQbGVhc2UgcHV0IGFsbCB0aGUgYW5ndWxhciBkZWNvcmF0ZWQgdmFyaWFibGVzIGJlbG93IHRoaXNcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbENvbnRhY3RJbnB1dFByb3BlcnRpZXM7XG5cbiAgLy8gQElucHV0KClcbiAgLy8gcHVibGljIGlzRGlzYWJsZWQ/OiBib29sZWFuID0gZmFsc2U7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIEBWaWV3Q2hpbGQoTWF0Rm9ybUZpZWxkKVxuICBwdWJsaWMgbWF0Rm9ybUZpZWxkITogTWF0Rm9ybUZpZWxkO1xuXG4gIC8vIEBWaWV3Q2hpbGQoJ21hdFRleHRGaWVsZCcpXG4gIC8vIHB1YmxpYyBtYXRUZXh0RmllbGREaXZFbGVtZW50UmVmITogRWxlbWVudFJlZjtcblxuICAvLyBAVmlld0NoaWxkKCdlcnJvck9ySGludERpdkVsZW1lbnRSZWYnKVxuICAvLyBwdWJsaWMgZXJyb3JPckhpbnREaXZFbGVtZW50UmVmITogRWxlbWVudFJlZjtcblxuICAvLyBwcml2YXRlIGVycm9yT3JIaW50RGl2RWxlbWVudCE6IEhUTUxEaXZFbGVtZW50O1xuICAvLyBwcml2YXRlIG1hdFRleHRGaWVsZERpdkVsZW1lbnQhOiBIVE1MRGl2RWxlbWVudDtcblxuICBwcm90ZWN0ZWQgX3ZhbHVlOiBhbnk7XG4gIHB1YmxpYyBzZWxlY3RlZENvdW50cnk/OiBDbENvdW50cnk7XG5cbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIHByaXZhdGUgc3ViPzogU3Vic2NyaXB0aW9uO1xuICBwcm90ZWN0ZWQgZXJyb3I/OiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbENvbnRhY3RJbnB1dFByb3BlcnRpZXMoKTtcbiAgICB0aGlzLnNlbGVjdGVkQ291bnRyeSA9IHRoaXMucHJvcGVydGllcy5zZWxlY3RlZENvdW50cnk7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgcHVibGljIGdldCBkaXNhYmxlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAvLyBzZXR0aW5nIHRoZSByZWZlcmVuY2VzIG9mIE5hdGl2ZSBFbGVtZW50cywgd2hpY2ggd2lsbCBiZSB1c2VkIGluIHNldEVycm9yVGV4dCgpIGFuZCBzZXRIaW50VGV4dCgpXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQgPSB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudCA9IHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1hdC1tZGMtdGV4dC1maWVsZC13cmFwcGVyLm1kYy10ZXh0LWZpZWxkJyk7XG5cbiAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG5cbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICAvLyByZW1vdmUgYWxsIHRoZSBlcnJvcnMgd2hlbiB0aGUgc3RhdHVzIGlzIHZhbGlkXG4gICAgdGhpcy5zdWIgPSB0aGlzLm5nQ29udHJvbD8uc3RhdHVzQ2hhbmdlcz8uc3Vic2NyaWJlKChjaGFuZ2VzOiBhbnkpID0+IHtcbiAgICAgIGlmIChjaGFuZ2VzICYmIGNoYW5nZXMgPT09ICdWQUxJRCcpIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IG51bGw7XG5cbiAgICAgICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgICAgIHRoaXMuc2V0SGludFRleHQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpOiB2b2lkIHtcbiAgICAvLyBiZWxvdyBpcyB0byBhdm9pZCBkaXNwbGF5aW5nICd1bmRlZmluZWQnIG9uIHNjcmVlbiB3aGVuIG1vZGVsIGlzIG5vdCBkZWZpbmVkIC4uIHlldC5cbiAgICB0aGlzLnNldEVtcHR5VmFsdWUoKTtcblxuICAgIC8vIHRyaWdnZXIgdGhlIGVycm9yIHBhdHRlcm4gb25jZSB0aGUgY29udGVudCBpcyBjaGVja2VkXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwgJiYgdGhpcy5uZ0NvbnRyb2wudG91Y2hlZCA9PT0gdHJ1ZSAmJiB0aGlzLm5nQ29udHJvbC5lcnJvcnMpIHtcbiAgICAgIGlmKHRoaXMucHJvcGVydGllcy5pc1JlYWN0aXZlRm9ybUNvbnRyb2wpIHtcbiAgICAgICAgY29uc3Qga2V5czogKGtleW9mIENsRXJyb3JIYW5kbGVyKVtdID0gT2JqZWN0LmtleXModGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSBhcyAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW107XG4gICAgICAgIHRoaXMuZXJyb3IgPSBnZXRFcnJvck1lc3NhZ2Uoa2V5c1swXSwgdGhpcy5wcm9wZXJ0aWVzLmVycm9yc0xpc3QhKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZXJyb3IgPSB0aGlzLm5nQ29udHJvbC5lcnJvcnMgPyB0aGlzLm5nQ29udHJvbC5lcnJvcnNbJ2Vycm9yJ10gOiBudWxsO1xuICAgICAgfVxuXG4gICAgICAvLyBjYWxsaW5nIHNldCBlcnJvciB0ZXh0IGZ1bmN0aW9uXG4gICAgICB0aGlzLnNldEVycm9yVGV4dCh0aGlzLmVycm9yKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldEhpbnRUZXh0KCkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IHRoaXMucHJvcGVydGllcy5oaW50VGV4dCA/PyAnJztcblxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21hdC1tZGMtZm9ybS1maWVsZC1oaW50Jyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG5cbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWRjLXRleHQtZmllbGQtLWludmFsaWQnKTtcbiAgICB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1mb3JtLWZpZWxkLWludmFsaWQnKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvclRleHQoZXJyb3I6IGFueSkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IGVycm9yO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcblxuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgLyoqXG4gICAgKiAhISBXYXJuaW5nICEhXG4gICAgKiBUaGUgYmVsb3cgc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICovXG5cbiAgICB0aGlzLnN1Yj8udW5zdWJzY3JpYmUoKTtcbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gIH1cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cblxuICByZWdpc3Rlck9uVG91Y2hlZChmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uVG91Y2hlZCA9IGZuXG4gIH1cblxuICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cblxuICBwcml2YXRlIHNldEVtcHR5VmFsdWUoKSB7XG4gICAgaWYgKHRoaXMuX3ZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuX3ZhbHVlID0gJydcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgYWxsb3dPbmx5TnVtYmVycyhldmVudDogS2V5Ym9hcmRFdmVudCk6IHZvaWQge1xuICAgIGNvbnN0IGlucHV0ID0gZXZlbnQua2V5O1xuICAgIGNvbnN0IGlzTnVtZXJpYyA9IC9eWzAtOV0kLy50ZXN0KGlucHV0KTtcblxuICAgIGlmICghaXNOdW1lcmljKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBjb3VudHJ5Q29kZVNlbGVjdGlvbihzZWxlY3RlZDogYW55KSB7XG4gICAgY29uc3QgZmlsdGVyZWRWYWx1ZXMgPSB0aGlzLnByb3BlcnRpZXMuY291bnRyaWVzPy5maWx0ZXIoKGNvdW50cnk6IENsQ291bnRyeSkgPT4gY291bnRyeS5jb2RlID09IHNlbGVjdGVkKTtcblxuICAgIGlmIChmaWx0ZXJlZFZhbHVlcz8ubGVuZ3RoKSB7XG4gICAgICB0aGlzLnNlbGVjdGVkQ291bnRyeSA9IGZpbHRlcmVkVmFsdWVzWzBdO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25Db3VudHJ5Q2hhbmdlZCAmJiB0aGlzLnNlbGVjdGVkQ291bnRyeSkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uQ291bnRyeUNoYW5nZWQodGhpcy5zZWxlY3RlZENvdW50cnkpO1xuICAgIH1cbiAgfVxufVxuIiwiPG1hdC1mb3JtLWZpZWxkIFtpZF09XCJwcm9wZXJ0aWVzLmlkXCIgc3Vic2NyaXB0U2l6aW5nPVwiZHluYW1pY1wiIFtmbG9hdExhYmVsXT1cInByb3BlcnRpZXMuZmxvYXRMYWJlbCFcIlxuICBbYXBwZWFyYW5jZV09XCJwcm9wZXJ0aWVzLmFwcGVhcmFuY2UhXCIgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzIH19XCI+XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmxhYmVsICE9IG51bGwgJiYgcHJvcGVydGllcy5sYWJlbCAhPSAnJyAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9IHVuZGVmaW5lZCkge1xuICA8bWF0LWxhYmVsIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICA8c3Bhbj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9zcGFuPlxuXG4gICAgQGlmIChwcm9wZXJ0aWVzLm9wdGlvbmFsKSB7XG4gICAgPHNwYW4gY2xhc3M9XCJvcHRpb25hbC10ZXh0XCI+KE9wdGlvbmFsKTwvc3Bhbj5cbiAgICB9XG5cbiAgICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCIgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmluZm9ybWF0aW9uLWNpcmNsZSdcIlxuICAgICAgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICA8L21hdC1pY29uPlxuICAgIH1cbiAgPC9tYXQtbGFiZWw+XG4gIH1cblxuICA8aW5wdXQgbWF0SW5wdXQgdHlwZT1cInRleHRcIiBbdmFsdWVdPVwidmFsdWVcIiBbZGlzYWJsZWRdPVwiZGlzYWJsZWRcIiAoa2V5cHJlc3MpPVwiYWxsb3dPbmx5TnVtYmVycygkZXZlbnQpXCJcbiAgICBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIiAoYmx1cik9XCJvblRvdWNoZWQoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIlxuICAgIChpbnB1dCk9XCJvbkNoYW5nZShzZWxlY3RlZENvdW50cnk/LmNvZGUgKyAnICcgKyAkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKVwiIC8+XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmNvdW50cmllcyEubGVuZ3RoID4gMCkge1xuICA8ZGl2IG1hdFByZWZpeCBjbGFzcz1cImJvcmRlci1yIGJvcmRlci1zb2xpZCBib3JkZXItbmV1dHJhbC01MDAgcHItMiBtci0xXCI+XG4gICAgPG1hdC1zZWxlY3QgW3ZhbHVlXT1cInNlbGVjdGVkQ291bnRyeT8uY29kZVwiIFtoaWRlU2luZ2xlU2VsZWN0aW9uSW5kaWNhdG9yXT1cInRydWVcIlxuICAgICAgKHZhbHVlQ2hhbmdlKT1cImNvdW50cnlDb2RlU2VsZWN0aW9uKCRldmVudClcIj5cblxuICAgICAgPG1hdC1zZWxlY3QtdHJpZ2dlcj57e3NlbGVjdGVkQ291bnRyeT8uY29kZX19PC9tYXQtc2VsZWN0LXRyaWdnZXI+XG5cbiAgICAgIEBmb3IgKGNvdW50cnkgb2YgcHJvcGVydGllcy5jb3VudHJpZXM7IHRyYWNrIGNvdW50cnkpIHtcbiAgICAgIDxtYXQtb3B0aW9uIFt2YWx1ZV09XCJjb3VudHJ5LmNvZGVcIiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBjbC1tYXQtc2VsZWN0LW9wdGlvblwiPlxuICAgICAgICB7e2NvdW50cnkuY29kZX19IC0ge3tjb3VudHJ5Lm5hbWV9fVxuICAgICAgPC9tYXQtb3B0aW9uPlxuICAgICAgfVxuICAgIDwvbWF0LXNlbGVjdD5cbiAgPC9kaXY+XG4gIH1cbjwvbWF0LWZvcm0tZmllbGQ+XG5cbjwhLS0gVGhpcyBkaXYgaXMgcmVxdWlyZWQgdG8gc2hvdyBoaW50IHRleHQgb3IgZXJyb3IgbWVzc2FnZSBmb3IgdGhlIGNvbXBvbmVudCAtLT5cbjwhLS0gPGRpdiAjZXJyb3JPckhpbnREaXZFbGVtZW50UmVmIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj48L2Rpdj4gLS0+XG48ZGl2IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgQGlmIChlcnJvcikge1xuICA8bWF0LWVycm9yPnt7IGVycm9yIH19PC9tYXQtZXJyb3I+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgPG1hdC1oaW50Pnt7IHByb3BlcnRpZXMuaGludFRleHQgfX08L21hdC1oaW50PlxuICB9XG48L2Rpdj5cbiJdfQ==