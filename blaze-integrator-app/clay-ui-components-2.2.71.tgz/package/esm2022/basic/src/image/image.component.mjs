import { ClImageProperties } from './image.properties';
import { Component, Input } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export class ClImageComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClImageProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClImageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClImageComponent, isStandalone: true, selector: "cl-image", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<img [id]=\"properties.id\" [src]=\"properties.link\" [alt]=\"properties.alt || ''\" class=\"{{properties.style?.cssClasses}}\">\n", styles: [""] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClImageComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-image', template: "<img [id]=\"properties.id\" [src]=\"properties.link\" [alt]=\"properties.alt || ''\" class=\"{{properties.style?.cssClasses}}\">\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW1hZ2UuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9pbWFnZS9pbWFnZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2ltYWdlL2ltYWdlLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBQ3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7QUFRN0QsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGVBQWU7SUFJbkQ7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1FBQzVDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDOzhHQWpCVSxnQkFBZ0I7a0dBQWhCLGdCQUFnQixpSUNWN0Isb0lBQ0E7OzJGRFNhLGdCQUFnQjtrQkFONUIsU0FBUztpQ0FDSSxJQUFJLFlBQ04sVUFBVTt3REFNSixVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENsSW1hZ2VQcm9wZXJ0aWVzIH0gZnJvbSAnLi9pbWFnZS5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50IH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1pbWFnZScsXG4gIHN0eWxlVXJsOiAnLi9pbWFnZS5jb21wb25lbnQuc2NzcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9pbWFnZS5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENsSW1hZ2VDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsSW1hZ2VQcm9wZXJ0aWVzO1xuXG4gIGNvbnN0cnVjdG9yICgpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xJbWFnZVByb3BlcnRpZXMoKTtcbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG59XG4iLCI8aW1nIFtpZF09XCJwcm9wZXJ0aWVzLmlkXCIgW3NyY109XCJwcm9wZXJ0aWVzLmxpbmtcIiBbYWx0XT1cInByb3BlcnRpZXMuYWx0IHx8ICcnXCIgY2xhc3M9XCJ7e3Byb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXN9fVwiPlxuIl19