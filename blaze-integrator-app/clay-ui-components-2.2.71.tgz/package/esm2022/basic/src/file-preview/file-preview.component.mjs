import { Component, Input } from '@angular/core';
import { ClFilePreviewProperties, ClFilePreviewType } from './file-preview.properties';
import { ClBaseComponent, ClComponentTypes } from '@clay/ui-components/shared';
import { MatCardModule } from '@angular/material/card';
import { ClIconComponent } from '../icon';
import { CommonModule, NgStyle } from '@angular/common';
import * as pdfjsLib from 'pdfjs-dist';
import { ClInputComponent, ClInputType } from '../input';
import { FormsModule } from '@angular/forms';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/card";
if (pdfjsLib !== undefined) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = "https://npmcdn.com/pdfjs-dist@2.16.105/build/pdf.worker.js";
}
export class ClFilePreviewComponent extends ClBaseComponent {
    // End of pdf variable
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.data = '';
        this.zoomInIconProperties = {
            id: 'zoomIn0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:magnifying-glass-plus',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.zoomInFn.bind(this)
        };
        this.zoomOutIconProperties = {
            id: 'zoomOut0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:magnifying-glass-minus',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.zoomOutFn.bind(this)
        };
        this.resetIconZoomProperties = {
            id: 'zoomOut0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:arrow-path',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.resetZoomFn.bind(this)
        };
        this.expansionIconProperties = {
            id: 'expand0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:arrows-pointing-out',
            style: {
                cssClasses: 'icon-size-9 text-3xl w-10 text-primary-600 border-l-2 border-gray-400 pl-2',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.onExpansionIconClicked.bind(this)
        };
        this.pageNumberIncrementIcon = {
            id: 'pageIncrement0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:chevron-right',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.pageNumberIncrement.bind(this)
        };
        this.pageNumberDecrementIcon = {
            id: 'pageIncrement0',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:chevron-left',
            style: {
                cssClasses: 'icon-size-9 text-xl text-primary-600',
                contentWidth: '',
                justifyContent: '',
                alignContent: '',
            },
            onIconClicked: this.pageNumberDecrement.bind(this)
        };
        this.goToPageInputProperties = {
            id: 'goTo0',
            type: ClComponentTypes.input,
            placeholder: 'Page Number',
            appearance: 'fill',
            inputType: ClInputType.number,
            onValueChange: this.goToPage.bind(this)
        };
        // common variable
        this.fileType = '';
        this.scale = 1;
        // Image zoom variable
        this.blobUrl = null;
        this.imageTransform = `scale(${this.scale})`;
        this.imagePosition = { x: 0, y: 0 };
        this.isDragging = false;
        this.lastMousePosition = { x: 0, y: 0 };
        this.pageNumber = 1;
        this.totalPageSize = 0;
        this.goPageIndex = 1;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClFilePreviewProperties();
        super.ngOnInit();
    }
    ngOnChanges(_changes) {
        if (this.properties.fileType == ClFilePreviewType.jpg || this.properties.fileType == ClFilePreviewType.png || this.properties.fileType == ClFilePreviewType.svg) {
            this.fileType = 'Image';
            if (this.properties.base64) {
                this.convertBase64ToBlobUrl(this.properties.base64);
            }
        }
        if (this.properties.fileType == ClFilePreviewType.pdf) {
            this.fileType = 'Pdf';
            if (this.properties.base64) {
                this.pdfData = this.properties.base64;
                this.loadPdf();
            }
        }
    }
    convertBase64ToBlobUrl(base64) {
        // Convert base64 string to binary
        const byteCharacters = atob(base64);
        const byteArray = new Uint8Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteArray[i] = byteCharacters.charCodeAt(i);
        }
        // Create a Blob object
        const blob = new Blob([byteArray], { type: this.properties.fileType }); // Adjust the MIME type accordingly
        // Generate Blob URL
        this.blobUrl = URL.createObjectURL(blob);
    }
    zoomInFn() {
        if (this.fileType == 'Image') {
            this.zoomIn();
        }
        if (this.fileType == 'Pdf') {
            this.pdfZoomIn();
        }
    }
    zoomOutFn() {
        if (this.fileType == 'Image') {
            this.zoomOut();
        }
        if (this.fileType == 'Pdf') {
            this.pdfZoomOut();
        }
    }
    resetZoomFn() {
        if (this.fileType == 'Image') {
            this.resetZoom();
        }
        if (this.fileType == 'Pdf') {
        }
    }
    // Image Zoom feature control funtion
    // zoomIn() {
    //   this.scale += 0.1;
    //   this.updateImageTransform();
    // }
    // zoomOut() {
    //   if (this.scale > 0.2) {
    //     this.scale -= 0.1;
    //     this.updateImageTransform();
    //   }
    // }
    // private updateImageTransform() {
    //   this.imageTransform = `scale(${this.scale})`;
    // }
    zoomIn() {
        this.scale += 0.1;
        this.updateImageTransform();
    }
    zoomOut() {
        if (this.scale > 0.2) {
            this.scale -= 0.1;
            this.updateImageTransform();
        }
    }
    updateImageTransform() {
        this.imageTransform = `scale(${this.scale}) translate(${this.imagePosition.x}px, ${this.imagePosition.y}px)`;
    }
    onMouseDown(event) {
        event.preventDefault();
        this.isDragging = true;
        this.lastMousePosition = { x: event.clientX, y: event.clientY };
    }
    onMouseMove(event) {
        if (!this.isDragging)
            return;
        const deltaX = event.clientX - this.lastMousePosition.x;
        const deltaY = event.clientY - this.lastMousePosition.y;
        this.imagePosition.x += deltaX;
        this.imagePosition.y += deltaY;
        this.updateImageTransform();
        this.lastMousePosition = { x: event.clientX, y: event.clientY };
    }
    onMouseUp() {
        this.isDragging = false;
    }
    onMouseOut() {
        this.isDragging = false;
    }
    resetZoom() {
        this.scale = 1;
        this.imageTransform = `scale(${this.scale})`;
        this.imagePosition = { x: 0, y: 0 };
        this.isDragging = false;
        this.lastMousePosition = { x: 0, y: 0 };
    }
    // End of Image Zoom feature control function
    // Pdf file load and zoom feature function
    loadPdf() {
        const loadingTask = pdfjsLib.getDocument({ data: atob(this.pdfData) });
        loadingTask.promise.then((pdf) => {
            this.totalPageSize = pdf.numPages;
            pdf.getPage(this.pageNumber).then((page) => {
                const scale = this.scale;
                const viewport = page.getViewport({ scale: scale });
                // Prepare canvas using PDF page dimensions
                const canvas = document.getElementById('pdfCanvas');
                const context = canvas.getContext('2d');
                // Check if context is not null
                if (context) {
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;
                    // Render PDF page into canvas context
                    const renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    const renderTask = page.render(renderContext);
                    renderTask.promise.then(() => {
                        console.log('Page rendered');
                    });
                }
                else {
                    console.error('Could not get 2D context for canvas');
                }
            });
        }, (reason) => {
            console.error('Error loading PDF', reason);
        });
    }
    pageNumberIncrement() {
        if ((this.pageNumber + 1) < this.totalPageSize) {
            this.pageNumber += 1;
            this.goPageIndex = this.pageNumber;
            this.loadPdf();
        }
    }
    pageNumberDecrement() {
        if ((this.pageNumber - 1) > 0) {
            this.pageNumber -= 1;
            this.goPageIndex = this.pageNumber;
            this.loadPdf();
        }
    }
    pdfZoomIn() {
        this.scale += 0.1;
        this.loadPdf();
    }
    pdfZoomOut() {
        this.scale -= 0.1;
        this.loadPdf();
    }
    goToPage(val) {
        if (Number(val) >= 1) {
            this.pageNumber = Number(val);
            this.loadPdf();
        }
    }
    onExpansionIconClicked() {
        if (this.properties.onExpansionIconClicked != undefined) {
            this.properties.onExpansionIconClicked();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFilePreviewComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClFilePreviewComponent, isStandalone: true, selector: "cl-file-preview", inputs: { properties: "properties", data: "data" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<!-- <mat-card class=\"{{properties.style?.cssClasses}} flex w-full h-full\">\n  <mat-card-header class=\"flex flex-row justify-between bg-white-200 p-4\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex flex-row gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow overflow-scroll relative\">\n      <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{'transform': imageTransform}\">\n  </mat-card-content>\n</mat-card> -->\n\n<mat-card class=\"flex w-full h-full {{properties.style?.cssClasses}}\">\n  <mat-card-header class=\"flex justify-between bg-white p-4 border-b-2\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"resetIconZoomProperties\"></cl-icon>\n      @if(properties.showExpansionIcon){\n        <cl-icon [properties]=\"expansionIconProperties\"></cl-icon>\n      }\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow relative overflow-hidden bg-primary-50\">\n    @if(fileType == 'Image'){\n      <div class=\"relative flex justify-center items-center w-full h-full max-h-lvh cursor-grab\" (mousedown)=\"onMouseDown($event)\"\n        (mousemove)=\"onMouseMove($event)\" (mouseup)=\"onMouseUp()\" (mouseout)=\"onMouseOut()\">\n        <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{ 'transform': imageTransform }\"\n          class=\"transition-transform duration-300 ease-in-out\" />\n      </div>\n    }\n    @if(fileType == 'Pdf'){\n      <!-- <canvas #pdfCanvas></canvas> -->\n      <div class=\"w-full h-full overflow-auto flex justify-center items-center\">\n        <canvas id=\"pdfCanvas\"></canvas>\n      </div>\n    }\n  </mat-card-content>\n  @if(fileType == 'Pdf'){\n    <mat-card-actions class=\"flex flex-row justify-between\">\n      <div class=\"flex flex-start text-xl font-bold\">\n        Total Page: {{totalPageSize}}\n      </div>\n      <div class=\"flex flex-row justify-center gap-8\">\n        <cl-icon [properties]=\"pageNumberDecrementIcon\"></cl-icon>\n        <cl-icon [properties]=\"pageNumberIncrementIcon\"></cl-icon>\n      </div>\n      <div class=\"flex flex-end\">\n        <cl-input [properties]=\"goToPageInputProperties\" [(ngModel)]=\"goPageIndex\"></cl-input>\n      </div>\n    </mat-card-actions>\n  }\n</mat-card>\n", styles: [""], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i2.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "directive", type: i2.MatCardActions, selector: "mat-card-actions", inputs: ["align"], exportAs: ["matCardActions"] }, { kind: "directive", type: i2.MatCardContent, selector: "mat-card-content" }, { kind: "component", type: i2.MatCardHeader, selector: "mat-card-header" }, { kind: "directive", type: i2.MatCardTitle, selector: "mat-card-title, [mat-card-title], [matCardTitle]" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClInputComponent, selector: "cl-input", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClFilePreviewComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-file-preview', standalone: true, imports: [
                        NgStyle,
                        CommonModule,
                        FormsModule,
                        MatCardModule,
                        ClIconComponent,
                        ClInputComponent,
                    ], template: "<!-- <mat-card class=\"{{properties.style?.cssClasses}} flex w-full h-full\">\n  <mat-card-header class=\"flex flex-row justify-between bg-white-200 p-4\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex flex-row gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow overflow-scroll relative\">\n      <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{'transform': imageTransform}\">\n  </mat-card-content>\n</mat-card> -->\n\n<mat-card class=\"flex w-full h-full {{properties.style?.cssClasses}}\">\n  <mat-card-header class=\"flex justify-between bg-white p-4 border-b-2\">\n    <mat-card-title class=\"font-bold text-lg\">{{ properties.fileName }}</mat-card-title>\n    <div class=\"flex gap-4\">\n      <cl-icon [properties]=\"zoomInIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"zoomOutIconProperties\"></cl-icon>\n      <cl-icon [properties]=\"resetIconZoomProperties\"></cl-icon>\n      @if(properties.showExpansionIcon){\n        <cl-icon [properties]=\"expansionIconProperties\"></cl-icon>\n      }\n    </div>\n  </mat-card-header>\n\n  <mat-card-content class=\"flex-grow relative overflow-hidden bg-primary-50\">\n    @if(fileType == 'Image'){\n      <div class=\"relative flex justify-center items-center w-full h-full max-h-lvh cursor-grab\" (mousedown)=\"onMouseDown($event)\"\n        (mousemove)=\"onMouseMove($event)\" (mouseup)=\"onMouseUp()\" (mouseout)=\"onMouseOut()\">\n        <img [src]=\"blobUrl\" alt=\"Base64 Image\" [ngStyle]=\"{ 'transform': imageTransform }\"\n          class=\"transition-transform duration-300 ease-in-out\" />\n      </div>\n    }\n    @if(fileType == 'Pdf'){\n      <!-- <canvas #pdfCanvas></canvas> -->\n      <div class=\"w-full h-full overflow-auto flex justify-center items-center\">\n        <canvas id=\"pdfCanvas\"></canvas>\n      </div>\n    }\n  </mat-card-content>\n  @if(fileType == 'Pdf'){\n    <mat-card-actions class=\"flex flex-row justify-between\">\n      <div class=\"flex flex-start text-xl font-bold\">\n        Total Page: {{totalPageSize}}\n      </div>\n      <div class=\"flex flex-row justify-center gap-8\">\n        <cl-icon [properties]=\"pageNumberDecrementIcon\"></cl-icon>\n        <cl-icon [properties]=\"pageNumberIncrementIcon\"></cl-icon>\n      </div>\n      <div class=\"flex flex-end\">\n        <cl-input [properties]=\"goToPageInputProperties\" [(ngModel)]=\"goPageIndex\"></cl-input>\n      </div>\n    </mat-card-actions>\n  }\n</mat-card>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], data: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1wcmV2aWV3LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvZmlsZS1wcmV2aWV3L2ZpbGUtcHJldmlldy5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2ZpbGUtcHJldmlldy9maWxlLXByZXZpZXcuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQXlCLE1BQU0sZUFBZSxDQUFDO0FBQ3hFLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3ZGLE9BQU8sRUFBRSxlQUFlLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUMvRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGVBQWUsRUFBb0IsTUFBTSxTQUFTLENBQUM7QUFDNUQsT0FBTyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN4RCxPQUFPLEtBQUssUUFBUSxNQUFNLFlBQVksQ0FBQztBQUN2QyxPQUFPLEVBQUUsZ0JBQWdCLEVBQXFCLFdBQVcsRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUM1RSxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7Ozs7QUFFN0MsSUFBSSxRQUFRLEtBQUssU0FBUyxFQUFFLENBQUM7SUFDM0IsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsR0FBRyw0REFBNEQsQ0FBQztBQUN4RyxDQUFDO0FBaUJELE1BQU0sT0FBTyxzQkFBdUIsU0FBUSxlQUFlO0lBd0d6RCxzQkFBc0I7SUFFdEI7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQTFHSCxTQUFJLEdBQVcsRUFBRSxDQUFDO1FBQ04seUJBQW9CLEdBQXFCO1lBQzFELEVBQUUsRUFBRSxTQUFTO1lBQ2IsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsUUFBUSxFQUFFLHlDQUF5QztZQUNuRCxLQUFLLEVBQUU7Z0JBQ0wsVUFBVSxFQUFFLHNDQUFzQztnQkFDbEQsWUFBWSxFQUFFLEVBQUU7Z0JBQ2hCLGNBQWMsRUFBRSxFQUFFO2dCQUNsQixZQUFZLEVBQUUsRUFBRTthQUNqQjtZQUNELGFBQWEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDeEMsQ0FBQztRQUNpQiwwQkFBcUIsR0FBcUI7WUFDM0QsRUFBRSxFQUFFLFVBQVU7WUFDZCxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixRQUFRLEVBQUUsMENBQTBDO1lBQ3BELEtBQUssRUFBRTtnQkFDTCxVQUFVLEVBQUUsc0NBQXNDO2dCQUNsRCxZQUFZLEVBQUUsRUFBRTtnQkFDaEIsY0FBYyxFQUFFLEVBQUU7Z0JBQ2xCLFlBQVksRUFBRSxFQUFFO2FBQ2pCO1lBQ0QsYUFBYSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUN6QyxDQUFDO1FBQ2lCLDRCQUF1QixHQUFxQjtZQUM3RCxFQUFFLEVBQUUsVUFBVTtZQUNkLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLFFBQVEsRUFBRSw4QkFBOEI7WUFDeEMsS0FBSyxFQUFFO2dCQUNMLFVBQVUsRUFBRSxzQ0FBc0M7Z0JBQ2xELFlBQVksRUFBRSxFQUFFO2dCQUNoQixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDakI7WUFDRCxhQUFhLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQzNDLENBQUM7UUFDaUIsNEJBQXVCLEdBQXFCO1lBQzdELEVBQUUsRUFBRSxTQUFTO1lBQ2IsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsUUFBUSxFQUFFLHVDQUF1QztZQUNqRCxLQUFLLEVBQUU7Z0JBQ0wsVUFBVSxFQUFFLDRFQUE0RTtnQkFDeEYsWUFBWSxFQUFFLEVBQUU7Z0JBQ2hCLGNBQWMsRUFBRSxFQUFFO2dCQUNsQixZQUFZLEVBQUUsRUFBRTthQUNqQjtZQUNELGFBQWEsRUFBRSxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUN0RCxDQUFDO1FBQ2lCLDRCQUF1QixHQUFxQjtZQUM3RCxFQUFFLEVBQUUsZ0JBQWdCO1lBQ3BCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLFFBQVEsRUFBRSxpQ0FBaUM7WUFDM0MsS0FBSyxFQUFFO2dCQUNMLFVBQVUsRUFBRSxzQ0FBc0M7Z0JBQ2xELFlBQVksRUFBRSxFQUFFO2dCQUNoQixjQUFjLEVBQUUsRUFBRTtnQkFDbEIsWUFBWSxFQUFFLEVBQUU7YUFDakI7WUFDRCxhQUFhLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDbkQsQ0FBQztRQUNpQiw0QkFBdUIsR0FBcUI7WUFDN0QsRUFBRSxFQUFFLGdCQUFnQjtZQUNwQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixRQUFRLEVBQUUsZ0NBQWdDO1lBQzFDLEtBQUssRUFBRTtnQkFDTCxVQUFVLEVBQUUsc0NBQXNDO2dCQUNsRCxZQUFZLEVBQUUsRUFBRTtnQkFDaEIsY0FBYyxFQUFFLEVBQUU7Z0JBQ2xCLFlBQVksRUFBRSxFQUFFO2FBQ2pCO1lBQ0QsYUFBYSxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ25ELENBQUM7UUFFaUIsNEJBQXVCLEdBQXNCO1lBQzlELEVBQUUsRUFBRSxPQUFPO1lBQ1gsSUFBSSxFQUFFLGdCQUFnQixDQUFDLEtBQUs7WUFDNUIsV0FBVyxFQUFFLGFBQWE7WUFDMUIsVUFBVSxFQUFFLE1BQU07WUFDbEIsU0FBUyxFQUFFLFdBQVcsQ0FBQyxNQUFNO1lBQzdCLGFBQWEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7U0FDeEMsQ0FBQTtRQUVELGtCQUFrQjtRQUNSLGFBQVEsR0FBVyxFQUFFLENBQUM7UUFDdEIsVUFBSyxHQUFXLENBQUMsQ0FBQztRQUM1QixzQkFBc0I7UUFDWixZQUFPLEdBQWtCLElBQUksQ0FBQztRQUM5QixtQkFBYyxHQUFXLFNBQVUsSUFBSSxDQUFDLEtBQU0sR0FBRyxDQUFDO1FBQ2xELGtCQUFhLEdBQTZCLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7UUFDekQsZUFBVSxHQUFZLEtBQUssQ0FBQztRQUM1QixzQkFBaUIsR0FBNkIsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztRQUs3RCxlQUFVLEdBQVcsQ0FBQyxDQUFDO1FBQ3ZCLGtCQUFhLEdBQVcsQ0FBQyxDQUFDO1FBQzFCLGdCQUFXLEdBQUcsQ0FBQyxDQUFDO1FBU3hCLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSx1QkFBdUIsRUFBRSxDQUFDO1FBQ2xELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQXVCO1FBQ2pDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksaUJBQWlCLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLGlCQUFpQixDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNoSyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQztZQUN4QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3RELENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN0RCxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUN0QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7Z0JBQ3RDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNqQixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxNQUFjO1FBQzNDLGtDQUFrQztRQUNsQyxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEMsTUFBTSxTQUFTLEdBQUcsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRXhELEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7WUFDL0MsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUMsQ0FBQztRQUVELHVCQUF1QjtRQUN2QixNQUFNLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFFLG1DQUFtQztRQUU1RyxvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFTyxRQUFRO1FBQ2QsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQixDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQzNCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQTtRQUNsQixDQUFDO0lBQ0gsQ0FBQztJQUVPLFNBQVM7UUFDZixJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO1FBQ25CLENBQUM7SUFDSCxDQUFDO0lBRU8sV0FBVztRQUNqQixJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxRQUFRLElBQUksS0FBSyxFQUFFLENBQUM7UUFDN0IsQ0FBQztJQUNILENBQUM7SUFHRCxxQ0FBcUM7SUFFckMsYUFBYTtJQUNiLHVCQUF1QjtJQUN2QixpQ0FBaUM7SUFDakMsSUFBSTtJQUVKLGNBQWM7SUFDZCw0QkFBNEI7SUFDNUIseUJBQXlCO0lBQ3pCLG1DQUFtQztJQUNuQyxNQUFNO0lBQ04sSUFBSTtJQUVKLG1DQUFtQztJQUNuQyxrREFBa0Q7SUFDbEQsSUFBSTtJQUVKLE1BQU07UUFDSixJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQztRQUNsQixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRUQsT0FBTztRQUNMLElBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQztZQUNsQixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztRQUM5QixDQUFDO0lBQ0gsQ0FBQztJQUVPLG9CQUFvQjtRQUMxQixJQUFJLENBQUMsY0FBYyxHQUFHLFNBQVUsSUFBSSxDQUFDLEtBQU0sZUFBZ0IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFFLE9BQVEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFFLEtBQUssQ0FBQztJQUNySCxDQUFDO0lBRUQsV0FBVyxDQUFDLEtBQWlCO1FBQzNCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ2xFLENBQUM7SUFFRCxXQUFXLENBQUMsS0FBaUI7UUFDM0IsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO1lBQUUsT0FBTztRQUU3QixNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7UUFDeEQsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO1FBRXhELElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQztRQUMvQixJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxNQUFNLENBQUM7UUFFL0IsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNsRSxDQUFDO0lBRUQsU0FBUztRQUNQLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQzFCLENBQUM7SUFFRCxVQUFVO1FBQ1IsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDMUIsQ0FBQztJQUVELFNBQVM7UUFDUCxJQUFJLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNmLElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBVSxJQUFJLENBQUMsS0FBTSxHQUFHLENBQUM7UUFDL0MsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO0lBQzFDLENBQUM7SUFFRCw2Q0FBNkM7SUFFN0MsMENBQTBDO0lBQzFDLE9BQU87UUFDTCxNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRXZFLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDL0IsSUFBSSxDQUFDLGFBQWEsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDO1lBRWxDLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO2dCQUV6QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO2dCQUN6QixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7Z0JBRXBELDJDQUEyQztnQkFDM0MsTUFBTSxNQUFNLEdBQXNCLFFBQVEsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFzQixDQUFDO2dCQUM1RixNQUFNLE9BQU8sR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUV4QywrQkFBK0I7Z0JBQy9CLElBQUksT0FBTyxFQUFFLENBQUM7b0JBQ1osTUFBTSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDO29CQUNoQyxNQUFNLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUM7b0JBRTlCLHNDQUFzQztvQkFDdEMsTUFBTSxhQUFhLEdBQUc7d0JBQ3BCLGFBQWEsRUFBRSxPQUFPO3dCQUN0QixRQUFRLEVBQUUsUUFBUTtxQkFDbkIsQ0FBQztvQkFFRixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO29CQUU5QyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUU7d0JBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUM7b0JBQy9CLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7cUJBQU0sQ0FBQztvQkFDTixPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxFQUFFO1lBQ1osT0FBTyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM3QyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxtQkFBbUI7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQy9DLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztZQUNuQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDakIsQ0FBQztJQUNILENBQUM7SUFFRCxtQkFBbUI7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDOUIsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUM7WUFDckIsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1lBQ25DLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNqQixDQUFDO0lBQ0gsQ0FBQztJQUVELFNBQVM7UUFDUCxJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDakIsQ0FBQztJQUVELFVBQVU7UUFDUixJQUFJLENBQUMsS0FBSyxJQUFJLEdBQUcsQ0FBQztRQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDakIsQ0FBQztJQUVELFFBQVEsQ0FBQyxHQUFXO1FBQ2xCLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNqQixDQUFDO0lBQ0gsQ0FBQztJQUVELHNCQUFzQjtRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsc0JBQXNCLElBQUksU0FBUyxFQUFFLENBQUM7WUFDeEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQzNDLENBQUM7SUFDSCxDQUFDOzhHQTdVVSxzQkFBc0I7a0dBQXRCLHNCQUFzQiwyS0M3Qm5DLDZuRkF5REEsMEREdkNJLE9BQU8sMEVBQ1AsWUFBWSw4QkFDWixXQUFXLDhWQUNYLGFBQWEsa2hCQUViLGVBQWUsNEVBQ2YsZ0JBQWdCOzsyRkFLUCxzQkFBc0I7a0JBZmxDLFNBQVM7K0JBQ0UsaUJBQWlCLGNBQ2YsSUFBSSxXQUNQO3dCQUNQLE9BQU87d0JBQ1AsWUFBWTt3QkFDWixXQUFXO3dCQUNYLGFBQWE7d0JBRWIsZUFBZTt3QkFDZixnQkFBZ0I7cUJBQ2pCO3dEQU1lLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUlsQixJQUFJO3NCQURWLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbEZpbGVQcmV2aWV3UHJvcGVydGllcywgQ2xGaWxlUHJldmlld1R5cGUgfSBmcm9tICcuL2ZpbGUtcHJldmlldy5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCwgQ2xDb21wb25lbnRUeXBlcyB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IE1hdENhcmRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jYXJkJztcbmltcG9ydCB7IENsSWNvbkNvbXBvbmVudCwgQ2xJY29uUHJvcGVydGllcyB9IGZyb20gJy4uL2ljb24nO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBOZ1N0eWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCAqIGFzIHBkZmpzTGliIGZyb20gJ3BkZmpzLWRpc3QnO1xuaW1wb3J0IHsgQ2xJbnB1dENvbXBvbmVudCwgQ2xJbnB1dFByb3BlcnRpZXMsIENsSW5wdXRUeXBlIH0gZnJvbSAnLi4vaW5wdXQnO1xuaW1wb3J0IHsgRm9ybXNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5cbmlmIChwZGZqc0xpYiAhPT0gdW5kZWZpbmVkKSB7XG4gIHBkZmpzTGliLkdsb2JhbFdvcmtlck9wdGlvbnMud29ya2VyU3JjID0gXCJodHRwczovL25wbWNkbi5jb20vcGRmanMtZGlzdEAyLjE2LjEwNS9idWlsZC9wZGYud29ya2VyLmpzXCI7XG59XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2NsLWZpbGUtcHJldmlldycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtcbiAgICBOZ1N0eWxlLFxuICAgIENvbW1vbk1vZHVsZSxcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBNYXRDYXJkTW9kdWxlLFxuXG4gICAgQ2xJY29uQ29tcG9uZW50LFxuICAgIENsSW5wdXRDb21wb25lbnQsXG4gIF0sXG4gIHRlbXBsYXRlVXJsOiAnLi9maWxlLXByZXZpZXcuY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybDogJy4vZmlsZS1wcmV2aWV3LmNvbXBvbmVudC5zY3NzJ1xufSlcbmV4cG9ydCBjbGFzcyBDbEZpbGVQcmV2aWV3Q29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbEZpbGVQcmV2aWV3UHJvcGVydGllcztcblxuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgZGF0YTogc3RyaW5nID0gJyc7XG4gIHByb3RlY3RlZCByZWFkb25seSB6b29tSW5JY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ3pvb21JbjAnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBpY29uTmFtZTogJ2hlcm9pY29uc19vdXRsaW5lOm1hZ25pZnlpbmctZ2xhc3MtcGx1cycsXG4gICAgc3R5bGU6IHtcbiAgICAgIGNzc0NsYXNzZXM6ICdpY29uLXNpemUtOSB0ZXh0LXhsIHRleHQtcHJpbWFyeS02MDAnLFxuICAgICAgY29udGVudFdpZHRoOiAnJyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnJyxcbiAgICAgIGFsaWduQ29udGVudDogJycsXG4gICAgfSxcbiAgICBvbkljb25DbGlja2VkOiB0aGlzLnpvb21JbkZuLmJpbmQodGhpcylcbiAgfTtcbiAgcHJvdGVjdGVkIHJlYWRvbmx5IHpvb21PdXRJY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ3pvb21PdXQwJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmljb24sXG4gICAgaWNvbk5hbWU6ICdoZXJvaWNvbnNfb3V0bGluZTptYWduaWZ5aW5nLWdsYXNzLW1pbnVzJyxcbiAgICBzdHlsZToge1xuICAgICAgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS05IHRleHQteGwgdGV4dC1wcmltYXJ5LTYwMCcsXG4gICAgICBjb250ZW50V2lkdGg6ICcnLFxuICAgICAganVzdGlmeUNvbnRlbnQ6ICcnLFxuICAgICAgYWxpZ25Db250ZW50OiAnJyxcbiAgICB9LFxuICAgIG9uSWNvbkNsaWNrZWQ6IHRoaXMuem9vbU91dEZuLmJpbmQodGhpcylcbiAgfTtcbiAgcHJvdGVjdGVkIHJlYWRvbmx5IHJlc2V0SWNvblpvb21Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAnem9vbU91dDAnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBpY29uTmFtZTogJ2hlcm9pY29uc19vdXRsaW5lOmFycm93LXBhdGgnLFxuICAgIHN0eWxlOiB7XG4gICAgICBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTkgdGV4dC14bCB0ZXh0LXByaW1hcnktNjAwJyxcbiAgICAgIGNvbnRlbnRXaWR0aDogJycsXG4gICAgICBqdXN0aWZ5Q29udGVudDogJycsXG4gICAgICBhbGlnbkNvbnRlbnQ6ICcnLFxuICAgIH0sXG4gICAgb25JY29uQ2xpY2tlZDogdGhpcy5yZXNldFpvb21Gbi5iaW5kKHRoaXMpXG4gIH07XG4gIHByb3RlY3RlZCByZWFkb25seSBleHBhbnNpb25JY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ2V4cGFuZDAnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBpY29uTmFtZTogJ2hlcm9pY29uc19vdXRsaW5lOmFycm93cy1wb2ludGluZy1vdXQnLFxuICAgIHN0eWxlOiB7XG4gICAgICBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTkgdGV4dC0zeGwgdy0xMCB0ZXh0LXByaW1hcnktNjAwIGJvcmRlci1sLTIgYm9yZGVyLWdyYXktNDAwIHBsLTInLFxuICAgICAgY29udGVudFdpZHRoOiAnJyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnJyxcbiAgICAgIGFsaWduQ29udGVudDogJycsXG4gICAgfSxcbiAgICBvbkljb25DbGlja2VkOiB0aGlzLm9uRXhwYW5zaW9uSWNvbkNsaWNrZWQuYmluZCh0aGlzKVxuICB9O1xuICBwcm90ZWN0ZWQgcmVhZG9ubHkgcGFnZU51bWJlckluY3JlbWVudEljb246IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICdwYWdlSW5jcmVtZW50MCcsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIGljb25OYW1lOiAnaGVyb2ljb25zX291dGxpbmU6Y2hldnJvbi1yaWdodCcsXG4gICAgc3R5bGU6IHtcbiAgICAgIGNzc0NsYXNzZXM6ICdpY29uLXNpemUtOSB0ZXh0LXhsIHRleHQtcHJpbWFyeS02MDAnLFxuICAgICAgY29udGVudFdpZHRoOiAnJyxcbiAgICAgIGp1c3RpZnlDb250ZW50OiAnJyxcbiAgICAgIGFsaWduQ29udGVudDogJycsXG4gICAgfSxcbiAgICBvbkljb25DbGlja2VkOiB0aGlzLnBhZ2VOdW1iZXJJbmNyZW1lbnQuYmluZCh0aGlzKVxuICB9O1xuICBwcm90ZWN0ZWQgcmVhZG9ubHkgcGFnZU51bWJlckRlY3JlbWVudEljb246IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICdwYWdlSW5jcmVtZW50MCcsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIGljb25OYW1lOiAnaGVyb2ljb25zX291dGxpbmU6Y2hldnJvbi1sZWZ0JyxcbiAgICBzdHlsZToge1xuICAgICAgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS05IHRleHQteGwgdGV4dC1wcmltYXJ5LTYwMCcsXG4gICAgICBjb250ZW50V2lkdGg6ICcnLFxuICAgICAganVzdGlmeUNvbnRlbnQ6ICcnLFxuICAgICAgYWxpZ25Db250ZW50OiAnJyxcbiAgICB9LFxuICAgIG9uSWNvbkNsaWNrZWQ6IHRoaXMucGFnZU51bWJlckRlY3JlbWVudC5iaW5kKHRoaXMpXG4gIH07XG5cbiAgcHJvdGVjdGVkIHJlYWRvbmx5IGdvVG9QYWdlSW5wdXRQcm9wZXJ0aWVzOiBDbElucHV0UHJvcGVydGllcyA9IHtcbiAgICBpZDogJ2dvVG8wJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmlucHV0LFxuICAgIHBsYWNlaG9sZGVyOiAnUGFnZSBOdW1iZXInLFxuICAgIGFwcGVhcmFuY2U6ICdmaWxsJyxcbiAgICBpbnB1dFR5cGU6IENsSW5wdXRUeXBlLm51bWJlcixcbiAgICBvblZhbHVlQ2hhbmdlOiB0aGlzLmdvVG9QYWdlLmJpbmQodGhpcylcbiAgfVxuXG4gIC8vIGNvbW1vbiB2YXJpYWJsZVxuICBwcm90ZWN0ZWQgZmlsZVR5cGU6IHN0cmluZyA9ICcnO1xuICBwcm90ZWN0ZWQgc2NhbGU6IG51bWJlciA9IDE7XG4gIC8vIEltYWdlIHpvb20gdmFyaWFibGVcbiAgcHJvdGVjdGVkIGJsb2JVcmw6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBwcm90ZWN0ZWQgaW1hZ2VUcmFuc2Zvcm06IHN0cmluZyA9IGBzY2FsZSgkeyB0aGlzLnNjYWxlIH0pYDtcbiAgcHJvdGVjdGVkIGltYWdlUG9zaXRpb246IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSA9IHsgeDogMCwgeTogMCB9O1xuICBwcm90ZWN0ZWQgaXNEcmFnZ2luZzogYm9vbGVhbiA9IGZhbHNlO1xuICBwcm90ZWN0ZWQgbGFzdE1vdXNlUG9zaXRpb246IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSA9IHsgeDogMCwgeTogMCB9O1xuICAvLyBFbmQgb2YgSW1hZ2Ugem9vbSB2YXJpYWJsZVxuXG4gIC8vIHBkZiB2YXJpYWJsZVxuICBwcm90ZWN0ZWQgcGRmRGF0YTogYW55O1xuICBwcm90ZWN0ZWQgcGFnZU51bWJlcjogbnVtYmVyID0gMTtcbiAgcHJvdGVjdGVkIHRvdGFsUGFnZVNpemU6IG51bWJlciA9IDA7XG4gIHByb3RlY3RlZCBnb1BhZ2VJbmRleCA9IDE7XG4gIC8vIEVuZCBvZiBwZGYgdmFyaWFibGVcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsRmlsZVByZXZpZXdQcm9wZXJ0aWVzKCk7XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nT25DaGFuZ2VzKF9jaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5maWxlVHlwZSA9PSBDbEZpbGVQcmV2aWV3VHlwZS5qcGcgfHwgdGhpcy5wcm9wZXJ0aWVzLmZpbGVUeXBlID09IENsRmlsZVByZXZpZXdUeXBlLnBuZyB8fCB0aGlzLnByb3BlcnRpZXMuZmlsZVR5cGUgPT0gQ2xGaWxlUHJldmlld1R5cGUuc3ZnKSB7XG4gICAgICB0aGlzLmZpbGVUeXBlID0gJ0ltYWdlJztcbiAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMuYmFzZTY0KSB7XG4gICAgICAgIHRoaXMuY29udmVydEJhc2U2NFRvQmxvYlVybCh0aGlzLnByb3BlcnRpZXMuYmFzZTY0KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmZpbGVUeXBlID09IENsRmlsZVByZXZpZXdUeXBlLnBkZikge1xuICAgICAgdGhpcy5maWxlVHlwZSA9ICdQZGYnO1xuICAgICAgaWYgKHRoaXMucHJvcGVydGllcy5iYXNlNjQpIHtcbiAgICAgICAgdGhpcy5wZGZEYXRhID0gdGhpcy5wcm9wZXJ0aWVzLmJhc2U2NDtcbiAgICAgICAgdGhpcy5sb2FkUGRmKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBjb252ZXJ0QmFzZTY0VG9CbG9iVXJsKGJhc2U2NDogc3RyaW5nKTogdm9pZCB7XG4gICAgLy8gQ29udmVydCBiYXNlNjQgc3RyaW5nIHRvIGJpbmFyeVxuICAgIGNvbnN0IGJ5dGVDaGFyYWN0ZXJzID0gYXRvYihiYXNlNjQpO1xuICAgIGNvbnN0IGJ5dGVBcnJheSA9IG5ldyBVaW50OEFycmF5KGJ5dGVDaGFyYWN0ZXJzLmxlbmd0aCk7XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJ5dGVDaGFyYWN0ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBieXRlQXJyYXlbaV0gPSBieXRlQ2hhcmFjdGVycy5jaGFyQ29kZUF0KGkpO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBhIEJsb2Igb2JqZWN0XG4gICAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtieXRlQXJyYXldLCB7IHR5cGU6IHRoaXMucHJvcGVydGllcy5maWxlVHlwZSB9KTsgIC8vIEFkanVzdCB0aGUgTUlNRSB0eXBlIGFjY29yZGluZ2x5XG5cbiAgICAvLyBHZW5lcmF0ZSBCbG9iIFVSTFxuICAgIHRoaXMuYmxvYlVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gIH1cblxuICBwcml2YXRlIHpvb21JbkZuKCkge1xuICAgIGlmICh0aGlzLmZpbGVUeXBlID09ICdJbWFnZScpIHtcbiAgICAgIHRoaXMuem9vbUluKCk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuZmlsZVR5cGUgPT0gJ1BkZicpIHtcbiAgICAgIHRoaXMucGRmWm9vbUluKClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHpvb21PdXRGbigpIHtcbiAgICBpZiAodGhpcy5maWxlVHlwZSA9PSAnSW1hZ2UnKSB7XG4gICAgICB0aGlzLnpvb21PdXQoKTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5maWxlVHlwZSA9PSAnUGRmJykge1xuICAgICAgdGhpcy5wZGZab29tT3V0KClcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlc2V0Wm9vbUZuKCkge1xuICAgIGlmICh0aGlzLmZpbGVUeXBlID09ICdJbWFnZScpIHtcbiAgICAgIHRoaXMucmVzZXRab29tKCk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuZmlsZVR5cGUgPT0gJ1BkZicpIHtcbiAgICB9XG4gIH1cblxuXG4gIC8vIEltYWdlIFpvb20gZmVhdHVyZSBjb250cm9sIGZ1bnRpb25cblxuICAvLyB6b29tSW4oKSB7XG4gIC8vICAgdGhpcy5zY2FsZSArPSAwLjE7XG4gIC8vICAgdGhpcy51cGRhdGVJbWFnZVRyYW5zZm9ybSgpO1xuICAvLyB9XG5cbiAgLy8gem9vbU91dCgpIHtcbiAgLy8gICBpZiAodGhpcy5zY2FsZSA+IDAuMikge1xuICAvLyAgICAgdGhpcy5zY2FsZSAtPSAwLjE7XG4gIC8vICAgICB0aGlzLnVwZGF0ZUltYWdlVHJhbnNmb3JtKCk7XG4gIC8vICAgfVxuICAvLyB9XG5cbiAgLy8gcHJpdmF0ZSB1cGRhdGVJbWFnZVRyYW5zZm9ybSgpIHtcbiAgLy8gICB0aGlzLmltYWdlVHJhbnNmb3JtID0gYHNjYWxlKCR7dGhpcy5zY2FsZX0pYDtcbiAgLy8gfVxuXG4gIHpvb21JbigpIHtcbiAgICB0aGlzLnNjYWxlICs9IDAuMTtcbiAgICB0aGlzLnVwZGF0ZUltYWdlVHJhbnNmb3JtKCk7XG4gIH1cblxuICB6b29tT3V0KCkge1xuICAgIGlmICh0aGlzLnNjYWxlID4gMC4yKSB7XG4gICAgICB0aGlzLnNjYWxlIC09IDAuMTtcbiAgICAgIHRoaXMudXBkYXRlSW1hZ2VUcmFuc2Zvcm0oKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHVwZGF0ZUltYWdlVHJhbnNmb3JtKCkge1xuICAgIHRoaXMuaW1hZ2VUcmFuc2Zvcm0gPSBgc2NhbGUoJHsgdGhpcy5zY2FsZSB9KSB0cmFuc2xhdGUoJHsgdGhpcy5pbWFnZVBvc2l0aW9uLnggfXB4LCAkeyB0aGlzLmltYWdlUG9zaXRpb24ueSB9cHgpYDtcbiAgfVxuXG4gIG9uTW91c2VEb3duKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB0aGlzLmlzRHJhZ2dpbmcgPSB0cnVlO1xuICAgIHRoaXMubGFzdE1vdXNlUG9zaXRpb24gPSB7IHg6IGV2ZW50LmNsaWVudFgsIHk6IGV2ZW50LmNsaWVudFkgfTtcbiAgfVxuXG4gIG9uTW91c2VNb3ZlKGV2ZW50OiBNb3VzZUV2ZW50KSB7XG4gICAgaWYgKCF0aGlzLmlzRHJhZ2dpbmcpIHJldHVybjtcblxuICAgIGNvbnN0IGRlbHRhWCA9IGV2ZW50LmNsaWVudFggLSB0aGlzLmxhc3RNb3VzZVBvc2l0aW9uLng7XG4gICAgY29uc3QgZGVsdGFZID0gZXZlbnQuY2xpZW50WSAtIHRoaXMubGFzdE1vdXNlUG9zaXRpb24ueTtcblxuICAgIHRoaXMuaW1hZ2VQb3NpdGlvbi54ICs9IGRlbHRhWDtcbiAgICB0aGlzLmltYWdlUG9zaXRpb24ueSArPSBkZWx0YVk7XG5cbiAgICB0aGlzLnVwZGF0ZUltYWdlVHJhbnNmb3JtKCk7XG4gICAgdGhpcy5sYXN0TW91c2VQb3NpdGlvbiA9IHsgeDogZXZlbnQuY2xpZW50WCwgeTogZXZlbnQuY2xpZW50WSB9O1xuICB9XG5cbiAgb25Nb3VzZVVwKCkge1xuICAgIHRoaXMuaXNEcmFnZ2luZyA9IGZhbHNlO1xuICB9XG5cbiAgb25Nb3VzZU91dCgpIHtcbiAgICB0aGlzLmlzRHJhZ2dpbmcgPSBmYWxzZTtcbiAgfVxuXG4gIHJlc2V0Wm9vbSgpIHtcbiAgICB0aGlzLnNjYWxlID0gMTtcbiAgICB0aGlzLmltYWdlVHJhbnNmb3JtID0gYHNjYWxlKCR7IHRoaXMuc2NhbGUgfSlgO1xuICAgIHRoaXMuaW1hZ2VQb3NpdGlvbiA9IHsgeDogMCwgeTogMCB9O1xuICAgIHRoaXMuaXNEcmFnZ2luZyA9IGZhbHNlO1xuICAgIHRoaXMubGFzdE1vdXNlUG9zaXRpb24gPSB7IHg6IDAsIHk6IDAgfTtcbiAgfVxuXG4gIC8vIEVuZCBvZiBJbWFnZSBab29tIGZlYXR1cmUgY29udHJvbCBmdW5jdGlvblxuXG4gIC8vIFBkZiBmaWxlIGxvYWQgYW5kIHpvb20gZmVhdHVyZSBmdW5jdGlvblxuICBsb2FkUGRmKCk6IHZvaWQge1xuICAgIGNvbnN0IGxvYWRpbmdUYXNrID0gcGRmanNMaWIuZ2V0RG9jdW1lbnQoeyBkYXRhOiBhdG9iKHRoaXMucGRmRGF0YSkgfSk7XG5cbiAgICBsb2FkaW5nVGFzay5wcm9taXNlLnRoZW4oKHBkZikgPT4ge1xuICAgICAgdGhpcy50b3RhbFBhZ2VTaXplID0gcGRmLm51bVBhZ2VzO1xuXG4gICAgICBwZGYuZ2V0UGFnZSh0aGlzLnBhZ2VOdW1iZXIpLnRoZW4oKHBhZ2UpID0+IHtcblxuICAgICAgICBjb25zdCBzY2FsZSA9IHRoaXMuc2NhbGU7XG4gICAgICAgIGNvbnN0IHZpZXdwb3J0ID0gcGFnZS5nZXRWaWV3cG9ydCh7IHNjYWxlOiBzY2FsZSB9KTtcblxuICAgICAgICAvLyBQcmVwYXJlIGNhbnZhcyB1c2luZyBQREYgcGFnZSBkaW1lbnNpb25zXG4gICAgICAgIGNvbnN0IGNhbnZhczogSFRNTENhbnZhc0VsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncGRmQ2FudmFzJykgYXMgSFRNTENhbnZhc0VsZW1lbnQ7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSBjYW52YXMuZ2V0Q29udGV4dCgnMmQnKTtcblxuICAgICAgICAvLyBDaGVjayBpZiBjb250ZXh0IGlzIG5vdCBudWxsXG4gICAgICAgIGlmIChjb250ZXh0KSB7XG4gICAgICAgICAgY2FudmFzLmhlaWdodCA9IHZpZXdwb3J0LmhlaWdodDtcbiAgICAgICAgICBjYW52YXMud2lkdGggPSB2aWV3cG9ydC53aWR0aDtcblxuICAgICAgICAgIC8vIFJlbmRlciBQREYgcGFnZSBpbnRvIGNhbnZhcyBjb250ZXh0XG4gICAgICAgICAgY29uc3QgcmVuZGVyQ29udGV4dCA9IHtcbiAgICAgICAgICAgIGNhbnZhc0NvbnRleHQ6IGNvbnRleHQsXG4gICAgICAgICAgICB2aWV3cG9ydDogdmlld3BvcnRcbiAgICAgICAgICB9O1xuXG4gICAgICAgICAgY29uc3QgcmVuZGVyVGFzayA9IHBhZ2UucmVuZGVyKHJlbmRlckNvbnRleHQpO1xuXG4gICAgICAgICAgcmVuZGVyVGFzay5wcm9taXNlLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ1BhZ2UgcmVuZGVyZWQnKTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZ2V0IDJEIGNvbnRleHQgZm9yIGNhbnZhcycpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9LCAocmVhc29uKSA9PiB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBsb2FkaW5nIFBERicsIHJlYXNvbik7XG4gICAgfSk7XG4gIH1cblxuICBwYWdlTnVtYmVySW5jcmVtZW50KCkge1xuICAgIGlmICgodGhpcy5wYWdlTnVtYmVyICsgMSkgPCB0aGlzLnRvdGFsUGFnZVNpemUpIHtcbiAgICAgIHRoaXMucGFnZU51bWJlciArPSAxO1xuICAgICAgdGhpcy5nb1BhZ2VJbmRleCA9IHRoaXMucGFnZU51bWJlcjtcbiAgICAgIHRoaXMubG9hZFBkZigpO1xuICAgIH1cbiAgfVxuXG4gIHBhZ2VOdW1iZXJEZWNyZW1lbnQoKSB7XG4gICAgaWYgKCh0aGlzLnBhZ2VOdW1iZXIgLSAxKSA+IDApIHtcbiAgICAgIHRoaXMucGFnZU51bWJlciAtPSAxO1xuICAgICAgdGhpcy5nb1BhZ2VJbmRleCA9IHRoaXMucGFnZU51bWJlcjtcbiAgICAgIHRoaXMubG9hZFBkZigpO1xuICAgIH1cbiAgfVxuXG4gIHBkZlpvb21JbigpIHtcbiAgICB0aGlzLnNjYWxlICs9IDAuMTtcbiAgICB0aGlzLmxvYWRQZGYoKTtcbiAgfVxuXG4gIHBkZlpvb21PdXQoKSB7XG4gICAgdGhpcy5zY2FsZSAtPSAwLjE7XG4gICAgdGhpcy5sb2FkUGRmKCk7XG4gIH1cblxuICBnb1RvUGFnZSh2YWw6IHN0cmluZykge1xuICAgIGlmIChOdW1iZXIodmFsKSA+PSAxKSB7XG4gICAgICB0aGlzLnBhZ2VOdW1iZXIgPSBOdW1iZXIodmFsKTtcbiAgICAgIHRoaXMubG9hZFBkZigpO1xuICAgIH1cbiAgfVxuXG4gIG9uRXhwYW5zaW9uSWNvbkNsaWNrZWQoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vbkV4cGFuc2lvbkljb25DbGlja2VkICE9IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uRXhwYW5zaW9uSWNvbkNsaWNrZWQoKTtcbiAgICB9XG4gIH1cblxufVxuIiwiPCEtLSA8bWF0LWNhcmQgY2xhc3M9XCJ7e3Byb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXN9fSBmbGV4IHctZnVsbCBoLWZ1bGxcIj5cbiAgPG1hdC1jYXJkLWhlYWRlciBjbGFzcz1cImZsZXggZmxleC1yb3cganVzdGlmeS1iZXR3ZWVuIGJnLXdoaXRlLTIwMCBwLTRcIj5cbiAgICA8bWF0LWNhcmQtdGl0bGUgY2xhc3M9XCJmb250LWJvbGQgdGV4dC1sZ1wiPnt7IHByb3BlcnRpZXMuZmlsZU5hbWUgfX08L21hdC1jYXJkLXRpdGxlPlxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtcm93IGdhcC00XCI+XG4gICAgICA8Y2wtaWNvbiBbcHJvcGVydGllc109XCJ6b29tSW5JY29uUHJvcGVydGllc1wiPjwvY2wtaWNvbj5cbiAgICAgIDxjbC1pY29uIFtwcm9wZXJ0aWVzXT1cInpvb21PdXRJY29uUHJvcGVydGllc1wiPjwvY2wtaWNvbj5cbiAgICA8L2Rpdj5cbiAgPC9tYXQtY2FyZC1oZWFkZXI+XG5cbiAgPG1hdC1jYXJkLWNvbnRlbnQgY2xhc3M9XCJmbGV4LWdyb3cgb3ZlcmZsb3ctc2Nyb2xsIHJlbGF0aXZlXCI+XG4gICAgICA8aW1nIFtzcmNdPVwiYmxvYlVybFwiIGFsdD1cIkJhc2U2NCBJbWFnZVwiIFtuZ1N0eWxlXT1cInsndHJhbnNmb3JtJzogaW1hZ2VUcmFuc2Zvcm19XCI+XG4gIDwvbWF0LWNhcmQtY29udGVudD5cbjwvbWF0LWNhcmQ+IC0tPlxuXG48bWF0LWNhcmQgY2xhc3M9XCJmbGV4IHctZnVsbCBoLWZ1bGwge3twcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzfX1cIj5cbiAgPG1hdC1jYXJkLWhlYWRlciBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGJnLXdoaXRlIHAtNCBib3JkZXItYi0yXCI+XG4gICAgPG1hdC1jYXJkLXRpdGxlIGNsYXNzPVwiZm9udC1ib2xkIHRleHQtbGdcIj57eyBwcm9wZXJ0aWVzLmZpbGVOYW1lIH19PC9tYXQtY2FyZC10aXRsZT5cbiAgICA8ZGl2IGNsYXNzPVwiZmxleCBnYXAtNFwiPlxuICAgICAgPGNsLWljb24gW3Byb3BlcnRpZXNdPVwiem9vbUluSWNvblByb3BlcnRpZXNcIj48L2NsLWljb24+XG4gICAgICA8Y2wtaWNvbiBbcHJvcGVydGllc109XCJ6b29tT3V0SWNvblByb3BlcnRpZXNcIj48L2NsLWljb24+XG4gICAgICA8Y2wtaWNvbiBbcHJvcGVydGllc109XCJyZXNldEljb25ab29tUHJvcGVydGllc1wiPjwvY2wtaWNvbj5cbiAgICAgIEBpZihwcm9wZXJ0aWVzLnNob3dFeHBhbnNpb25JY29uKXtcbiAgICAgICAgPGNsLWljb24gW3Byb3BlcnRpZXNdPVwiZXhwYW5zaW9uSWNvblByb3BlcnRpZXNcIj48L2NsLWljb24+XG4gICAgICB9XG4gICAgPC9kaXY+XG4gIDwvbWF0LWNhcmQtaGVhZGVyPlxuXG4gIDxtYXQtY2FyZC1jb250ZW50IGNsYXNzPVwiZmxleC1ncm93IHJlbGF0aXZlIG92ZXJmbG93LWhpZGRlbiBiZy1wcmltYXJ5LTUwXCI+XG4gICAgQGlmKGZpbGVUeXBlID09ICdJbWFnZScpe1xuICAgICAgPGRpdiBjbGFzcz1cInJlbGF0aXZlIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIHctZnVsbCBoLWZ1bGwgbWF4LWgtbHZoIGN1cnNvci1ncmFiXCIgKG1vdXNlZG93bik9XCJvbk1vdXNlRG93bigkZXZlbnQpXCJcbiAgICAgICAgKG1vdXNlbW92ZSk9XCJvbk1vdXNlTW92ZSgkZXZlbnQpXCIgKG1vdXNldXApPVwib25Nb3VzZVVwKClcIiAobW91c2VvdXQpPVwib25Nb3VzZU91dCgpXCI+XG4gICAgICAgIDxpbWcgW3NyY109XCJibG9iVXJsXCIgYWx0PVwiQmFzZTY0IEltYWdlXCIgW25nU3R5bGVdPVwieyAndHJhbnNmb3JtJzogaW1hZ2VUcmFuc2Zvcm0gfVwiXG4gICAgICAgICAgY2xhc3M9XCJ0cmFuc2l0aW9uLXRyYW5zZm9ybSBkdXJhdGlvbi0zMDAgZWFzZS1pbi1vdXRcIiAvPlxuICAgICAgPC9kaXY+XG4gICAgfVxuICAgIEBpZihmaWxlVHlwZSA9PSAnUGRmJyl7XG4gICAgICA8IS0tIDxjYW52YXMgI3BkZkNhbnZhcz48L2NhbnZhcz4gLS0+XG4gICAgICA8ZGl2IGNsYXNzPVwidy1mdWxsIGgtZnVsbCBvdmVyZmxvdy1hdXRvIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgIDxjYW52YXMgaWQ9XCJwZGZDYW52YXNcIj48L2NhbnZhcz5cbiAgICAgIDwvZGl2PlxuICAgIH1cbiAgPC9tYXQtY2FyZC1jb250ZW50PlxuICBAaWYoZmlsZVR5cGUgPT0gJ1BkZicpe1xuICAgIDxtYXQtY2FyZC1hY3Rpb25zIGNsYXNzPVwiZmxleCBmbGV4LXJvdyBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtc3RhcnQgdGV4dC14bCBmb250LWJvbGRcIj5cbiAgICAgICAgVG90YWwgUGFnZToge3t0b3RhbFBhZ2VTaXplfX1cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cImZsZXggZmxleC1yb3cganVzdGlmeS1jZW50ZXIgZ2FwLThcIj5cbiAgICAgICAgPGNsLWljb24gW3Byb3BlcnRpZXNdPVwicGFnZU51bWJlckRlY3JlbWVudEljb25cIj48L2NsLWljb24+XG4gICAgICAgIDxjbC1pY29uIFtwcm9wZXJ0aWVzXT1cInBhZ2VOdW1iZXJJbmNyZW1lbnRJY29uXCI+PC9jbC1pY29uPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWVuZFwiPlxuICAgICAgICA8Y2wtaW5wdXQgW3Byb3BlcnRpZXNdPVwiZ29Ub1BhZ2VJbnB1dFByb3BlcnRpZXNcIiBbKG5nTW9kZWwpXT1cImdvUGFnZUluZGV4XCI+PC9jbC1pbnB1dD5cbiAgICAgIDwvZGl2PlxuICAgIDwvbWF0LWNhcmQtYWN0aW9ucz5cbiAgfVxuPC9tYXQtY2FyZD5cbiJdfQ==