import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { Self, Input, Optional, Component } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClCheckboxProperties } from './checkbox.properties';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/checkbox";
export class ClCheckboxComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClCheckboxProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'INVALID' && this.ngControl.errors) {
                if (this.properties.isReactiveFormControl) {
                    const keys = Object.keys(this.ngControl.errors);
                    this.error = getErrorMessage(keys[0], this.properties.errorsList);
                }
                else {
                    this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
                }
                // this.error = this.ngControl.errors ? this.ngControl.errors!['error'] : null;
            }
            else if (changes === 'VALID') {
                this.error = null;
            }
        });
    }
    writeValue(value) {
        this.properties.checked = value;
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        this._value = this.properties.checked ?? false;
        return this._value;
    }
    onValueChanged(event) {
        this.writeValue(event.checked);
        this.onChange(this._value);
        if (this.properties.onValueChanged) {
            this.properties.onValueChanged(this._value);
        }
    }
    get isDisabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        // this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCheckboxComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClCheckboxComponent, isStandalone: true, selector: "cl-checkbox", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-checkbox color=\"primary\" [checked]=\"value\" class=\"flex w-full\" [id]=\"properties.id\" [disabled]=\"isDisabled\"\n  (change)=\"onValueChanged($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n  <div class=\"flex w-full items-center\">\n    <div class=\"{{ properties.style?.labelCssClasses }} select-none\">{{ properties.label }}</div>\n\n    @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n    }\n  </div>\n</mat-checkbox>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i3.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCheckboxComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-checkbox', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        ClTooltipDirective
                    ], template: "<mat-checkbox color=\"primary\" [checked]=\"value\" class=\"flex w-full\" [id]=\"properties.id\" [disabled]=\"isDisabled\"\n  (change)=\"onValueChanged($event)\" (blur)=\"onTouched($any($event.target).value)\">\n\n  <div class=\"flex w-full items-center\">\n    <div class=\"{{ properties.style?.labelCssClasses }} select-none\">{{ properties.label }}</div>\n\n    @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n    }\n\n    @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n    }\n  </div>\n</mat-checkbox>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3guY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9jaGVja2JveC9jaGVja2JveC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NoZWNrYm94L2NoZWNrYm94LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUUvRCxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQWEsU0FBUyxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUUzRixPQUFPLEVBQUUsZUFBZSxFQUFrQixNQUFNLDRCQUE0QixDQUFDO0FBQzdFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQzs7Ozs7QUFhdkUsTUFBTSxPQUFPLG1CQUFvQixTQUFRLGVBQWU7SUFnQnRELFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFSNUQsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFhMUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFckMsdUdBQXVHO1FBQ3ZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksb0JBQW9CLEVBQUUsQ0FBQztRQUUvQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELGVBQWU7UUFDYixLQUFLLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLE9BQU8sS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDbkQsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7b0JBQ3pDLE1BQU0sSUFBSSxHQUE2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUE2QixDQUFDO29CQUN0RyxJQUFJLENBQUMsS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLENBQUMsQ0FBQztnQkFDckUsQ0FBQztxQkFBTSxDQUFDO29CQUNOLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQzdFLENBQUM7Z0JBQ0QsK0VBQStFO1lBQ2pGLENBQUM7aUJBQU0sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1lBQ3BCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDaEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFrQjtRQUNsQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQTtJQUNyQixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUM7UUFFL0MsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3JCLENBQUM7SUFFTSxjQUFjLENBQUMsS0FBVTtRQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUUvQixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUzQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzlDLENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBVyxVQUFVO1FBQ25CLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDMUMsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ2xDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVELElBQVcsV0FBVztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzdDLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDcEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUNyQyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFUSxXQUFXO1FBQ2xCOzs7VUFHRTtRQUVGLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFDeEIsdUNBQXVDO1FBRXZDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQix1R0FBdUc7SUFDekcsQ0FBQzs4R0F4SFUsbUJBQW1CO2tHQUFuQixtQkFBbUIsb0lDdkJoQyw2dEJBaUJBLDJDREFJLGFBQWEsbUxBQ2IsZ0JBQWdCLDhCQUNoQixpQkFBaUIscVlBQ2pCLGtCQUFrQjs7MkZBR1QsbUJBQW1CO2tCQVgvQixTQUFTO2lDQUNJLElBQUksWUFDTixhQUFhLFdBRWQ7d0JBQ1AsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLGlCQUFpQjt3QkFDakIsa0JBQWtCO3FCQUNuQjs7MEJBa0JhLFFBQVE7OzBCQUFJLElBQUk7eUNBZGQsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdFRvb2x0aXBNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sdGlwJztcbmltcG9ydCB7IE1hdENoZWNrYm94TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvY2hlY2tib3gnO1xuaW1wb3J0IHsgTmdDb250cm9sLCBWYWxpZGF0aW9uRXJyb3JzLCBDb250cm9sVmFsdWVBY2Nlc3NvciB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IFNlbGYsIElucHV0LCBPcHRpb25hbCwgT25EZXN0cm95LCBDb21wb25lbnQsIEFmdGVyVmlld0luaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50LCBDbEVycm9ySGFuZGxlciB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsQ2hlY2tib3hQcm9wZXJ0aWVzIH0gZnJvbSAnLi9jaGVja2JveC5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWNoZWNrYm94JyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NoZWNrYm94LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0VG9vbHRpcE1vZHVsZSxcbiAgICBNYXRDaGVja2JveE1vZHVsZSxcbiAgICBDbFRvb2x0aXBEaXJlY3RpdmVcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBDbENoZWNrYm94Q29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xDaGVja2JveFByb3BlcnRpZXM7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcblxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgcHJpdmF0ZSBzdWI/OiBTdWJzY3JpcHRpb247XG4gIHByaXZhdGUgZXJyb3I/OiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbDtcblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG5cbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbENoZWNrYm94UHJvcGVydGllcygpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICB0aGlzLnN1YiA9IHRoaXMubmdDb250cm9sPy5zdGF0dXNDaGFuZ2VzIS5zdWJzY3JpYmUoY2hhbmdlcyA9PiB7XG4gICAgICBpZiAoY2hhbmdlcyA9PT0gJ0lOVkFMSUQnICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgICBpZih0aGlzLnByb3BlcnRpZXMuaXNSZWFjdGl2ZUZvcm1Db250cm9sKSB7XG4gICAgICAgICAgY29uc3Qga2V5czogKGtleW9mIENsRXJyb3JIYW5kbGVyKVtdID0gT2JqZWN0LmtleXModGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSBhcyAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW107XG4gICAgICAgICAgdGhpcy5lcnJvciA9IGdldEVycm9yTWVzc2FnZShrZXlzWzBdLCB0aGlzLnByb3BlcnRpZXMuZXJyb3JzTGlzdCEpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuZXJyb3IgPSB0aGlzLm5nQ29udHJvbC5lcnJvcnMgPyB0aGlzLm5nQ29udHJvbC5lcnJvcnNbJ2Vycm9yJ10gOiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIC8vIHRoaXMuZXJyb3IgPSB0aGlzLm5nQ29udHJvbC5lcnJvcnMgPyB0aGlzLm5nQ29udHJvbC5lcnJvcnMhWydlcnJvciddIDogbnVsbDtcbiAgICAgIH0gZWxzZSBpZiAoY2hhbmdlcyA9PT0gJ1ZBTElEJykge1xuICAgICAgICB0aGlzLmVycm9yID0gbnVsbDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcy5jaGVja2VkID0gdmFsdWU7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgdGhpcy5fdmFsdWUgPSB0aGlzLnByb3BlcnRpZXMuY2hlY2tlZCA/PyBmYWxzZTtcblxuICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgfVxuXG4gIHB1YmxpYyBvblZhbHVlQ2hhbmdlZChldmVudDogYW55KSB7XG4gICAgdGhpcy53cml0ZVZhbHVlKGV2ZW50LmNoZWNrZWQpO1xuXG4gICAgdGhpcy5vbkNoYW5nZSh0aGlzLl92YWx1ZSk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uVmFsdWVDaGFuZ2VkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZWQodGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBnZXQgaXNEaXNhYmxlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIC8qKlxuICAgICogISEgV2FybmluZyAhIVxuICAgICogVGhlIGJlbG93IHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAqL1xuXG4gICAgdGhpcy5zdWI/LnVuc3Vic2NyaWJlKCk7XG4gICAgLy8gdGhpcy52YWx1ZUNoYW5nZXNTdWI/LnVuc3Vic2NyaWJlKCk7XG5cbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxufVxuIiwiPG1hdC1jaGVja2JveCBjb2xvcj1cInByaW1hcnlcIiBbY2hlY2tlZF09XCJ2YWx1ZVwiIGNsYXNzPVwiZmxleCB3LWZ1bGxcIiBbaWRdPVwicHJvcGVydGllcy5pZFwiIFtkaXNhYmxlZF09XCJpc0Rpc2FibGVkXCJcbiAgKGNoYW5nZSk9XCJvblZhbHVlQ2hhbmdlZCgkZXZlbnQpXCIgKGJsdXIpPVwib25Ub3VjaGVkKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCI+XG5cbiAgPGRpdiBjbGFzcz1cImZsZXggdy1mdWxsIGl0ZW1zLWNlbnRlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN0eWxlPy5sYWJlbENzc0NsYXNzZXMgfX0gc2VsZWN0LW5vbmVcIj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9kaXY+XG5cbiAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwpIHtcbiAgICAgIDxzcGFuIGNsYXNzPVwib3B0aW9uYWwtdGV4dFwiPihPcHRpb25hbCk8L3NwYW4+XG4gICAgfVxuXG4gICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCJcbiAgICAgICAgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmluZm9ybWF0aW9uLWNpcmNsZSdcIiBjbGFzcz1cIm1sLTEgaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXIgdGV4dC1uZXV0cmFsLTYwMFwiPlxuICAgICAgPC9tYXQtaWNvbj5cbiAgICB9XG4gIDwvZGl2PlxuPC9tYXQtY2hlY2tib3g+XG4iXX0=