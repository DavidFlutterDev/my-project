import { MatFormFieldModule } from '@angular/material/form-field';
import { Component, Input, forwardRef } from '@angular/core';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { ClTimerProperties } from './timer.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/form-field";
import * as i2 from "@angular/material/progress-spinner";
export class ClTimerComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClTimerProperties();
        this.timeInSeconds = this.properties.timeInSec;
        // calling update display time function
        this.updateDisplayTime();
        // calling calculate reverse progress function
        this.calculateReverseProgress();
        // calling start timer function
        this.startTimer();
        // calling on timer started function
        this.onTimerStarted();
        super.ngOnInit();
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    startTimer() {
        this.intervalId = setInterval(() => {
            if (this.timeInSeconds > 0) {
                this.timeInSeconds--;
            }
            else if (this.timeInSeconds <= 0) {
                // calling stop timer function
                this.stopTimer();
                if (this.properties.onTimerStopped) {
                    // calling on timer stopped callback function
                    this.properties.onTimerStopped();
                }
            }
            // calling update display time function
            this.updateDisplayTime();
            // calling calculate reverse progress function
            this.calculateReverseProgress();
        }, 1000);
    }
    stopTimer() {
        clearInterval(this.intervalId);
    }
    formatTime(time) {
        return time < 10 ? `0${time}` : `${time}`;
    }
    onTimerStarted() {
        if (this.properties.onTimerStarted != undefined) {
            this.properties.onTimerStarted();
        }
    }
    calculateReverseProgress() {
        const totalTime = this.properties.timeInSec;
        const remainingTime = this.timeInSeconds > 0 ? this.timeInSeconds : 0;
        const progress = (remainingTime / totalTime) * 100;
        // Ensure progress is between 0 and 100;
        this.remainingProgress = 100 - Math.max(0, Math.min(100 - progress, 100));
    }
    updateDisplayTime() {
        const seconds = this.timeInSeconds % 60;
        const hours = Math.floor(this.timeInSeconds / 3600);
        const minutes = Math.floor((this.timeInSeconds % 3600) / 60);
        if (hours <= 0) {
            // for showing minutes and seconds
            this.displayTime = `${this.formatTime(minutes)}:${this.formatTime(seconds)}`;
        }
        else {
            // for showing hours, minutes and seconds
            this.displayTime = `${this.formatTime(hours)}:${this.formatTime(minutes)}:${this.formatTime(seconds)}`;
        }
    }
    ngOnDestroy() {
        this.stopTimer();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClTimerComponent, isStandalone: true, selector: "cl-timer", inputs: { properties: "properties" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => ClTimerComponent),
                multi: true
            }
        ], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"countdown-container\">\n  <mat-progress-spinner mode=\"determinate\" [strokeWidth]=\"5\" [value]=\"remainingProgress\"\n    class=\"progress-spinner -scale-x-1 -scale-y--1\" style=\"width: 5rem; height: 5rem;\">\n  </mat-progress-spinner>\n\n  <mat-label class=\"time-display\">{{ displayTime }}</mat-label>\n</div>\n", styles: [".countdown-container{position:relative;display:flex;align-items:center;justify-content:center;height:100px;width:100px}.progress-spinner{position:absolute;top:0;left:0}.time-display{position:absolute;font-size:1.125rem;font-weight:400;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity));top:1.85rem!important;left:1.5rem!important}::ng-deep .countdown-container mat-progress-spinner circle{stroke-linecap:round;--mdc-circular-progress-active-indicator-color: var(--cl-primary-300)}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i1.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i2.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-timer', providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => ClTimerComponent),
                            multi: true
                        }
                    ], imports: [MatFormFieldModule, MatProgressSpinnerModule], template: "<div [id]=\"properties.id\" class=\"countdown-container\">\n  <mat-progress-spinner mode=\"determinate\" [strokeWidth]=\"5\" [value]=\"remainingProgress\"\n    class=\"progress-spinner -scale-x-1 -scale-y--1\" style=\"width: 5rem; height: 5rem;\">\n  </mat-progress-spinner>\n\n  <mat-label class=\"time-display\">{{ displayTime }}</mat-label>\n</div>\n", styles: [".countdown-container{position:relative;display:flex;align-items:center;justify-content:center;height:100px;width:100px}.progress-spinner{position:absolute;top:0;left:0}.time-display{position:absolute;font-size:1.125rem;font-weight:400;--tw-text-opacity: 1;color:rgb(38 38 38 / var(--tw-text-opacity));top:1.85rem!important;left:1.5rem!important}::ng-deep .countdown-container mat-progress-spinner circle{stroke-linecap:round;--mdc-circular-progress-active-indicator-color: var(--cl-primary-300)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy90aW1lci90aW1lci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RpbWVyL3RpbWVyLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNyRSxPQUFPLEVBQUUsd0JBQXdCLEVBQUUsTUFBTSxvQ0FBb0MsQ0FBQztBQUM5RSxPQUFPLEVBQXdCLGlCQUFpQixFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDekUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDdkQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7O0FBaUI3RCxNQUFNLE9BQU8sZ0JBQWlCLFNBQVEsZUFBZTtJQWNuRCw4Q0FBOEM7SUFDOUM7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQVJWLGFBQVEsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLGNBQVMsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBUTFCLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1FBQzVDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUM7UUFFL0MsdUNBQXVDO1FBQ3ZDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBRXpCLDhDQUE4QztRQUM5QyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUVoQywrQkFBK0I7UUFDL0IsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRWxCLG9DQUFvQztRQUNwQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFFdEIsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBQ0QsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUNELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFDRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDcEIsQ0FBQztJQUVPLFVBQVU7UUFDaEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsR0FBRyxFQUFFO1lBQ2pDLElBQUksSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3ZCLENBQUM7aUJBQU0sSUFBSSxJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNuQyw4QkFBOEI7Z0JBQzlCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFFakIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUNuQyw2Q0FBNkM7b0JBQzdDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ25DLENBQUM7WUFDSCxDQUFDO1lBRUQsdUNBQXVDO1lBQ3ZDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBRXpCLDhDQUE4QztZQUM5QyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNsQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRU8sU0FBUztRQUNmLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVPLFVBQVUsQ0FBQyxJQUFZO1FBQzdCLE9BQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSyxJQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBSSxJQUFLLEVBQUUsQ0FBQztJQUNoRCxDQUFDO0lBRU8sY0FBYztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDbkMsQ0FBQztJQUNILENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsTUFBTSxTQUFTLEdBQVcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFVLENBQUM7UUFDckQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUV0RSxNQUFNLFFBQVEsR0FBRyxDQUFDLGFBQWEsR0FBRyxTQUFTLENBQUMsR0FBRyxHQUFHLENBQUM7UUFFbkQsd0NBQXdDO1FBQ3hDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsUUFBUSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVPLGlCQUFpQjtRQUN2QixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFHLEVBQUUsQ0FBQztRQUN4QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDcEQsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7UUFFN0QsSUFBSSxLQUFLLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDZixrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLFdBQVcsR0FBRyxHQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFFLElBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUUsRUFBRSxDQUFDO1FBQ25GLENBQUM7YUFBTSxDQUFDO1lBQ04seUNBQXlDO1lBQ3pDLElBQUksQ0FBQyxXQUFXLEdBQUcsR0FBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBRSxJQUFLLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFFLElBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUUsRUFBRSxDQUFDO1FBQy9HLENBQUM7SUFDSCxDQUFDO0lBRVEsV0FBVztRQUNsQixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7SUFDbkIsQ0FBQzs4R0F2SFUsZ0JBQWdCO2tHQUFoQixnQkFBZ0IsNkZBVmhCO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLGlCQUFpQjtnQkFDMUIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDL0MsS0FBSyxFQUFFLElBQUk7YUFDWjtTQUNGLGlEQ2xCSCxtV0FPQSwwaUJEWVksa0JBQWtCLCtGQUFFLHdCQUF3Qjs7MkZBRzNDLGdCQUFnQjtrQkFmNUIsU0FBUztpQ0FDSSxJQUFJLFlBQ04sVUFBVSxhQUdUO3dCQUNUOzRCQUNFLE9BQU8sRUFBRSxpQkFBaUI7NEJBQzFCLFdBQVcsRUFBRSxVQUFVLENBQUMsR0FBRyxFQUFFLGlCQUFpQixDQUFDOzRCQUMvQyxLQUFLLEVBQUUsSUFBSTt5QkFDWjtxQkFDRixXQUNRLENBQUMsa0JBQWtCLEVBQUUsd0JBQXdCLENBQUM7d0RBS3ZDLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZm9ybS1maWVsZCc7XG5pbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIGZvcndhcmRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1hdFByb2dyZXNzU3Bpbm5lck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Byb2dyZXNzLXNwaW5uZXInO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5HX1ZBTFVFX0FDQ0VTU09SIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ2xUaW1lclByb3BlcnRpZXMgfSBmcm9tICcuL3RpbWVyLnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50IH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC10aW1lcicsXG4gIHRlbXBsYXRlVXJsOiAnLi90aW1lci5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3RpbWVyLmNvbXBvbmVudC5zY3NzJ10sXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgICAgdXNlRXhpc3Rpbmc6IGZvcndhcmRSZWYoKCkgPT4gQ2xUaW1lckNvbXBvbmVudCksXG4gICAgICBtdWx0aTogdHJ1ZVxuICAgIH1cbiAgXSxcbiAgaW1wb3J0czogW01hdEZvcm1GaWVsZE1vZHVsZSwgTWF0UHJvZ3Jlc3NTcGlubmVyTW9kdWxlXSxcbn0pXG5cbmV4cG9ydCBjbGFzcyBDbFRpbWVyQ29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBDb250cm9sVmFsdWVBY2Nlc3NvciB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xUaW1lclByb3BlcnRpZXM7XG5cbiAgcHVibGljIGRpc3BsYXlUaW1lOiBhbnk7XG4gIHByaXZhdGUgaW50ZXJ2YWxJZDogYW55O1xuICBwdWJsaWMgdGltZUluU2Vjb25kczogYW55O1xuICBwdWJsaWMgcmVtYWluaW5nUHJvZ3Jlc3M6IGFueTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsVGltZXJQcm9wZXJ0aWVzKCk7XG4gICAgdGhpcy50aW1lSW5TZWNvbmRzID0gdGhpcy5wcm9wZXJ0aWVzLnRpbWVJblNlYztcblxuICAgIC8vIGNhbGxpbmcgdXBkYXRlIGRpc3BsYXkgdGltZSBmdW5jdGlvblxuICAgIHRoaXMudXBkYXRlRGlzcGxheVRpbWUoKTtcblxuICAgIC8vIGNhbGxpbmcgY2FsY3VsYXRlIHJldmVyc2UgcHJvZ3Jlc3MgZnVuY3Rpb25cbiAgICB0aGlzLmNhbGN1bGF0ZVJldmVyc2VQcm9ncmVzcygpO1xuXG4gICAgLy8gY2FsbGluZyBzdGFydCB0aW1lciBmdW5jdGlvblxuICAgIHRoaXMuc3RhcnRUaW1lcigpO1xuXG4gICAgLy8gY2FsbGluZyBvbiB0aW1lciBzdGFydGVkIGZ1bmN0aW9uXG4gICAgdGhpcy5vblRpbWVyU3RhcnRlZCgpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gIH1cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG4gIGdldCB2YWx1ZSgpOiBhbnkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZVxuICB9XG5cbiAgcHJpdmF0ZSBzdGFydFRpbWVyKCkge1xuICAgIHRoaXMuaW50ZXJ2YWxJZCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnRpbWVJblNlY29uZHMgPiAwKSB7XG4gICAgICAgIHRoaXMudGltZUluU2Vjb25kcy0tO1xuICAgICAgfSBlbHNlIGlmICh0aGlzLnRpbWVJblNlY29uZHMgPD0gMCkge1xuICAgICAgICAvLyBjYWxsaW5nIHN0b3AgdGltZXIgZnVuY3Rpb25cbiAgICAgICAgdGhpcy5zdG9wVGltZXIoKTtcblxuICAgICAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uVGltZXJTdG9wcGVkKSB7XG4gICAgICAgICAgLy8gY2FsbGluZyBvbiB0aW1lciBzdG9wcGVkIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uVGltZXJTdG9wcGVkKCk7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gY2FsbGluZyB1cGRhdGUgZGlzcGxheSB0aW1lIGZ1bmN0aW9uXG4gICAgICB0aGlzLnVwZGF0ZURpc3BsYXlUaW1lKCk7XG5cbiAgICAgIC8vIGNhbGxpbmcgY2FsY3VsYXRlIHJldmVyc2UgcHJvZ3Jlc3MgZnVuY3Rpb25cbiAgICAgIHRoaXMuY2FsY3VsYXRlUmV2ZXJzZVByb2dyZXNzKCk7XG4gICAgfSwgMTAwMCk7XG4gIH1cblxuICBwcml2YXRlIHN0b3BUaW1lcigpIHtcbiAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWxJZCk7XG4gIH1cblxuICBwcml2YXRlIGZvcm1hdFRpbWUodGltZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGltZSA8IDEwID8gYDAkeyB0aW1lIH1gIDogYCR7IHRpbWUgfWA7XG4gIH1cblxuICBwcml2YXRlIG9uVGltZXJTdGFydGVkKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25UaW1lclN0YXJ0ZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25UaW1lclN0YXJ0ZWQoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNhbGN1bGF0ZVJldmVyc2VQcm9ncmVzcygpIHtcbiAgICBjb25zdCB0b3RhbFRpbWU6IG51bWJlciA9IHRoaXMucHJvcGVydGllcy50aW1lSW5TZWMhO1xuICAgIGNvbnN0IHJlbWFpbmluZ1RpbWUgPSB0aGlzLnRpbWVJblNlY29uZHMgPiAwID8gdGhpcy50aW1lSW5TZWNvbmRzIDogMDtcblxuICAgIGNvbnN0IHByb2dyZXNzID0gKHJlbWFpbmluZ1RpbWUgLyB0b3RhbFRpbWUpICogMTAwO1xuXG4gICAgLy8gRW5zdXJlIHByb2dyZXNzIGlzIGJldHdlZW4gMCBhbmQgMTAwO1xuICAgIHRoaXMucmVtYWluaW5nUHJvZ3Jlc3MgPSAxMDAgLSBNYXRoLm1heCgwLCBNYXRoLm1pbigxMDAgLSBwcm9ncmVzcywgMTAwKSk7XG4gIH1cblxuICBwcml2YXRlIHVwZGF0ZURpc3BsYXlUaW1lKCkge1xuICAgIGNvbnN0IHNlY29uZHMgPSB0aGlzLnRpbWVJblNlY29uZHMgJSA2MDtcbiAgICBjb25zdCBob3VycyA9IE1hdGguZmxvb3IodGhpcy50aW1lSW5TZWNvbmRzIC8gMzYwMCk7XG4gICAgY29uc3QgbWludXRlcyA9IE1hdGguZmxvb3IoKHRoaXMudGltZUluU2Vjb25kcyAlIDM2MDApIC8gNjApO1xuXG4gICAgaWYgKGhvdXJzIDw9IDApIHtcbiAgICAgIC8vIGZvciBzaG93aW5nIG1pbnV0ZXMgYW5kIHNlY29uZHNcbiAgICAgIHRoaXMuZGlzcGxheVRpbWUgPSBgJHsgdGhpcy5mb3JtYXRUaW1lKG1pbnV0ZXMpIH06JHsgdGhpcy5mb3JtYXRUaW1lKHNlY29uZHMpIH1gO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBmb3Igc2hvd2luZyBob3VycywgbWludXRlcyBhbmQgc2Vjb25kc1xuICAgICAgdGhpcy5kaXNwbGF5VGltZSA9IGAkeyB0aGlzLmZvcm1hdFRpbWUoaG91cnMpIH06JHsgdGhpcy5mb3JtYXRUaW1lKG1pbnV0ZXMpIH06JHsgdGhpcy5mb3JtYXRUaW1lKHNlY29uZHMpIH1gO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMuc3RvcFRpbWVyKCk7XG4gIH1cbn1cbiIsIjxkaXYgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBjbGFzcz1cImNvdW50ZG93bi1jb250YWluZXJcIj5cbiAgPG1hdC1wcm9ncmVzcy1zcGlubmVyIG1vZGU9XCJkZXRlcm1pbmF0ZVwiIFtzdHJva2VXaWR0aF09XCI1XCIgW3ZhbHVlXT1cInJlbWFpbmluZ1Byb2dyZXNzXCJcbiAgICBjbGFzcz1cInByb2dyZXNzLXNwaW5uZXIgLXNjYWxlLXgtMSAtc2NhbGUteS0tMVwiIHN0eWxlPVwid2lkdGg6IDVyZW07IGhlaWdodDogNXJlbTtcIj5cbiAgPC9tYXQtcHJvZ3Jlc3Mtc3Bpbm5lcj5cblxuICA8bWF0LWxhYmVsIGNsYXNzPVwidGltZS1kaXNwbGF5XCI+e3sgZGlzcGxheVRpbWUgfX08L21hdC1sYWJlbD5cbjwvZGl2PlxuIl19