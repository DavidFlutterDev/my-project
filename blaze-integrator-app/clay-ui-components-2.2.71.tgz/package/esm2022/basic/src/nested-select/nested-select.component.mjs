import { CommonModule } from '@angular/common';
import { Component, Input, Optional, Self, ViewChild, computed, signal, } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { ClNestedSelectProperties } from './nested-select.properties';
import { ClNestedItemComponent } from './nested-item/nested-item.component';
import { MatIconModule } from '@angular/material/icon';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { cloneDeep } from 'lodash';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/form-field";
import * as i3 from "@angular/material/input";
import * as i4 from "@angular/common";
import * as i5 from "@angular/material/menu";
import * as i6 from "@angular/material/icon";
export class ClNestedSelectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this._value = '';
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.filterString = signal('');
        this.filteredListSignal = computed(() => this.filterNestedListSkipParents(this.properties.options, this.filterString())
        // this.filterNestedList(this.properties.options!, this.filterString())
        );
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        ;
    }
    ngOnChanges(_changes) {
        this.setDefaultValue();
    }
    ngOnInit() {
        this.properties ??= new ClNestedSelectProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            const val = this.findValue(this.properties.options, value);
            if (val) {
                this.selectedOption = val;
                if (this._value !== val.value) {
                    this.writeValue(val.value);
                }
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
    }
    setDefaultValue() {
        if (this.properties.selectedValue) {
            this.setDefaultSelectedValues();
        }
    }
    onOptionSelected(event) {
        this.selectedOption = event;
        this.onValueChange();
    }
    setDefaultSelectedValues() {
        if (!this.properties.selectedValue) {
            return;
        }
        if (this.properties.options) {
            const val = this.findValue(this.properties.options, this.properties.selectedValue);
            if (val) {
                this.selectedOption = val;
                this.onValueChange();
            }
        }
    }
    onInputChange(event) {
        const value = event.target.value;
        if (value === this.filterString()) {
            this.filterString.set(' ');
            this.filterString.set(value);
        }
        else {
            this.filterString.set(value);
        }
    }
    // filterNestedList(data: ClNestedSelectOption[], searchText: string): ClNestedSelectOption[] {
    //   return data.reduce((acc: ClNestedSelectOption[], item: ClNestedSelectOption) => {
    //     // If the current item's text matches the searchText, add it to the result
    //     if (item.text?.toLowerCase().includes(searchText.toLowerCase())) {
    //       acc.push(item);
    //     }
    //     // If the item has a nested 'list', filter it as well recursively
    //     if (item.list && item.list.length > 0) {
    //       const filteredList = this.filterNestedList(item.list, searchText);
    //       if (filteredList.length > 0) {
    //         // Add the item to the result if its nested list has matches
    //         acc.push({ text: item.text, value: item.value, list: filteredList });
    //       }
    //     }
    //     return acc;
    //   }, []);
    // }
    filterNestedListSkipParents(data, searchText) {
        let result = [];
        if (!searchText && this.properties.options) {
            return this.properties.options;
        }
        // Iterate through the array of items
        for (const item of data) {
            // If the item's text matches the search text, add it to the result
            if (item.text?.toLowerCase().includes(searchText.toLowerCase())) {
                result.push(item);
            }
            // If the item has a 'list', we need to check the nested items (children)
            if (item.list && item.list.length > 0) {
                // Recursively filter the nested list
                const nestedMatches = this.filterNestedListSkipParents(item.list, searchText);
                // If we find matching items in the nested list, include them in the result
                if (nestedMatches.length > 0) {
                    result = result.concat(nestedMatches);
                }
            }
        }
        return result;
    }
    findValue(arr, targetValue) {
        for (const item of arr) {
            // Check the current level
            if (item.value === targetValue) {
                return item;
            }
            // Recursively check the 'list' array in case of nested objects
            if (item.list && item.list.length > 0) {
                const result = this.findValue(item.list, targetValue);
                if (result) {
                    return result;
                }
            }
        }
        return null; // Return null if the value is not found
    }
    onPrefixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked();
        }
    }
    onSuffixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked();
        }
    }
    onValueChange() {
        if (this.selectedOption) {
            this.writeValue(this.selectedOption.value);
            this.onChange(this.selectedOption.value);
            if (this.properties.onValueChange) {
                this.properties.onValueChange(this.selectedOption.value);
            }
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        if (this.selectedOption) {
            return cloneDeep(this.selectedOption.text);
        }
        else if (this.properties.options && this._value) {
            const val = this.findValue(this.properties.options, this._value);
            return val ? val.text : '';
        }
        return '';
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.valueChangesSub?.unsubscribe();
        this.sub?.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedSelectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedSelectComponent, isStandalone: true, selector: "cl-nested-select", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"h-fit {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input #nestedSelectInput matInput [placeholder]=\"properties.placeholder!\"\n    [matMenuTriggerFor]=\"menu.childMenu\" [value]=\"value ? value : ''\" [disabled]=\"disabled\"\n    (input)=\"onInputChange($event)\" (blur)=\"onTouched($any($event.target).value)\"\n    (focus)=\"onInputChange($event)\"\n    (keyup)=\"writeValue($any($event.target).value)\"/>\n\n  @if (properties.suffixIcon) {\n  <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked($event)\" [svgIcon]=\"properties.suffixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n  </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n  <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked($event)\" [svgIcon]=\"properties.prefixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n  </mat-icon>\n  }\n</mat-form-field>\n\n<cl-nested-item #menu [items]=\"filteredListSignal()\" (optionSelected)=\"onOptionSelected($event)\">\n</cl-nested-item>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i2.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "directive", type: i2.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i2.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i2.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i2.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i4.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "directive", type: i5.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: ClNestedItemComponent, selector: "cl-nested-item", inputs: ["items"], outputs: ["optionSelected"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i6.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedSelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-select', imports: [
                        FormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatFormFieldModule,
                        CommonModule,
                        MatMenuModule,
                        ReactiveFormsModule,
                        ClNestedItemComponent,
                        MatIconModule,
                        MatInputModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"h-fit {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n    @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n  </mat-label>\n  }\n\n  <input #nestedSelectInput matInput [placeholder]=\"properties.placeholder!\"\n    [matMenuTriggerFor]=\"menu.childMenu\" [value]=\"value ? value : ''\" [disabled]=\"disabled\"\n    (input)=\"onInputChange($event)\" (blur)=\"onTouched($any($event.target).value)\"\n    (focus)=\"onInputChange($event)\"\n    (keyup)=\"writeValue($any($event.target).value)\"/>\n\n  @if (properties.suffixIcon) {\n  <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked($event)\" [svgIcon]=\"properties.suffixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n  </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n  <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked($event)\" [svgIcon]=\"properties.prefixIcon!\"\n    [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n  </mat-icon>\n  }\n</mat-form-field>\n\n<cl-nested-item #menu [items]=\"filteredListSignal()\" (optionSelected)=\"onOptionSelected($event)\">\n</cl-nested-item>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n  <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n  <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVzdGVkLXNlbGVjdC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL25lc3RlZC1zZWxlY3QvbmVzdGVkLXNlbGVjdC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL25lc3RlZC1zZWxlY3QvbmVzdGVkLXNlbGVjdC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUdMLFNBQVMsRUFDVCxLQUFLLEVBSUwsUUFBUSxFQUNSLElBQUksRUFFSixTQUFTLEVBRVQsUUFBUSxFQUNSLE1BQU0sR0FDUCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQXdCLFdBQVcsRUFBYSxtQkFBbUIsRUFBb0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUNySCxPQUFPLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEYsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUV2RCxPQUFPLEVBQUUsd0JBQXdCLEVBQXdCLE1BQU0sNEJBQTRCLENBQUM7QUFDNUYsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0scUNBQXFDLENBQUM7QUFDNUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxRQUFRLENBQUM7QUFDbkMsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7Ozs7OztBQXFCN0QsTUFBTSxPQUFPLHVCQUF3QixTQUFRLGVBQWU7SUEyQjFELFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFsQmxELFdBQU0sR0FBVyxFQUFFLENBQUM7UUFLOUIsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFJNUIsaUJBQVksR0FBMkIsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBRWxELHVCQUFrQixHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUUsQ0FDakMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxFQUFFLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUMvRSx1RUFBdUU7U0FDeEUsQ0FBQztRQVFBLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztRQUV2RyxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxFQUFFLENBQUM7WUFDM0Isd0RBQXdEO1lBQ3hELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDdEMsQ0FBQztRQUFBLENBQUM7SUFDSixDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQXVCO1FBQ2pDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUN6QixDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSx3QkFBd0IsRUFBRSxDQUFDO1FBQ25ELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsZUFBZTtRQUNiLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUM1RSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRTVELElBQUksR0FBRyxFQUFFLENBQUM7Z0JBQ1IsSUFBSSxDQUFDLGNBQWMsR0FBRyxHQUFHLENBQUM7Z0JBQzFCLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQzlCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM3QixDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsaURBQWlEO1FBQ2pELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUMsT0FBWSxFQUFFLEVBQUU7WUFDbkUsSUFBSSxPQUFPLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUNuQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFbEIsaUNBQWlDO2dCQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHFCQUFxQjtRQUNuQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUV2RixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzNFLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQyxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU0sWUFBWSxDQUFDLEtBQVU7UUFDNUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUN0RixDQUFDO0lBRU8sZUFBZTtRQUNyQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7UUFDbEMsQ0FBQztJQUNILENBQUM7SUFDUyxnQkFBZ0IsQ0FBQyxLQUEyQjtRQUNwRCxJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDdkIsQ0FBQztJQUVPLHdCQUF3QjtRQUM5QixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuQyxPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM1QixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7WUFFbkYsSUFBSSxHQUFHLEVBQUUsQ0FBQztnQkFDUixJQUFJLENBQUMsY0FBYyxHQUFHLEdBQUcsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3ZCLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELGFBQWEsQ0FBQyxLQUFVO1FBQ3RCLE1BQU0sS0FBSyxHQUFZLEtBQUssQ0FBQyxNQUEyQixDQUFDLEtBQUssQ0FBQztRQUMvRCxJQUFHLEtBQUssS0FBSyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUMsQ0FBQztZQUNoQyxJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMvQixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRUQsK0ZBQStGO0lBQy9GLHNGQUFzRjtJQUN0RixpRkFBaUY7SUFDakYseUVBQXlFO0lBQ3pFLHdCQUF3QjtJQUN4QixRQUFRO0lBRVIsd0VBQXdFO0lBQ3hFLCtDQUErQztJQUMvQywyRUFBMkU7SUFDM0UsdUNBQXVDO0lBQ3ZDLHVFQUF1RTtJQUN2RSxnRkFBZ0Y7SUFDaEYsVUFBVTtJQUNWLFFBQVE7SUFFUixrQkFBa0I7SUFDbEIsWUFBWTtJQUNaLElBQUk7SUFFSiwyQkFBMkIsQ0FBQyxJQUE0QixFQUFFLFVBQWtCO1FBQzFFLElBQUksTUFBTSxHQUFVLEVBQUUsQ0FBQztRQUV2QixJQUFHLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFDLENBQUM7WUFDekMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQztRQUNqQyxDQUFDO1FBQ0QscUNBQXFDO1FBQ3JDLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxFQUFFLENBQUM7WUFDeEIsbUVBQW1FO1lBQ25FLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDaEUsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNwQixDQUFDO1lBRUQseUVBQXlFO1lBQ3pFLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztnQkFDdEMscUNBQXFDO2dCQUNyQyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsQ0FBQztnQkFFOUUsMkVBQTJFO2dCQUMzRSxJQUFJLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzdCLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO2dCQUN4QyxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBQ0QsU0FBUyxDQUFDLEdBQVUsRUFBRSxXQUE0QjtRQUNoRCxLQUFLLE1BQU0sSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLDBCQUEwQjtZQUMxQixJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxFQUFFLENBQUM7Z0JBQy9CLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELCtEQUErRDtZQUMvRCxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3RDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDdEQsSUFBSSxNQUFNLEVBQUUsQ0FBQztvQkFDWCxPQUFPLE1BQU0sQ0FBQztnQkFDaEIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsQ0FBQyx3Q0FBd0M7SUFDdkQsQ0FBQztJQUNTLG1CQUFtQixDQUFDLEtBQVU7UUFDdEMsb0RBQW9EO1FBQ3BELEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUV4QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUM7SUFFUyxtQkFBbUIsQ0FBQyxLQUFVO1FBQ3RDLG9EQUFvRDtRQUNwRCxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFeEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRU8sYUFBYTtRQUNuQixJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzRCxDQUFDO1FBQ0gsQ0FBQztJQUVILENBQUM7SUFDRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzdDLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNsRCxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRSxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1FBQzdCLENBQUM7UUFDRCxPQUFPLEVBQUUsQ0FBQztJQUNaLENBQUM7SUFFRCxJQUFjLFFBQVE7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVRLFdBQVc7UUFDbEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QixDQUFDOzhHQWxSVSx1QkFBdUI7a0dBQXZCLHVCQUF1QixnS0FNdkIsWUFBWSw0RkN0RHpCLDJoRUFtREEsd0hEaEJJLFdBQVcsOEJBQ1gsa0JBQWtCLGl1QkFDbEIsY0FBYywwV0FFZCxZQUFZLDRIQUNaLGFBQWEsb1ZBQ2IsbUJBQW1CLCtCQUNuQixxQkFBcUIsMEdBQ3JCLGFBQWEsb0xBR2Isa0JBQWtCOzsyRkFFVCx1QkFBdUI7a0JBbkJuQyxTQUFTO2lDQUNJLElBQUksWUFDTixrQkFBa0IsV0FHbkI7d0JBQ1AsV0FBVzt3QkFDWCxrQkFBa0I7d0JBQ2xCLGNBQWM7d0JBQ2Qsa0JBQWtCO3dCQUNsQixZQUFZO3dCQUNaLGFBQWE7d0JBQ2IsbUJBQW1CO3dCQUNuQixxQkFBcUI7d0JBQ3JCLGFBQWE7d0JBQ2IsY0FBYzt3QkFDZCxrQkFBa0I7d0JBQ2xCLGtCQUFrQjtxQkFBQzs7MEJBNkJQLFFBQVE7OzBCQUFJLElBQUk7eUNBdkJkLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUlsQixZQUFZO3NCQURsQixTQUFTO3VCQUFDLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHtcbiAgQWZ0ZXJDb250ZW50Q2hlY2tlZCxcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ29tcG9uZW50LFxuICBJbnB1dCxcbiAgT25DaGFuZ2VzLFxuICBPbkRlc3Ryb3ksXG4gIE9uSW5pdCxcbiAgT3B0aW9uYWwsXG4gIFNlbGYsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFZpZXdDaGlsZCxcbiAgV3JpdGFibGVTaWduYWwsXG4gIGNvbXB1dGVkLFxuICBzaWduYWwsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1zTW9kdWxlLCBOZ0NvbnRyb2wsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgTWF0SW5wdXRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pbnB1dCc7XG5pbXBvcnQgeyBNYXRNZW51TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvbWVudSc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IENsTmVzdGVkU2VsZWN0UHJvcGVydGllcywgQ2xOZXN0ZWRTZWxlY3RPcHRpb24gfSBmcm9tICcuL25lc3RlZC1zZWxlY3QucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbE5lc3RlZEl0ZW1Db21wb25lbnQgfSBmcm9tICcuL25lc3RlZC1pdGVtL25lc3RlZC1pdGVtLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBjbG9uZURlZXAgfSBmcm9tICdsb2Rhc2gnO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50IH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1uZXN0ZWQtc2VsZWN0JyxcbiAgc3R5bGVVcmw6ICcuL25lc3RlZC1zZWxlY3QuY29tcG9uZW50LnNjc3MnLFxuICB0ZW1wbGF0ZVVybDogJy4vbmVzdGVkLXNlbGVjdC5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBNYXRGb3JtRmllbGRNb2R1bGUsXG4gICAgTWF0SW5wdXRNb2R1bGUsXG4gICAgTWF0Rm9ybUZpZWxkTW9kdWxlLFxuICAgIENvbW1vbk1vZHVsZSxcbiAgICBNYXRNZW51TW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgQ2xOZXN0ZWRJdGVtQ29tcG9uZW50LFxuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0SW5wdXRNb2R1bGUsXG4gICAgTWF0Rm9ybUZpZWxkTW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZV1cbn0pXG5leHBvcnQgY2xhc3MgQ2xOZXN0ZWRTZWxlY3RDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciwgT25DaGFuZ2VzLCBPbkluaXQsXG4gIEFmdGVyVmlld0luaXQsIEFmdGVyQ29udGVudENoZWNrZWQsIE9uRGVzdHJveSB7XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbE5lc3RlZFNlbGVjdFByb3BlcnRpZXM7XG5cbiAgQFZpZXdDaGlsZChNYXRGb3JtRmllbGQpXG4gIHB1YmxpYyBtYXRGb3JtRmllbGQhOiBNYXRGb3JtRmllbGQ7XG5cbiAgcHJvdGVjdGVkIF92YWx1ZTogc3RyaW5nID0gJyc7XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuXG4gIHByaXZhdGUgc2VsZWN0ZWRPcHRpb246IENsTmVzdGVkU2VsZWN0T3B0aW9uIHwgdW5kZWZpbmVkO1xuXG4gIG9uQ2hhbmdlID0gKF86IGFueSkgPT4geyB9O1xuXG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcblxuICBwcml2YXRlIHZhbHVlQ2hhbmdlc1N1Yj86IFN1YnNjcmlwdGlvbjtcbiAgcHJpdmF0ZSBzdWI/OiBTdWJzY3JpcHRpb247XG4gIGZpbHRlclN0cmluZzogV3JpdGFibGVTaWduYWw8c3RyaW5nPiA9IHNpZ25hbCgnJyk7XG5cbiAgZmlsdGVyZWRMaXN0U2lnbmFsID0gY29tcHV0ZWQoKCkgPT5cbiAgICB0aGlzLmZpbHRlck5lc3RlZExpc3RTa2lwUGFyZW50cyh0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEsIHRoaXMuZmlsdGVyU3RyaW5nKCkpXG4gICAgLy8gdGhpcy5maWx0ZXJOZXN0ZWRMaXN0KHRoaXMucHJvcGVydGllcy5vcHRpb25zISwgdGhpcy5maWx0ZXJTdHJpbmcoKSlcbiAgKTtcblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9O1xuICB9XG5cbiAgbmdPbkNoYW5nZXMoX2NoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICB0aGlzLnNldERlZmF1bHRWYWx1ZSgpO1xuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xOZXN0ZWRTZWxlY3RQcm9wZXJ0aWVzKCk7XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG5cbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICB0aGlzLnZhbHVlQ2hhbmdlc1N1YiA9IHRoaXMubmdDb250cm9sPy52YWx1ZUNoYW5nZXM/LnN1YnNjcmliZSgodmFsdWU6IGFueSkgPT4ge1xuICAgICAgY29uc3QgdmFsID0gdGhpcy5maW5kVmFsdWUodGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMhLCB2YWx1ZSk7XG5cbiAgICAgIGlmICh2YWwpIHtcbiAgICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbiA9IHZhbDtcbiAgICAgICAgaWYgKHRoaXMuX3ZhbHVlICE9PSB2YWwudmFsdWUpIHtcbiAgICAgICAgICB0aGlzLndyaXRlVmFsdWUodmFsLnZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gcmVtb3ZlIGFsbCB0aGUgZXJyb3JzIHdoZW4gdGhlIHN0YXR1cyBpcyB2YWxpZFxuICAgIHRoaXMuc3ViID0gdGhpcy5uZ0NvbnRyb2w/LnN0YXR1c0NoYW5nZXM/LnN1YnNjcmliZSgoY2hhbmdlczogYW55KSA9PiB7XG4gICAgICBpZiAoY2hhbmdlcyAmJiBjaGFuZ2VzID09PSAnVkFMSUQnKSB7XG4gICAgICAgIHRoaXMuZXJyb3IgPSBudWxsO1xuXG4gICAgICAgIC8vIGNhbGxpbmcgc2V0IGhpbnQgdGV4dCBmdW5jdGlvblxuICAgICAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7XG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuXG4gICAgICB0aGlzLmVycm9yID0gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzID8gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzWydlcnJvciddIDogbnVsbDtcbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBzZXRIaW50VGV4dCgpIHtcbiAgICB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1mb3JtLWZpZWxkLWludmFsaWQnKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvclRleHQoZXJyb3I6IGFueSkge1xuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXREZWZhdWx0VmFsdWUoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zZWxlY3RlZFZhbHVlKSB7XG4gICAgICB0aGlzLnNldERlZmF1bHRTZWxlY3RlZFZhbHVlcygpO1xuICAgIH1cbiAgfVxuICBwcm90ZWN0ZWQgb25PcHRpb25TZWxlY3RlZChldmVudDogQ2xOZXN0ZWRTZWxlY3RPcHRpb24pIHtcbiAgICB0aGlzLnNlbGVjdGVkT3B0aW9uID0gZXZlbnQ7XG4gICAgdGhpcy5vblZhbHVlQ2hhbmdlKCk7XG4gIH1cblxuICBwcml2YXRlIHNldERlZmF1bHRTZWxlY3RlZFZhbHVlcygpIHtcbiAgICBpZiAoIXRoaXMucHJvcGVydGllcy5zZWxlY3RlZFZhbHVlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub3B0aW9ucykge1xuICAgICAgY29uc3QgdmFsID0gdGhpcy5maW5kVmFsdWUodGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMsIHRoaXMucHJvcGVydGllcy5zZWxlY3RlZFZhbHVlKTtcblxuICAgICAgaWYgKHZhbCkge1xuICAgICAgICB0aGlzLnNlbGVjdGVkT3B0aW9uID0gdmFsO1xuICAgICAgICB0aGlzLm9uVmFsdWVDaGFuZ2UoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBvbklucHV0Q2hhbmdlKGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCB2YWx1ZTogc3RyaW5nID0gKGV2ZW50LnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcbiAgICBpZih2YWx1ZSA9PT0gdGhpcy5maWx0ZXJTdHJpbmcoKSl7XG4gICAgICB0aGlzLmZpbHRlclN0cmluZy5zZXQoJyAnKTtcbiAgICAgIHRoaXMuZmlsdGVyU3RyaW5nLnNldCh2YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZmlsdGVyU3RyaW5nLnNldCh2YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgLy8gZmlsdGVyTmVzdGVkTGlzdChkYXRhOiBDbE5lc3RlZFNlbGVjdE9wdGlvbltdLCBzZWFyY2hUZXh0OiBzdHJpbmcpOiBDbE5lc3RlZFNlbGVjdE9wdGlvbltdIHtcbiAgLy8gICByZXR1cm4gZGF0YS5yZWR1Y2UoKGFjYzogQ2xOZXN0ZWRTZWxlY3RPcHRpb25bXSwgaXRlbTogQ2xOZXN0ZWRTZWxlY3RPcHRpb24pID0+IHtcbiAgLy8gICAgIC8vIElmIHRoZSBjdXJyZW50IGl0ZW0ncyB0ZXh0IG1hdGNoZXMgdGhlIHNlYXJjaFRleHQsIGFkZCBpdCB0byB0aGUgcmVzdWx0XG4gIC8vICAgICBpZiAoaXRlbS50ZXh0Py50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaFRleHQudG9Mb3dlckNhc2UoKSkpIHtcbiAgLy8gICAgICAgYWNjLnB1c2goaXRlbSk7XG4gIC8vICAgICB9XG5cbiAgLy8gICAgIC8vIElmIHRoZSBpdGVtIGhhcyBhIG5lc3RlZCAnbGlzdCcsIGZpbHRlciBpdCBhcyB3ZWxsIHJlY3Vyc2l2ZWx5XG4gIC8vICAgICBpZiAoaXRlbS5saXN0ICYmIGl0ZW0ubGlzdC5sZW5ndGggPiAwKSB7XG4gIC8vICAgICAgIGNvbnN0IGZpbHRlcmVkTGlzdCA9IHRoaXMuZmlsdGVyTmVzdGVkTGlzdChpdGVtLmxpc3QsIHNlYXJjaFRleHQpO1xuICAvLyAgICAgICBpZiAoZmlsdGVyZWRMaXN0Lmxlbmd0aCA+IDApIHtcbiAgLy8gICAgICAgICAvLyBBZGQgdGhlIGl0ZW0gdG8gdGhlIHJlc3VsdCBpZiBpdHMgbmVzdGVkIGxpc3QgaGFzIG1hdGNoZXNcbiAgLy8gICAgICAgICBhY2MucHVzaCh7IHRleHQ6IGl0ZW0udGV4dCwgdmFsdWU6IGl0ZW0udmFsdWUsIGxpc3Q6IGZpbHRlcmVkTGlzdCB9KTtcbiAgLy8gICAgICAgfVxuICAvLyAgICAgfVxuXG4gIC8vICAgICByZXR1cm4gYWNjO1xuICAvLyAgIH0sIFtdKTtcbiAgLy8gfVxuXG4gIGZpbHRlck5lc3RlZExpc3RTa2lwUGFyZW50cyhkYXRhOiBDbE5lc3RlZFNlbGVjdE9wdGlvbltdLCBzZWFyY2hUZXh0OiBzdHJpbmcpOiBDbE5lc3RlZFNlbGVjdE9wdGlvbltdIHtcbiAgICBsZXQgcmVzdWx0OiBhbnlbXSA9IFtdO1xuXG4gICAgaWYoIXNlYXJjaFRleHQgJiYgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMpe1xuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5vcHRpb25zO1xuICAgIH1cbiAgICAvLyBJdGVyYXRlIHRocm91Z2ggdGhlIGFycmF5IG9mIGl0ZW1zXG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGRhdGEpIHtcbiAgICAgIC8vIElmIHRoZSBpdGVtJ3MgdGV4dCBtYXRjaGVzIHRoZSBzZWFyY2ggdGV4dCwgYWRkIGl0IHRvIHRoZSByZXN1bHRcbiAgICAgIGlmIChpdGVtLnRleHQ/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoVGV4dC50b0xvd2VyQ2FzZSgpKSkge1xuICAgICAgICByZXN1bHQucHVzaChpdGVtKTtcbiAgICAgIH1cblxuICAgICAgLy8gSWYgdGhlIGl0ZW0gaGFzIGEgJ2xpc3QnLCB3ZSBuZWVkIHRvIGNoZWNrIHRoZSBuZXN0ZWQgaXRlbXMgKGNoaWxkcmVuKVxuICAgICAgaWYgKGl0ZW0ubGlzdCAmJiBpdGVtLmxpc3QubGVuZ3RoID4gMCkge1xuICAgICAgICAvLyBSZWN1cnNpdmVseSBmaWx0ZXIgdGhlIG5lc3RlZCBsaXN0XG4gICAgICAgIGNvbnN0IG5lc3RlZE1hdGNoZXMgPSB0aGlzLmZpbHRlck5lc3RlZExpc3RTa2lwUGFyZW50cyhpdGVtLmxpc3QsIHNlYXJjaFRleHQpO1xuXG4gICAgICAgIC8vIElmIHdlIGZpbmQgbWF0Y2hpbmcgaXRlbXMgaW4gdGhlIG5lc3RlZCBsaXN0LCBpbmNsdWRlIHRoZW0gaW4gdGhlIHJlc3VsdFxuICAgICAgICBpZiAobmVzdGVkTWF0Y2hlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgcmVzdWx0ID0gcmVzdWx0LmNvbmNhdChuZXN0ZWRNYXRjaGVzKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgZmluZFZhbHVlKGFycjogYW55W10sIHRhcmdldFZhbHVlOiBzdHJpbmcgfCBudW1iZXIpOiBhbnkge1xuICAgIGZvciAoY29uc3QgaXRlbSBvZiBhcnIpIHtcbiAgICAgIC8vIENoZWNrIHRoZSBjdXJyZW50IGxldmVsXG4gICAgICBpZiAoaXRlbS52YWx1ZSA9PT0gdGFyZ2V0VmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICB9XG5cbiAgICAgIC8vIFJlY3Vyc2l2ZWx5IGNoZWNrIHRoZSAnbGlzdCcgYXJyYXkgaW4gY2FzZSBvZiBuZXN0ZWQgb2JqZWN0c1xuICAgICAgaWYgKGl0ZW0ubGlzdCAmJiBpdGVtLmxpc3QubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0aGlzLmZpbmRWYWx1ZShpdGVtLmxpc3QsIHRhcmdldFZhbHVlKTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7IC8vIFJldHVybiBudWxsIGlmIHRoZSB2YWx1ZSBpcyBub3QgZm91bmRcbiAgfVxuICBwcm90ZWN0ZWQgb25QcmVmaXhJY29uQ2xpY2tlZChldmVudDogYW55KTogdm9pZCB7XG4gICAgLy8gUHJldmVudHMgdGhlIGNsaWNrIGZyb20gcHJvcGFnYXRpbmcgdG8gdGhlIHNlbGVjdFxuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblByZWZpeEljb25DbGlja2VkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25QcmVmaXhJY29uQ2xpY2tlZCgpO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBvblN1ZmZpeEljb25DbGlja2VkKGV2ZW50OiBhbnkpOiB2b2lkIHtcbiAgICAvLyBQcmV2ZW50cyB0aGUgY2xpY2sgZnJvbSBwcm9wYWdhdGluZyB0byB0aGUgc2VsZWN0XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uU3VmZml4SWNvbkNsaWNrZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vblN1ZmZpeEljb25DbGlja2VkKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBvblZhbHVlQ2hhbmdlKCkge1xuICAgIGlmICh0aGlzLnNlbGVjdGVkT3B0aW9uKSB7XG4gICAgICB0aGlzLndyaXRlVmFsdWUodGhpcy5zZWxlY3RlZE9wdGlvbi52YWx1ZSk7XG4gICAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuc2VsZWN0ZWRPcHRpb24udmFsdWUpO1xuICAgICAgaWYgKHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKSB7XG4gICAgICAgIHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKHRoaXMuc2VsZWN0ZWRPcHRpb24udmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICB9XG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gIH1cblxuICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcbiAgfVxuXG4gIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25Ub3VjaGVkID0gZm47XG4gIH1cblxuICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICBpZiAodGhpcy5zZWxlY3RlZE9wdGlvbikge1xuICAgICAgcmV0dXJuIGNsb25lRGVlcCh0aGlzLnNlbGVjdGVkT3B0aW9uLnRleHQpO1xuICAgIH0gZWxzZSBpZiAodGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMgJiYgdGhpcy5fdmFsdWUpIHtcbiAgICAgIGNvbnN0IHZhbCA9IHRoaXMuZmluZFZhbHVlKHRoaXMucHJvcGVydGllcy5vcHRpb25zLCB0aGlzLl92YWx1ZSk7XG4gICAgICByZXR1cm4gdmFsID8gdmFsLnRleHQgOiAnJztcbiAgICB9XG4gICAgcmV0dXJuICcnO1xuICB9XG5cbiAgcHJvdGVjdGVkIGdldCBkaXNhYmxlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIHRoaXMudmFsdWVDaGFuZ2VzU3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gIH1cbn1cbiIsIjxtYXQtZm9ybS1maWVsZCBbaWRdPVwicHJvcGVydGllcy5pZFwiIHN1YnNjcmlwdFNpemluZz1cImR5bmFtaWNcIiBbZmxvYXRMYWJlbF09XCJwcm9wZXJ0aWVzLmZsb2F0TGFiZWwhXCJcbiAgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiIGNsYXNzPVwiaC1maXQge3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fVwiPlxuXG4gIEBpZiAocHJvcGVydGllcy5sYWJlbCAhPSBudWxsICYmIHByb3BlcnRpZXMubGFiZWwgIT0gJycgJiYgcHJvcGVydGllcy5sYWJlbCAhPSB1bmRlZmluZWQpIHtcbiAgICA8bWF0LWxhYmVsIGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgIDxzcGFuPnt7IHByb3BlcnRpZXMubGFiZWwgfX08L3NwYW4+XG5cbiAgICAgIEBpZiAocHJvcGVydGllcy5vcHRpb25hbCkge1xuICAgICAgICA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsLXRleHRcIj4oT3B0aW9uYWwpPC9zcGFuPlxuICAgICAgfVxuXG4gICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICA8bWF0LWljb24gW3Rvb2x0aXBdPVwicHJvcGVydGllcy5pbmZvTXNnIVwiXG4gICAgICBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgPC9tYXQtaWNvbj5cbiAgICB9XG4gIDwvbWF0LWxhYmVsPlxuICB9XG5cbiAgPGlucHV0ICNuZXN0ZWRTZWxlY3RJbnB1dCBtYXRJbnB1dCBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIlxuICAgIFttYXRNZW51VHJpZ2dlckZvcl09XCJtZW51LmNoaWxkTWVudVwiIFt2YWx1ZV09XCJ2YWx1ZSA/IHZhbHVlIDogJydcIiBbZGlzYWJsZWRdPVwiZGlzYWJsZWRcIlxuICAgIChpbnB1dCk9XCJvbklucHV0Q2hhbmdlKCRldmVudClcIiAoYmx1cik9XCJvblRvdWNoZWQoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIlxuICAgIChmb2N1cyk9XCJvbklucHV0Q2hhbmdlKCRldmVudClcIlxuICAgIChrZXl1cCk9XCJ3cml0ZVZhbHVlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCIvPlxuXG4gIEBpZiAocHJvcGVydGllcy5zdWZmaXhJY29uKSB7XG4gIDxtYXQtaWNvbiBtYXRTdWZmaXggY2xhc3M9XCJpY29uLXNpemUtNVwiIChjbGljayk9XCJvblN1ZmZpeEljb25DbGlja2VkKCRldmVudClcIiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnN1ZmZpeEljb24hXCJcbiAgICBbbmdDbGFzc109XCJ7J2N1cnNvci1wb2ludGVyJzogcHJvcGVydGllcy5vblN1ZmZpeEljb25DbGlja2VkfVwiPlxuICA8L21hdC1pY29uPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLnByZWZpeEljb24pIHtcbiAgPG1hdC1pY29uIG1hdFByZWZpeCBjbGFzcz1cImljb24tc2l6ZS01XCIgKGNsaWNrKT1cIm9uUHJlZml4SWNvbkNsaWNrZWQoJGV2ZW50KVwiIFtzdmdJY29uXT1cInByb3BlcnRpZXMucHJlZml4SWNvbiFcIlxuICAgIFtuZ0NsYXNzXT1cInsnY3Vyc29yLXBvaW50ZXInOiBwcm9wZXJ0aWVzLm9uUHJlZml4SWNvbkNsaWNrZWR9XCI+XG4gIDwvbWF0LWljb24+XG4gIH1cbjwvbWF0LWZvcm0tZmllbGQ+XG5cbjxjbC1uZXN0ZWQtaXRlbSAjbWVudSBbaXRlbXNdPVwiZmlsdGVyZWRMaXN0U2lnbmFsKClcIiAob3B0aW9uU2VsZWN0ZWQpPVwib25PcHRpb25TZWxlY3RlZCgkZXZlbnQpXCI+XG48L2NsLW5lc3RlZC1pdGVtPlxuXG48IS0tIFRoaXMgZGl2IGlzIHJlcXVpcmVkIHRvIHNob3cgaGludCB0ZXh0IG9yIGVycm9yIG1lc3NhZ2UgZm9yIHRoZSBjb21wb25lbnQgLS0+XG48ZGl2IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgQGlmIChlcnJvcikge1xuICA8bWF0LWVycm9yPnt7IGVycm9yIH19PC9tYXQtZXJyb3I+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgPG1hdC1oaW50Pnt7IHByb3BlcnRpZXMuaGludFRleHQgfX08L21hdC1oaW50PlxuICB9XG48L2Rpdj5cbiJdfQ==