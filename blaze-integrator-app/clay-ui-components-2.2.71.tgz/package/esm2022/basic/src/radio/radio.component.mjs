import { MatIconModule } from '@angular/material/icon';
import { MatRadioModule } from '@angular/material/radio';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ReactiveFormsModule } from '@angular/forms';
import { Component, Input, Optional, Self } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClDisplay, ClRadioProperties } from './radio.properties';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/radio";
import * as i4 from "@angular/material/form-field";
export class ClRadioComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClRadioProperties();
        this.properties.display ??= ClDisplay.row;
        this.properties.radioStyle ??= 'cl-radio-button';
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having checked as true and check with the value.
        // if both are not same update the value with the checked true option
        const checkedOption = this.properties.options?.find((opt) => opt.checked == true);
        if (checkedOption && checkedOption.value != this._value) {
            this._value = checkedOption.value;
        }
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            this.writeValue(value);
        });
    }
    writeValue(value) {
        if (value) {
            this.properties.options?.forEach((option) => {
                option.checked = option.value === value;
            });
            this._value = value;
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        if (this.properties.options && this.properties.options?.length > 0) {
            const selectedOption = this.properties.options.find(option => option.checked);
            if (selectedOption) {
                this._value = selectedOption?.value;
            }
            else {
                this._value = '';
            }
        }
        return this._value;
    }
    onValueChanged(option) {
        this.writeValue(option.value);
        this.onChange(option.value);
        if (this.properties.onValueChanged) {
            this.properties.onValueChanged(option.value);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClRadioComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClRadioComponent, isStandalone: true, selector: "cl-radio", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 flex-col {{properties.style?.cssClasses}}\">\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span class=\"{{ properties.style?.labelCssClasses }}\">{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-radio-group color=\"primary\" [id]=\"properties.id\" class=\"flex gap-2 {{properties.display}}\" [value]=\"value\"\n    (change)=\"writeValue($any($event).value)\" [disabled]=\"disabled\">\n\n    @for (option of properties.options!; track option) {\n      <mat-radio-button [value]=\"option.value\" (change)=\"onValueChanged(option)\"\n        class=\"cursor-pointer {{properties.radioStyle}}\">\n        <span class=\"cursor-pointer\">{{ option.text }}</span>\n      </mat-radio-button>\n    }\n  </mat-radio-group>\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i3.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i3.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClRadioComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-radio', imports: [
                        MatIconModule,
                        MatRadioModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 flex-col {{properties.style?.cssClasses}}\">\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span class=\"{{ properties.style?.labelCssClasses }}\">{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-radio-group color=\"primary\" [id]=\"properties.id\" class=\"flex gap-2 {{properties.display}}\" [value]=\"value\"\n    (change)=\"writeValue($any($event).value)\" [disabled]=\"disabled\">\n\n    @for (option of properties.options!; track option) {\n      <mat-radio-button [value]=\"option.value\" (change)=\"onValueChanged(option)\"\n        class=\"cursor-pointer {{properties.radioStyle}}\">\n        <span class=\"cursor-pointer\">{{ option.text }}</span>\n      </mat-radio-button>\n    }\n  </mat-radio-group>\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9yYWRpby9yYWRpby5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3JhZGlvL3JhZGlvLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFtQyxtQkFBbUIsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3RGLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLFFBQVEsRUFBRSxJQUFJLEVBQTRCLE1BQU0sZUFBZSxDQUFDO0FBRW5HLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsU0FBUyxFQUFrQixpQkFBaUIsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ2xGLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7Ozs7QUFpQmhFLE1BQU0sT0FBTyxnQkFBaUIsU0FBUSxlQUFlO0lBY25ELFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFONUQsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFXMUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFckMsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLHdEQUF3RDtZQUN4RCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUM7UUFDRCx1R0FBdUc7SUFDekcsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksaUJBQWlCLEVBQUUsQ0FBQztRQUM1QyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sS0FBSyxTQUFTLENBQUMsR0FBRyxDQUFDO1FBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxLQUFLLGlCQUFpQixDQUFDO1FBRWpELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsU0FBUztRQUNQLDRFQUE0RTtRQUM1RSxxRUFBcUU7UUFDckUsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDO1FBQ3RGLElBQUcsYUFBYSxJQUFJLGFBQWEsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZELElBQUksQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQztRQUNwQyxDQUFDO0lBQ0gsQ0FBQztJQUNELGVBQWU7UUFDYixLQUFLLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQzVFLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDekIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDbkIsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNWLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQXNCLEVBQUUsRUFBRTtnQkFDMUQsTUFBTSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsS0FBSyxLQUFLLEtBQUssQ0FBQztZQUMxQyxDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLENBQUM7SUFDSCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNuRSxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFOUUsSUFBSSxjQUFjLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxjQUFjLEVBQUUsS0FBSyxDQUFDO1lBQ3RDLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztZQUNuQixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUNyQixDQUFDO0lBRU0sY0FBYyxDQUFDLE1BQXNCO1FBQzFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTVCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFXLFFBQVE7UUFDakIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUNRLFdBQVc7UUFDbEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUNwQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDdEIsQ0FBQzs4R0F6SFUsZ0JBQWdCO2tHQUFoQixnQkFBZ0IsaUlDMUI3QixzdkNBZ0NBLDJDRGZJLGFBQWEsbUxBQ2IsY0FBYyxvbEJBQ2QsZ0JBQWdCLDhCQUNoQixrQkFBa0IsdUxBQ2xCLG1CQUFtQiwrQkFDbkIsa0JBQWtCOzsyRkFJVCxnQkFBZ0I7a0JBZDVCLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLFVBQVUsV0FFWDt3QkFDUCxhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBQ2xCLG1CQUFtQjt3QkFDbkIsa0JBQWtCO3FCQUNuQjs7MEJBaUJhLFFBQVE7OzBCQUFJLElBQUk7eUNBWGQsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBNYXRSYWRpb01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3JhZGlvJztcbmltcG9ydCB7IE1hdFRvb2x0aXBNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sdGlwJztcbmltcG9ydCB7IE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5nQ29udHJvbCwgUmVhY3RpdmVGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgT3B0aW9uYWwsIFNlbGYsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbERpc3BsYXksIENsUmFkaW9PcHRpb25zLCBDbFJhZGlvUHJvcGVydGllcyB9IGZyb20gJy4vcmFkaW8ucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtcmFkaW8nLFxuICB0ZW1wbGF0ZVVybDogJy4vcmFkaW8uY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRSYWRpb01vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdXG59KVxuXG5leHBvcnQgY2xhc3MgQ2xSYWRpb0NvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XG4gIC8vIFBsZWFzZSBwdXQgYWxsIHRoZSBhbmd1bGFyIGRlY29yYXRlZCB2YXJpYWJsZXMgYmVsb3cgdGhpc1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsUmFkaW9Qcm9wZXJ0aWVzO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBSZXF1aXJlZCB0byBpbXBsZW1lbnQgQ29udHJvbFZhbHVlQWNjZXNzb3JcbiAgcHJvdGVjdGVkIF92YWx1ZTogYW55O1xuICBvbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgb25Ub3VjaGVkID0gKF86IGFueSkgPT4geyB9O1xuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgcHJpdmF0ZSB2YWx1ZUNoYW5nZXNTdWI/OiBTdWJzY3JpcHRpb247XG5cbiAgY29uc3RydWN0b3IgKEBPcHRpb25hbCgpIEBTZWxmKCkgcHVibGljIG5nQ29udHJvbDogTmdDb250cm9sKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xSYWRpb1Byb3BlcnRpZXMoKTtcbiAgICB0aGlzLnByb3BlcnRpZXMuZGlzcGxheSA/Pz0gQ2xEaXNwbGF5LnJvdztcbiAgICB0aGlzLnByb3BlcnRpZXMucmFkaW9TdHlsZSA/Pz0gJ2NsLXJhZGlvLWJ1dHRvbic7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgbmdEb0NoZWNrKCkge1xuICAgIC8vIGZpbmQgdGhlIG9wdGlvbiB3aGljaCBpcyBoYXZpbmcgY2hlY2tlZCBhcyB0cnVlIGFuZCBjaGVjayB3aXRoIHRoZSB2YWx1ZS5cbiAgICAvLyBpZiBib3RoIGFyZSBub3Qgc2FtZSB1cGRhdGUgdGhlIHZhbHVlIHdpdGggdGhlIGNoZWNrZWQgdHJ1ZSBvcHRpb25cbiAgICBjb25zdCBjaGVja2VkT3B0aW9uID0gdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnM/LmZpbmQoKG9wdDphbnkpID0+IG9wdC5jaGVja2VkID09IHRydWUpO1xuICAgIGlmKGNoZWNrZWRPcHRpb24gJiYgY2hlY2tlZE9wdGlvbi52YWx1ZSAhPSB0aGlzLl92YWx1ZSkge1xuICAgICAgdGhpcy5fdmFsdWUgPSBjaGVja2VkT3B0aW9uLnZhbHVlO1xuICAgIH1cbiAgfVxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgc3VwZXIuc3Vic2NyaWJlVG9WYWx1ZUNoYW5nZXModGhpcy53cml0ZVZhbHVlLmJpbmQodGhpcykpO1xuXG4gICAgdGhpcy52YWx1ZUNoYW5nZXNTdWIgPSB0aGlzLm5nQ29udHJvbD8udmFsdWVDaGFuZ2VzPy5zdWJzY3JpYmUoKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgIHRoaXMud3JpdGVWYWx1ZSh2YWx1ZSk7XG4gICAgfSk7XG4gIH1cblxuICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vcHRpb25zPy5mb3JFYWNoKChvcHRpb246IENsUmFkaW9PcHRpb25zKSA9PiB7XG4gICAgICAgIG9wdGlvbi5jaGVja2VkID0gb3B0aW9uLnZhbHVlID09PSB2YWx1ZTtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLl92YWx1ZSA9IHZhbHVlO1xuICAgIH1cbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmbjtcbiAgfVxuXG4gIGdldCB2YWx1ZSgpOiBhbnkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub3B0aW9ucyAmJiB0aGlzLnByb3BlcnRpZXMub3B0aW9ucz8ubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3Qgc2VsZWN0ZWRPcHRpb24gPSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucy5maW5kKG9wdGlvbiA9PiBvcHRpb24uY2hlY2tlZCk7XG5cbiAgICAgIGlmIChzZWxlY3RlZE9wdGlvbikge1xuICAgICAgICB0aGlzLl92YWx1ZSA9IHNlbGVjdGVkT3B0aW9uPy52YWx1ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3ZhbHVlID0gJyc7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICB9XG5cbiAgcHVibGljIG9uVmFsdWVDaGFuZ2VkKG9wdGlvbjogQ2xSYWRpb09wdGlvbnMpIHtcbiAgICB0aGlzLndyaXRlVmFsdWUob3B0aW9uLnZhbHVlKTtcbiAgICB0aGlzLm9uQ2hhbmdlKG9wdGlvbi52YWx1ZSk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uVmFsdWVDaGFuZ2VkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZWQob3B0aW9uLnZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZ2V0IGRpc2FibGVkKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCgpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgc2hvd0luZm9Nc2coKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIG92ZXJyaWRlIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMudmFsdWVDaGFuZ2VzU3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gIH1cbn1cbiIsIjxkaXYgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBjbGFzcz1cImZsZXggZ2FwLTIgZmxleC1jb2wge3twcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzfX1cIj5cbiAgQGlmIChwcm9wZXJ0aWVzLmxhYmVsKSB7XG4gICAgPG1hdC1sYWJlbCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICA8c3BhbiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmxhYmVsQ3NzQ2xhc3NlcyB9fVwiPnt7IHByb3BlcnRpZXMubGFiZWwgfX08L3NwYW4+XG5cbiAgICAgIEBpZiAocHJvcGVydGllcy5vcHRpb25hbCkge1xuICAgICAgICA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsLXRleHRcIj4oT3B0aW9uYWwpPC9zcGFuPlxuICAgICAgfVxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgICAgICA8bWF0LWljb24gW3Rvb2x0aXBdPVwicHJvcGVydGllcy5pbmZvTXNnIVwiXG4gICAgICAgICAgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmluZm9ybWF0aW9uLWNpcmNsZSdcIiBjbGFzcz1cIm1sLTEgaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXIgdGV4dC1uZXV0cmFsLTYwMFwiPlxuICAgICAgICA8L21hdC1pY29uPlxuICAgICAgfVxuICAgIDwvbWF0LWxhYmVsPlxuICB9XG5cbiAgPG1hdC1yYWRpby1ncm91cCBjb2xvcj1cInByaW1hcnlcIiBbaWRdPVwicHJvcGVydGllcy5pZFwiIGNsYXNzPVwiZmxleCBnYXAtMiB7e3Byb3BlcnRpZXMuZGlzcGxheX19XCIgW3ZhbHVlXT1cInZhbHVlXCJcbiAgICAoY2hhbmdlKT1cIndyaXRlVmFsdWUoJGFueSgkZXZlbnQpLnZhbHVlKVwiIFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiPlxuXG4gICAgQGZvciAob3B0aW9uIG9mIHByb3BlcnRpZXMub3B0aW9ucyE7IHRyYWNrIG9wdGlvbikge1xuICAgICAgPG1hdC1yYWRpby1idXR0b24gW3ZhbHVlXT1cIm9wdGlvbi52YWx1ZVwiIChjaGFuZ2UpPVwib25WYWx1ZUNoYW5nZWQob3B0aW9uKVwiXG4gICAgICAgIGNsYXNzPVwiY3Vyc29yLXBvaW50ZXIge3twcm9wZXJ0aWVzLnJhZGlvU3R5bGV9fVwiPlxuICAgICAgICA8c3BhbiBjbGFzcz1cImN1cnNvci1wb2ludGVyXCI+e3sgb3B0aW9uLnRleHQgfX08L3NwYW4+XG4gICAgICA8L21hdC1yYWRpby1idXR0b24+XG4gICAgfVxuICA8L21hdC1yYWRpby1ncm91cD5cblxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgICA8bWF0LWhpbnQ+e3sgcHJvcGVydGllcy5oaW50VGV4dCB9fTwvbWF0LWhpbnQ+XG4gIH1cbjwvZGl2PlxuIl19