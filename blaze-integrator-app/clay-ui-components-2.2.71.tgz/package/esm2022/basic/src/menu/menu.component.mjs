import { Component, Input } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { ClIconComponent } from '../icon';
import { ClLabelComponent } from '../label';
import { ClMenuProperties } from './menu.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClMenuItemComponent } from './menu-item/menu-item.component';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/icon";
import * as i2 from "@angular/material/menu";
export class ClMenuComponent extends ClBaseComponent {
    // ---------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClMenuProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMenuComponent, isStandalone: true, selector: "cl-menu", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<button mat-flat-button type=\"button\" [id]=\"properties.id\" [matMenuTriggerFor]=\"menu.childMenu\"\n  class=\"{{properties.style?.cssClasses}} px-4 py-2 flex gap-1 items-center justify-center\">\n\n  <div class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</div>\n\n  @if (properties.iconName) {\n    <mat-icon [svgIcon]=\"properties.iconName\"></mat-icon>\n  }\n</button>\n\n<cl-menu-item #menu [items]=\"properties.children!\"></cl-menu-item>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "directive", type: i2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "component", type: ClMenuItemComponent, selector: "cl-menu-item", inputs: ["items"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMenuComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-menu', imports: [
                        MatIconModule,
                        MatMenuModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClMenuItemComponent,
                    ], template: "<button mat-flat-button type=\"button\" [id]=\"properties.id\" [matMenuTriggerFor]=\"menu.childMenu\"\n  class=\"{{properties.style?.cssClasses}} px-4 py-2 flex gap-1 items-center justify-center\">\n\n  <div class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</div>\n\n  @if (properties.iconName) {\n    <mat-icon [svgIcon]=\"properties.iconName\"></mat-icon>\n  }\n</button>\n\n<cl-menu-item #menu [items]=\"properties.children!\"></cl-menu-item>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL21lbnUvbWVudS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL21lbnUvbWVudS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUN6RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBRXZELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxTQUFTLENBQUM7QUFDMUMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sVUFBVSxDQUFDO0FBQzVDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQzs7OztBQWdCdEUsTUFBTSxPQUFPLGVBQWdCLFNBQVEsZUFBZTtJQUdsRCw4QkFBOEI7SUFFOUI7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1FBRTNDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDOzhHQW5CVSxlQUFlO2tHQUFmLGVBQWUsZ0lDeEI1QixzZEFXQSx5RERLSSxhQUFhLG1MQUNiLGFBQWEscVZBSWIsbUJBQW1COzsyRkFHVixlQUFlO2tCQWQzQixTQUFTO2lDQUNJLElBQUksWUFDTixTQUFTLFdBR1Y7d0JBQ1AsYUFBYTt3QkFDYixhQUFhO3dCQUViLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQixtQkFBbUI7cUJBQ3BCO3dEQUllLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNYXRNZW51TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvbWVudSc7XG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5cbmltcG9ydCB7IENsSWNvbkNvbXBvbmVudCB9IGZyb20gJy4uL2ljb24nO1xuaW1wb3J0IHsgQ2xMYWJlbENvbXBvbmVudCB9IGZyb20gJy4uL2xhYmVsJztcbmltcG9ydCB7IENsTWVudVByb3BlcnRpZXMgfSBmcm9tICcuL21lbnUucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbE1lbnVJdGVtQ29tcG9uZW50IH0gZnJvbSAnLi9tZW51LWl0ZW0vbWVudS1pdGVtLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLW1lbnUnLFxuICBzdHlsZVVybDogJy4vbWVudS5jb21wb25lbnQuc2NzcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9tZW51LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0TWVudU1vZHVsZSxcblxuICAgIENsSWNvbkNvbXBvbmVudCxcbiAgICBDbExhYmVsQ29tcG9uZW50LFxuICAgIENsTWVudUl0ZW1Db21wb25lbnQsXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIENsTWVudUNvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xNZW51UHJvcGVydGllcztcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgY29uc3RydWN0b3IgKCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbE1lbnVQcm9wZXJ0aWVzKCk7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG59XG4iLCI8YnV0dG9uIG1hdC1mbGF0LWJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBbbWF0TWVudVRyaWdnZXJGb3JdPVwibWVudS5jaGlsZE1lbnVcIlxuICBjbGFzcz1cInt7cHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3Nlc319IHB4LTQgcHktMiBmbGV4IGdhcC0xIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuXG4gIDxkaXYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN0eWxlPy5sYWJlbENzc0NsYXNzZXMgfX1cIj57e3Byb3BlcnRpZXMubGFiZWx9fTwvZGl2PlxuXG4gIEBpZiAocHJvcGVydGllcy5pY29uTmFtZSkge1xuICAgIDxtYXQtaWNvbiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLmljb25OYW1lXCI+PC9tYXQtaWNvbj5cbiAgfVxuPC9idXR0b24+XG5cbjxjbC1tZW51LWl0ZW0gI21lbnUgW2l0ZW1zXT1cInByb3BlcnRpZXMuY2hpbGRyZW4hXCI+PC9jbC1tZW51LWl0ZW0+XG4iXX0=