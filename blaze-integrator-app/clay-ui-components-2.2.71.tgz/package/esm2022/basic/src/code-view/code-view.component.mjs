import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Input, Component } from '@angular/core';
import { ClHighlightComponent } from '@clay/ui-commons/ccc';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClCodeViewProperties } from './code-view.properties';
import * as i0 from "@angular/core";
export class ClCodeViewComponent extends ClBaseComponent {
    constructor(cdr) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.cdr = cdr;
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClCodeViewProperties();
        this.formatCode();
        super.ngOnInit();
    }
    ngOnChanges(_changes) {
        this.formatCode();
    }
    formatCode() {
        if (this.code?.length && this.properties.lang?.toLowerCase() == 'json') {
            // Step 1: Clean the escape characters
            let code = this.code?.replace(/\\"/g, '"'); // Replace escaped quotes \" with actual "
            code = code?.replace(/\\n/g, ''); // Remove any newlines
            code = code?.replace(/\\/g, ''); // Remove unnecessary backslashes
            try {
                // Step 2: Parse the string to JSON
                const validJson = JSON.parse(code);
                // Step 3: Prettify JSON object
                this.properties.code = JSON.stringify(validJson, null, 2);
                this.cdr.detectChanges();
            }
            catch (e) {
                console.error(66, "Error parsing JSON:", e.message);
                console.error(67, "JSON:", code);
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCodeViewComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClCodeViewComponent, isStandalone: true, selector: "cl-code-view", inputs: { code: "code", properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<textarea cl-highlight [lang]=\"properties.lang\" [code]=\"properties.code\" [class]=\"properties.style?.cssClasses\"\n  [fontStyle]=\"properties.style?.fontStyle\">\n</textarea>\n", styles: [":host{display:flex;width:100%;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClHighlightComponent, selector: "textarea[cl-highlight]", inputs: ["code", "lang", "fontStyle"], exportAs: ["clHighlight"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClCodeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-code-view', imports: [
                        MatIconModule,
                        MatFormFieldModule,
                        ClHighlightComponent
                    ], template: "<textarea cl-highlight [lang]=\"properties.lang\" [code]=\"properties.code\" [class]=\"properties.style?.cssClasses\"\n  [fontStyle]=\"properties.style?.fontStyle\">\n</textarea>\n", styles: [":host{display:flex;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { code: [{
                type: Input,
                args: [{ required: true }]
            }], properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZS12aWV3LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvY29kZS12aWV3L2NvZGUtdmlldy5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NvZGUtdmlldy9jb2RlLXZpZXcuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxLQUFLLEVBQVUsU0FBUyxFQUFvQyxNQUFNLGVBQWUsQ0FBQztBQUUzRixPQUFPLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUM1RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDN0QsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sd0JBQXdCLENBQUM7O0FBYzlELE1BQU0sT0FBTyxtQkFBb0IsU0FBUSxlQUFlO0lBT3RELFlBQXFCLEdBQXNCO1FBQ3pDOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTFcsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFNekMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO0lBQ3pHLENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLG9CQUFvQixFQUFFLENBQUM7UUFFL0MsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBRWxCLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQXVCO1FBQ2pDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU8sVUFBVTtRQUNoQixJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRSxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ3ZFLHNDQUFzQztZQUN0QyxJQUFJLElBQUksR0FBUSxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQywwQ0FBMEM7WUFDM0YsSUFBSSxHQUFHLElBQUksRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUcsc0JBQXNCO1lBQzFELElBQUksR0FBRyxJQUFJLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFJLGlDQUFpQztZQUVyRSxJQUFJLENBQUM7Z0JBQ0gsbUNBQW1DO2dCQUNuQyxNQUFNLFNBQVMsR0FBUSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUV4QywrQkFBK0I7Z0JBQy9CLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFFMUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUMzQixDQUFDO1lBQUMsT0FBTyxDQUFNLEVBQUUsQ0FBQztnQkFDaEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUNwRCxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDbkMsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDOzhHQWpEVSxtQkFBbUI7a0dBQW5CLG1CQUFtQix3S0NwQmhDLHNMQUdBLHFHRFdJLGFBQWEsOEJBQ2Isa0JBQWtCLCtCQUVsQixvQkFBb0I7OzJGQUdYLG1CQUFtQjtrQkFaL0IsU0FBUztpQ0FDSSxJQUFJLFlBQ04sY0FBYyxXQUdmO3dCQUNQLGFBQWE7d0JBQ2Isa0JBQWtCO3dCQUVsQixvQkFBb0I7cUJBQ3JCO3NGQUlNLElBQUk7c0JBRFYsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBSVQsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9mb3JtLWZpZWxkJztcbmltcG9ydCB7IElucHV0LCBPbkluaXQsIENvbXBvbmVudCwgU2ltcGxlQ2hhbmdlcywgQ2hhbmdlRGV0ZWN0b3JSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ2xIaWdobGlnaHRDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21tb25zL2NjYyc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbENvZGVWaWV3UHJvcGVydGllcyB9IGZyb20gJy4vY29kZS12aWV3LnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1jb2RlLXZpZXcnLFxuICBzdHlsZVVybDogJy4vY29kZS12aWV3LmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvZGUtdmlldy5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtcbiAgICBNYXRJY29uTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcblxuICAgIENsSGlnaGxpZ2h0Q29tcG9uZW50XG4gIF1cbn0pXG5leHBvcnQgY2xhc3MgQ2xDb2RlVmlld0NvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBjb2RlOiBhbnk7XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbENvZGVWaWV3UHJvcGVydGllcztcblxuICBjb25zdHJ1Y3RvciAocHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsQ29kZVZpZXdQcm9wZXJ0aWVzKCk7XG5cbiAgICB0aGlzLmZvcm1hdENvZGUoKTtcblxuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuICBuZ09uQ2hhbmdlcyhfY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIHRoaXMuZm9ybWF0Q29kZSgpO1xuICB9XG5cbiAgcHJpdmF0ZSBmb3JtYXRDb2RlKCkge1xuICAgIGlmICh0aGlzLmNvZGU/Lmxlbmd0aCAmJiB0aGlzLnByb3BlcnRpZXMubGFuZz8udG9Mb3dlckNhc2UoKSA9PSAnanNvbicpIHtcbiAgICAgIC8vIFN0ZXAgMTogQ2xlYW4gdGhlIGVzY2FwZSBjaGFyYWN0ZXJzXG4gICAgICBsZXQgY29kZTogYW55ID0gdGhpcy5jb2RlPy5yZXBsYWNlKC9cXFxcXCIvZywgJ1wiJyk7IC8vIFJlcGxhY2UgZXNjYXBlZCBxdW90ZXMgXFxcIiB3aXRoIGFjdHVhbCBcIlxuICAgICAgY29kZSA9IGNvZGU/LnJlcGxhY2UoL1xcXFxuL2csICcnKTsgICAvLyBSZW1vdmUgYW55IG5ld2xpbmVzXG4gICAgICBjb2RlID0gY29kZT8ucmVwbGFjZSgvXFxcXC9nLCAnJyk7ICAgIC8vIFJlbW92ZSB1bm5lY2Vzc2FyeSBiYWNrc2xhc2hlc1xuXG4gICAgICB0cnkge1xuICAgICAgICAvLyBTdGVwIDI6IFBhcnNlIHRoZSBzdHJpbmcgdG8gSlNPTlxuICAgICAgICBjb25zdCB2YWxpZEpzb246IGFueSA9IEpTT04ucGFyc2UoY29kZSk7XG5cbiAgICAgICAgLy8gU3RlcCAzOiBQcmV0dGlmeSBKU09OIG9iamVjdFxuICAgICAgICB0aGlzLnByb3BlcnRpZXMuY29kZSA9IEpTT04uc3RyaW5naWZ5KHZhbGlkSnNvbiwgbnVsbCwgMik7XG5cbiAgICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICAgICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoNjYsIFwiRXJyb3IgcGFyc2luZyBKU09OOlwiLCBlLm1lc3NhZ2UpO1xuICAgICAgICBjb25zb2xlLmVycm9yKDY3LCBcIkpTT046XCIsIGNvZGUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuIiwiPHRleHRhcmVhIGNsLWhpZ2hsaWdodCBbbGFuZ109XCJwcm9wZXJ0aWVzLmxhbmdcIiBbY29kZV09XCJwcm9wZXJ0aWVzLmNvZGVcIiBbY2xhc3NdPVwicHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3Nlc1wiXG4gIFtmb250U3R5bGVdPVwicHJvcGVydGllcy5zdHlsZT8uZm9udFN0eWxlXCI+XG48L3RleHRhcmVhPlxuIl19