import { Component, Input } from '@angular/core';
import { ClLabelProperties } from './label.properties';
import { ClTruncatePipe } from '@clay/ui-commons/ancillary';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/icon";
import * as i2 from "@angular/material/tooltip";
export class ClLabelComponent extends ClBaseComponent {
    // ---------------------------
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClLabelProperties();
        super.ngOnInit();
    }
    onLabelClick() {
        if (this.properties.onClick) {
            this.properties.onClick();
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClLabelComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClLabelComponent, isStandalone: true, selector: "cl-label", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" (click)=\"onLabelClick()\" class=\"{{ properties.style?.cssClasses }} flex items-center\"\n  [matTooltip]=\"properties.showTooltip ? properties.label!: ''\">\n\n  @if (properties.lengthToTrim == undefined) {\n    <span>{{ properties.label }}</span>\n  } @else if (properties.lengthToTrim != undefined) {\n    <span>{{ properties.label | truncate: [properties.lengthToTrim] }}</span>\n  }\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n</div>\n", styles: [":host{display:flex!important}\n"], dependencies: [{ kind: "pipe", type: ClTruncatePipe, name: "truncate" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClLabelComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-label', imports: [
                        ClTruncatePipe,
                        MatIconModule,
                        MatTooltipModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" (click)=\"onLabelClick()\" class=\"{{ properties.style?.cssClasses }} flex items-center\"\n  [matTooltip]=\"properties.showTooltip ? properties.label!: ''\">\n\n  @if (properties.lengthToTrim == undefined) {\n    <span>{{ properties.label }}</span>\n  } @else if (properties.lengthToTrim != undefined) {\n    <span>{{ properties.label | truncate: [properties.lengthToTrim] }}</span>\n  }\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n    }\n</div>\n", styles: [":host{display:flex!important}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFiZWwuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9sYWJlbC9sYWJlbC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2xhYmVsL2xhYmVsLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2pELE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUM1RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7O0FBa0JoRSxNQUFNLE9BQU8sZ0JBQWlCLFNBQVEsZUFBZTtJQUluRCw4QkFBOEI7SUFFOUI7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxpQkFBaUIsRUFBRSxDQUFDO1FBQzVDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRVMsWUFBWTtRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVELElBQVcsV0FBVztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzdDLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDcEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUNyQyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7OEdBckNVLGdCQUFnQjtrR0FBaEIsZ0JBQWdCLGlJQ3hCN0IseXBCQWNBLG9GRElJLGNBQWMsZ0RBQ2QsYUFBYSxtTEFDYixnQkFBZ0IsNlRBQ2hCLGtCQUFrQjs7MkZBR1QsZ0JBQWdCO2tCQWhCNUIsU0FBUztpQ0FDSSxJQUFJLFlBQ04sVUFBVSxXQU9YO3dCQUNQLGNBQWM7d0JBQ2QsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLGtCQUFrQjtxQkFDbkI7d0RBS2UsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbExhYmVsUHJvcGVydGllcyB9IGZyb20gJy4vbGFiZWwucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbFRydW5jYXRlUGlwZSB9IGZyb20gJ0BjbGF5L3VpLWNvbW1vbnMvYW5jaWxsYXJ5JztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IE1hdFRvb2x0aXBNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sdGlwJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtbGFiZWwnLFxuICB0ZW1wbGF0ZVVybDogJy4vbGFiZWwuY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZXM6IFtgXG4gICAgOmhvc3Qge1xuICAgICAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICAgIH1cbiAgYF0sXG4gIGltcG9ydHM6IFtcbiAgICBDbFRydW5jYXRlUGlwZSxcbiAgICBNYXRJY29uTW9kdWxlLFxuICAgIE1hdFRvb2x0aXBNb2R1bGUsXG4gICAgQ2xUb29sdGlwRGlyZWN0aXZlXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIENsTGFiZWxDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQge1xuICAvLyBQbGVhc2UgcHV0IGFsbCB0aGUgYW5ndWxhciBkZWNvcmF0ZWQgdmFyaWFibGVzIGJlbG93IHRoaXNcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbExhYmVsUHJvcGVydGllcztcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgY29uc3RydWN0b3IgKCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbExhYmVsUHJvcGVydGllcygpO1xuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgb25MYWJlbENsaWNrKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25DbGljaykge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uQ2xpY2soKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuIiwiPGRpdiBbaWRdPVwicHJvcGVydGllcy5pZFwiIChjbGljayk9XCJvbkxhYmVsQ2xpY2soKVwiIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fSBmbGV4IGl0ZW1zLWNlbnRlclwiXG4gIFttYXRUb29sdGlwXT1cInByb3BlcnRpZXMuc2hvd1Rvb2x0aXAgPyBwcm9wZXJ0aWVzLmxhYmVsITogJydcIj5cblxuICBAaWYgKHByb3BlcnRpZXMubGVuZ3RoVG9UcmltID09IHVuZGVmaW5lZCkge1xuICAgIDxzcGFuPnt7IHByb3BlcnRpZXMubGFiZWwgfX08L3NwYW4+XG4gIH0gQGVsc2UgaWYgKHByb3BlcnRpZXMubGVuZ3RoVG9UcmltICE9IHVuZGVmaW5lZCkge1xuICAgIDxzcGFuPnt7IHByb3BlcnRpZXMubGFiZWwgfCB0cnVuY2F0ZTogW3Byb3BlcnRpZXMubGVuZ3RoVG9UcmltXSB9fTwvc3Bhbj5cbiAgfVxuICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCJcbiAgICAgIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTppbmZvcm1hdGlvbi1jaXJjbGUnXCIgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICA8L21hdC1pY29uPlxuICAgIH1cbjwvZGl2PlxuIl19