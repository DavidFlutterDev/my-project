import { of } from 'rxjs';
import { NgClass, AsyncPipe } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatAutocompleteTrigger, MatAutocompleteModule } from '@angular/material/autocomplete';
import { FormsModule, FormControl, ReactiveFormsModule } from '@angular/forms';
import { Self, Input, Optional, Component, ViewChild } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { ClNestedAutoCompleteProperties } from './nested-autocomplete.properties';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/input";
import * as i4 from "@angular/material/form-field";
import * as i5 from "@angular/material/autocomplete";
import * as i6 from "@angular/material/core";
export class ClNestedAutocompleteComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.inputControl = new FormControl();
        this.selectedOptions = [];
        this.filteredOptions = of([]);
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnChanges(_changes) {
        this.setDefaultValueAndOptions();
    }
    ngOnInit() {
        this.properties ??= new ClNestedAutoCompleteProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            .subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
        }
    }
    setDefaultValueAndOptions() {
        if (this.properties.selectedValue) {
            this.setDefaultSelectedValues();
            this.filteredOptions = of([]);
        }
        else {
            this.filteredOptions = of(this.properties.options);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    filterOptions(value) {
        let filterValue;
        if (typeof value === 'object') {
            filterValue = value.name.toLowerCase();
        }
        else {
            filterValue = value.toLowerCase();
        }
        let currentOptions = this.properties.options;
        // Traverse the selected options to reach the current level
        this.selectedOptions.forEach((selected) => {
            if (selected.list) {
                currentOptions = selected.list;
            }
        });
        // Filter out already selected options
        const selectedNames = this.selectedOptions.map((option) => option.text.toLowerCase());
        // If filterValue ends with ".", show list of the last selected option
        if (filterValue.endsWith('.')) {
            const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
            return lastSelected?.list || [];
        }
        return currentOptions.filter((option) => option.text.toLowerCase().includes(filterValue) && !selectedNames.includes(option.text.toLowerCase()));
    }
    onOptionSelected(event) {
        const selectedOption = event.option.value;
        // Check if the selected option is already in the selectedOptions array
        if (!this.selectedOptions.includes(selectedOption)) {
            // Add to the selected options
            this.selectedOptions.push(selectedOption);
            // Update the input control to show the selected path
            const selectedPath = this.selectedOptions.map((option) => option.text).join('.');
            this.inputControl.setValue(selectedPath, { emitEvent: false });
            // Reset filtered options to empty
            this.filteredOptions = of([]);
            this.onValueChange(this.inputControl.value);
        }
    }
    setDefaultSelectedValues() {
        const defaultPath = this.properties.selectedValue;
        if (!defaultPath) {
            return;
        }
        this.selectedOptions = [];
        let currentOptions = this.properties.options;
        const parts = defaultPath.split('.');
        for (const part of parts) {
            const selectedOption = currentOptions?.find((option) => option.text === part);
            if (selectedOption) {
                this.selectedOptions.push(selectedOption);
                if (selectedOption.list) {
                    currentOptions = selectedOption.list;
                }
                else {
                    break;
                }
            }
            else {
                break;
            }
        }
        if (this.selectedOptions.length > 0) {
            const selectedPath = this.selectedOptions.map((option) => option.text).join('.');
            this.inputControl.setValue(selectedPath, { emitEvent: false });
        }
        else {
            this.inputControl.setValue(defaultPath, { emitEvent: false });
        }
    }
    onInputChange(event) {
        const value = event.target.value;
        if (!value || value.trim() === '') {
            // If the input field is empty, show all top-level options
            this.filteredOptions = of(this.properties.options);
        }
        else {
            const lastDotIndex = value.lastIndexOf('.');
            let additionalText = '';
            if (lastDotIndex !== -1 && this.selectedOptions.length > 0) {
                // Separate the additional typed text from the selected options
                additionalText = value.slice(lastDotIndex + 1);
                const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
                const children = lastSelected?.list || [];
                this.filteredOptions = of(children.filter((option) => option.text?.toLowerCase().includes(additionalText.toLowerCase())));
            }
            else if (!this.properties.manualEntry) {
                // Filter options based on the input value
                this.filteredOptions = of(this.filterOptions(value));
            }
            else if (this.properties.manualEntry) {
                // Emit the combined result: selected options + manually typed text
                const combinedValue = this.selectedOptions.map((option) => option.text).join('.') + (additionalText ? `.${additionalText}` : '');
                this.onValueChange(combinedValue);
            }
        }
    }
    onKeydown(event) {
        if (event.key === 'Backspace') {
            const currentValue = this.inputControl.value;
            const lastDotIndex = currentValue.lastIndexOf('.');
            if (lastDotIndex !== -1) {
                // Remove everything after and including the last dot
                const newValue = currentValue.slice(0, lastDotIndex);
                this.inputControl.setValue(newValue, { emitEvent: false });
                // Update the selected options accordingly
                this.selectedOptions = [];
                let currentOptions = this.properties.options;
                newValue.split('.').every((part) => {
                    const selectedOption = currentOptions.find((option) => option.text === part);
                    if (selectedOption) {
                        this.selectedOptions.push(selectedOption);
                        currentOptions = selectedOption.list || [];
                        return true;
                    }
                    return false;
                });
                // Update the filtered options to reflect the current state
                const lastSelected = this.selectedOptions[this.selectedOptions.length - 1];
                this.filteredOptions = of(lastSelected?.list || []);
                this.onValueChange(this.inputControl.value);
                // If there are no list, don't open the dropdown
                if (!lastSelected?.list) {
                    this.autocompleteTrigger?.closePanel();
                }
            }
            else {
                // Clear the input control and reset selections
                this.clearSelection();
                this.autocompleteTrigger?.openPanel();
            }
            event.preventDefault();
        }
    }
    onPrefixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked();
        }
    }
    onSuffixIconClicked(event) {
        // Prevents the click from propagating to the select
        event.stopPropagation();
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked();
        }
    }
    clearSelection() {
        this.selectedOptions = [];
        this.inputControl.setValue('', { emitEvent: false });
        this.filteredOptions = of(this.properties.options);
        this.onValueChange('');
    }
    onValueChange(value) {
        this.onChange(value);
        this.writeValue(value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(value);
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        this.sub?.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedAutocompleteComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClNestedAutocompleteComponent, isStandalone: true, selector: "cl-nested-autocomplete", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "autocompleteTrigger", first: true, predicate: ["autocompleteInput"], descendants: true, read: MatAutocompleteTrigger }], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput #autocompleteInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" [matAutocomplete]=\"auto\"\n    [formControl]=\"inputControl\" (keydown)=\"onKeydown($event)\" (input)=\"onInputChange($event)\"\n    [placeholder]=\"properties.placeholder!\">\n\n  <mat-autocomplete #auto=\"matAutocomplete\" (optionSelected)=\"onOptionSelected($event)\">\n    @for (option of filteredOptions | async; track option) {\n      <mat-option [value]=\"option\" [style.display]=\"option?.hideOption ? 'none' : 'flex'\">{{ option.text }}</mat-option>\n    }\n  </mat-autocomplete>\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\" (click)=\"onPrefixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\" (click)=\"onSuffixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i5.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i6.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i5.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClNestedAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-nested-autocomplete', imports: [
                        NgClass,
                        AsyncPipe,
                        FormsModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        MatAutocompleteModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput #autocompleteInput type=\"text\" [value]=\"value\" [disabled]=\"disabled\" [matAutocomplete]=\"auto\"\n    [formControl]=\"inputControl\" (keydown)=\"onKeydown($event)\" (input)=\"onInputChange($event)\"\n    [placeholder]=\"properties.placeholder!\">\n\n  <mat-autocomplete #auto=\"matAutocomplete\" (optionSelected)=\"onOptionSelected($event)\">\n    @for (option of filteredOptions | async; track option) {\n      <mat-option [value]=\"option\" [style.display]=\"option?.hideOption ? 'none' : 'flex'\">{{ option.text }}</mat-option>\n    }\n  </mat-autocomplete>\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\" (click)=\"onPrefixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\" (click)=\"onSuffixIconClicked($event)\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], autocompleteTrigger: [{
                type: ViewChild,
                args: ['autocompleteInput', { read: MatAutocompleteTrigger }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmVzdGVkLWF1dG9jb21wbGV0ZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL25lc3RlZC1hdXRvY29tcGxldGUvbmVzdGVkLWF1dG9jb21wbGV0ZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL25lc3RlZC1hdXRvY29tcGxldGUvbmVzdGVkLWF1dG9jb21wbGV0ZS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsRUFBRSxFQUE0QixNQUFNLE1BQU0sQ0FBQztBQUNwRCxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDbEUsT0FBTyxFQUFFLHNCQUFzQixFQUFFLHFCQUFxQixFQUFnQyxNQUFNLGdDQUFnQyxDQUFDO0FBQzdILE9BQU8sRUFBYSxXQUFXLEVBQUUsV0FBVyxFQUFvQixtQkFBbUIsRUFBd0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUNsSSxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBVSxRQUFRLEVBQWEsU0FBUyxFQUFFLFNBQVMsRUFBZ0UsTUFBTSxlQUFlLENBQUM7QUFFN0osT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBOEIsOEJBQThCLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQzs7Ozs7Ozs7QUE2QjlHLE1BQU0sT0FBTyw2QkFBOEIsU0FBUSxlQUFlO0lBcUJoRSxZQUF3QyxTQUFvQjtRQUMxRDs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUw4QixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBVjVELGFBQVEsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBRTNCLGNBQVMsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBR2xCLGlCQUFZLEdBQXFCLElBQUksV0FBVyxFQUFFLENBQUM7UUFFbkQsb0JBQWUsR0FBaUMsRUFBRSxDQUFDO1FBQ25ELG9CQUFlLEdBQTZDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQVEzRSxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyQyx1R0FBdUc7UUFFdkcsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLHdEQUF3RDtZQUN4RCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBRUQsV0FBVyxDQUFDLFFBQXVCO1FBQ2pDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxDQUFDO0lBQ25DLENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLDhCQUE4QixFQUFFLENBQUM7UUFFekQsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxlQUFlO1FBQ2IsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFMUQsaURBQWlEO1FBQ2pELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFjO2FBQ3RDLFNBQVMsQ0FBQyxDQUFDLE9BQVksRUFBRSxFQUFFO1lBQzFCLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztZQUNwQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQscUJBQXFCO1FBQ25CLHVGQUF1RjtRQUN2RixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsd0RBQXdEO1FBQ3hELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdkYsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM3RSxDQUFDO0lBQ0gsQ0FBQztJQUVPLHlCQUF5QjtRQUMvQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7WUFDaEMsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEMsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsQ0FBQyxDQUFDO1FBQ3RELENBQUM7SUFDSCxDQUFDO0lBRU8sYUFBYTtRQUNuQixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDOUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUE7UUFDbEIsQ0FBQztJQUNILENBQUM7SUFFTyxhQUFhLENBQUMsS0FBVTtRQUM5QixJQUFJLFdBQW1CLENBQUM7UUFFeEIsSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUUsQ0FBQztZQUM5QixXQUFXLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN6QyxDQUFDO2FBQU0sQ0FBQztZQUNOLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEMsQ0FBQztRQUVELElBQUksY0FBYyxHQUFpQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsQ0FBQztRQUU1RSwyREFBMkQ7UUFDM0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFvQyxFQUFFLEVBQUU7WUFDcEUsSUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2xCLGNBQWMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBQ2pDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILHNDQUFzQztRQUN0QyxNQUFNLGFBQWEsR0FBVSxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQWtDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztRQUV6SCxzRUFBc0U7UUFDdEUsSUFBSSxXQUFXLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDOUIsTUFBTSxZQUFZLEdBQStCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFFdkcsT0FBTyxZQUFZLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNsQyxDQUFDO1FBRUQsT0FBTyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBa0MsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzlLLENBQUM7SUFFUyxnQkFBZ0IsQ0FBQyxLQUFtQztRQUM1RCxNQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQW1DLENBQUM7UUFFeEUsdUVBQXVFO1FBQ3ZFLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO1lBQ25ELDhCQUE4QjtZQUM5QixJQUFJLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUUxQyxxREFBcUQ7WUFDckQsTUFBTSxZQUFZLEdBQVcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFrQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3JILElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBRS9ELGtDQUFrQztZQUNsQyxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUU5QixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUMsQ0FBQztJQUNILENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsTUFBTSxXQUFXLEdBQXVCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1FBRXRFLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNqQixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDO1FBQzFCLElBQUksY0FBYyxHQUFpQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsQ0FBQztRQUU1RSxNQUFNLEtBQUssR0FBYSxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRS9DLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUM7WUFDekIsTUFBTSxjQUFjLEdBQTJDLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFrQyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDO1lBRWxKLElBQUksY0FBYyxFQUFFLENBQUM7Z0JBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUUxQyxJQUFJLGNBQWMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDeEIsY0FBYyxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUM7Z0JBQ3ZDLENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNO2dCQUNSLENBQUM7WUFDSCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTTtZQUNSLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNwQyxNQUFNLFlBQVksR0FBVyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQWtDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDckgsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDakUsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUNoRSxDQUFDO0lBQ0gsQ0FBQztJQUVTLGFBQWEsQ0FBQyxLQUFZO1FBQ2xDLE1BQU0sS0FBSyxHQUFZLEtBQUssQ0FBQyxNQUEyQixDQUFDLEtBQUssQ0FBQztRQUUvRCxJQUFJLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUNsQywwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsQ0FBQztRQUN0RCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sWUFBWSxHQUFXLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEQsSUFBSSxjQUFjLEdBQVcsRUFBRSxDQUFDO1lBRWhDLElBQUksWUFBWSxLQUFLLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUMzRCwrREFBK0Q7Z0JBQy9ELGNBQWMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFFL0MsTUFBTSxZQUFZLEdBQStCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZHLE1BQU0sUUFBUSxHQUFpQyxZQUFZLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFFeEUsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQWtDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4SixDQUFDO2lCQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN4QywwQ0FBMEM7Z0JBQzFDLElBQUksQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN2RCxDQUFDO2lCQUFNLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDdkMsbUVBQW1FO2dCQUNuRSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQWtDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUssY0FBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUUvSixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3BDLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVTLFNBQVMsQ0FBQyxLQUFvQjtRQUN0QyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssV0FBVyxFQUFFLENBQUM7WUFDOUIsTUFBTSxZQUFZLEdBQVEsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7WUFDbEQsTUFBTSxZQUFZLEdBQVEsWUFBWSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUV4RCxJQUFJLFlBQVksS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUN4QixxREFBcUQ7Z0JBQ3JELE1BQU0sUUFBUSxHQUFRLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDO2dCQUMxRCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLENBQUMsQ0FBQztnQkFFM0QsMENBQTBDO2dCQUMxQyxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztnQkFDMUIsSUFBSSxjQUFjLEdBQWlDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxDQUFDO2dCQUU1RSxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFO29CQUN0QyxNQUFNLGNBQWMsR0FBMkMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQWtDLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUM7b0JBRWpKLElBQUksY0FBYyxFQUFFLENBQUM7d0JBQ25CLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO3dCQUMxQyxjQUFjLEdBQUcsY0FBYyxDQUFDLElBQUksSUFBSSxFQUFFLENBQUM7d0JBRTNDLE9BQU8sSUFBSSxDQUFDO29CQUNkLENBQUM7b0JBRUQsT0FBTyxLQUFLLENBQUM7Z0JBQ2YsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsMkRBQTJEO2dCQUMzRCxNQUFNLFlBQVksR0FBK0IsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFFdkcsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUMsWUFBWSxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQztnQkFFcEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUU1QyxnREFBZ0Q7Z0JBQ2hELElBQUksQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUM7b0JBQ3hCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxVQUFVLEVBQUUsQ0FBQztnQkFDekMsQ0FBQztZQUNILENBQUM7aUJBQU0sQ0FBQztnQkFDTiwrQ0FBK0M7Z0JBQy9DLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLG1CQUFtQixFQUFFLFNBQVMsRUFBRSxDQUFDO1lBQ3hDLENBQUM7WUFFRCxLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDekIsQ0FBQztJQUNILENBQUM7SUFFUyxtQkFBbUIsQ0FBQyxLQUFVO1FBQ3RDLG9EQUFvRDtRQUNwRCxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7UUFFeEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRVMsbUJBQW1CLENBQUMsS0FBVTtRQUN0QyxvREFBb0Q7UUFDcEQsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXhCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVPLGNBQWM7UUFDcEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsQ0FBQztRQUVwRCxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCLENBQUM7SUFFTyxhQUFhLENBQUMsS0FBVTtRQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdkIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDbkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFrQjtRQUNsQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxJQUFjLFFBQVE7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVRLFdBQVc7UUFDbEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsQ0FBQztJQUMxQixDQUFDOzhHQXRVVSw2QkFBNkI7a0dBQTdCLDZCQUE2Qiw2TkFJQSxzQkFBc0IseUVDN0NoRSx1bEVBb0RBLHlIRDNCSSxPQUFPLCtFQUVQLFNBQVMsNkNBRVQsV0FBVyxzWkFDWCxtQkFBbUIsaU5BRW5CLGFBQWEsbUxBQ2IsY0FBYyw2aUNBQ2QsZ0JBQWdCLDhCQUNoQixrQkFBa0IsOEJBQ2xCLHFCQUFxQix5MUJBRXJCLGtCQUFrQjs7MkZBR1QsNkJBQTZCO2tCQTNCekMsU0FBUztpQ0FDSSxJQUFJLFlBQ04sd0JBQXdCLFdBUXpCO3dCQUNQLE9BQU87d0JBRVAsU0FBUzt3QkFFVCxXQUFXO3dCQUNYLG1CQUFtQjt3QkFFbkIsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsa0JBQWtCO3dCQUNsQixxQkFBcUI7d0JBRXJCLGtCQUFrQjtxQkFDbkI7OzBCQXVCYSxRQUFROzswQkFBSSxJQUFJO3lDQW5CZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJZixtQkFBbUI7c0JBRDVCLFNBQVM7dUJBQUMsbUJBQW1CLEVBQUUsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBvZiwgT2JzZXJ2YWJsZSwgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBOZ0NsYXNzLCBBc3luY1BpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2ljb24nO1xuaW1wb3J0IHsgTWF0SW5wdXRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pbnB1dCc7XG5pbXBvcnQgeyBNYXRUb29sdGlwTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdG9vbHRpcCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9mb3JtLWZpZWxkJztcbmltcG9ydCB7IE1hdEF1dG9jb21wbGV0ZVRyaWdnZXIsIE1hdEF1dG9jb21wbGV0ZU1vZHVsZSwgTWF0QXV0b2NvbXBsZXRlU2VsZWN0ZWRFdmVudCB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2F1dG9jb21wbGV0ZSc7XG5pbXBvcnQgeyBOZ0NvbnRyb2wsIEZvcm1zTW9kdWxlLCBGb3JtQ29udHJvbCwgVmFsaWRhdGlvbkVycm9ycywgUmVhY3RpdmVGb3Jtc01vZHVsZSwgQ29udHJvbFZhbHVlQWNjZXNzb3IgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBTZWxmLCBJbnB1dCwgT25Jbml0LCBPcHRpb25hbCwgT25DaGFuZ2VzLCBDb21wb25lbnQsIFZpZXdDaGlsZCwgT25EZXN0cm95LCBTaW1wbGVDaGFuZ2VzLCBBZnRlclZpZXdJbml0LCBBZnRlckNvbnRlbnRDaGVja2VkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uLCBDbE5lc3RlZEF1dG9Db21wbGV0ZVByb3BlcnRpZXMgfSBmcm9tICcuL25lc3RlZC1hdXRvY29tcGxldGUucHJvcGVydGllcyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLW5lc3RlZC1hdXRvY29tcGxldGUnLFxuICB0ZW1wbGF0ZVVybDogJy4vbmVzdGVkLWF1dG9jb21wbGV0ZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlczogW2BcbiAgICA6aG9zdCB7XG4gICAgICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXSxcbiAgaW1wb3J0czogW1xuICAgIE5nQ2xhc3MsXG5cbiAgICBBc3luY1BpcGUsXG5cbiAgICBGb3Jtc01vZHVsZSxcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRJbnB1dE1vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBNYXRBdXRvY29tcGxldGVNb2R1bGUsXG5cbiAgICBDbFRvb2x0aXBEaXJlY3RpdmVcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBDbE5lc3RlZEF1dG9jb21wbGV0ZUNvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkNoYW5nZXMsIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgT25EZXN0cm95IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbE5lc3RlZEF1dG9Db21wbGV0ZVByb3BlcnRpZXM7XG5cbiAgQFZpZXdDaGlsZCgnYXV0b2NvbXBsZXRlSW5wdXQnLCB7IHJlYWQ6IE1hdEF1dG9jb21wbGV0ZVRyaWdnZXIgfSlcbiAgcHJvdGVjdGVkIGF1dG9jb21wbGV0ZVRyaWdnZXI/OiBNYXRBdXRvY29tcGxldGVUcmlnZ2VyO1xuXG4gIC8vIFJlcXVpcmVkIHRvIGltcGxlbWVudCBDb250cm9sVmFsdWVBY2Nlc3NvclxuICBwcm90ZWN0ZWQgX3ZhbHVlOiBhbnk7XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuXG4gIG9uQ2hhbmdlID0gKF86IGFueSkgPT4geyB9O1xuXG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcblxuICBwcml2YXRlIHN1Yj86IFN1YnNjcmlwdGlvbjtcbiAgcHJvdGVjdGVkIGlucHV0Q29udHJvbDogRm9ybUNvbnRyb2w8YW55PiA9IG5ldyBGb3JtQ29udHJvbCgpO1xuXG4gIHByb3RlY3RlZCBzZWxlY3RlZE9wdGlvbnM6IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uW10gPSBbXTtcbiAgcHJvdGVjdGVkIGZpbHRlcmVkT3B0aW9uczogT2JzZXJ2YWJsZTxDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbltdPiA9IG9mKFtdKTtcblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBuZ09uQ2hhbmdlcyhfY2hhbmdlczogU2ltcGxlQ2hhbmdlcyk6IHZvaWQge1xuICAgIHRoaXMuc2V0RGVmYXVsdFZhbHVlQW5kT3B0aW9ucygpO1xuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xOZXN0ZWRBdXRvQ29tcGxldGVQcm9wZXJ0aWVzKCk7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIHN1cGVyLnN1YnNjcmliZVRvVmFsdWVDaGFuZ2VzKHRoaXMud3JpdGVWYWx1ZS5iaW5kKHRoaXMpKTtcblxuICAgIC8vIHJlbW92ZSBhbGwgdGhlIGVycm9ycyB3aGVuIHRoZSBzdGF0dXMgaXMgdmFsaWRcbiAgICB0aGlzLnN1YiA9IHRoaXMubmdDb250cm9sPy5zdGF0dXNDaGFuZ2VzIVxuICAgICAgLnN1YnNjcmliZSgoY2hhbmdlczogYW55KSA9PiB7XG4gICAgICAgIGlmIChjaGFuZ2VzID09PSAnVkFMSUQnKSB7XG4gICAgICAgICAgdGhpcy5lcnJvciA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG5cbiAgbmdBZnRlckNvbnRlbnRDaGVja2VkKCk6IHZvaWQge1xuICAgIC8vIGJlbG93IGlzIHRvIGF2b2lkIGRpc3BsYXlpbmcgJ3VuZGVmaW5lZCcgb24gc2NyZWVuIHdoZW4gbW9kZWwgaXMgbm90IGRlZmluZWQgLi4geWV0LlxuICAgIHRoaXMuc2V0RW1wdHlWYWx1ZSgpO1xuXG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzZXREZWZhdWx0VmFsdWVBbmRPcHRpb25zKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2VsZWN0ZWRWYWx1ZSkge1xuICAgICAgdGhpcy5zZXREZWZhdWx0U2VsZWN0ZWRWYWx1ZXMoKTtcbiAgICAgIHRoaXMuZmlsdGVyZWRPcHRpb25zID0gb2YoW10pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmZpbHRlcmVkT3B0aW9ucyA9IG9mKHRoaXMucHJvcGVydGllcy5vcHRpb25zISk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzZXRFbXB0eVZhbHVlKCkge1xuICAgIGlmICh0aGlzLl92YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLl92YWx1ZSA9ICcnXG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBmaWx0ZXJPcHRpb25zKHZhbHVlOiBhbnkpOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbltdIHtcbiAgICBsZXQgZmlsdGVyVmFsdWU6IHN0cmluZztcblxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgICBmaWx0ZXJWYWx1ZSA9IHZhbHVlLm5hbWUudG9Mb3dlckNhc2UoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgZmlsdGVyVmFsdWUgPSB2YWx1ZS50b0xvd2VyQ2FzZSgpO1xuICAgIH1cblxuICAgIGxldCBjdXJyZW50T3B0aW9uczogQ2xOZXN0ZWRBdXRvQ29tcGxldGVPcHRpb25bXSA9IHRoaXMucHJvcGVydGllcy5vcHRpb25zITtcblxuICAgIC8vIFRyYXZlcnNlIHRoZSBzZWxlY3RlZCBvcHRpb25zIHRvIHJlYWNoIHRoZSBjdXJyZW50IGxldmVsXG4gICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMuZm9yRWFjaCgoc2VsZWN0ZWQ6IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uKSA9PiB7XG4gICAgICBpZiAoc2VsZWN0ZWQubGlzdCkge1xuICAgICAgICBjdXJyZW50T3B0aW9ucyA9IHNlbGVjdGVkLmxpc3Q7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBGaWx0ZXIgb3V0IGFscmVhZHkgc2VsZWN0ZWQgb3B0aW9uc1xuICAgIGNvbnN0IHNlbGVjdGVkTmFtZXM6IGFueVtdID0gdGhpcy5zZWxlY3RlZE9wdGlvbnMubWFwKChvcHRpb246IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uKSA9PiBvcHRpb24udGV4dC50b0xvd2VyQ2FzZSgpKTtcblxuICAgIC8vIElmIGZpbHRlclZhbHVlIGVuZHMgd2l0aCBcIi5cIiwgc2hvdyBsaXN0IG9mIHRoZSBsYXN0IHNlbGVjdGVkIG9wdGlvblxuICAgIGlmIChmaWx0ZXJWYWx1ZS5lbmRzV2l0aCgnLicpKSB7XG4gICAgICBjb25zdCBsYXN0U2VsZWN0ZWQ6IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uID0gdGhpcy5zZWxlY3RlZE9wdGlvbnNbdGhpcy5zZWxlY3RlZE9wdGlvbnMubGVuZ3RoIC0gMV07XG5cbiAgICAgIHJldHVybiBsYXN0U2VsZWN0ZWQ/Lmxpc3QgfHwgW107XG4gICAgfVxuXG4gICAgcmV0dXJuIGN1cnJlbnRPcHRpb25zLmZpbHRlcigob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhmaWx0ZXJWYWx1ZSkgJiYgIXNlbGVjdGVkTmFtZXMuaW5jbHVkZXMob3B0aW9uLnRleHQudG9Mb3dlckNhc2UoKSkpO1xuICB9XG5cbiAgcHJvdGVjdGVkIG9uT3B0aW9uU2VsZWN0ZWQoZXZlbnQ6IE1hdEF1dG9jb21wbGV0ZVNlbGVjdGVkRXZlbnQpIHtcbiAgICBjb25zdCBzZWxlY3RlZE9wdGlvbiA9IGV2ZW50Lm9wdGlvbi52YWx1ZSBhcyBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbjtcblxuICAgIC8vIENoZWNrIGlmIHRoZSBzZWxlY3RlZCBvcHRpb24gaXMgYWxyZWFkeSBpbiB0aGUgc2VsZWN0ZWRPcHRpb25zIGFycmF5XG4gICAgaWYgKCF0aGlzLnNlbGVjdGVkT3B0aW9ucy5pbmNsdWRlcyhzZWxlY3RlZE9wdGlvbikpIHtcbiAgICAgIC8vIEFkZCB0byB0aGUgc2VsZWN0ZWQgb3B0aW9uc1xuICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMucHVzaChzZWxlY3RlZE9wdGlvbik7XG5cbiAgICAgIC8vIFVwZGF0ZSB0aGUgaW5wdXQgY29udHJvbCB0byBzaG93IHRoZSBzZWxlY3RlZCBwYXRoXG4gICAgICBjb25zdCBzZWxlY3RlZFBhdGg6IHN0cmluZyA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zLm1hcCgob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQpLmpvaW4oJy4nKTtcbiAgICAgIHRoaXMuaW5wdXRDb250cm9sLnNldFZhbHVlKHNlbGVjdGVkUGF0aCwgeyBlbWl0RXZlbnQ6IGZhbHNlIH0pO1xuXG4gICAgICAvLyBSZXNldCBmaWx0ZXJlZCBvcHRpb25zIHRvIGVtcHR5XG4gICAgICB0aGlzLmZpbHRlcmVkT3B0aW9ucyA9IG9mKFtdKTtcblxuICAgICAgdGhpcy5vblZhbHVlQ2hhbmdlKHRoaXMuaW5wdXRDb250cm9sLnZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldERlZmF1bHRTZWxlY3RlZFZhbHVlcygpIHtcbiAgICBjb25zdCBkZWZhdWx0UGF0aDogc3RyaW5nIHwgdW5kZWZpbmVkID0gdGhpcy5wcm9wZXJ0aWVzLnNlbGVjdGVkVmFsdWU7XG5cbiAgICBpZiAoIWRlZmF1bHRQYXRoKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICBsZXQgY3VycmVudE9wdGlvbnM6IENsTmVzdGVkQXV0b0NvbXBsZXRlT3B0aW9uW10gPSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyE7XG5cbiAgICBjb25zdCBwYXJ0czogc3RyaW5nW10gPSBkZWZhdWx0UGF0aC5zcGxpdCgnLicpO1xuXG4gICAgZm9yIChjb25zdCBwYXJ0IG9mIHBhcnRzKSB7XG4gICAgICBjb25zdCBzZWxlY3RlZE9wdGlvbjogQ2xOZXN0ZWRBdXRvQ29tcGxldGVPcHRpb24gfCB1bmRlZmluZWQgPSBjdXJyZW50T3B0aW9ucz8uZmluZCgob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQgPT09IHBhcnQpO1xuXG4gICAgICBpZiAoc2VsZWN0ZWRPcHRpb24pIHtcbiAgICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMucHVzaChzZWxlY3RlZE9wdGlvbik7XG5cbiAgICAgICAgaWYgKHNlbGVjdGVkT3B0aW9uLmxpc3QpIHtcbiAgICAgICAgICBjdXJyZW50T3B0aW9ucyA9IHNlbGVjdGVkT3B0aW9uLmxpc3Q7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmICh0aGlzLnNlbGVjdGVkT3B0aW9ucy5sZW5ndGggPiAwKSB7XG4gICAgICBjb25zdCBzZWxlY3RlZFBhdGg6IHN0cmluZyA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zLm1hcCgob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQpLmpvaW4oJy4nKTtcbiAgICAgIHRoaXMuaW5wdXRDb250cm9sLnNldFZhbHVlKHNlbGVjdGVkUGF0aCwgeyBlbWl0RXZlbnQ6IGZhbHNlIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmlucHV0Q29udHJvbC5zZXRWYWx1ZShkZWZhdWx0UGF0aCwgeyBlbWl0RXZlbnQ6IGZhbHNlIH0pO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBvbklucHV0Q2hhbmdlKGV2ZW50OiBFdmVudCkge1xuICAgIGNvbnN0IHZhbHVlOiBzdHJpbmcgPSAoZXZlbnQudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuXG4gICAgaWYgKCF2YWx1ZSB8fCB2YWx1ZS50cmltKCkgPT09ICcnKSB7XG4gICAgICAvLyBJZiB0aGUgaW5wdXQgZmllbGQgaXMgZW1wdHksIHNob3cgYWxsIHRvcC1sZXZlbCBvcHRpb25zXG4gICAgICB0aGlzLmZpbHRlcmVkT3B0aW9ucyA9IG9mKHRoaXMucHJvcGVydGllcy5vcHRpb25zISk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGxhc3REb3RJbmRleDogbnVtYmVyID0gdmFsdWUubGFzdEluZGV4T2YoJy4nKTtcbiAgICAgIGxldCBhZGRpdGlvbmFsVGV4dDogc3RyaW5nID0gJyc7XG5cbiAgICAgIGlmIChsYXN0RG90SW5kZXggIT09IC0xICYmIHRoaXMuc2VsZWN0ZWRPcHRpb25zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgLy8gU2VwYXJhdGUgdGhlIGFkZGl0aW9uYWwgdHlwZWQgdGV4dCBmcm9tIHRoZSBzZWxlY3RlZCBvcHRpb25zXG4gICAgICAgIGFkZGl0aW9uYWxUZXh0ID0gdmFsdWUuc2xpY2UobGFzdERvdEluZGV4ICsgMSk7XG5cbiAgICAgICAgY29uc3QgbGFzdFNlbGVjdGVkOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbiA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zW3RoaXMuc2VsZWN0ZWRPcHRpb25zLmxlbmd0aCAtIDFdO1xuICAgICAgICBjb25zdCBjaGlsZHJlbjogQ2xOZXN0ZWRBdXRvQ29tcGxldGVPcHRpb25bXSA9IGxhc3RTZWxlY3RlZD8ubGlzdCB8fCBbXTtcblxuICAgICAgICB0aGlzLmZpbHRlcmVkT3B0aW9ucyA9IG9mKGNoaWxkcmVuLmZpbHRlcigob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQ/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoYWRkaXRpb25hbFRleHQudG9Mb3dlckNhc2UoKSkpKTtcbiAgICAgIH0gZWxzZSBpZiAoIXRoaXMucHJvcGVydGllcy5tYW51YWxFbnRyeSkge1xuICAgICAgICAvLyBGaWx0ZXIgb3B0aW9ucyBiYXNlZCBvbiB0aGUgaW5wdXQgdmFsdWVcbiAgICAgICAgdGhpcy5maWx0ZXJlZE9wdGlvbnMgPSBvZih0aGlzLmZpbHRlck9wdGlvbnModmFsdWUpKTtcbiAgICAgIH0gZWxzZSBpZiAodGhpcy5wcm9wZXJ0aWVzLm1hbnVhbEVudHJ5KSB7XG4gICAgICAgIC8vIEVtaXQgdGhlIGNvbWJpbmVkIHJlc3VsdDogc2VsZWN0ZWQgb3B0aW9ucyArIG1hbnVhbGx5IHR5cGVkIHRleHRcbiAgICAgICAgY29uc3QgY29tYmluZWRWYWx1ZSA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zLm1hcCgob3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbikgPT4gb3B0aW9uLnRleHQpLmpvaW4oJy4nKSArIChhZGRpdGlvbmFsVGV4dCA/IGAuJHsgYWRkaXRpb25hbFRleHQgfWAgOiAnJyk7XG5cbiAgICAgICAgdGhpcy5vblZhbHVlQ2hhbmdlKGNvbWJpbmVkVmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBvbktleWRvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQpIHtcbiAgICBpZiAoZXZlbnQua2V5ID09PSAnQmFja3NwYWNlJykge1xuICAgICAgY29uc3QgY3VycmVudFZhbHVlOiBhbnkgPSB0aGlzLmlucHV0Q29udHJvbC52YWx1ZTtcbiAgICAgIGNvbnN0IGxhc3REb3RJbmRleDogYW55ID0gY3VycmVudFZhbHVlLmxhc3RJbmRleE9mKCcuJyk7XG5cbiAgICAgIGlmIChsYXN0RG90SW5kZXggIT09IC0xKSB7XG4gICAgICAgIC8vIFJlbW92ZSBldmVyeXRoaW5nIGFmdGVyIGFuZCBpbmNsdWRpbmcgdGhlIGxhc3QgZG90XG4gICAgICAgIGNvbnN0IG5ld1ZhbHVlOiBhbnkgPSBjdXJyZW50VmFsdWUuc2xpY2UoMCwgbGFzdERvdEluZGV4KTtcbiAgICAgICAgdGhpcy5pbnB1dENvbnRyb2wuc2V0VmFsdWUobmV3VmFsdWUsIHsgZW1pdEV2ZW50OiBmYWxzZSB9KTtcblxuICAgICAgICAvLyBVcGRhdGUgdGhlIHNlbGVjdGVkIG9wdGlvbnMgYWNjb3JkaW5nbHlcbiAgICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICAgICAgbGV0IGN1cnJlbnRPcHRpb25zOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbltdID0gdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMhO1xuXG4gICAgICAgIG5ld1ZhbHVlLnNwbGl0KCcuJykuZXZlcnkoKHBhcnQ6IGFueSkgPT4ge1xuICAgICAgICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbiB8IHVuZGVmaW5lZCA9IGN1cnJlbnRPcHRpb25zLmZpbmQoKG9wdGlvbjogQ2xOZXN0ZWRBdXRvQ29tcGxldGVPcHRpb24pID0+IG9wdGlvbi50ZXh0ID09PSBwYXJ0KTtcblxuICAgICAgICAgIGlmIChzZWxlY3RlZE9wdGlvbikge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMucHVzaChzZWxlY3RlZE9wdGlvbik7XG4gICAgICAgICAgICBjdXJyZW50T3B0aW9ucyA9IHNlbGVjdGVkT3B0aW9uLmxpc3QgfHwgW107XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gVXBkYXRlIHRoZSBmaWx0ZXJlZCBvcHRpb25zIHRvIHJlZmxlY3QgdGhlIGN1cnJlbnQgc3RhdGVcbiAgICAgICAgY29uc3QgbGFzdFNlbGVjdGVkOiBDbE5lc3RlZEF1dG9Db21wbGV0ZU9wdGlvbiA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zW3RoaXMuc2VsZWN0ZWRPcHRpb25zLmxlbmd0aCAtIDFdO1xuXG4gICAgICAgIHRoaXMuZmlsdGVyZWRPcHRpb25zID0gb2YobGFzdFNlbGVjdGVkPy5saXN0IHx8IFtdKTtcblxuICAgICAgICB0aGlzLm9uVmFsdWVDaGFuZ2UodGhpcy5pbnB1dENvbnRyb2wudmFsdWUpO1xuXG4gICAgICAgIC8vIElmIHRoZXJlIGFyZSBubyBsaXN0LCBkb24ndCBvcGVuIHRoZSBkcm9wZG93blxuICAgICAgICBpZiAoIWxhc3RTZWxlY3RlZD8ubGlzdCkge1xuICAgICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlVHJpZ2dlcj8uY2xvc2VQYW5lbCgpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBDbGVhciB0aGUgaW5wdXQgY29udHJvbCBhbmQgcmVzZXQgc2VsZWN0aW9uc1xuICAgICAgICB0aGlzLmNsZWFyU2VsZWN0aW9uKCk7XG4gICAgICAgIHRoaXMuYXV0b2NvbXBsZXRlVHJpZ2dlcj8ub3BlblBhbmVsKCk7XG4gICAgICB9XG5cbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIG9uUHJlZml4SWNvbkNsaWNrZWQoZXZlbnQ6IGFueSk6IHZvaWQge1xuICAgIC8vIFByZXZlbnRzIHRoZSBjbGljayBmcm9tIHByb3BhZ2F0aW5nIHRvIHRoZSBzZWxlY3RcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25QcmVmaXhJY29uQ2xpY2tlZCkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uUHJlZml4SWNvbkNsaWNrZWQoKTtcbiAgICB9XG4gIH1cblxuICBwcm90ZWN0ZWQgb25TdWZmaXhJY29uQ2xpY2tlZChldmVudDogYW55KTogdm9pZCB7XG4gICAgLy8gUHJldmVudHMgdGhlIGNsaWNrIGZyb20gcHJvcGFnYXRpbmcgdG8gdGhlIHNlbGVjdFxuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblN1ZmZpeEljb25DbGlja2VkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25TdWZmaXhJY29uQ2xpY2tlZCgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgY2xlYXJTZWxlY3Rpb24oKSB7XG4gICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICB0aGlzLmlucHV0Q29udHJvbC5zZXRWYWx1ZSgnJywgeyBlbWl0RXZlbnQ6IGZhbHNlIH0pO1xuICAgIHRoaXMuZmlsdGVyZWRPcHRpb25zID0gb2YodGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMhKTtcblxuICAgIHRoaXMub25WYWx1ZUNoYW5nZSgnJyk7XG4gIH1cblxuICBwcml2YXRlIG9uVmFsdWVDaGFuZ2UodmFsdWU6IGFueSkge1xuICAgIHRoaXMub25DaGFuZ2UodmFsdWUpO1xuXG4gICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlKTtcblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZSkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uVmFsdWVDaGFuZ2UodmFsdWUpO1xuICAgIH1cbiAgfVxuXG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gIH1cblxuICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcbiAgfVxuXG4gIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25Ub3VjaGVkID0gZm47XG4gIH1cblxuICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cblxuICBwcm90ZWN0ZWQgZ2V0IGRpc2FibGVkKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCgpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgc2hvd0luZm9Nc2coKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy5zdWI/LnVuc3Vic2NyaWJlKCk7XG4gIH1cbn1cbiIsIjxtYXQtZm9ybS1maWVsZCBbaWRdPVwicHJvcGVydGllcy5pZFwiIHN1YnNjcmlwdFNpemluZz1cImR5bmFtaWNcIiBbZmxvYXRMYWJlbF09XCJwcm9wZXJ0aWVzLmZsb2F0TGFiZWwhXCJcbiAgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fVwiPlxuXG4gIEBpZiAocHJvcGVydGllcy5sYWJlbCkge1xuICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPHNwYW4+e3sgcHJvcGVydGllcy5sYWJlbCB9fTwvc3Bhbj5cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLm9wdGlvbmFsKSB7XG4gICAgICAgIDxzcGFuIGNsYXNzPVwib3B0aW9uYWwtdGV4dFwiPihPcHRpb25hbCk8L3NwYW4+XG4gICAgICB9XG5cbiAgICAgIEBpZiAocHJvcGVydGllcy5pbmZvTXNnICYmIHNob3dJbmZvTXNnKSB7XG4gICAgICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCIgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmluZm9ybWF0aW9uLWNpcmNsZSdcIlxuICAgICAgICAgIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgICAgIDwvbWF0LWljb24+XG4gICAgICB9XG4gICAgPC9tYXQtbGFiZWw+XG4gIH1cblxuICA8aW5wdXQgbWF0SW5wdXQgI2F1dG9jb21wbGV0ZUlucHV0IHR5cGU9XCJ0ZXh0XCIgW3ZhbHVlXT1cInZhbHVlXCIgW2Rpc2FibGVkXT1cImRpc2FibGVkXCIgW21hdEF1dG9jb21wbGV0ZV09XCJhdXRvXCJcbiAgICBbZm9ybUNvbnRyb2xdPVwiaW5wdXRDb250cm9sXCIgKGtleWRvd24pPVwib25LZXlkb3duKCRldmVudClcIiAoaW5wdXQpPVwib25JbnB1dENoYW5nZSgkZXZlbnQpXCJcbiAgICBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIj5cblxuICA8bWF0LWF1dG9jb21wbGV0ZSAjYXV0bz1cIm1hdEF1dG9jb21wbGV0ZVwiIChvcHRpb25TZWxlY3RlZCk9XCJvbk9wdGlvblNlbGVjdGVkKCRldmVudClcIj5cbiAgICBAZm9yIChvcHRpb24gb2YgZmlsdGVyZWRPcHRpb25zIHwgYXN5bmM7IHRyYWNrIG9wdGlvbikge1xuICAgICAgPG1hdC1vcHRpb24gW3ZhbHVlXT1cIm9wdGlvblwiIFtzdHlsZS5kaXNwbGF5XT1cIm9wdGlvbj8uaGlkZU9wdGlvbiA/ICdub25lJyA6ICdmbGV4J1wiPnt7IG9wdGlvbi50ZXh0IH19PC9tYXQtb3B0aW9uPlxuICAgIH1cbiAgPC9tYXQtYXV0b2NvbXBsZXRlPlxuXG4gIEBpZiAocHJvcGVydGllcy5wcmVmaXhJY29uKSB7XG4gICAgPG1hdC1pY29uIG1hdFByZWZpeCBjbGFzcz1cImljb24tc2l6ZS01XCIgW3N2Z0ljb25dPVwicHJvcGVydGllcy5wcmVmaXhJY29uIVwiIChjbGljayk9XCJvblByZWZpeEljb25DbGlja2VkKCRldmVudClcIlxuICAgICAgW25nQ2xhc3NdPVwieydjdXJzb3ItcG9pbnRlcic6IHByb3BlcnRpZXMub25QcmVmaXhJY29uQ2xpY2tlZH1cIj5cbiAgICA8L21hdC1pY29uPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLnN1ZmZpeEljb24pIHtcbiAgICA8bWF0LWljb24gbWF0U3VmZml4IGNsYXNzPVwiaWNvbi1zaXplLTVcIiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnN1ZmZpeEljb24hXCIgKGNsaWNrKT1cIm9uU3VmZml4SWNvbkNsaWNrZWQoJGV2ZW50KVwiXG4gICAgICBbbmdDbGFzc109XCJ7J2N1cnNvci1wb2ludGVyJzogcHJvcGVydGllcy5vblN1ZmZpeEljb25DbGlja2VkfVwiPlxuICAgIDwvbWF0LWljb24+XG4gIH1cbjwvbWF0LWZvcm0tZmllbGQ+XG5cbjwhLS0gVGhpcyBkaXYgaXMgcmVxdWlyZWQgdG8gc2hvdyBoaW50IHRleHQgb3IgZXJyb3IgbWVzc2FnZSBmb3IgdGhlIGNvbXBvbmVudCAtLT5cbjxkaXYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPlxuICBAaWYgKGVycm9yKSB7XG4gICAgPG1hdC1lcnJvcj57eyBlcnJvciB9fTwvbWF0LWVycm9yPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmhpbnRUZXh0KSB7XG4gICAgPG1hdC1oaW50Pnt7IHByb3BlcnRpZXMuaGludFRleHQgfX08L21hdC1oaW50PlxuICB9XG48L2Rpdj5cbiJdfQ==