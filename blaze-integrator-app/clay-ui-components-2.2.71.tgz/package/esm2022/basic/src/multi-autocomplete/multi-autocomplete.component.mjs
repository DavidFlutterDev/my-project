import { NgClass } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, Input, Optional, Self, ViewChild, ViewEncapsulation } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClMultiAutoCompleteProperties } from './multi-autocomplete.properties';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import { SPACE } from '@angular/cdk/keycodes';
import { includes } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/chips";
import * as i4 from "@angular/material/input";
import * as i5 from "@angular/material/form-field";
import * as i6 from "@angular/material/select";
import * as i7 from "@angular/material/core";
import * as i8 from "@angular/material/checkbox";
export class ClMultiAutocompleteComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        //--------------------------------------------
        this.selectedOptions = [];
        this.searchQuery = '';
        this.isAllChecked = false;
        this.selectedValues = [];
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClMultiAutoCompleteProperties();
        this.autoComplete._handleKeydown = (event) => {
            if (event.keyCode == SPACE) {
                return;
            }
        };
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (!this.compareValues(value)) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    compareValues(values) {
        // check values and this._value is same or not
        if (values && values.length && values.length == this._value.length) {
            let allValuesExist = true;
            values.forEach((value) => {
                if (!this._value.includes(value)) {
                    allValuesExist = false;
                }
            });
            return allValuesExist;
        }
        else {
            return false;
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    writeValue(values) {
        this.selectedOptions = [];
        this.selectedValues = [];
        if (values?.length) {
            this.properties.options.forEach((option) => {
                if (includes(values, option.value)) {
                    option.selected = true;
                    this.selectedOptions.push(option);
                }
                else {
                    option.selected = false;
                }
            });
        }
        else {
            this.properties.options.forEach((item) => item.selected = false);
        }
        if (values && values.length == this.properties.options.length && values.length > 0) {
            // this.toggleSelectAll(true);
            this.isAllChecked = true;
        }
        else {
            this.isAllChecked = false;
        }
        this._value = this.selectedOptions.map((option) => option.value);
        this.selectedValues = this._value;
        this.getSelectedValues();
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    onValueChange(value) {
        this.searchQuery = '';
        this.selectedOptions = [];
        this.properties.options.forEach((item) => item.hidden = false);
        this.writeValue(value);
        this.onChange(value);
        // if (value.length) {
        //   value.forEach((selectedValue: any) => {
        //     let filteredOptions = this.properties.options!.filter((option) => option.value == selectedValue);
        //     this.selectedOptions.push(...filteredOptions);
        //   });
        //   if (value.length == this.properties.options!.length) {
        //     this.toggleSelectAll(true);
        //   } else {
        //     this.isAllChecked = false;
        //   }
        // }
        // this.getSelectedValues();
    }
    clearSelection(event) {
        event.stopPropagation();
        this.onValueChange('');
    }
    toggleSelectAll(checked) {
        if (checked) {
            this.isAllChecked = true;
            this.selectedOptions = this.properties.options;
            this.selectedOptions.map((item) => item.value);
        }
        else {
            this.selectedOptions = [];
        }
        // this.getSelectedValues();
        let values = this.selectedOptions.map((option) => option.value);
        this.writeValue(values);
        this.onChange(values);
        // calling emit selection function
    }
    getSelectedValues() {
        // this.selectedValues = [];
        // this.selectedValues = this.selectedOptions.map((option: any) => option.value);
        // this.onChange(this.selectedValues);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this.selectedValues);
        }
    }
    filter(searchQuery) {
        const query = searchQuery.target.value;
        this.properties.options.forEach((option) => {
            if (!option.text?.toLowerCase().includes(query.toLowerCase())) {
                option.hidden = true;
            }
            else {
                option.hidden = false;
            }
        });
    }
    remove(i) {
        let options = this.selectedOptions.slice();
        options.splice(i, 1);
        this.selectedOptions = options.slice();
        let values = this.selectedOptions.map((option) => option.value);
        this.writeValue(values);
        this.onChange(values);
        // this.getSelectedValues();
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiAutocompleteComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClMultiAutocompleteComponent, isStandalone: true, selector: "cl-multi-autocomplete", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }, { propertyName: "autoComplete", first: true, predicate: ["autoComplete"], descendants: true, static: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"auto-complete {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\" [disabled]=\"disabled\" #autoComplete=\"matSelect\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">\n                  {{ selectedOption.text }}\n                </mat-label>\n\n                <mat-icon (click)=\"remove(i)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (keyup)=\"filter($event)\"\n        class=\"autocomplete-search-input\" placeholder=\"{{properties.searchBoxHint || 'Search here'}}\">\n\n      <mat-icon class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\" matPrefix></mat-icon>\n    </mat-form-field>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n\n      <mat-checkbox color=\"primary\" [checked]=\"isAllChecked\" class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        (change)=\"toggleSelectAll($event.checked)\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n    <!-- div is required the restrict the height of the checkbox -->\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option; let i = $index) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i4.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i5.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i5.MatLabel, selector: "mat-label" }, { kind: "directive", type: i5.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i5.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i5.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i6.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "directive", type: i6.MatSelectTrigger, selector: "mat-select-trigger" }, { kind: "component", type: i7.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i8.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClMultiAutocompleteComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-multi-autocomplete', imports: [
                        NgClass,
                        FormsModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClTooltipDirective
                    ], encapsulation: ViewEncapsulation.None, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"auto-complete {{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [multiple]=\"true\" [value]=\"selectedValues\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\" [disabled]=\"disabled\" #autoComplete=\"matSelect\">\n\n    <mat-select-trigger>\n      <mat-chip-set>\n        @for (selectedOption of selectedOptions; track selectedOption; let i = $index) {\n          @if (i < properties.itemLimit!) {\n            <mat-chip>\n              <span class=\"flex gap-1 items-center\">\n                <mat-label class=\"text-primary-700\">\n                  {{ selectedOption.text }}\n                </mat-label>\n\n                <mat-icon (click)=\"remove(i)\" [svgIcon]=\"'heroicons_outline:x-mark'\"\n                  class=\"icon-size-4 cursor-pointer text-primary-700\">\n                </mat-icon>\n              </span>\n            </mat-chip>\n          }\n        }\n\n        @if (selectedOptions.length > properties.itemLimit!) {\n          <div>\n            <mat-label class=\"text-primary-700 ml-2\">...</mat-label>\n            <mat-chip>+{{ selectedOptions.length - properties.itemLimit! }} others</mat-chip>\n          </div>\n        }\n      </mat-chip-set>\n    </mat-select-trigger>\n\n    <!-- search field for auto complete -->\n    <mat-form-field appearance=\"outline\" subscriptSizing=\"dynamic\"\n      class=\"w-full cl-mat-dense-1 autocomplete-search-form-field\">\n\n      <input matInput type=\"text\" autocomplete=\"off\" [(ngModel)]=\"searchQuery\" (keyup)=\"filter($event)\"\n        class=\"autocomplete-search-input\" placeholder=\"{{properties.searchBoxHint || 'Search here'}}\">\n\n      <mat-icon class=\"icon-size-4\" [svgIcon]=\"'fss_icons:search-icon'\" matPrefix></mat-icon>\n    </mat-form-field>\n\n    <!-- div is required the restrict the height of the checkbox -->\n    <div mat-ripple class=\"cl-select-all-check-box\">\n\n      <mat-checkbox color=\"primary\" [checked]=\"isAllChecked\" class=\"w-full h-full mat-mdc-option select-all-checkbox\"\n        (change)=\"toggleSelectAll($event.checked)\">\n\n        <mat-label>Select All</mat-label>\n      </mat-checkbox>\n    </div>\n    <!-- div is required the restrict the height of the checkbox -->\n\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option; let i = $index) {\n      <mat-option [value]=\"option.value\" [ngClass]=\"{'hidden': option.hidden}\"\n        class=\"flex items-center justify-between cl-mat-select-option\">\n\n        <mat-label>{{ option.text }}</mat-label>\n\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection($event)\">close</mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: ["::ng-deep .hide-option{display:none!important}::ng-deep .mat-mdc-checkbox .mdc-form-field,::ng-deep .mat-mdc-checkbox .mdc-form-field .mdc-label{margin-left:-2px;display:flex;height:48px;width:100%;cursor:pointer;align-items:center}.auto-complete.mat-mdc-form-field-has-icon-prefix.mat-form-field-appearance-outline .mat-mdc-text-field-wrapper{padding-left:unset;--mat-mdc-form-field-label-offset-x: 0px !important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], autoComplete: [{
                type: ViewChild,
                args: ['autoComplete', { static: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXVsdGktYXV0b2NvbXBsZXRlLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvbXVsdGktYXV0b2NvbXBsZXRlL211bHRpLWF1dG9jb21wbGV0ZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL211bHRpLWF1dG9jb21wbGV0ZS9tdWx0aS1hdXRvY29tcGxldGUuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEYsT0FBTyxFQUF3QixXQUFXLEVBQWEsbUJBQW1CLEVBQW9CLE1BQU0sZ0JBQWdCLENBQUM7QUFDckgsT0FBTyxFQUFzQyxTQUFTLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRW5JLE9BQU8sRUFBRSxlQUFlLEVBQWtCLE1BQU0sNEJBQTRCLENBQUM7QUFDN0UsT0FBTyxFQUFFLDZCQUE2QixFQUFFLE1BQU0saUNBQWlDLENBQUM7QUFDaEYsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUM5QyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7Ozs7Ozs7O0FBNEJyQyxNQUFNLE9BQU8sNEJBQTZCLFNBQVEsZUFBZTtJQWtDL0QsWUFBd0MsU0FBb0I7UUFDMUQ7OztXQUdHO1FBQ0gsS0FBSyxFQUFFLENBQUM7UUFMOEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQVo1RCxhQUFRLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzQixjQUFTLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUM1Qiw4Q0FBOEM7UUFDdkMsb0JBQWUsR0FBUSxFQUFFLENBQUM7UUFDMUIsZ0JBQVcsR0FBVyxFQUFFLENBQUM7UUFDekIsaUJBQVksR0FBWSxLQUFLLENBQUM7UUFDOUIsbUJBQWMsR0FBUSxFQUFFLENBQUM7UUFZOUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO1FBRXZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO1FBQ0QsdUdBQXVHO0lBQ3pHLENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLDZCQUE2QixFQUFFLENBQUM7UUFFeEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLEdBQUcsQ0FBQyxLQUFvQixFQUFFLEVBQUU7WUFDMUQsSUFBSSxLQUFLLENBQUMsT0FBTyxJQUFFLEtBQUssRUFBRSxDQUFDO2dCQUN6QixPQUFPO1lBQ1QsQ0FBQztRQUNILENBQUMsQ0FBQTtRQUVELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsZUFBZTtRQUNiLG9HQUFvRztRQUNwRyw0RUFBNEU7UUFDNUUseUlBQXlJO1FBRXpJLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFMUQsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUM1RSxJQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUM5QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBRWxCLGlDQUFpQztnQkFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxxQkFBcUI7UUFDbkIsd0RBQXdEO1FBQ3hELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdkYsSUFBRyxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQ3pDLE1BQU0sSUFBSSxHQUE2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUE2QixDQUFDO2dCQUN0RyxJQUFJLENBQUMsS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLENBQUMsQ0FBQztZQUNyRSxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM3RSxDQUFDO1lBRUQsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBRU8sYUFBYSxDQUFDLE1BQVc7UUFDL0IsOENBQThDO1FBQzlDLElBQUcsTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xFLElBQUksY0FBYyxHQUFHLElBQUksQ0FBQztZQUMxQixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBUyxFQUFFLEVBQUU7Z0JBQzNCLElBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO29CQUNoQyxjQUFjLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUE7WUFDRixPQUFPLGNBQWMsQ0FBQztRQUN4QixDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sS0FBSyxDQUFBO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFFTyxXQUFXO1FBQ2pCLHlFQUF5RTtRQUV6RSx1RUFBdUU7UUFDdkUsMkVBQTJFO1FBRTNFLDJFQUEyRTtRQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFFTSxZQUFZLENBQUMsS0FBVTtRQUM1QixnREFBZ0Q7UUFFaEQsd0VBQXdFO1FBQ3hFLDBFQUEwRTtRQUUxRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3BGLHdFQUF3RTtJQUMxRSxDQUFDO0lBRUQsVUFBVSxDQUFDLE1BQVc7UUFDcEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7WUFDbkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUU7Z0JBQy9DLElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztvQkFDbkMsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7b0JBQ3ZCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNwQyxDQUFDO3FCQUFNLENBQUM7b0JBQ04sTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7Z0JBQzFCLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO1FBQ3pFLENBQUM7UUFFRCxJQUFJLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3BGLDhCQUE4QjtZQUM5QixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztRQUMzQixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBQzVCLENBQUM7UUFFRCxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEUsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2xDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFrQjtRQUNqQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBa0I7UUFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUE7SUFDckIsQ0FBQztJQUVELElBQUksS0FBSztRQUNQLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQTtJQUNwQixDQUFDO0lBRVEsV0FBVztRQUNsQjs7O1VBR0U7UUFDRixJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxlQUFlLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFFcEMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BCLHVHQUF1RztJQUN6RyxDQUFDO0lBRU0sYUFBYSxDQUFDLEtBQVU7UUFDN0IsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDdEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDO1FBRXJFLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixzQkFBc0I7UUFDdEIsNENBQTRDO1FBQzVDLHdHQUF3RztRQUV4RyxxREFBcUQ7UUFDckQsUUFBUTtRQUVSLDJEQUEyRDtRQUMzRCxrQ0FBa0M7UUFDbEMsYUFBYTtRQUNiLGlDQUFpQztRQUNqQyxNQUFNO1FBQ04sSUFBSTtRQUVKLDRCQUE0QjtJQUM5QixDQUFDO0lBRVMsY0FBYyxDQUFDLEtBQVU7UUFDakMsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBRXhCLElBQUksQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVNLGVBQWUsQ0FBQyxPQUFZO1FBQ2pDLElBQUksT0FBTyxFQUFFLENBQUM7WUFDWixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUV6QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQy9DLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBUyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEQsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQztRQUM1QixDQUFDO1FBRUQsNEJBQTRCO1FBQzVCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCLGtDQUFrQztJQUNwQyxDQUFDO0lBRUQsaUJBQWlCO1FBQ2YsNEJBQTRCO1FBQzVCLGlGQUFpRjtRQUNqRixzQ0FBc0M7UUFDdEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUNyRCxDQUFDO0lBQ0gsQ0FBQztJQUVNLE1BQU0sQ0FBQyxXQUFnQjtRQUM1QixNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUV2QyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFXLEVBQUUsRUFBRTtZQUMvQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDOUQsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7WUFDdkIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3hCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxNQUFNLENBQUMsQ0FBUztRQUNyQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQzNDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxlQUFlLEdBQUcsT0FBTyxDQUFDLEtBQUssRUFBRSxDQUFDO1FBRXZDLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBVyxFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RCLDRCQUE0QjtJQUM5QixDQUFDO0lBRUQsSUFBVyxRQUFRO1FBQ2pCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7WUFDMUMsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNqRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ2xDLENBQUM7WUFDRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEMsQ0FBQztRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVELElBQVcsV0FBVztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzdDLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDcEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztZQUNyQyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7OEdBblNVLDRCQUE0QjtrR0FBNUIsNEJBQTRCLHFLQU01QixZQUFZLG9MQ25EekIsdTdIQWtHQSw4aEJEbkVJLE9BQU8sbUZBQ1AsV0FBVyw4bUJBQ1gsbUJBQW1CLDhCQUNuQixhQUFhLG1MQUNiLGNBQWMsMGJBQ2QsY0FBYyw0NkJBQ2QsZUFBZSxxd0JBQ2YsZ0JBQWdCLDhCQUNoQixpQkFBaUIsb1lBQ2pCLGtCQUFrQiwrQkFDbEIsa0JBQWtCOzsyRkFJVCw0QkFBNEI7a0JBMUJ4QyxTQUFTO2lDQUNJLElBQUksWUFDTix1QkFBdUIsV0FTeEI7d0JBQ1AsT0FBTzt3QkFDUCxXQUFXO3dCQUNYLG1CQUFtQjt3QkFDbkIsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGNBQWM7d0JBQ2QsZUFBZTt3QkFDZixnQkFBZ0I7d0JBQ2hCLGlCQUFpQjt3QkFDakIsa0JBQWtCO3dCQUNsQixrQkFBa0I7cUJBQ25CLGlCQUNjLGlCQUFpQixDQUFDLElBQUk7OzBCQW9DdkIsUUFBUTs7MEJBQUksSUFBSTt5Q0EvQmQsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBS2xCLFlBQVk7c0JBRGxCLFNBQVM7dUJBQUMsWUFBWTtnQkFHc0IsWUFBWTtzQkFBeEQsU0FBUzt1QkFBQyxjQUFjLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBOZ0NsYXNzIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdElucHV0TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaW5wdXQnO1xuaW1wb3J0IHsgTWF0Q2hpcHNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jaGlwcyc7XG5pbXBvcnQgeyBNYXRTZWxlY3RNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9zZWxlY3QnO1xuaW1wb3J0IHsgTWF0VG9vbHRpcE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Rvb2x0aXAnO1xuaW1wb3J0IHsgTWF0Q2hlY2tib3hNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jaGVja2JveCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1zTW9kdWxlLCBOZ0NvbnRyb2wsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBBZnRlckNvbnRlbnRDaGVja2VkLCBBZnRlclZpZXdJbml0LCBDb21wb25lbnQsIElucHV0LCBPcHRpb25hbCwgU2VsZiwgVmlld0NoaWxkLCBWaWV3RW5jYXBzdWxhdGlvbiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQsIENsRXJyb3JIYW5kbGVyIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuaW1wb3J0IHsgQ2xNdWx0aUF1dG9Db21wbGV0ZVByb3BlcnRpZXMgfSBmcm9tICcuL211bHRpLWF1dG9jb21wbGV0ZS5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5pbXBvcnQgeyBTUEFDRSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9rZXljb2Rlcyc7XG5pbXBvcnQgeyBpbmNsdWRlcyB9IGZyb20gJ2xvZGFzaC1lcyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLW11bHRpLWF1dG9jb21wbGV0ZScsXG4gIHN0eWxlVXJsOiAnLi9tdWx0aS1hdXRvY29tcGxldGUuY29tcG9uZW50LnNjc3MnLFxuICB0ZW1wbGF0ZVVybDogJy4vbXVsdGktYXV0b2NvbXBsZXRlLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVzOiBbYFxuICAgIDpob3N0IHtcbiAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcbiAgICB9XG4gIGBdLFxuICBpbXBvcnRzOiBbXG4gICAgTmdDbGFzcyxcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0Q2hpcHNNb2R1bGUsXG4gICAgTWF0SW5wdXRNb2R1bGUsXG4gICAgTWF0U2VsZWN0TW9kdWxlLFxuICAgIE1hdFRvb2x0aXBNb2R1bGUsXG4gICAgTWF0Q2hlY2tib3hNb2R1bGUsXG4gICAgTWF0Rm9ybUZpZWxkTW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdLFxuICBlbmNhcHN1bGF0aW9uOiBWaWV3RW5jYXBzdWxhdGlvbi5Ob25lXG59KVxuZXhwb3J0IGNsYXNzIENsTXVsdGlBdXRvY29tcGxldGVDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciwgQWZ0ZXJWaWV3SW5pdCwgQWZ0ZXJDb250ZW50Q2hlY2tlZCB7XG4gIC8vIFBsZWFzZSBwdXQgYWxsIHRoZSBhbmd1bGFyIGRlY29yYXRlZCB2YXJpYWJsZXMgYmVsb3cgdGhpc1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsTXVsdGlBdXRvQ29tcGxldGVQcm9wZXJ0aWVzO1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBAVmlld0NoaWxkKE1hdEZvcm1GaWVsZClcbiAgcHVibGljIG1hdEZvcm1GaWVsZCE6IE1hdEZvcm1GaWVsZDtcblxuICBAVmlld0NoaWxkKCdhdXRvQ29tcGxldGUnLCB7IHN0YXRpYzogdHJ1ZSB9KSBhdXRvQ29tcGxldGU6IGFueTtcblxuICAvLyBAVmlld0NoaWxkKCdtYXRUZXh0RmllbGQnKVxuICAvLyBwdWJsaWMgbWF0VGV4dEZpZWxkRGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gQFZpZXdDaGlsZCgnZXJyb3JPckhpbnREaXZFbGVtZW50UmVmJylcbiAgLy8gcHVibGljIGVycm9yT3JIaW50RGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gcHJpdmF0ZSBlcnJvck9ySGludERpdkVsZW1lbnQhOiBIVE1MRGl2RWxlbWVudDtcbiAgLy8gcHJpdmF0ZSBtYXRUZXh0RmllbGREaXZFbGVtZW50ITogSFRNTERpdkVsZW1lbnQ7XG5cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBwdWJsaWMgc2VsZWN0ZWRPcHRpb25zOiBhbnkgPSBbXTtcbiAgcHVibGljIHNlYXJjaFF1ZXJ5OiBzdHJpbmcgPSAnJztcbiAgcHVibGljIGlzQWxsQ2hlY2tlZDogYm9vbGVhbiA9IGZhbHNlO1xuICBwdWJsaWMgc2VsZWN0ZWRWYWx1ZXM6IGFueSA9IFtdO1xuXG4gIHByaXZhdGUgc3ViPzogU3Vic2NyaXB0aW9uO1xuICBwcml2YXRlIHZhbHVlQ2hhbmdlc1N1Yj86IFN1YnNjcmlwdGlvbjtcbiAgcHJvdGVjdGVkIGVycm9yPzogVmFsaWRhdGlvbkVycm9ycyB8IG51bGw7XG5cbiAgY29uc3RydWN0b3IgKEBPcHRpb25hbCgpIEBTZWxmKCkgcHVibGljIG5nQ29udHJvbDogTmdDb250cm9sKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICAgIGlmICh0aGlzLm5nQ29udHJvbCAhPSBudWxsKSB7XG4gICAgICAvLyBTZXR0aW5nIHRoZSB2YWx1ZSBhY2Nlc3NvciBkaXJlY3RseSAoaW5zdGVhZCBvZiB1c2luZ1xuICAgICAgLy8gdGhlIHByb3ZpZGVycykgdG8gYXZvaWQgcnVubmluZyBpbnRvIGEgY2lyY3VsYXIgaW1wb3J0LlxuICAgICAgdGhpcy5uZ0NvbnRyb2wudmFsdWVBY2Nlc3NvciA9IHRoaXM7XG4gICAgfVxuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsTXVsdGlBdXRvQ29tcGxldGVQcm9wZXJ0aWVzKCk7XG5cbiAgICB0aGlzLmF1dG9Db21wbGV0ZS5faGFuZGxlS2V5ZG93biA9IChldmVudDogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGV2ZW50LmtleUNvZGU9PVNQQUNFKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIC8vIHNldHRpbmcgdGhlIHJlZmVyZW5jZXMgb2YgTmF0aXZlIEVsZW1lbnRzLCB3aGljaCB3aWxsIGJlIHVzZWQgaW4gc2V0RXJyb3JUZXh0KCkgYW5kIHNldEhpbnRUZXh0KClcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudCA9IHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQ7XG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50ID0gdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKCcubWF0LW1kYy10ZXh0LWZpZWxkLXdyYXBwZXIubWRjLXRleHQtZmllbGQnKTtcblxuICAgIC8vIGNhbGxpbmcgc2V0IGhpbnQgdGV4dCBmdW5jdGlvblxuICAgIHRoaXMuc2V0SGludFRleHQoKTtcblxuICAgIHN1cGVyLnN1YnNjcmliZVRvVmFsdWVDaGFuZ2VzKHRoaXMud3JpdGVWYWx1ZS5iaW5kKHRoaXMpKTtcblxuICAgIHRoaXMudmFsdWVDaGFuZ2VzU3ViID0gdGhpcy5uZ0NvbnRyb2w/LnZhbHVlQ2hhbmdlcz8uc3Vic2NyaWJlKCh2YWx1ZTogYW55KSA9PiB7XG4gICAgICBpZighdGhpcy5jb21wYXJlVmFsdWVzKHZhbHVlKSkge1xuICAgICAgICB0aGlzLndyaXRlVmFsdWUodmFsdWUpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gcmVtb3ZlIGFsbCB0aGUgZXJyb3JzIHdoZW4gdGhlIHN0YXR1cyBpcyB2YWxpZFxuICAgIHRoaXMuc3ViID0gdGhpcy5uZ0NvbnRyb2w/LnN0YXR1c0NoYW5nZXMhLnN1YnNjcmliZShjaGFuZ2VzID0+IHtcbiAgICAgIGlmIChjaGFuZ2VzID09PSAnVkFMSUQnKSB7XG4gICAgICAgIHRoaXMuZXJyb3IgPSBudWxsO1xuXG4gICAgICAgIC8vIGNhbGxpbmcgc2V0IGhpbnQgdGV4dCBmdW5jdGlvblxuICAgICAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7XG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgaWYodGhpcy5wcm9wZXJ0aWVzLmlzUmVhY3RpdmVGb3JtQ29udHJvbCkge1xuICAgICAgICBjb25zdCBrZXlzOiAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW10gPSBPYmplY3Qua2V5cyh0aGlzLm5nQ29udHJvbC5lcnJvcnMpIGFzIChrZXlvZiBDbEVycm9ySGFuZGxlcilbXTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGdldEVycm9yTWVzc2FnZShrZXlzWzBdLCB0aGlzLnByb3BlcnRpZXMuZXJyb3JzTGlzdCEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG4gICAgICB9XG5cbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgY29tcGFyZVZhbHVlcyh2YWx1ZXM6IGFueSkge1xuICAgIC8vIGNoZWNrIHZhbHVlcyBhbmQgdGhpcy5fdmFsdWUgaXMgc2FtZSBvciBub3RcbiAgICBpZih2YWx1ZXMgJiYgdmFsdWVzLmxlbmd0aCAmJiB2YWx1ZXMubGVuZ3RoID09IHRoaXMuX3ZhbHVlLmxlbmd0aCkge1xuICAgICAgbGV0IGFsbFZhbHVlc0V4aXN0ID0gdHJ1ZTtcbiAgICAgIHZhbHVlcy5mb3JFYWNoKCh2YWx1ZTphbnkpID0+IHtcbiAgICAgICAgaWYoIXRoaXMuX3ZhbHVlLmluY2x1ZGVzKHZhbHVlKSkge1xuICAgICAgICAgIGFsbFZhbHVlc0V4aXN0ID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICByZXR1cm4gYWxsVmFsdWVzRXhpc3Q7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0SGludFRleHQoKSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gdGhpcy5wcm9wZXJ0aWVzLmhpbnRUZXh0ID8/ICcnO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcblxuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICB9XG5cbiAgcHVibGljIHNldEVycm9yVGV4dChlcnJvcjogYW55KSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gZXJyb3I7XG5cbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtaGludCcpO1xuXG4gICAgdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtZm9ybS1maWVsZC1pbnZhbGlkJyk7XG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21kYy10ZXh0LWZpZWxkLS1pbnZhbGlkJyk7XG4gIH1cblxuICB3cml0ZVZhbHVlKHZhbHVlczogYW55KTogdm9pZCB7XG4gICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICB0aGlzLnNlbGVjdGVkVmFsdWVzID0gW107XG4gICAgaWYgKHZhbHVlcz8ubGVuZ3RoKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEuZm9yRWFjaCgob3B0aW9uOiBhbnkpID0+IHtcbiAgICAgICAgaWYgKGluY2x1ZGVzKHZhbHVlcywgb3B0aW9uLnZhbHVlKSkge1xuICAgICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IHRydWU7XG4gICAgICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMucHVzaChvcHRpb24pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMhLmZvckVhY2goKGl0ZW06IGFueSkgPT4gaXRlbS5zZWxlY3RlZCA9IGZhbHNlKTtcbiAgICB9XG5cbiAgICBpZiAodmFsdWVzICYmIHZhbHVlcy5sZW5ndGggPT0gdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnMhLmxlbmd0aCAmJiB2YWx1ZXMubGVuZ3RoID4gMCkge1xuICAgICAgLy8gdGhpcy50b2dnbGVTZWxlY3RBbGwodHJ1ZSk7XG4gICAgICB0aGlzLmlzQWxsQ2hlY2tlZCA9IHRydWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuaXNBbGxDaGVja2VkID0gZmFsc2U7XG4gICAgfVxuXG4gICAgdGhpcy5fdmFsdWUgPSB0aGlzLnNlbGVjdGVkT3B0aW9ucy5tYXAoKG9wdGlvbjogYW55KSA9PiBvcHRpb24udmFsdWUpO1xuICAgIHRoaXMuc2VsZWN0ZWRWYWx1ZXMgPSB0aGlzLl92YWx1ZTtcbiAgICB0aGlzLmdldFNlbGVjdGVkVmFsdWVzKCk7XG4gIH1cblxuICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcbiAgfVxuXG4gIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25Ub3VjaGVkID0gZm5cbiAgfVxuXG4gIGdldCB2YWx1ZSgpOiBhbnkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgLyoqXG4gICAgKiAhISBXYXJuaW5nICEhXG4gICAgKiBUaGUgYmVsb3cgc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICovXG4gICAgdGhpcy5zdWI/LnVuc3Vic2NyaWJlKCk7XG4gICAgdGhpcy52YWx1ZUNoYW5nZXNTdWI/LnVuc3Vic2NyaWJlKCk7XG5cbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIHB1YmxpYyBvblZhbHVlQ2hhbmdlKHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLnNlYXJjaFF1ZXJ5ID0gJyc7XG4gICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEuZm9yRWFjaCgoaXRlbTogYW55KSA9PiBpdGVtLmhpZGRlbiA9IGZhbHNlKTtcblxuICAgIHRoaXMud3JpdGVWYWx1ZSh2YWx1ZSk7XG4gICAgdGhpcy5vbkNoYW5nZSh2YWx1ZSk7XG4gICAgLy8gaWYgKHZhbHVlLmxlbmd0aCkge1xuICAgIC8vICAgdmFsdWUuZm9yRWFjaCgoc2VsZWN0ZWRWYWx1ZTogYW55KSA9PiB7XG4gICAgLy8gICAgIGxldCBmaWx0ZXJlZE9wdGlvbnMgPSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEuZmlsdGVyKChvcHRpb24pID0+IG9wdGlvbi52YWx1ZSA9PSBzZWxlY3RlZFZhbHVlKTtcblxuICAgIC8vICAgICB0aGlzLnNlbGVjdGVkT3B0aW9ucy5wdXNoKC4uLmZpbHRlcmVkT3B0aW9ucyk7XG4gICAgLy8gICB9KTtcblxuICAgIC8vICAgaWYgKHZhbHVlLmxlbmd0aCA9PSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEubGVuZ3RoKSB7XG4gICAgLy8gICAgIHRoaXMudG9nZ2xlU2VsZWN0QWxsKHRydWUpO1xuICAgIC8vICAgfSBlbHNlIHtcbiAgICAvLyAgICAgdGhpcy5pc0FsbENoZWNrZWQgPSBmYWxzZTtcbiAgICAvLyAgIH1cbiAgICAvLyB9XG5cbiAgICAvLyB0aGlzLmdldFNlbGVjdGVkVmFsdWVzKCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgY2xlYXJTZWxlY3Rpb24oZXZlbnQ6IGFueSkge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuXG4gICAgdGhpcy5vblZhbHVlQ2hhbmdlKCcnKTtcbiAgfVxuXG4gIHB1YmxpYyB0b2dnbGVTZWxlY3RBbGwoY2hlY2tlZDogYW55KTogdm9pZCB7XG4gICAgaWYgKGNoZWNrZWQpIHtcbiAgICAgIHRoaXMuaXNBbGxDaGVja2VkID0gdHJ1ZTtcblxuICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucztcbiAgICAgIHRoaXMuc2VsZWN0ZWRPcHRpb25zLm1hcCgoaXRlbTogYW55KSA9PiBpdGVtLnZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zZWxlY3RlZE9wdGlvbnMgPSBbXTtcbiAgICB9XG5cbiAgICAvLyB0aGlzLmdldFNlbGVjdGVkVmFsdWVzKCk7XG4gICAgbGV0IHZhbHVlcyA9IHRoaXMuc2VsZWN0ZWRPcHRpb25zLm1hcCgob3B0aW9uOiBhbnkpID0+IG9wdGlvbi52YWx1ZSk7XG4gICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlcyk7XG4gICAgdGhpcy5vbkNoYW5nZSh2YWx1ZXMpO1xuICAgIC8vIGNhbGxpbmcgZW1pdCBzZWxlY3Rpb24gZnVuY3Rpb25cbiAgfVxuXG4gIGdldFNlbGVjdGVkVmFsdWVzKCkge1xuICAgIC8vIHRoaXMuc2VsZWN0ZWRWYWx1ZXMgPSBbXTtcbiAgICAvLyB0aGlzLnNlbGVjdGVkVmFsdWVzID0gdGhpcy5zZWxlY3RlZE9wdGlvbnMubWFwKChvcHRpb246IGFueSkgPT4gb3B0aW9uLnZhbHVlKTtcbiAgICAvLyB0aGlzLm9uQ2hhbmdlKHRoaXMuc2VsZWN0ZWRWYWx1ZXMpO1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZSkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uVmFsdWVDaGFuZ2UodGhpcy5zZWxlY3RlZFZhbHVlcyk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGZpbHRlcihzZWFyY2hRdWVyeTogYW55KSB7XG4gICAgY29uc3QgcXVlcnkgPSBzZWFyY2hRdWVyeS50YXJnZXQudmFsdWU7XG5cbiAgICB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEuZm9yRWFjaCgob3B0aW9uOiBhbnkpID0+IHtcbiAgICAgIGlmICghb3B0aW9uLnRleHQ/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMocXVlcnkudG9Mb3dlckNhc2UoKSkpIHtcbiAgICAgICAgb3B0aW9uLmhpZGRlbiA9IHRydWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvcHRpb24uaGlkZGVuID0gZmFsc2U7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgcmVtb3ZlKGk6IG51bWJlcikge1xuICAgIGxldCBvcHRpb25zID0gdGhpcy5zZWxlY3RlZE9wdGlvbnMuc2xpY2UoKTtcbiAgICBvcHRpb25zLnNwbGljZShpLCAxKTtcbiAgICB0aGlzLnNlbGVjdGVkT3B0aW9ucyA9IG9wdGlvbnMuc2xpY2UoKTtcblxuICAgIGxldCB2YWx1ZXMgPSB0aGlzLnNlbGVjdGVkT3B0aW9ucy5tYXAoKG9wdGlvbjogYW55KSA9PiBvcHRpb24udmFsdWUpO1xuICAgIHRoaXMud3JpdGVWYWx1ZSh2YWx1ZXMpO1xuICAgIHRoaXMub25DaGFuZ2UodmFsdWVzKTtcbiAgICAvLyB0aGlzLmdldFNlbGVjdGVkVmFsdWVzKCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0IGRpc2FibGVkKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5kaXNhYmxlZDtcbiAgICAgIH1cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgcHVibGljIGdldCBzaG93SW5mb01zZygpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2c7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2coKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cbiIsIjxtYXQtZm9ybS1maWVsZCBbaWRdPVwicHJvcGVydGllcy5pZFwiIHN1YnNjcmlwdFNpemluZz1cImR5bmFtaWNcIiBbYXBwZWFyYW5jZV09XCJwcm9wZXJ0aWVzLmFwcGVhcmFuY2UhXCJcbiAgW2Zsb2F0TGFiZWxdPVwicHJvcGVydGllcy5mbG9hdExhYmVsIVwiIGNsYXNzPVwiYXV0by1jb21wbGV0ZSB7eyBwcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzIH19XCI+XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmxhYmVsICE9IG51bGwgJiYgcHJvcGVydGllcy5sYWJlbCAhPSAnJyAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9IHVuZGVmaW5lZCkge1xuICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPHNwYW4+e3sgcHJvcGVydGllcy5sYWJlbCB9fTwvc3Bhbj5cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLm9wdGlvbmFsKSB7XG4gICAgICAgIDxzcGFuIGNsYXNzPVwib3B0aW9uYWwtdGV4dFwiPihPcHRpb25hbCk8L3NwYW4+XG4gICAgICB9XG5cbiAgICAgIEBpZiAocHJvcGVydGllcy5pbmZvTXNnICYmIHNob3dJbmZvTXNnKSB7XG4gICAgICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCJcbiAgICAgICAgICBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgICAgIDwvbWF0LWljb24+XG4gICAgICB9XG4gICAgPC9tYXQtbGFiZWw+XG4gIH1cblxuICA8bWF0LXNlbGVjdCBbbXVsdGlwbGVdPVwidHJ1ZVwiIFt2YWx1ZV09XCJzZWxlY3RlZFZhbHVlc1wiICh2YWx1ZUNoYW5nZSk9XCJvblZhbHVlQ2hhbmdlKCRldmVudClcIlxuICAgIFtoaWRlU2luZ2xlU2VsZWN0aW9uSW5kaWNhdG9yXT1cInRydWVcIiBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIiBbZGlzYWJsZWRdPVwiZGlzYWJsZWRcIiAjYXV0b0NvbXBsZXRlPVwibWF0U2VsZWN0XCI+XG5cbiAgICA8bWF0LXNlbGVjdC10cmlnZ2VyPlxuICAgICAgPG1hdC1jaGlwLXNldD5cbiAgICAgICAgQGZvciAoc2VsZWN0ZWRPcHRpb24gb2Ygc2VsZWN0ZWRPcHRpb25zOyB0cmFjayBzZWxlY3RlZE9wdGlvbjsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgICAgICBAaWYgKGkgPCBwcm9wZXJ0aWVzLml0ZW1MaW1pdCEpIHtcbiAgICAgICAgICAgIDxtYXQtY2hpcD5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XCJmbGV4IGdhcC0xIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJ0ZXh0LXByaW1hcnktNzAwXCI+XG4gICAgICAgICAgICAgICAgICB7eyBzZWxlY3RlZE9wdGlvbi50ZXh0IH19XG4gICAgICAgICAgICAgICAgPC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICAgICAgICA8bWF0LWljb24gKGNsaWNrKT1cInJlbW92ZShpKVwiIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTp4LW1hcmsnXCJcbiAgICAgICAgICAgICAgICAgIGNsYXNzPVwiaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXIgdGV4dC1wcmltYXJ5LTcwMFwiPlxuICAgICAgICAgICAgICAgIDwvbWF0LWljb24+XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvbWF0LWNoaXA+XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgQGlmIChzZWxlY3RlZE9wdGlvbnMubGVuZ3RoID4gcHJvcGVydGllcy5pdGVtTGltaXQhKSB7XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJ0ZXh0LXByaW1hcnktNzAwIG1sLTJcIj4uLi48L21hdC1sYWJlbD5cbiAgICAgICAgICAgIDxtYXQtY2hpcD4re3sgc2VsZWN0ZWRPcHRpb25zLmxlbmd0aCAtIHByb3BlcnRpZXMuaXRlbUxpbWl0ISB9fSBvdGhlcnM8L21hdC1jaGlwPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA8L21hdC1jaGlwLXNldD5cbiAgICA8L21hdC1zZWxlY3QtdHJpZ2dlcj5cblxuICAgIDwhLS0gc2VhcmNoIGZpZWxkIGZvciBhdXRvIGNvbXBsZXRlIC0tPlxuICAgIDxtYXQtZm9ybS1maWVsZCBhcHBlYXJhbmNlPVwib3V0bGluZVwiIHN1YnNjcmlwdFNpemluZz1cImR5bmFtaWNcIlxuICAgICAgY2xhc3M9XCJ3LWZ1bGwgY2wtbWF0LWRlbnNlLTEgYXV0b2NvbXBsZXRlLXNlYXJjaC1mb3JtLWZpZWxkXCI+XG5cbiAgICAgIDxpbnB1dCBtYXRJbnB1dCB0eXBlPVwidGV4dFwiIGF1dG9jb21wbGV0ZT1cIm9mZlwiIFsobmdNb2RlbCldPVwic2VhcmNoUXVlcnlcIiAoa2V5dXApPVwiZmlsdGVyKCRldmVudClcIlxuICAgICAgICBjbGFzcz1cImF1dG9jb21wbGV0ZS1zZWFyY2gtaW5wdXRcIiBwbGFjZWhvbGRlcj1cInt7cHJvcGVydGllcy5zZWFyY2hCb3hIaW50IHx8ICdTZWFyY2ggaGVyZSd9fVwiPlxuXG4gICAgICA8bWF0LWljb24gY2xhc3M9XCJpY29uLXNpemUtNFwiIFtzdmdJY29uXT1cIidmc3NfaWNvbnM6c2VhcmNoLWljb24nXCIgbWF0UHJlZml4PjwvbWF0LWljb24+XG4gICAgPC9tYXQtZm9ybS1maWVsZD5cblxuICAgIDwhLS0gZGl2IGlzIHJlcXVpcmVkIHRoZSByZXN0cmljdCB0aGUgaGVpZ2h0IG9mIHRoZSBjaGVja2JveCAtLT5cbiAgICA8ZGl2IG1hdC1yaXBwbGUgY2xhc3M9XCJjbC1zZWxlY3QtYWxsLWNoZWNrLWJveFwiPlxuXG4gICAgICA8bWF0LWNoZWNrYm94IGNvbG9yPVwicHJpbWFyeVwiIFtjaGVja2VkXT1cImlzQWxsQ2hlY2tlZFwiIGNsYXNzPVwidy1mdWxsIGgtZnVsbCBtYXQtbWRjLW9wdGlvbiBzZWxlY3QtYWxsLWNoZWNrYm94XCJcbiAgICAgICAgKGNoYW5nZSk9XCJ0b2dnbGVTZWxlY3RBbGwoJGV2ZW50LmNoZWNrZWQpXCI+XG5cbiAgICAgICAgPG1hdC1sYWJlbD5TZWxlY3QgQWxsPC9tYXQtbGFiZWw+XG4gICAgICA8L21hdC1jaGVja2JveD5cbiAgICA8L2Rpdj5cbiAgICA8IS0tIGRpdiBpcyByZXF1aXJlZCB0aGUgcmVzdHJpY3QgdGhlIGhlaWdodCBvZiB0aGUgY2hlY2tib3ggLS0+XG5cbiAgICA8IS0tIG9wdGlvbnMgZm9yIGRyb3Bkb3duIC0tPlxuICAgIEBmb3IgKG9wdGlvbiBvZiBwcm9wZXJ0aWVzLm9wdGlvbnM7IHRyYWNrIG9wdGlvbjsgbGV0IGkgPSAkaW5kZXgpIHtcbiAgICAgIDxtYXQtb3B0aW9uIFt2YWx1ZV09XCJvcHRpb24udmFsdWVcIiBbbmdDbGFzc109XCJ7J2hpZGRlbic6IG9wdGlvbi5oaWRkZW59XCJcbiAgICAgICAgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gY2wtbWF0LXNlbGVjdC1vcHRpb25cIj5cblxuICAgICAgICA8bWF0LWxhYmVsPnt7IG9wdGlvbi50ZXh0IH19PC9tYXQtbGFiZWw+XG5cbiAgICAgIDwvbWF0LW9wdGlvbj5cbiAgICB9XG4gICAgPCEtLSBvcHRpb25zIGZvciBkcm9wZG93biAtLT5cbiAgPC9tYXQtc2VsZWN0PlxuXG4gIEBpZiAocHJvcGVydGllcy5vcHRpb25hbCAmJiB2YWx1ZSAhPSAnJykge1xuICAgIDxtYXQtaWNvbiBjbGFzcz1cImNsLXNlbGVjdC1jbGVhci1pY29uXCIgKGNsaWNrKT1cImNsZWFyU2VsZWN0aW9uKCRldmVudClcIj5jbG9zZTwvbWF0LWljb24+XG4gIH1cbjwvbWF0LWZvcm0tZmllbGQ+XG5cbjwhLS0gVGhpcyBkaXYgaXMgcmVxdWlyZWQgdG8gc2hvdyBoaW50IHRleHQgb3IgZXJyb3IgbWVzc2FnZSBmb3IgdGhlIGNvbXBvbmVudCAtLT5cbjwhLS0gPGRpdiAjZXJyb3JPckhpbnREaXZFbGVtZW50UmVmIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj48L2Rpdj4gLS0+XG48ZGl2IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgQGlmIChlcnJvcikge1xuICAgIDxtYXQtZXJyb3I+e3sgZXJyb3IgfX08L21hdC1lcnJvcj5cbiAgfVxuXG4gIEBpZiAocHJvcGVydGllcy5oaW50VGV4dCkge1xuICAgIDxtYXQtaGludD57eyBwcm9wZXJ0aWVzLmhpbnRUZXh0IH19PC9tYXQtaGludD5cbiAgfVxuPC9kaXY+XG4iXX0=