import { NgClass } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { Component, Input, Optional, Self, ViewChild } from '@angular/core';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { ClInputProperties, ClInputType } from './input.properties';
import { ClPatternInputDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import { ClBaseComponent, ClInputPatternType } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/input";
import * as i4 from "@angular/material/form-field";
export class ClInputComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.numberTypeInputValue = 0;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClInputProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        if (this.inputType != this.properties?.inputType && this.properties?.inputType === ClInputType.number) {
            this.properties.pattern = { patternType: ClInputPatternType.numeric };
        }
        this.inputType = this.properties?.inputType;
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.valueChangesSub?.unsubscribe();
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onValueChange(ev) {
        let value = ev.value;
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    onSuffixIconClicked() {
        if (this.properties.onSuffixIconClicked) {
            this.properties.onSuffixIconClicked(this);
        }
    }
    onPrefixIconClicked() {
        if (this.properties.onPrefixIconClicked) {
            this.properties.onPrefixIconClicked(this);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    increment() {
        this.numberTypeInputValue = this._value != '' ? this._value : 0;
        // check if the form control is disabled or not
        // if it is disabled - return
        if (this.disabled) {
            return;
        }
        if (this.properties.max != undefined && this.numberTypeInputValue >= this.properties.max) {
            return;
        }
        else {
            this.numberTypeInputValue++;
            this._value = this.numberTypeInputValue;
            this.onChange(this._value);
        }
    }
    decrement() {
        this.numberTypeInputValue = this._value != '' ? this._value : 0;
        // check if the form control is disabled or not
        // if it is disabled - return
        if (this.disabled) {
            return;
        }
        if (this.properties.min != undefined && this.numberTypeInputValue <= this.properties.min) {
            return;
        }
        else {
            this.numberTypeInputValue--;
            this._value = this.numberTypeInputValue;
            this.onChange(this._value);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClInputComponent, isStandalone: true, selector: "cl-input", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput [value]=\"value\" [disabled]=\"disabled\" [type]=\"properties.inputType!\"\n    [clPatternInput]=\"properties.pattern!\" [placeholder]=\"properties.placeholder!\"\n    [attr.minlength]=\"properties.minLength!\" [attr.maxlength]=\"properties.maxLength!\"\n    (input)=\"onValueChange($event.target)\" (blur)=\"onTouched($any($event.target).value)\"\n    (keyup)=\"writeValue($any($event.target).value)\" />\n\n  @if (properties.prefixLabel) {\n    <span matPrefix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.prefixLabel }}</span>\n  }\n\n  @if (properties.suffixLabel) {\n    <span matSuffix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.suffixLabel }}</span>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.inputType == 'number') {\n    <span matSuffix>\n      <div class=\"flex flex-col cl-input-increment-icons\">\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"increment()\" [svgIcon]=\"'fss_icons:up-arrow'\">\n        </mat-icon>\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"decrement()\" [svgIcon]=\"'fss_icons:down-arrow'\">\n        </mat-icon>\n      </div>\n    </span>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }, { kind: "directive", type: ClPatternInputDirective, selector: "[clPatternInput]", inputs: ["clPatternInput", "allowedSpecialChars"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-input', imports: [
                        NgClass,
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClTooltipDirective,
                        ClPatternInputDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [floatLabel]=\"properties.floatLabel!\"\n  [appearance]=\"properties.appearance!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\" [svgIcon]=\"'heroicons_outline:information-circle'\"\n          class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <input matInput [value]=\"value\" [disabled]=\"disabled\" [type]=\"properties.inputType!\"\n    [clPatternInput]=\"properties.pattern!\" [placeholder]=\"properties.placeholder!\"\n    [attr.minlength]=\"properties.minLength!\" [attr.maxlength]=\"properties.maxLength!\"\n    (input)=\"onValueChange($event.target)\" (blur)=\"onTouched($any($event.target).value)\"\n    (keyup)=\"writeValue($any($event.target).value)\" />\n\n  @if (properties.prefixLabel) {\n    <span matPrefix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.prefixLabel }}</span>\n  }\n\n  @if (properties.suffixLabel) {\n    <span matSuffix class=\"text-md font-normal text-neutral-600 leading-6 p-4\">{{ properties.suffixLabel }}</span>\n  }\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" (click)=\"onSuffixIconClicked()\" [svgIcon]=\"properties.suffixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onSuffixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"icon-size-5\" (click)=\"onPrefixIconClicked()\" [svgIcon]=\"properties.prefixIcon!\"\n      [ngClass]=\"{'cursor-pointer': properties.onPrefixIconClicked}\">\n    </mat-icon>\n  }\n\n  @if (properties.inputType == 'number') {\n    <span matSuffix>\n      <div class=\"flex flex-col cl-input-increment-icons\">\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"increment()\" [svgIcon]=\"'fss_icons:up-arrow'\">\n        </mat-icon>\n\n        <mat-icon class=\"icon-size-4 cursor-pointer\" (click)=\"decrement()\" [svgIcon]=\"'fss_icons:down-arrow'\">\n        </mat-icon>\n      </div>\n    </span>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9pbnB1dC9pbnB1dC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2lucHV0L2lucHV0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMxQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxZQUFZLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRixPQUFPLEVBQXdCLFdBQVcsRUFBK0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUNoRyxPQUFPLEVBQXNDLFNBQVMsRUFBVyxLQUFLLEVBQXFCLFFBQVEsRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRTVJLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxXQUFXLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNwRSxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNyRSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sc0NBQXNDLENBQUM7QUFDdkUsT0FBTyxFQUFFLGVBQWUsRUFBa0Isa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7Ozs7O0FBeUJqRyxNQUFNLE9BQU8sZ0JBQWlCLFNBQVEsZUFBZTtJQStCbkQsWUFBd0MsU0FBb0I7UUFDMUQ7OztXQUdHO1FBQ0gsS0FBSyxFQUFFLENBQUM7UUFMOEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQVhwRCx5QkFBb0IsR0FBVyxDQUFDLENBQUM7UUFFekMsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFjMUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO1FBRXZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksaUJBQWlCLEVBQUUsQ0FBQztRQUM1QyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELFNBQVM7UUFDUCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxTQUFTLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxTQUFTLEtBQUssV0FBVyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3RHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxHQUFHLEVBQUUsV0FBVyxFQUFFLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ3hFLENBQUM7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUyxDQUFDO0lBQzlDLENBQUM7SUFFRCxlQUFlO1FBQ2Isb0dBQW9HO1FBQ3BHLDRFQUE0RTtRQUM1RSx5SUFBeUk7UUFFekksaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixLQUFLLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUUxRCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQzVFLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxpREFBaUQ7UUFDakQsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQyxPQUFZLEVBQUUsRUFBRTtZQUNuRSxJQUFJLE9BQU8sSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixpQ0FBaUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQscUJBQXFCO1FBQ25CLHVGQUF1RjtRQUN2RixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFFckIsd0RBQXdEO1FBQ3hELElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDdkYsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQzFDLE1BQU0sSUFBSSxHQUE2QixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUE2QixDQUFDO2dCQUN0RyxJQUFJLENBQUMsS0FBSyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFXLENBQUMsQ0FBQztZQUNyRSxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM3RSxDQUFDO1lBRUQsa0NBQWtDO1lBQ2xDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQix5RUFBeUU7UUFFekUsdUVBQXVFO1FBQ3ZFLDJFQUEyRTtRQUUzRSwyRUFBMkU7UUFDM0UsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU0sWUFBWSxDQUFDLEtBQVU7UUFDNUIsZ0RBQWdEO1FBRWhELHdFQUF3RTtRQUN4RSwwRUFBMEU7UUFFMUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNwRix3RUFBd0U7SUFDMUUsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBQ0YsSUFBSSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRSxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNwQix1R0FBdUc7SUFDekcsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFrQjtRQUNqQyxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBRUQsaUJBQWlCLENBQUMsRUFBa0I7UUFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFLENBQUE7SUFDckIsQ0FBQztJQUVELElBQUksS0FBSztRQUNQLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQTtJQUNwQixDQUFDO0lBRUQsYUFBYSxDQUFDLEVBQU87UUFDbkIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFTyxhQUFhO1FBQ25CLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQTtRQUNsQixDQUFDO0lBQ0gsQ0FBQztJQUVNLG1CQUFtQjtRQUN4QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzVDLENBQUM7SUFDSCxDQUFDO0lBRU0sbUJBQW1CO1FBQ3hCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDNUMsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFXLFFBQVE7UUFDakIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVNLFNBQVM7UUFDZCxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVoRSwrQ0FBK0M7UUFDL0MsNkJBQTZCO1FBQzdCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2xCLE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxTQUFTLElBQUksSUFBSSxDQUFDLG9CQUFvQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDekYsT0FBTztRQUNULENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUM7WUFFeEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFTSxTQUFTO1FBQ2QsSUFBSSxDQUFDLG9CQUFvQixHQUFHLElBQUksQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFaEUsK0NBQStDO1FBQy9DLDZCQUE2QjtRQUM3QixJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNsQixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxvQkFBb0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3pGLE9BQU87UUFDVCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzVCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDO1lBRXhDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQzVCLENBQUM7SUFDSCxDQUFDOzhHQWhQVSxnQkFBZ0I7a0dBQWhCLGdCQUFnQix3SkFNaEIsWUFBWSx1RUM1Q3pCLHkxRkFzRUEseUhENUNJLE9BQU8sbUZBQ1AsV0FBVyw4QkFDWCxhQUFhLG1MQUNiLGNBQWMsNmlDQUNkLGdCQUFnQiw4QkFDaEIsa0JBQWtCLCtCQUVsQixrQkFBa0IsdUhBQ2xCLHVCQUF1Qjs7MkZBSWQsZ0JBQWdCO2tCQXZCNUIsU0FBUztpQ0FDSSxJQUFJLFlBQ04sVUFBVSxXQVFYO3dCQUNQLE9BQU87d0JBQ1AsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBRWxCLGtCQUFrQjt3QkFDbEIsdUJBQXVCO3FCQUN4Qjs7MEJBa0NhLFFBQVE7OzBCQUFJLElBQUk7eUNBNUJkLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUtsQixZQUFZO3NCQURsQixTQUFTO3VCQUFDLFlBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE5nQ2xhc3MgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2ljb24nO1xuaW1wb3J0IHsgTWF0SW5wdXRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pbnB1dCc7XG5pbXBvcnQgeyBNYXRUb29sdGlwTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdG9vbHRpcCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1zTW9kdWxlLCBOZ0NvbnRyb2wsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBBZnRlckNvbnRlbnRDaGVja2VkLCBBZnRlclZpZXdJbml0LCBDb21wb25lbnQsIERvQ2hlY2ssIElucHV0LCBPbkRlc3Ryb3ksIE9uSW5pdCwgT3B0aW9uYWwsIFNlbGYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBDbElucHV0UHJvcGVydGllcywgQ2xJbnB1dFR5cGUgfSBmcm9tICcuL2lucHV0LnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xQYXR0ZXJuSW5wdXREaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBnZXRFcnJvck1lc3NhZ2UgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL2Zvcm0tdmFsaWRhdGlvbnMnO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50LCBDbEVycm9ySGFuZGxlciwgQ2xJbnB1dFBhdHRlcm5UeXBlIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1pbnB1dCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9pbnB1dC5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlczogW2BcbiAgICA6aG9zdCB7XG4gICAgICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXSxcbiAgaW1wb3J0czogW1xuICAgIE5nQ2xhc3MsXG4gICAgRm9ybXNNb2R1bGUsXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRJbnB1dE1vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcblxuICAgIENsVG9vbHRpcERpcmVjdGl2ZSxcbiAgICBDbFBhdHRlcm5JbnB1dERpcmVjdGl2ZVxuICBdXG59KVxuXG5leHBvcnQgY2xhc3MgQ2xJbnB1dENvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkluaXQsIE9uRGVzdHJveSwgQWZ0ZXJWaWV3SW5pdCwgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgRG9DaGVjayB7XG4gIC8vIFBsZWFzZSBwdXQgYWxsIHRoZSBhbmd1bGFyIGRlY29yYXRlZCB2YXJpYWJsZXMgYmVsb3cgdGhpc1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsSW5wdXRQcm9wZXJ0aWVzO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBAVmlld0NoaWxkKE1hdEZvcm1GaWVsZClcbiAgcHVibGljIG1hdEZvcm1GaWVsZCE6IE1hdEZvcm1GaWVsZDtcblxuICAvLyBAVmlld0NoaWxkKCdtYXRUZXh0RmllbGQnKVxuICAvLyBwdWJsaWMgbWF0VGV4dEZpZWxkRGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gQFZpZXdDaGlsZCgnZXJyb3JPckhpbnREaXZFbGVtZW50UmVmJylcbiAgLy8gcHVibGljIGVycm9yT3JIaW50RGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gcHJpdmF0ZSBlcnJvck9ySGludERpdkVsZW1lbnQhOiBIVE1MRGl2RWxlbWVudDtcbiAgLy8gcHJpdmF0ZSBtYXRUZXh0RmllbGREaXZFbGVtZW50ITogSFRNTERpdkVsZW1lbnQ7XG5cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgcHJpdmF0ZSBudW1iZXJUeXBlSW5wdXRWYWx1ZTogbnVtYmVyID0gMDtcblxuICBvbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgb25Ub3VjaGVkID0gKF86IGFueSkgPT4geyB9O1xuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgcHJpdmF0ZSB2YWx1ZUNoYW5nZXNTdWI/OiBTdWJzY3JpcHRpb247XG4gIHB1YmxpYyBzdWI/OiBTdWJzY3JpcHRpb247XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuICBwdWJsaWMgaW5wdXRUeXBlPzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yIChAT3B0aW9uYWwoKSBAU2VsZigpIHB1YmxpYyBuZ0NvbnRyb2w6IE5nQ29udHJvbCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCkge1xuICAgICAgLy8gU2V0dGluZyB0aGUgdmFsdWUgYWNjZXNzb3IgZGlyZWN0bHkgKGluc3RlYWQgb2YgdXNpbmdcbiAgICAgIC8vIHRoZSBwcm92aWRlcnMpIHRvIGF2b2lkIHJ1bm5pbmcgaW50byBhIGNpcmN1bGFyIGltcG9ydC5cbiAgICAgIHRoaXMubmdDb250cm9sLnZhbHVlQWNjZXNzb3IgPSB0aGlzO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsSW5wdXRQcm9wZXJ0aWVzKCk7XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nRG9DaGVjaygpIHtcbiAgICBpZiAodGhpcy5pbnB1dFR5cGUgIT0gdGhpcy5wcm9wZXJ0aWVzPy5pbnB1dFR5cGUgJiYgdGhpcy5wcm9wZXJ0aWVzPy5pbnB1dFR5cGUgPT09IENsSW5wdXRUeXBlLm51bWJlcikge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLnBhdHRlcm4gPSB7IHBhdHRlcm5UeXBlOiBDbElucHV0UGF0dGVyblR5cGUubnVtZXJpYyB9O1xuICAgIH1cblxuICAgIHRoaXMuaW5wdXRUeXBlID0gdGhpcy5wcm9wZXJ0aWVzPy5pbnB1dFR5cGU7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgLy8gc2V0dGluZyB0aGUgcmVmZXJlbmNlcyBvZiBOYXRpdmUgRWxlbWVudHMsIHdoaWNoIHdpbGwgYmUgdXNlZCBpbiBzZXRFcnJvclRleHQoKSBhbmQgc2V0SGludFRleHQoKVxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50ID0gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnRSZWYubmF0aXZlRWxlbWVudDtcbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQgPSB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5tYXQtbWRjLXRleHQtZmllbGQtd3JhcHBlci5tZGMtdGV4dC1maWVsZCcpO1xuXG4gICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgdGhpcy5zZXRIaW50VGV4dCgpO1xuXG4gICAgc3VwZXIuc3Vic2NyaWJlVG9WYWx1ZUNoYW5nZXModGhpcy53cml0ZVZhbHVlLmJpbmQodGhpcykpO1xuXG4gICAgdGhpcy52YWx1ZUNoYW5nZXNTdWIgPSB0aGlzLm5nQ29udHJvbD8udmFsdWVDaGFuZ2VzPy5zdWJzY3JpYmUoKHZhbHVlOiBhbnkpID0+IHtcbiAgICAgIGlmICh0aGlzLl92YWx1ZSAhPSB2YWx1ZSkge1xuICAgICAgICB0aGlzLndyaXRlVmFsdWUodmFsdWUpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8gcmVtb3ZlIGFsbCB0aGUgZXJyb3JzIHdoZW4gdGhlIHN0YXR1cyBpcyB2YWxpZFxuICAgIHRoaXMuc3ViID0gdGhpcy5uZ0NvbnRyb2w/LnN0YXR1c0NoYW5nZXM/LnN1YnNjcmliZSgoY2hhbmdlczogYW55KSA9PiB7XG4gICAgICBpZiAoY2hhbmdlcyAmJiBjaGFuZ2VzID09PSAnVkFMSUQnKSB7XG4gICAgICAgIHRoaXMuZXJyb3IgPSBudWxsO1xuXG4gICAgICAgIC8vIGNhbGxpbmcgc2V0IGhpbnQgdGV4dCBmdW5jdGlvblxuICAgICAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7XG4gICAgLy8gYmVsb3cgaXMgdG8gYXZvaWQgZGlzcGxheWluZyAndW5kZWZpbmVkJyBvbiBzY3JlZW4gd2hlbiBtb2RlbCBpcyBub3QgZGVmaW5lZCAuLiB5ZXQuXG4gICAgdGhpcy5zZXRFbXB0eVZhbHVlKCk7XG5cbiAgICAvLyB0cmlnZ2VyIHRoZSBlcnJvciBwYXR0ZXJuIG9uY2UgdGhlIGNvbnRlbnQgaXMgY2hlY2tlZFxuICAgIGlmICh0aGlzLm5nQ29udHJvbCAhPSBudWxsICYmIHRoaXMubmdDb250cm9sLnRvdWNoZWQgPT09IHRydWUgJiYgdGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSB7XG4gICAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmlzUmVhY3RpdmVGb3JtQ29udHJvbCkge1xuICAgICAgICBjb25zdCBrZXlzOiAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW10gPSBPYmplY3Qua2V5cyh0aGlzLm5nQ29udHJvbC5lcnJvcnMpIGFzIChrZXlvZiBDbEVycm9ySGFuZGxlcilbXTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGdldEVycm9yTWVzc2FnZShrZXlzWzBdLCB0aGlzLnByb3BlcnRpZXMuZXJyb3JzTGlzdCEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG4gICAgICB9XG5cbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBzZXRIaW50VGV4dCgpIHtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5pbm5lclRleHQgPSB0aGlzLnByb3BlcnRpZXMuaGludFRleHQgPz8gJyc7XG5cbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtbWRjLWZvcm0tZmllbGQtaGludCcpO1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1tZGMtZm9ybS1maWVsZC1lcnJvcicpO1xuXG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21kYy10ZXh0LWZpZWxkLS1pbnZhbGlkJyk7XG4gICAgdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtZm9ybS1maWVsZC1pbnZhbGlkJyk7XG4gIH1cblxuICBwdWJsaWMgc2V0RXJyb3JUZXh0KGVycm9yOiBhbnkpIHtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5pbm5lclRleHQgPSBlcnJvcjtcblxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21hdC1tZGMtZm9ybS1maWVsZC1lcnJvcicpO1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1tZGMtZm9ybS1maWVsZC1oaW50Jyk7XG5cbiAgICB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21hdC1mb3JtLWZpZWxkLWludmFsaWQnKTtcbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWRjLXRleHQtZmllbGQtLWludmFsaWQnKTtcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25EZXN0cm95KCk6IHZvaWQge1xuICAgIC8qKlxuICAgICogISEgV2FybmluZyAhIVxuICAgICogVGhlIGJlbG93IHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAqL1xuICAgIHRoaXMudmFsdWVDaGFuZ2VzU3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlXG4gIH1cblxuICBvblZhbHVlQ2hhbmdlKGV2OiBhbnkpIHtcbiAgICBsZXQgdmFsdWUgPSBldi52YWx1ZTtcbiAgICB0aGlzLndyaXRlVmFsdWUodmFsdWUpO1xuICAgIHRoaXMub25DaGFuZ2UodGhpcy5fdmFsdWUpO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZSh0aGlzLl92YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzZXRFbXB0eVZhbHVlKCkge1xuICAgIGlmICh0aGlzLl92YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLl92YWx1ZSA9ICcnXG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uU3VmZml4SWNvbkNsaWNrZWQoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblN1ZmZpeEljb25DbGlja2VkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25TdWZmaXhJY29uQ2xpY2tlZCh0aGlzKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgb25QcmVmaXhJY29uQ2xpY2tlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uUHJlZml4SWNvbkNsaWNrZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vblByZWZpeEljb25DbGlja2VkKHRoaXMpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBnZXQgZGlzYWJsZWQoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgcHVibGljIGdldCBzaG93SW5mb01zZygpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2c7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2coKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgaW5jcmVtZW50KCkge1xuICAgIHRoaXMubnVtYmVyVHlwZUlucHV0VmFsdWUgPSB0aGlzLl92YWx1ZSAhPSAnJyA/IHRoaXMuX3ZhbHVlIDogMDtcblxuICAgIC8vIGNoZWNrIGlmIHRoZSBmb3JtIGNvbnRyb2wgaXMgZGlzYWJsZWQgb3Igbm90XG4gICAgLy8gaWYgaXQgaXMgZGlzYWJsZWQgLSByZXR1cm5cbiAgICBpZiAodGhpcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMubWF4ICE9IHVuZGVmaW5lZCAmJiB0aGlzLm51bWJlclR5cGVJbnB1dFZhbHVlID49IHRoaXMucHJvcGVydGllcy5tYXgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5udW1iZXJUeXBlSW5wdXRWYWx1ZSsrO1xuICAgICAgdGhpcy5fdmFsdWUgPSB0aGlzLm51bWJlclR5cGVJbnB1dFZhbHVlO1xuXG4gICAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuX3ZhbHVlKVxuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkZWNyZW1lbnQoKSB7XG4gICAgdGhpcy5udW1iZXJUeXBlSW5wdXRWYWx1ZSA9IHRoaXMuX3ZhbHVlICE9ICcnID8gdGhpcy5fdmFsdWUgOiAwO1xuXG4gICAgLy8gY2hlY2sgaWYgdGhlIGZvcm0gY29udHJvbCBpcyBkaXNhYmxlZCBvciBub3RcbiAgICAvLyBpZiBpdCBpcyBkaXNhYmxlZCAtIHJldHVyblxuICAgIGlmICh0aGlzLmRpc2FibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5taW4gIT0gdW5kZWZpbmVkICYmIHRoaXMubnVtYmVyVHlwZUlucHV0VmFsdWUgPD0gdGhpcy5wcm9wZXJ0aWVzLm1pbikge1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm51bWJlclR5cGVJbnB1dFZhbHVlLS07XG4gICAgICB0aGlzLl92YWx1ZSA9IHRoaXMubnVtYmVyVHlwZUlucHV0VmFsdWU7XG5cbiAgICAgIHRoaXMub25DaGFuZ2UodGhpcy5fdmFsdWUpXG4gICAgfVxuICB9XG59XG4iLCI8bWF0LWZvcm0tZmllbGQgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgW2Zsb2F0TGFiZWxdPVwicHJvcGVydGllcy5mbG9hdExhYmVsIVwiXG4gIFthcHBlYXJhbmNlXT1cInByb3BlcnRpZXMuYXBwZWFyYW5jZSFcIiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIj5cblxuICBAaWYgKHByb3BlcnRpZXMubGFiZWwgIT0gbnVsbCAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9ICcnICYmIHByb3BlcnRpZXMubGFiZWwgIT0gdW5kZWZpbmVkKSB7XG4gICAgPG1hdC1sYWJlbCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICA8c3Bhbj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9zcGFuPlxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwpIHtcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJvcHRpb25hbC10ZXh0XCI+KE9wdGlvbmFsKTwvc3Bhbj5cbiAgICAgIH1cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiXG4gICAgICAgICAgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgIH1cbiAgICA8L21hdC1sYWJlbD5cbiAgfVxuXG4gIDxpbnB1dCBtYXRJbnB1dCBbdmFsdWVdPVwidmFsdWVcIiBbZGlzYWJsZWRdPVwiZGlzYWJsZWRcIiBbdHlwZV09XCJwcm9wZXJ0aWVzLmlucHV0VHlwZSFcIlxuICAgIFtjbFBhdHRlcm5JbnB1dF09XCJwcm9wZXJ0aWVzLnBhdHRlcm4hXCIgW3BsYWNlaG9sZGVyXT1cInByb3BlcnRpZXMucGxhY2Vob2xkZXIhXCJcbiAgICBbYXR0ci5taW5sZW5ndGhdPVwicHJvcGVydGllcy5taW5MZW5ndGghXCIgW2F0dHIubWF4bGVuZ3RoXT1cInByb3BlcnRpZXMubWF4TGVuZ3RoIVwiXG4gICAgKGlucHV0KT1cIm9uVmFsdWVDaGFuZ2UoJGV2ZW50LnRhcmdldClcIiAoYmx1cik9XCJvblRvdWNoZWQoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIlxuICAgIChrZXl1cCk9XCJ3cml0ZVZhbHVlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCIgLz5cblxuICBAaWYgKHByb3BlcnRpZXMucHJlZml4TGFiZWwpIHtcbiAgICA8c3BhbiBtYXRQcmVmaXggY2xhc3M9XCJ0ZXh0LW1kIGZvbnQtbm9ybWFsIHRleHQtbmV1dHJhbC02MDAgbGVhZGluZy02IHAtNFwiPnt7IHByb3BlcnRpZXMucHJlZml4TGFiZWwgfX08L3NwYW4+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMuc3VmZml4TGFiZWwpIHtcbiAgICA8c3BhbiBtYXRTdWZmaXggY2xhc3M9XCJ0ZXh0LW1kIGZvbnQtbm9ybWFsIHRleHQtbmV1dHJhbC02MDAgbGVhZGluZy02IHAtNFwiPnt7IHByb3BlcnRpZXMuc3VmZml4TGFiZWwgfX08L3NwYW4+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMuc3VmZml4SWNvbikge1xuICAgIDxtYXQtaWNvbiBtYXRTdWZmaXggY2xhc3M9XCJpY29uLXNpemUtNVwiIChjbGljayk9XCJvblN1ZmZpeEljb25DbGlja2VkKClcIiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnN1ZmZpeEljb24hXCJcbiAgICAgIFtuZ0NsYXNzXT1cInsnY3Vyc29yLXBvaW50ZXInOiBwcm9wZXJ0aWVzLm9uU3VmZml4SWNvbkNsaWNrZWR9XCI+XG4gICAgPC9tYXQtaWNvbj5cbiAgfVxuXG4gIEBpZiAocHJvcGVydGllcy5wcmVmaXhJY29uKSB7XG4gICAgPG1hdC1pY29uIG1hdFByZWZpeCBjbGFzcz1cImljb24tc2l6ZS01XCIgKGNsaWNrKT1cIm9uUHJlZml4SWNvbkNsaWNrZWQoKVwiIFtzdmdJY29uXT1cInByb3BlcnRpZXMucHJlZml4SWNvbiFcIlxuICAgICAgW25nQ2xhc3NdPVwieydjdXJzb3ItcG9pbnRlcic6IHByb3BlcnRpZXMub25QcmVmaXhJY29uQ2xpY2tlZH1cIj5cbiAgICA8L21hdC1pY29uPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmlucHV0VHlwZSA9PSAnbnVtYmVyJykge1xuICAgIDxzcGFuIG1hdFN1ZmZpeD5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGNsLWlucHV0LWluY3JlbWVudC1pY29uc1wiPlxuXG4gICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyXCIgKGNsaWNrKT1cImluY3JlbWVudCgpXCIgW3N2Z0ljb25dPVwiJ2Zzc19pY29uczp1cC1hcnJvdydcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cblxuICAgICAgICA8bWF0LWljb24gY2xhc3M9XCJpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlclwiIChjbGljayk9XCJkZWNyZW1lbnQoKVwiIFtzdmdJY29uXT1cIidmc3NfaWNvbnM6ZG93bi1hcnJvdydcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvc3Bhbj5cbiAgfVxuPC9tYXQtZm9ybS1maWVsZD5cblxuPCEtLSBUaGlzIGRpdiBpcyByZXF1aXJlZCB0byBzaG93IGhpbnQgdGV4dCBvciBlcnJvciBtZXNzYWdlIGZvciB0aGUgY29tcG9uZW50IC0tPlxuPCEtLSA8ZGl2ICNlcnJvck9ySGludERpdkVsZW1lbnRSZWYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPjwvZGl2PiAtLT5cbjxkaXYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPlxuICBAaWYgKGVycm9yKSB7XG4gICAgPG1hdC1lcnJvcj57eyBlcnJvciB9fTwvbWF0LWVycm9yPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmhpbnRUZXh0KSB7XG4gICAgPG1hdC1oaW50Pnt7IHByb3BlcnRpZXMuaGludFRleHQgfX08L21hdC1oaW50PlxuICB9XG48L2Rpdj5cbiJdfQ==