import { Component, Input } from '@angular/core';
import { ClChipProperties } from './chip.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
export class ClChipComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClChipProperties();
        super.ngOnInit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClChipComponent, isStandalone: true, selector: "cl-chip", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"{{properties.style?.cssClasses}} flex rounded-full items-center justify-center\">\n  <span class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</span>\n</div>\n" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chip', template: "<div [id]=\"properties.id\" class=\"{{properties.style?.cssClasses}} flex rounded-full items-center justify-center\">\n  <span class=\"{{ properties.style?.labelCssClasses }}\">{{properties.label}}</span>\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hpcC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NoaXAvY2hpcC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NoaXAvY2hpcC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUV6RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7O0FBTzdELE1BQU0sT0FBTyxlQUFnQixTQUFRLGVBQWU7SUFJbEQ7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1FBRTNDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQTtJQUNsQixDQUFDOzhHQWxCVSxlQUFlO2tHQUFmLGVBQWUsZ0lDVjVCLHdOQUdBOzsyRkRPYSxlQUFlO2tCQUwzQixTQUFTO2lDQUNJLElBQUksWUFDTixTQUFTO3dEQUtILFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsQ2hpcFByb3BlcnRpZXMgfSBmcm9tICcuL2NoaXAucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWNoaXAnLFxuICB0ZW1wbGF0ZVVybDogJy4vY2hpcC5jb21wb25lbnQuaHRtbCcsXG59KVxuZXhwb3J0IGNsYXNzIENsQ2hpcENvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xDaGlwUHJvcGVydGllcztcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5wcm9wZXJ0aWVzID8/PSBuZXcgQ2xDaGlwUHJvcGVydGllcygpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKVxuICB9XG59XG4iLCI8ZGl2IFtpZF09XCJwcm9wZXJ0aWVzLmlkXCIgY2xhc3M9XCJ7e3Byb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXN9fSBmbGV4IHJvdW5kZWQtZnVsbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIj5cbiAgPHNwYW4gY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN0eWxlPy5sYWJlbENzc0NsYXNzZXMgfX1cIj57e3Byb3BlcnRpZXMubGFiZWx9fTwvc3Bhbj5cbjwvZGl2PlxuIl19