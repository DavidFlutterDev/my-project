import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { Component, Input, Optional, Self, ViewEncapsulation } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClToggleButtonProperties } from './toggle-button.properties';
import { MatIconModule } from '@angular/material/icon';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/button-toggle";
import * as i3 from "@angular/material/icon";
export class ClToggleButtonComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClToggleButtonProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having selected as true and check with the value.
        // if both are not same update the value with the selected true option
        const selectedOption = this.properties.options?.find((opt) => opt.selected == true);
        if (selectedOption && selectedOption.value != this._value) {
            this.writeValue(selectedOption.value);
        }
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
    }
    writeValue(value) {
        // this._value = value;
        // this.properties.selectedText = this._value;
        if (value) {
            this.properties.options?.forEach((option) => {
                if (option.value === value) {
                    option.selected = true;
                }
                else {
                    option.selected = false;
                }
            });
            this._value = value;
        }
        else {
            this.properties.options?.forEach((option) => {
                option.selected = false;
            });
            this._value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onChangeButtonToggle(event) {
        this.writeValue(event.value);
        this.onChange(this._value);
        if (this.properties.onToggleChange) {
            this.properties.onToggleChange(this._value);
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToggleButtonComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClToggleButtonComponent, isStandalone: true, selector: "cl-toggle-button", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\"\n  class=\"{{properties.style?.parentClass ? properties.style?.parentClass : 'cl-toggle-button'}}\">\n\n  <mat-button-toggle-group class=\"{{properties.style?.cssClasses}}\"\n    [hideSingleSelectionIndicator]=\"properties.hideSelectionIndicator\"\n    [value]=\"value\"\n    [disabled]=\"properties.disabled\"\n    (change)=\"onChangeButtonToggle($event)\" aria-label=\"Font Style\">\n\n    @for (option of properties.options; track option) {\n      <mat-button-toggle class=\"{{properties.style?.innerClass}}\" [value]=\"option.value\" [disabled]=\"option.disabled\">\n        @if (option.icon){\n          <mat-icon class=\"icon-size-4\" [svgIcon]=\"option.icon\"></mat-icon>\n        }\n\n        {{option.text}}\n      </mat-button-toggle>\n    }\n  </mat-button-toggle-group>\n</div>\n", styles: [".cl-toggle-button{width:fit-content!important;padding:4px;background:#dfe3ec;border-radius:8px}.cl-toggle-button .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle{border-radius:4px!important;overflow:hidden;border:none!important;font-weight:500;color:#181b21!important;background:#dfe3ec}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-button .mat-button-toggle-label-content{color:#181b21!important}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle-checked{background:#fff;color:#181b21!important;font-weight:600!important}.cl-toggle-button-rounded-black{width:fit-content!important;padding:8px;background:#fff;border-radius:8px!important;border:.5px solid #E1E1E1!important}.cl-toggle-button-rounded-black .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle{border-radius:20px!important;overflow:hidden}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked{background:#181b21!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked .mat-button-toggle-label-content,.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked mat-icon{color:#fff!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-label-content{padding:8px!important}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonToggleModule }, { kind: "directive", type: i2.MatButtonToggleGroup, selector: "mat-button-toggle-group", inputs: ["appearance", "name", "vertical", "value", "multiple", "disabled", "disabledInteractive", "hideSingleSelectionIndicator", "hideMultipleSelectionIndicator"], outputs: ["valueChange", "change"], exportAs: ["matButtonToggleGroup"] }, { kind: "component", type: i2.MatButtonToggle, selector: "mat-button-toggle", inputs: ["aria-label", "aria-labelledby", "id", "name", "value", "tabIndex", "disableRipple", "appearance", "checked", "disabled", "disabledInteractive"], outputs: ["change"], exportAs: ["matButtonToggle"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToggleButtonComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-toggle-button', imports: [
                        MatButtonToggleModule,
                        MatIconModule
                    ], encapsulation: ViewEncapsulation.None, template: "<div [id]=\"properties.id\"\n  class=\"{{properties.style?.parentClass ? properties.style?.parentClass : 'cl-toggle-button'}}\">\n\n  <mat-button-toggle-group class=\"{{properties.style?.cssClasses}}\"\n    [hideSingleSelectionIndicator]=\"properties.hideSelectionIndicator\"\n    [value]=\"value\"\n    [disabled]=\"properties.disabled\"\n    (change)=\"onChangeButtonToggle($event)\" aria-label=\"Font Style\">\n\n    @for (option of properties.options; track option) {\n      <mat-button-toggle class=\"{{properties.style?.innerClass}}\" [value]=\"option.value\" [disabled]=\"option.disabled\">\n        @if (option.icon){\n          <mat-icon class=\"icon-size-4\" [svgIcon]=\"option.icon\"></mat-icon>\n        }\n\n        {{option.text}}\n      </mat-button-toggle>\n    }\n  </mat-button-toggle-group>\n</div>\n", styles: [".cl-toggle-button{width:fit-content!important;padding:4px;background:#dfe3ec;border-radius:8px}.cl-toggle-button .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle{border-radius:4px!important;overflow:hidden;border:none!important;font-weight:500;color:#181b21!important;background:#dfe3ec}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-button .mat-button-toggle-label-content{color:#181b21!important}.cl-toggle-button .mat-button-toggle-group .mat-button-toggle-checked{background:#fff;color:#181b21!important;font-weight:600!important}.cl-toggle-button-rounded-black{width:fit-content!important;padding:8px;background:#fff;border-radius:8px!important;border:.5px solid #E1E1E1!important}.cl-toggle-button-rounded-black .mat-button-toggle-group{height:30px;align-items:center}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle{border-radius:20px!important;overflow:hidden}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked{background:#181b21!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked .mat-button-toggle-label-content,.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle.mat-button-toggle-checked mat-icon{color:#fff!important}.cl-toggle-button-rounded-black .mat-button-toggle-group .mat-button-toggle .mat-button-toggle-label-content{padding:8px!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9nZ2xlLWJ1dHRvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RvZ2dsZS1idXR0b24vdG9nZ2xlLWJ1dHRvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RvZ2dsZS1idXR0b24vdG9nZ2xlLWJ1dHRvbi5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxpQ0FBaUMsQ0FBQztBQUN4RSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxRQUFRLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUUzRyxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFFN0QsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDOzs7OztBQWF2RCxNQUFNLE9BQU8sdUJBQXdCLFNBQVEsZUFBZTtJQVMxRCw4Q0FBOEM7SUFFOUMsWUFBd0MsU0FBb0I7UUFDMUQ7OztXQUdHO1FBQ0gsS0FBSyxFQUFFLENBQUM7UUFMOEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUo1RCxhQUFRLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzQixjQUFTLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQVMxQixLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyQyx1R0FBdUc7UUFFdkcsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLHdEQUF3RDtZQUN4RCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSx3QkFBd0IsRUFBRSxDQUFDO1FBQ25ELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBQ0QsU0FBUztRQUNQLDZFQUE2RTtRQUM3RSxzRUFBc0U7UUFDdEUsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDO1FBQ3hGLElBQUcsY0FBYyxJQUFJLGNBQWMsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3pELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3hDLENBQUM7SUFDSCxDQUFDO0lBRUQsZUFBZTtRQUNiLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzVELENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQix1QkFBdUI7UUFDdkIsOENBQThDO1FBRTlDLElBQUksS0FBSyxFQUFFLENBQUM7WUFDVixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtnQkFDMUMsSUFBSSxNQUFNLENBQUMsS0FBSyxLQUFLLEtBQUssRUFBRSxDQUFDO29CQUMzQixNQUFNLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztnQkFDekIsQ0FBQztxQkFBTSxDQUFDO29CQUNOLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztRQUN0QixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLE1BQU0sRUFBRSxFQUFFO2dCQUMxQyxNQUFNLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDSCxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDcEIsQ0FBQztJQUVNLG9CQUFvQixDQUFDLEtBQVU7UUFDcEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDM0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM5QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBQ0YsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BCLHVHQUF1RztJQUN6RyxDQUFDOzhHQTlGVSx1QkFBdUI7a0dBQXZCLHVCQUF1Qix5SUNuQnBDLHF6QkFvQkEsa2pERE5JLHFCQUFxQixzb0JBQ3JCLGFBQWE7OzJGQUlKLHVCQUF1QjtrQkFYbkMsU0FBUztpQ0FDSSxJQUFJLFlBQ04sa0JBQWtCLFdBR25CO3dCQUNQLHFCQUFxQjt3QkFDckIsYUFBYTtxQkFDZCxpQkFDYyxpQkFBaUIsQ0FBQyxJQUFJOzswQkFhdkIsUUFBUTs7MEJBQUksSUFBSTt5Q0FUZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1hdEJ1dHRvblRvZ2dsZU1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2J1dHRvbi10b2dnbGUnO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBPcHRpb25hbCwgU2VsZiwgVmlld0VuY2Fwc3VsYXRpb24sIEFmdGVyVmlld0luaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50IH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9zaGFyZWQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIE5nQ29udHJvbCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IENsVG9nZ2xlQnV0dG9uUHJvcGVydGllcyB9IGZyb20gJy4vdG9nZ2xlLWJ1dHRvbi5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtdG9nZ2xlLWJ1dHRvbicsXG4gIHN0eWxlVXJsOiAnLi90b2dnbGUtYnV0dG9uLmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3RvZ2dsZS1idXR0b24uY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbXG4gICAgTWF0QnV0dG9uVG9nZ2xlTW9kdWxlLFxuICAgIE1hdEljb25Nb2R1bGVcbiAgXSxcbiAgZW5jYXBzdWxhdGlvbjogVmlld0VuY2Fwc3VsYXRpb24uTm9uZVxufSlcbmV4cG9ydCBjbGFzcyBDbFRvZ2dsZUJ1dHRvbkNvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsVG9nZ2xlQnV0dG9uUHJvcGVydGllcztcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIGNvbnN0cnVjdG9yIChAT3B0aW9uYWwoKSBAU2VsZigpIHB1YmxpYyBuZ0NvbnRyb2w6IE5nQ29udHJvbCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCkge1xuICAgICAgLy8gU2V0dGluZyB0aGUgdmFsdWUgYWNjZXNzb3IgZGlyZWN0bHkgKGluc3RlYWQgb2YgdXNpbmdcbiAgICAgIC8vIHRoZSBwcm92aWRlcnMpIHRvIGF2b2lkIHJ1bm5pbmcgaW50byBhIGNpcmN1bGFyIGltcG9ydC5cbiAgICAgIHRoaXMubmdDb250cm9sLnZhbHVlQWNjZXNzb3IgPSB0aGlzO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsVG9nZ2xlQnV0dG9uUHJvcGVydGllcygpO1xuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cbiAgbmdEb0NoZWNrKCkge1xuICAgIC8vIGZpbmQgdGhlIG9wdGlvbiB3aGljaCBpcyBoYXZpbmcgc2VsZWN0ZWQgYXMgdHJ1ZSBhbmQgY2hlY2sgd2l0aCB0aGUgdmFsdWUuXG4gICAgLy8gaWYgYm90aCBhcmUgbm90IHNhbWUgdXBkYXRlIHRoZSB2YWx1ZSB3aXRoIHRoZSBzZWxlY3RlZCB0cnVlIG9wdGlvblxuICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uID0gdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnM/LmZpbmQoKG9wdDphbnkpID0+IG9wdC5zZWxlY3RlZCA9PSB0cnVlKTtcbiAgICBpZihzZWxlY3RlZE9wdGlvbiAmJiBzZWxlY3RlZE9wdGlvbi52YWx1ZSAhPSB0aGlzLl92YWx1ZSkge1xuICAgICAgdGhpcy53cml0ZVZhbHVlKHNlbGVjdGVkT3B0aW9uLnZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgc3VwZXIuc3Vic2NyaWJlVG9WYWx1ZUNoYW5nZXModGhpcy53cml0ZVZhbHVlLmJpbmQodGhpcykpO1xuICB9XG5cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgLy8gdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICAvLyB0aGlzLnByb3BlcnRpZXMuc2VsZWN0ZWRUZXh0ID0gdGhpcy5fdmFsdWU7XG5cbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vcHRpb25zPy5mb3JFYWNoKChvcHRpb24pID0+IHtcbiAgICAgICAgaWYgKG9wdGlvbi52YWx1ZSA9PT0gdmFsdWUpIHtcbiAgICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnM/LmZvckVhY2goKG9wdGlvbikgPT4ge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSBmYWxzZTtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLl92YWx1ZSA9ICcnO1xuICAgIH1cbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlXG4gIH1cblxuICBwdWJsaWMgb25DaGFuZ2VCdXR0b25Ub2dnbGUoZXZlbnQ6IGFueSkge1xuICAgIHRoaXMud3JpdGVWYWx1ZShldmVudC52YWx1ZSk7XG4gICAgdGhpcy5vbkNoYW5nZSh0aGlzLl92YWx1ZSk7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblRvZ2dsZUNoYW5nZSkge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uVG9nZ2xlQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAvKipcbiAgICAqICEhIFdhcm5pbmcgISFcbiAgICAqIFRoZSBiZWxvdyBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgKi9cbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxufVxuIiwiPGRpdiBbaWRdPVwicHJvcGVydGllcy5pZFwiXG4gIGNsYXNzPVwie3twcm9wZXJ0aWVzLnN0eWxlPy5wYXJlbnRDbGFzcyA/IHByb3BlcnRpZXMuc3R5bGU/LnBhcmVudENsYXNzIDogJ2NsLXRvZ2dsZS1idXR0b24nfX1cIj5cblxuICA8bWF0LWJ1dHRvbi10b2dnbGUtZ3JvdXAgY2xhc3M9XCJ7e3Byb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXN9fVwiXG4gICAgW2hpZGVTaW5nbGVTZWxlY3Rpb25JbmRpY2F0b3JdPVwicHJvcGVydGllcy5oaWRlU2VsZWN0aW9uSW5kaWNhdG9yXCJcbiAgICBbdmFsdWVdPVwidmFsdWVcIlxuICAgIFtkaXNhYmxlZF09XCJwcm9wZXJ0aWVzLmRpc2FibGVkXCJcbiAgICAoY2hhbmdlKT1cIm9uQ2hhbmdlQnV0dG9uVG9nZ2xlKCRldmVudClcIiBhcmlhLWxhYmVsPVwiRm9udCBTdHlsZVwiPlxuXG4gICAgQGZvciAob3B0aW9uIG9mIHByb3BlcnRpZXMub3B0aW9uczsgdHJhY2sgb3B0aW9uKSB7XG4gICAgICA8bWF0LWJ1dHRvbi10b2dnbGUgY2xhc3M9XCJ7e3Byb3BlcnRpZXMuc3R5bGU/LmlubmVyQ2xhc3N9fVwiIFt2YWx1ZV09XCJvcHRpb24udmFsdWVcIiBbZGlzYWJsZWRdPVwib3B0aW9uLmRpc2FibGVkXCI+XG4gICAgICAgIEBpZiAob3B0aW9uLmljb24pe1xuICAgICAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImljb24tc2l6ZS00XCIgW3N2Z0ljb25dPVwib3B0aW9uLmljb25cIj48L21hdC1pY29uPlxuICAgICAgICB9XG5cbiAgICAgICAge3tvcHRpb24udGV4dH19XG4gICAgICA8L21hdC1idXR0b24tdG9nZ2xlPlxuICAgIH1cbiAgPC9tYXQtYnV0dG9uLXRvZ2dsZS1ncm91cD5cbjwvZGl2PlxuIl19