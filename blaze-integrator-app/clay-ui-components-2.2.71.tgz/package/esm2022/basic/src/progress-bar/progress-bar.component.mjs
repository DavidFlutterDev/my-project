import { NgClass } from '@angular/common';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { Component, Input } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClProgressBarMode, ClProgressBarProperties, ClProgressSize } from './progress-bar.properties';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/progress-bar";
export class ClProgressBarComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnChanges(changes) {
        this.properties.size ??= ClProgressSize.normal;
        this.properties.mode ??= ClProgressBarMode.determinate;
    }
    ngOnInit() {
        this.properties ??= new ClProgressBarProperties();
        super.ngOnInit();
    }
    //--------------------------------------------
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClProgressBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClProgressBarComponent, isStandalone: true, selector: "cl-progress-bar", inputs: { properties: "properties" }, usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 items-center {{ properties.style?.cssClasses }}\">\n  <mat-progress-bar [mode]=\"properties.mode!\" [value]=\"properties.value\"\n    class=\"{{ properties.size }} {{ properties.showRadius ? 'rounded-2xl' : 'rounded-none' }} {{ properties.style?.cssClasses }}\"\n    [ngClass]=\"properties.value != undefined && properties.value === 100 ? 'progress-green' : properties.value != undefined && properties.value &lt; 50 ? 'progress-yellow' : ''\">\n  </mat-progress-bar>\n\n  @if (properties.mode === 'determinate') {\n    <div class=\"text-xs font-bold\">{{ properties.value }}%</div>\n  }\n</div>\n", styles: [".progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatProgressBarModule }, { kind: "component", type: i1.MatProgressBar, selector: "mat-progress-bar", inputs: ["color", "value", "bufferValue", "mode"], outputs: ["animationEnd"], exportAs: ["matProgressBar"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClProgressBarComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-progress-bar', imports: [
                        NgClass,
                        MatProgressBarModule,
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 items-center {{ properties.style?.cssClasses }}\">\n  <mat-progress-bar [mode]=\"properties.mode!\" [value]=\"properties.value\"\n    class=\"{{ properties.size }} {{ properties.showRadius ? 'rounded-2xl' : 'rounded-none' }} {{ properties.style?.cssClasses }}\"\n    [ngClass]=\"properties.value != undefined && properties.value === 100 ? 'progress-green' : properties.value != undefined && properties.value &lt; 50 ? 'progress-yellow' : ''\">\n  </mat-progress-bar>\n\n  @if (properties.mode === 'determinate') {\n    <div class=\"text-xs font-bold\">{{ properties.value }}%</div>\n  }\n</div>\n", styles: [".progress-yellow ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(234 179 8 / var(--tw-border-opacity))}.progress-green ::ng-deep .mdc-linear-progress__bar-inner{--tw-border-opacity: 1;border-color:rgb(22 163 74 / var(--tw-border-opacity))}\n"] }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZ3Jlc3MtYmFyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvcHJvZ3Jlc3MtYmFyL3Byb2dyZXNzLWJhci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3Byb2dyZXNzLWJhci9wcm9ncmVzcy1iYXIuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLGdDQUFnQyxDQUFDO0FBQ3RFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUF5QixNQUFNLGVBQWUsQ0FBQztBQUV4RSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGlCQUFpQixFQUFFLHVCQUF1QixFQUFFLGNBQWMsRUFBRSxNQUFNLDJCQUEyQixDQUFDOzs7QUFhdkcsTUFBTSxPQUFPLHNCQUF1QixTQUFRLGVBQWU7SUFJekQ7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQWlCVixhQUFRLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzQixjQUFTLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQWpCMUIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO0lBQ3pHLENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDaEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLEtBQUssY0FBYyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksS0FBSyxpQkFBaUIsQ0FBQyxXQUFXLENBQUM7SUFDekQsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksdUJBQXVCLEVBQUUsQ0FBQztRQUVsRCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUtELDhDQUE4QztJQUU5QyxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDcEIsQ0FBQzs4R0E1Q1Usc0JBQXNCO2tHQUF0QixzQkFBc0IsNkpDbEJuQyxxb0JBVUEsNlVER0ksT0FBTyxtRkFFUCxvQkFBb0I7OzJGQUdYLHNCQUFzQjtrQkFYbEMsU0FBUztpQ0FDSSxJQUFJLFlBQ04saUJBQWlCLFdBR2xCO3dCQUNQLE9BQU87d0JBRVAsb0JBQW9CO3FCQUNyQjt3REFJZSxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nQ2xhc3MgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgTWF0UHJvZ3Jlc3NCYXJNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9wcm9ncmVzcy1iYXInO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBTaW1wbGVDaGFuZ2VzIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsUHJvZ3Jlc3NCYXJNb2RlLCBDbFByb2dyZXNzQmFyUHJvcGVydGllcywgQ2xQcm9ncmVzc1NpemUgfSBmcm9tICcuL3Byb2dyZXNzLWJhci5wcm9wZXJ0aWVzJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtcHJvZ3Jlc3MtYmFyJyxcbiAgc3R5bGVVcmw6ICcuL3Byb2dyZXNzLWJhci5jb21wb25lbnQuc2NzcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9wcm9ncmVzcy1iYXIuY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbXG4gICAgTmdDbGFzcyxcblxuICAgIE1hdFByb2dyZXNzQmFyTW9kdWxlLFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBDbFByb2dyZXNzQmFyQ29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbFByb2dyZXNzQmFyUHJvcGVydGllcztcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMuc2l6ZSA/Pz0gQ2xQcm9ncmVzc1NpemUubm9ybWFsO1xuICAgIHRoaXMucHJvcGVydGllcy5tb2RlID8/PSBDbFByb2dyZXNzQmFyTW9kZS5kZXRlcm1pbmF0ZTtcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsUHJvZ3Jlc3NCYXJQcm9wZXJ0aWVzKCk7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgcHJvdGVjdGVkIF92YWx1ZTogYW55O1xuICBvbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgb25Ub3VjaGVkID0gKF86IGFueSkgPT4geyB9O1xuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlXG4gIH1cbn1cbiIsIjxkaXYgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBjbGFzcz1cImZsZXggZ2FwLTIgaXRlbXMtY2VudGVyIHt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIj5cbiAgPG1hdC1wcm9ncmVzcy1iYXIgW21vZGVdPVwicHJvcGVydGllcy5tb2RlIVwiIFt2YWx1ZV09XCJwcm9wZXJ0aWVzLnZhbHVlXCJcbiAgICBjbGFzcz1cInt7IHByb3BlcnRpZXMuc2l6ZSB9fSB7eyBwcm9wZXJ0aWVzLnNob3dSYWRpdXMgPyAncm91bmRlZC0yeGwnIDogJ3JvdW5kZWQtbm9uZScgfX0ge3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fVwiXG4gICAgW25nQ2xhc3NdPVwicHJvcGVydGllcy52YWx1ZSAhPSB1bmRlZmluZWQgJiYgcHJvcGVydGllcy52YWx1ZSA9PT0gMTAwID8gJ3Byb2dyZXNzLWdyZWVuJyA6IHByb3BlcnRpZXMudmFsdWUgIT0gdW5kZWZpbmVkICYmIHByb3BlcnRpZXMudmFsdWUgJmx0OyA1MCA/ICdwcm9ncmVzcy15ZWxsb3cnIDogJydcIj5cbiAgPC9tYXQtcHJvZ3Jlc3MtYmFyPlxuXG4gIEBpZiAocHJvcGVydGllcy5tb2RlID09PSAnZGV0ZXJtaW5hdGUnKSB7XG4gICAgPGRpdiBjbGFzcz1cInRleHQteHMgZm9udC1ib2xkXCI+e3sgcHJvcGVydGllcy52YWx1ZSB9fSU8L2Rpdj5cbiAgfVxuPC9kaXY+XG4iXX0=