import { Component, Input } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClTextBlockProperties } from './text-block.properties';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/icon";
export class ClTextBlockComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClTextBlockProperties();
        super.ngOnInit();
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextBlockComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTextBlockComponent, isStandalone: true, selector: "cl-text-block", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"{{ properties.style?.cssClasses }}\">\n  <span>{{ properties.label }}</span>\n\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextBlockComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-text-block', imports: [
                        MatIconModule,
                        MatTooltipModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"{{ properties.style?.cssClasses }}\">\n  <span>{{ properties.label }}</span>\n\n  @if (properties.infoMsg && showInfoMsg) {\n    <mat-icon [tooltip]=\"properties.infoMsg!\"\n      [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n    </mat-icon>\n  }\n</div>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGV4dC1ibG9jay5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RleHQtYmxvY2svdGV4dC1ibG9jay5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RleHQtYmxvY2svdGV4dC1ibG9jay5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUN6RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDN0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7QUFZaEUsTUFBTSxPQUFPLG9CQUFxQixTQUFRLGVBQWU7SUFJdkQ7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxxQkFBcUIsRUFBRSxDQUFDO1FBRWhELEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQzs4R0E5QlUsb0JBQW9CO2tHQUFwQixvQkFBb0Isc0lDakJqQywwV0FTQSwyQ0RHSSxhQUFhLG1MQUNiLGdCQUFnQiwrQkFDaEIsa0JBQWtCOzsyRkFHVCxvQkFBb0I7a0JBVmhDLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLGVBQWUsV0FFaEI7d0JBQ1AsYUFBYTt3QkFDYixnQkFBZ0I7d0JBQ2hCLGtCQUFrQjtxQkFDbkI7d0RBSWUsVUFBVTtzQkFEekIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsVGV4dEJsb2NrUHJvcGVydGllcyB9IGZyb20gJy4vdGV4dC1ibG9jay5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdFRvb2x0aXBNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sdGlwJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcblxuQENvbXBvbmVudCh7XG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHNlbGVjdG9yOiAnY2wtdGV4dC1ibG9jaycsXG4gIHRlbXBsYXRlVXJsOiAnLi90ZXh0LWJsb2NrLmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0VG9vbHRpcE1vZHVsZSxcbiAgICBDbFRvb2x0aXBEaXJlY3RpdmVcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xUZXh0QmxvY2tDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsVGV4dEJsb2NrUHJvcGVydGllcztcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgLyoqXG4gICAgICogISEgV2FybmluZyAhIVxuICAgICAqIFRoZSBiZWxvdyB0d28gc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICAqL1xuICAgIHN1cGVyKCk7XG4gICAgc3VwZXIuc2V0UHJvcGVydGllcyh0aGlzLnByb3BlcnRpZXMpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsVGV4dEJsb2NrUHJvcGVydGllcygpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgc2hvd0luZm9Nc2coKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG4iLCI8ZGl2IFtpZF09XCJwcm9wZXJ0aWVzLmlkXCIgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzIH19XCI+XG4gIDxzcGFuPnt7IHByb3BlcnRpZXMubGFiZWwgfX08L3NwYW4+XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICA8bWF0LWljb24gW3Rvb2x0aXBdPVwicHJvcGVydGllcy5pbmZvTXNnIVwiXG4gICAgICBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgPC9tYXQtaWNvbj5cbiAgfVxuPC9kaXY+XG4iXX0=