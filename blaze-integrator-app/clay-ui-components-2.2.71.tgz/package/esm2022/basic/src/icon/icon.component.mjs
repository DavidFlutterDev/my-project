import { MatIconModule } from '@angular/material/icon';
import { Component, Input } from '@angular/core';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClIconProperties } from './icon.properties';
import { ClBaseComponent } from '@clay/ui-components/shared';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/icon";
import * as i2 from "@angular/material/tooltip";
export class ClIconComponent extends ClBaseComponent {
    constructor() {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
    }
    ngOnInit() {
        this.properties ??= new ClIconProperties();
        super.ngOnInit();
    }
    onIconClicked() {
        if (this.properties.onIconClicked != undefined) {
            this.properties.onIconClicked();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: ClIconComponent, isStandalone: true, selector: "cl-icon", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<mat-icon [id]=\"properties.id\" (click)=\"onIconClicked()\" [svgIcon]=\"properties.iconName!\"\n  [matTooltip]=\"properties.tooltip?? ''\" [matTooltipPosition]=\"properties.tooltipPosition ?? 'above'\"\n  class=\"{{ properties.style?.cssClasses }} flex items-center justify-center {{ this.properties.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n</mat-icon>\n", styles: [""], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClIconComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-icon', imports: [
                        MatIconModule,
                        MatTooltipModule
                    ], template: "<mat-icon [id]=\"properties.id\" (click)=\"onIconClicked()\" [svgIcon]=\"properties.iconName!\"\n  [matTooltip]=\"properties.tooltip?? ''\" [matTooltipPosition]=\"properties.tooltipPosition ?? 'above'\"\n  class=\"{{ properties.style?.cssClasses }} flex items-center justify-center {{ this.properties.onIconClicked != undefined ? 'cursor-pointer' : '' }}\">\n</mat-icon>\n" }]
        }], ctorParameters: () => [], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2ljb24vaWNvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2ljb24vaWNvbi5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFFN0QsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDckQsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7O0FBWTdELE1BQU0sT0FBTyxlQUFnQixTQUFRLGVBQWU7SUFJbEQ7UUFDRTs7O1dBR0c7UUFDSCxLQUFLLEVBQUUsQ0FBQztRQUNSLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztJQUN6RyxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO1FBQzNDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRU0sYUFBYTtRQUNsQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDbEMsQ0FBQztJQUNILENBQUM7OEdBdkJVLGVBQWU7a0dBQWYsZUFBZSxnSUNqQjVCLHNYQUlBLHlERFNJLGFBQWEsbUxBQ2IsZ0JBQWdCOzsyRkFHUCxlQUFlO2tCQVYzQixTQUFTO2lDQUNJLElBQUksWUFDTixTQUFTLFdBR1Y7d0JBQ1AsYUFBYTt3QkFDYixnQkFBZ0I7cUJBQ2pCO3dEQUllLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2ljb24nO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBNYXRUb29sdGlwTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdG9vbHRpcCc7XG5cbmltcG9ydCB7IENsSWNvblByb3BlcnRpZXMgfSBmcm9tICcuL2ljb24ucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbEJhc2VDb21wb25lbnQgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWljb24nLFxuICBzdHlsZVVybDogJy4vaWNvbi5jb21wb25lbnQuc2NzcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9pY29uLmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0VG9vbHRpcE1vZHVsZVxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBDbEljb25Db21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsSWNvblByb3BlcnRpZXM7XG5cbiAgY29uc3RydWN0b3IgKCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbEljb25Qcm9wZXJ0aWVzKCk7XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIHB1YmxpYyBvbkljb25DbGlja2VkKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25JY29uQ2xpY2tlZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vbkljb25DbGlja2VkKCk7XG4gICAgfVxuICB9XG59XG4iLCI8bWF0LWljb24gW2lkXT1cInByb3BlcnRpZXMuaWRcIiAoY2xpY2spPVwib25JY29uQ2xpY2tlZCgpXCIgW3N2Z0ljb25dPVwicHJvcGVydGllcy5pY29uTmFtZSFcIlxuICBbbWF0VG9vbHRpcF09XCJwcm9wZXJ0aWVzLnRvb2x0aXA/PyAnJ1wiIFttYXRUb29sdGlwUG9zaXRpb25dPVwicHJvcGVydGllcy50b29sdGlwUG9zaXRpb24gPz8gJ2Fib3ZlJ1wiXG4gIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB7eyB0aGlzLnByb3BlcnRpZXMub25JY29uQ2xpY2tlZCAhPSB1bmRlZmluZWQgPyAnY3Vyc29yLXBvaW50ZXInIDogJycgfX1cIj5cbjwvbWF0LWljb24+XG4iXX0=