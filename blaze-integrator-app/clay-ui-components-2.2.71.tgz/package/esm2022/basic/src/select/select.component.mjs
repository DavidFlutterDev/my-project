import { NgClass } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatChipsModule } from '@angular/material/chips';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { Component, Input, Optional, Self, ViewChild } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { ClIconComponent, ClLabelComponent, ClSelectProperties } from '../../public-api';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/form-field";
import * as i4 from "@angular/material/select";
import * as i5 from "@angular/material/core";
export class ClSelectComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClSelectProperties();
        super.ngOnInit();
    }
    ngDoCheck() {
        // find the option which is having selected as true and check with the value.
        // if both are not same update the value with the selected true option
        const selectedOption = this.properties.options?.find((opt) => opt.selected == true);
        if (selectedOption && selectedOption.value != this._value) {
            this.writeValue(selectedOption.value);
        }
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
        });
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            .subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    writeValue(value) {
        if (value) {
            this.properties.options?.forEach((option) => {
                if (option.value === value) {
                    option.selected = true;
                }
                else {
                    option.selected = false;
                }
            });
            this._value = value;
        }
        else {
            this.properties.options?.forEach((option) => {
                option.selected = false;
            });
            this._value = '';
        }
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    onCustomFieldSelected() {
        // this.matSelect.close();
        if (this.properties.onCustomFieldSelected != undefined) {
            this.properties.onCustomFieldSelected();
        }
    }
    onValueChange(value) {
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    clearSelection() {
        this.onValueChange('');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClSelectComponent, isStandalone: true, selector: "cl-select", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- custom field div -->\n    @if (properties.showCustomField!) {\n      <div (click)=\"onCustomFieldSelected()\"\n        class=\"flex p-1 w-full h-12 min-h-12 items-center cursor-pointer cl-mat-select-option\">\n\n        @if (properties.customFieldIcon!) {\n          <cl-icon class=\"mr-2 icon-size-5\" [properties]=\"properties.customFieldIcon\">\n          </cl-icon>\n        }\n\n        <cl-label [properties]=\"properties.customFieldLabel!\">\n        </cl-label>\n      </div>\n    }\n\n    <!-- custom field div -->\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" class=\"flex items-center justify-between cl-mat-select-option\"\n        [ngClass]=\"{'hidden': option.hidden}\">\n\n        <mat-label class=\"{{option.cssClasses}}\">{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n  }\n\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "component", type: i3.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "directive", type: i3.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i3.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i4.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i5.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClLabelComponent, selector: "cl-label", inputs: ["properties"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClSelectComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-select', imports: [
                        NgClass,
                        ReactiveFormsModule,
                        MatIconModule,
                        MatChipsModule,
                        MatInputModule,
                        MatSelectModule,
                        MatTooltipModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClLabelComponent,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-select [value]=\"value\" [disabled]=\"disabled\" (valueChange)=\"onValueChange($event)\"\n    [hideSingleSelectionIndicator]=\"true\" [placeholder]=\"properties.placeholder!\"\n    (blur)=\"onTouched($any($event.target).value)\">\n\n    <!-- custom field div -->\n    @if (properties.showCustomField!) {\n      <div (click)=\"onCustomFieldSelected()\"\n        class=\"flex p-1 w-full h-12 min-h-12 items-center cursor-pointer cl-mat-select-option\">\n\n        @if (properties.customFieldIcon!) {\n          <cl-icon class=\"mr-2 icon-size-5\" [properties]=\"properties.customFieldIcon\">\n          </cl-icon>\n        }\n\n        <cl-label [properties]=\"properties.customFieldLabel!\">\n        </cl-label>\n      </div>\n    }\n\n    <!-- custom field div -->\n    <!-- options for dropdown -->\n    @for (option of properties.options; track option) {\n      <mat-option [value]=\"option.value\" class=\"flex items-center justify-between cl-mat-select-option\"\n        [ngClass]=\"{'hidden': option.hidden}\">\n\n        <mat-label class=\"{{option.cssClasses}}\">{{ option.text }}</mat-label>\n      </mat-option>\n    }\n    <!-- options for dropdown -->\n  </mat-select>\n\n  @if (properties.optional && value != '') {\n    <mat-icon class=\"cl-select-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n  }\n\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvc2VsZWN0L3NlbGVjdC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3NlbGVjdC9zZWxlY3QuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUMzRCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEYsT0FBTyxFQUFFLFNBQVMsRUFBVyxLQUFLLEVBQVUsUUFBUSxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDN0YsT0FBTyxFQUFtQyxtQkFBbUIsRUFBb0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUN4RyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFtQixrQkFBa0IsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQzFHLE9BQU8sRUFBRSxlQUFlLEVBQWtCLE1BQU0sNEJBQTRCLENBQUM7QUFDN0UsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHNDQUFzQyxDQUFDOzs7Ozs7O0FBc0J2RSxNQUFNLE9BQU8saUJBQWtCLFNBQVEsZUFBZTtJQWdDcEQsWUFBd0MsU0FBb0I7UUFDMUQ7OztXQUdHO1FBQ0gsS0FBSyxFQUFFLENBQUM7UUFMOEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQVQ1RCxhQUFRLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMzQixjQUFTLEdBQUcsQ0FBQyxDQUFNLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQztRQWMxQixLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNyQyx1R0FBdUc7UUFFdkcsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLHdEQUF3RDtZQUN4RCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBRVEsUUFBUTtRQUNmLElBQUksQ0FBQyxVQUFVLEtBQUssSUFBSSxrQkFBa0IsRUFBRSxDQUFDO1FBQzdDLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsU0FBUztRQUNQLDZFQUE2RTtRQUM3RSxzRUFBc0U7UUFDdEUsTUFBTSxjQUFjLEdBQWdDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsQ0FBQztRQUV0SCxJQUFJLGNBQWMsSUFBSSxjQUFjLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUMxRCxJQUFJLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QyxDQUFDO0lBQ0gsQ0FBQztJQUVELGVBQWU7UUFDYixvR0FBb0c7UUFDcEcsNEVBQTRFO1FBQzVFLHlJQUF5STtRQUV6SSxpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRTFELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsU0FBUyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7WUFDNUUsSUFBRyxJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYzthQUN0QyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbkIsSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixpQ0FBaUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRUQscUJBQXFCO1FBQ25CLHdEQUF3RDtRQUN4RCxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZGLElBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLElBQUksR0FBNkIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBNkIsQ0FBQztnQkFDdEcsSUFBSSxDQUFDLEtBQUssR0FBRyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVyxDQUFDLENBQUM7WUFDckUsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDN0UsQ0FBQztZQUVELGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQyxDQUFDO0lBQ0gsQ0FBQztJQUVPLFdBQVc7UUFDakIseUVBQXlFO1FBRXpFLHVFQUF1RTtRQUN2RSwyRUFBMkU7UUFFM0UsMkVBQTJFO1FBQzNFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDekYsQ0FBQztJQUVNLFlBQVksQ0FBQyxLQUFVO1FBQzVCLGdEQUFnRDtRQUVoRCx3RUFBd0U7UUFDeEUsMEVBQTBFO1FBRTFFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDcEYsd0VBQXdFO0lBQzFFLENBQUM7SUFFUSxXQUFXO1FBQ2xCOzs7VUFHRTtRQUVGLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFDeEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUVwQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsdUdBQXVHO0lBQ3pHLENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ1YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7Z0JBQzFDLElBQUksTUFBTSxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUUsQ0FBQztvQkFDM0IsTUFBTSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQ3pCLENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztnQkFDMUIsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7UUFDdEIsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQyxNQUFNLEVBQUUsRUFBRTtnQkFDMUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNuQixDQUFDO0lBQ0gsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFrQjtRQUNsQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsSUFBVyxLQUFLO1FBQ2QsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFBO0lBQ3BCLENBQUM7SUFDTSxxQkFBcUI7UUFDMUIsMEJBQTBCO1FBRTFCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUN2RCxJQUFJLENBQUMsVUFBVSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDMUMsQ0FBQztJQUNILENBQUM7SUFFRCxhQUFhLENBQUMsS0FBVTtRQUN0QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFjLFFBQVE7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVTLGNBQWM7UUFDdEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN6QixDQUFDOzhHQXJOVSxpQkFBaUI7a0dBQWpCLGlCQUFpQix5SkFNakIsWUFBWSx1RUMxQ3pCLGdnRkFtRUEseUhEOUNJLE9BQU8sbUZBQ1AsbUJBQW1CLDhCQUNuQixhQUFhLG1MQUNiLGNBQWMsOEJBQ2QsY0FBYywrZEFDZCxlQUFlLG1yQkFDZixnQkFBZ0IsOEJBQ2hCLGlCQUFpQiw4QkFDakIsa0JBQWtCLCtCQUVsQixlQUFlLDRFQUNmLGdCQUFnQiw2RUFDaEIsa0JBQWtCOzsyRkFHVCxpQkFBaUI7a0JBckI3QixTQUFTO2lDQUNJLElBQUksWUFDTixXQUFXLFdBR1o7d0JBQ1AsT0FBTzt3QkFDUCxtQkFBbUI7d0JBQ25CLGFBQWE7d0JBQ2IsY0FBYzt3QkFDZCxjQUFjO3dCQUNkLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQixpQkFBaUI7d0JBQ2pCLGtCQUFrQjt3QkFFbEIsZUFBZTt3QkFDZixnQkFBZ0I7d0JBQ2hCLGtCQUFrQjtxQkFDbkI7OzBCQWtDYSxRQUFROzswQkFBSSxJQUFJO3lDQTdCZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFLbEIsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBOZ0NsYXNzIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdElucHV0TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaW5wdXQnO1xuaW1wb3J0IHsgTWF0Q2hpcHNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jaGlwcyc7XG5pbXBvcnQgeyBNYXRTZWxlY3RNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9zZWxlY3QnO1xuaW1wb3J0IHsgTWF0VG9vbHRpcE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Rvb2x0aXAnO1xuaW1wb3J0IHsgTWF0Q2hlY2tib3hNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9jaGVja2JveCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgQ29tcG9uZW50LCBEb0NoZWNrLCBJbnB1dCwgT25Jbml0LCBPcHRpb25hbCwgU2VsZiwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb250cm9sVmFsdWVBY2Nlc3NvciwgTmdDb250cm9sLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgQ2xUb29sdGlwRGlyZWN0aXZlIH0gZnJvbSAnQGNsYXkvYXBwLXNoZWxsL3N0cnVjdHVyYWwnO1xuaW1wb3J0IHsgQ2xJY29uQ29tcG9uZW50LCBDbExhYmVsQ29tcG9uZW50LCBDbFNlbGVjdE9wdGlvbnMsIENsU2VsZWN0UHJvcGVydGllcyB9IGZyb20gJy4uLy4uL3B1YmxpYy1hcGknO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50LCBDbEVycm9ySGFuZGxlciB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1zZWxlY3QnLFxuICBzdHlsZVVybDogJy4vc2VsZWN0LmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3NlbGVjdC5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtcbiAgICBOZ0NsYXNzLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRDaGlwc01vZHVsZSxcbiAgICBNYXRJbnB1dE1vZHVsZSxcbiAgICBNYXRTZWxlY3RNb2R1bGUsXG4gICAgTWF0VG9vbHRpcE1vZHVsZSxcbiAgICBNYXRDaGVja2JveE1vZHVsZSxcbiAgICBNYXRGb3JtRmllbGRNb2R1bGUsXG5cbiAgICBDbEljb25Db21wb25lbnQsXG4gICAgQ2xMYWJlbENvbXBvbmVudCxcbiAgICBDbFRvb2x0aXBEaXJlY3RpdmVcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xTZWxlY3RDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIERvQ2hlY2ssIENvbnRyb2xWYWx1ZUFjY2Vzc29yIHtcbiAgLy8gUGxlYXNlIHB1dCBhbGwgdGhlIGFuZ3VsYXIgZGVjb3JhdGVkIHZhcmlhYmxlcyBiZWxvdyB0aGlzXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pXG4gIHB1YmxpYyBvdmVycmlkZSBwcm9wZXJ0aWVzITogQ2xTZWxlY3RQcm9wZXJ0aWVzO1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBAVmlld0NoaWxkKE1hdEZvcm1GaWVsZClcbiAgcHVibGljIG1hdEZvcm1GaWVsZCE6IE1hdEZvcm1GaWVsZDtcblxuICBwcml2YXRlIHZhbHVlQ2hhbmdlc1N1Yj86IFN1YnNjcmlwdGlvbjtcblxuICAvLyBAVmlld0NoaWxkKCdtYXRUZXh0RmllbGQnKVxuICAvLyBwdWJsaWMgbWF0VGV4dEZpZWxkRGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gQFZpZXdDaGlsZCgnZXJyb3JPckhpbnREaXZFbGVtZW50UmVmJylcbiAgLy8gcHVibGljIGVycm9yT3JIaW50RGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gcHJpdmF0ZSBlcnJvck9ySGludERpdkVsZW1lbnQhOiBIVE1MRGl2RWxlbWVudDtcbiAgLy8gcHJpdmF0ZSBtYXRUZXh0RmllbGREaXZFbGVtZW50ITogSFRNTERpdkVsZW1lbnQ7XG5cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcblxuICBvbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgb25Ub3VjaGVkID0gKF86IGFueSkgPT4geyB9O1xuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgcHJpdmF0ZSBzdWI/OiBTdWJzY3JpcHRpb247XG5cbiAgLy8gcHJpdmF0ZSB2YWx1ZUNoYW5nZXNTdWI/OiBTdWJzY3JpcHRpb247XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yIChAT3B0aW9uYWwoKSBAU2VsZigpIHB1YmxpYyBuZ0NvbnRyb2w6IE5nQ29udHJvbCkge1xuICAgIC8qKlxuICAgICAqICEhIFdhcm5pbmcgISFcbiAgICAgKiBUaGUgYmVsb3cgdHdvIHN1cGVyIGNhbGxzIGFyZSBhbHdheXMgdG8gYmUgaW1wbGVtZW50ZWQgZm9yIGFueSBjb21wb25lbnQuIE90aGVyd2lzZSBub3RoaW5nIHdpbGwgd29yay5cbiAgICAgKi9cbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCkge1xuICAgICAgLy8gU2V0dGluZyB0aGUgdmFsdWUgYWNjZXNzb3IgZGlyZWN0bHkgKGluc3RlYWQgb2YgdXNpbmdcbiAgICAgIC8vIHRoZSBwcm92aWRlcnMpIHRvIGF2b2lkIHJ1bm5pbmcgaW50byBhIGNpcmN1bGFyIGltcG9ydC5cbiAgICAgIHRoaXMubmdDb250cm9sLnZhbHVlQWNjZXNzb3IgPSB0aGlzO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsU2VsZWN0UHJvcGVydGllcygpO1xuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuICBuZ0RvQ2hlY2soKSB7XG4gICAgLy8gZmluZCB0aGUgb3B0aW9uIHdoaWNoIGlzIGhhdmluZyBzZWxlY3RlZCBhcyB0cnVlIGFuZCBjaGVjayB3aXRoIHRoZSB2YWx1ZS5cbiAgICAvLyBpZiBib3RoIGFyZSBub3Qgc2FtZSB1cGRhdGUgdGhlIHZhbHVlIHdpdGggdGhlIHNlbGVjdGVkIHRydWUgb3B0aW9uXG4gICAgY29uc3Qgc2VsZWN0ZWRPcHRpb246IENsU2VsZWN0T3B0aW9ucyB8IHVuZGVmaW5lZCA9IHRoaXMucHJvcGVydGllcy5vcHRpb25zPy5maW5kKChvcHQ6IGFueSkgPT4gb3B0LnNlbGVjdGVkID09IHRydWUpO1xuXG4gICAgaWYgKHNlbGVjdGVkT3B0aW9uICYmIHNlbGVjdGVkT3B0aW9uLnZhbHVlICE9IHRoaXMuX3ZhbHVlKSB7XG4gICAgICB0aGlzLndyaXRlVmFsdWUoc2VsZWN0ZWRPcHRpb24udmFsdWUpO1xuICAgIH1cbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAvLyBzZXR0aW5nIHRoZSByZWZlcmVuY2VzIG9mIE5hdGl2ZSBFbGVtZW50cywgd2hpY2ggd2lsbCBiZSB1c2VkIGluIHNldEVycm9yVGV4dCgpIGFuZCBzZXRIaW50VGV4dCgpXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQgPSB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudCA9IHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1hdC1tZGMtdGV4dC1maWVsZC13cmFwcGVyLm1kYy10ZXh0LWZpZWxkJyk7XG5cbiAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG5cbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICB0aGlzLnZhbHVlQ2hhbmdlc1N1YiA9IHRoaXMubmdDb250cm9sPy52YWx1ZUNoYW5nZXM/LnN1YnNjcmliZSgodmFsdWU6IGFueSkgPT4ge1xuICAgICAgaWYodGhpcy5fdmFsdWUgIT0gdmFsdWUpIHtcbiAgICAgICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIHJlbW92ZSBhbGwgdGhlIGVycm9ycyB3aGVuIHRoZSBzdGF0dXMgaXMgdmFsaWRcbiAgICB0aGlzLnN1YiA9IHRoaXMubmdDb250cm9sPy5zdGF0dXNDaGFuZ2VzIVxuICAgICAgLnN1YnNjcmliZShjaGFuZ2VzID0+IHtcbiAgICAgICAgaWYgKGNoYW5nZXMgPT09ICdWQUxJRCcpIHtcbiAgICAgICAgICB0aGlzLmVycm9yID0gbnVsbDtcblxuICAgICAgICAgIC8vIGNhbGxpbmcgc2V0IGhpbnQgdGV4dCBmdW5jdGlvblxuICAgICAgICAgIHRoaXMuc2V0SGludFRleHQoKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7XG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgaWYodGhpcy5wcm9wZXJ0aWVzLmlzUmVhY3RpdmVGb3JtQ29udHJvbCkge1xuICAgICAgICBjb25zdCBrZXlzOiAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW10gPSBPYmplY3Qua2V5cyh0aGlzLm5nQ29udHJvbC5lcnJvcnMpIGFzIChrZXlvZiBDbEVycm9ySGFuZGxlcilbXTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGdldEVycm9yTWVzc2FnZShrZXlzWzBdLCB0aGlzLnByb3BlcnRpZXMuZXJyb3JzTGlzdCEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG4gICAgICB9XG5cbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0SGludFRleHQoKSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gdGhpcy5wcm9wZXJ0aWVzLmhpbnRUZXh0ID8/ICcnO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcblxuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICB9XG5cbiAgcHVibGljIHNldEVycm9yVGV4dChlcnJvcjogYW55KSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gZXJyb3I7XG5cbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtaGludCcpO1xuXG4gICAgdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtZm9ybS1maWVsZC1pbnZhbGlkJyk7XG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21kYy10ZXh0LWZpZWxkLS1pbnZhbGlkJyk7XG4gIH1cblxuICBvdmVycmlkZSBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAvKipcbiAgICAqICEhIFdhcm5pbmcgISFcbiAgICAqIFRoZSBiZWxvdyBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgKi9cblxuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHRoaXMudmFsdWVDaGFuZ2VzU3ViPy51bnN1YnNjcmliZSgpO1xuXG4gICAgc3VwZXIubmdPbkRlc3Ryb3koKTtcbiAgICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIH1cblxuICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vcHRpb25zPy5mb3JFYWNoKChvcHRpb24pID0+IHtcbiAgICAgICAgaWYgKG9wdGlvbi52YWx1ZSA9PT0gdmFsdWUpIHtcbiAgICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnM/LmZvckVhY2goKG9wdGlvbikgPT4ge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSBmYWxzZTtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLl92YWx1ZSA9ICcnO1xuICAgIH1cbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmbjtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgdmFsdWUoKTogYW55IHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWVcbiAgfVxuICBwdWJsaWMgb25DdXN0b21GaWVsZFNlbGVjdGVkKCkge1xuICAgIC8vIHRoaXMubWF0U2VsZWN0LmNsb3NlKCk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uQ3VzdG9tRmllbGRTZWxlY3RlZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vbkN1c3RvbUZpZWxkU2VsZWN0ZWQoKTtcbiAgICB9XG4gIH1cblxuICBvblZhbHVlQ2hhbmdlKHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLndyaXRlVmFsdWUodmFsdWUpO1xuICAgIHRoaXMub25DaGFuZ2UodGhpcy5fdmFsdWUpO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25WYWx1ZUNoYW5nZSh0aGlzLl92YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIGdldCBkaXNhYmxlZCgpOiBib29sZWFuIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCk6IGJvb2xlYW4ge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHByb3RlY3RlZCBjbGVhclNlbGVjdGlvbigpIHtcbiAgICB0aGlzLm9uVmFsdWVDaGFuZ2UoJycpO1xuICB9XG59XG4iLCI8bWF0LWZvcm0tZmllbGQgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiXG4gIFtmbG9hdExhYmVsXT1cInByb3BlcnRpZXMuZmxvYXRMYWJlbCFcIiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIj5cblxuICBAaWYgKHByb3BlcnRpZXMubGFiZWwgIT0gbnVsbCAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9ICcnICYmIHByb3BlcnRpZXMubGFiZWwgIT0gdW5kZWZpbmVkKSB7XG4gICAgPG1hdC1sYWJlbCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICA8c3Bhbj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9zcGFuPlxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwpIHtcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJvcHRpb25hbC10ZXh0XCI+KE9wdGlvbmFsKTwvc3Bhbj5cbiAgICAgIH1cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIlxuICAgICAgICAgIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTppbmZvcm1hdGlvbi1jaXJjbGUnXCIgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgIH1cbiAgICA8L21hdC1sYWJlbD5cbiAgfVxuXG4gIDxtYXQtc2VsZWN0IFt2YWx1ZV09XCJ2YWx1ZVwiIFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiICh2YWx1ZUNoYW5nZSk9XCJvblZhbHVlQ2hhbmdlKCRldmVudClcIlxuICAgIFtoaWRlU2luZ2xlU2VsZWN0aW9uSW5kaWNhdG9yXT1cInRydWVcIiBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIlxuICAgIChibHVyKT1cIm9uVG91Y2hlZCgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKVwiPlxuXG4gICAgPCEtLSBjdXN0b20gZmllbGQgZGl2IC0tPlxuICAgIEBpZiAocHJvcGVydGllcy5zaG93Q3VzdG9tRmllbGQhKSB7XG4gICAgICA8ZGl2IChjbGljayk9XCJvbkN1c3RvbUZpZWxkU2VsZWN0ZWQoKVwiXG4gICAgICAgIGNsYXNzPVwiZmxleCBwLTEgdy1mdWxsIGgtMTIgbWluLWgtMTIgaXRlbXMtY2VudGVyIGN1cnNvci1wb2ludGVyIGNsLW1hdC1zZWxlY3Qtb3B0aW9uXCI+XG5cbiAgICAgICAgQGlmIChwcm9wZXJ0aWVzLmN1c3RvbUZpZWxkSWNvbiEpIHtcbiAgICAgICAgICA8Y2wtaWNvbiBjbGFzcz1cIm1yLTIgaWNvbi1zaXplLTVcIiBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLmN1c3RvbUZpZWxkSWNvblwiPlxuICAgICAgICAgIDwvY2wtaWNvbj5cbiAgICAgICAgfVxuXG4gICAgICAgIDxjbC1sYWJlbCBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLmN1c3RvbUZpZWxkTGFiZWwhXCI+XG4gICAgICAgIDwvY2wtbGFiZWw+XG4gICAgICA8L2Rpdj5cbiAgICB9XG5cbiAgICA8IS0tIGN1c3RvbSBmaWVsZCBkaXYgLS0+XG4gICAgPCEtLSBvcHRpb25zIGZvciBkcm9wZG93biAtLT5cbiAgICBAZm9yIChvcHRpb24gb2YgcHJvcGVydGllcy5vcHRpb25zOyB0cmFjayBvcHRpb24pIHtcbiAgICAgIDxtYXQtb3B0aW9uIFt2YWx1ZV09XCJvcHRpb24udmFsdWVcIiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBjbC1tYXQtc2VsZWN0LW9wdGlvblwiXG4gICAgICAgIFtuZ0NsYXNzXT1cInsnaGlkZGVuJzogb3B0aW9uLmhpZGRlbn1cIj5cblxuICAgICAgICA8bWF0LWxhYmVsIGNsYXNzPVwie3tvcHRpb24uY3NzQ2xhc3Nlc319XCI+e3sgb3B0aW9uLnRleHQgfX08L21hdC1sYWJlbD5cbiAgICAgIDwvbWF0LW9wdGlvbj5cbiAgICB9XG4gICAgPCEtLSBvcHRpb25zIGZvciBkcm9wZG93biAtLT5cbiAgPC9tYXQtc2VsZWN0PlxuXG4gIEBpZiAocHJvcGVydGllcy5vcHRpb25hbCAmJiB2YWx1ZSAhPSAnJykge1xuICAgIDxtYXQtaWNvbiBjbGFzcz1cImNsLXNlbGVjdC1jbGVhci1pY29uXCIgKGNsaWNrKT1cImNsZWFyU2VsZWN0aW9uKClcIj5jbG9zZTwvbWF0LWljb24+XG4gIH1cblxuPC9tYXQtZm9ybS1maWVsZD5cblxuPCEtLSBUaGlzIGRpdiBpcyByZXF1aXJlZCB0byBzaG93IGhpbnQgdGV4dCBvciBlcnJvciBtZXNzYWdlIGZvciB0aGUgY29tcG9uZW50IC0tPlxuPCEtLSA8ZGl2ICNlcnJvck9ySGludERpdkVsZW1lbnRSZWYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPjwvZGl2PiAtLT5cbjxkaXYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPlxuICBAaWYgKGVycm9yKSB7XG4gICAgPG1hdC1lcnJvcj57eyBlcnJvciB9fTwvbWF0LWVycm9yPlxuICB9XG5cbiAgQGlmIChwcm9wZXJ0aWVzLmhpbnRUZXh0KSB7XG4gICAgPG1hdC1oaW50Pnt7IHByb3BlcnRpZXMuaGludFRleHQgfX08L21hdC1oaW50PlxuICB9XG48L2Rpdj5cbiJdfQ==