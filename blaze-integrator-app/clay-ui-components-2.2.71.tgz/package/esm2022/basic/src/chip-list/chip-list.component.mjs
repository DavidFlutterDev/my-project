import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { Self, Input, Optional, Component } from '@angular/core';
import { clAnimations } from '@clay/ui-commons/ancillary';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClChipListProperties } from './chip-list.properties';
import { ClChipListOptionComponent } from './chip-list-option/chip-list-option.component';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/form-field";
export class ClChipListComponent extends ClBaseComponent {
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_value) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClChipListProperties();
        // calling set default value function
        // this.setDefaultValue();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges
            ?.subscribe((changes) => {
            if (changes && changes === 'VALID') {
                this.error = null;
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
        }
    }
    // private setDefaultValue() {
    //   if (this.properties.disabled) {
    //     if(this.properties.showOptionAll && this.properties.optionAllProperties) {
    //       this.properties.optionAllProperties.disabled = true;
    //     }
    //     this.properties.options?.forEach((option: ClChipListOptions) => option.disabled = true);
    //   } else {
    //     if(this.properties.showOptionAll && this.properties.optionAllProperties) {
    //       this.properties.optionAllProperties.disabled = false;
    //     }
    //   }
    // }
    onChipsSelected(index) {
        if (this.properties.options[index].disabled) {
            return;
        }
        this.onTouched(true);
        if (this.properties.multiple) {
            this.toggleMultipleSelection(index);
        }
        else {
            this.toggleSingleSelection(index);
        }
        this.emitSelectedOptions();
    }
    onOptionAllSelected() {
        if (this.properties.optionAllProperties?.disabled) {
            return;
        }
        this.onTouched(true);
        if (this.properties.optionAllProperties) {
            this.properties.optionAllProperties.isSelected = !this.properties.optionAllProperties.isSelected;
            for (let eachChip of this.properties.options) {
                eachChip.isSelected = this.properties.optionAllProperties.isSelected;
            }
            this.emitSelectedOptions();
        }
    }
    toggleMultipleSelection(index) {
        const option = this.properties.options[index];
        option.isSelected = !option.isSelected;
        this.checkIfAllOptionsAreSelectedInOptionsList();
    }
    toggleSingleSelection(index) {
        for (const option of this.properties.options) {
            option.isSelected = false;
        }
        this.properties.options[index].isSelected = true;
    }
    checkIfAllOptionsAreSelectedInOptionsList() {
        let allOptionsSelected = true;
        for (const option of this.properties.options) {
            if (!option.isSelected) {
                allOptionsSelected = false;
            }
        }
        if (this.properties.optionAllProperties) {
            this.properties.optionAllProperties.isSelected = allOptionsSelected;
        }
    }
    emitSelectedOptions() {
        const selectedOptions = this.properties.options.filter((option) => option.isSelected);
        this.onChange(selectedOptions);
        this.writeValue(selectedOptions);
        if (this.properties.optionsSelected) {
            this.properties.optionsSelected(selectedOptions);
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChipListComponent, isStandalone: true, selector: "cl-chip-list", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col\">\n  <div\n    class=\"flex {{ properties.style?.cssClasses }} {{ properties.direction == 'row' ? 'flex-row items-center' : 'flex-col' }}\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n      <div class=\"flex items-center {{ properties.direction === 'row' ? 'w-32' : 'mb-1' }}\">\n        <div class=\"break-all {{ properties.style?.labelCssClasses }}\">{{ properties.label }}</div>\n\n        @if (properties.optional) {\n          <span class=\"optional-text\">(Optional)</span>\n        }\n\n        @if (properties.infoMsg && showInfoMsg) {\n          <mat-icon [tooltip]=\"properties.infoMsg!\"\n            [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n          </mat-icon>\n        }\n      </div>\n    }\n\n    <div class=\"flex gap-2\">\n      @if (properties.showOptionAll && properties.optionAllProperties && properties.multiple) {\n        <cl-chip-list-option [index]=\"0\" [chip]=\"properties.optionAllProperties\" (optionSelected)=\"onOptionAllSelected()\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n\n      @for (chip of properties.options; track chip; let optionIndex = $index;) {\n        <cl-chip-list-option [chip]=\"chip\" [index]=\"optionIndex\" (optionSelected)=\"onChipsSelected(optionIndex)\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n    </div>\n  </div>\n\n  @if (error) {\n    <mat-error class=\"text-warn\">{{ error }}</mat-error>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i3.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "component", type: ClChipListOptionComponent, selector: "cl-chip-list-option", inputs: ["index", "iconCssClasses", "imageCssClasses", "listDisabled", "chip"], outputs: ["optionSelected"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], animations: clAnimations }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipListComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chip-list', animations: clAnimations, imports: [
                        MatIconModule,
                        MatChipsModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ClChipListOptionComponent,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"flex gap-2 w-full flex-col\">\n  <div\n    class=\"flex {{ properties.style?.cssClasses }} {{ properties.direction == 'row' ? 'flex-row items-center' : 'flex-col' }}\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n      <div class=\"flex items-center {{ properties.direction === 'row' ? 'w-32' : 'mb-1' }}\">\n        <div class=\"break-all {{ properties.style?.labelCssClasses }}\">{{ properties.label }}</div>\n\n        @if (properties.optional) {\n          <span class=\"optional-text\">(Optional)</span>\n        }\n\n        @if (properties.infoMsg && showInfoMsg) {\n          <mat-icon [tooltip]=\"properties.infoMsg!\"\n            [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n          </mat-icon>\n        }\n      </div>\n    }\n\n    <div class=\"flex gap-2\">\n      @if (properties.showOptionAll && properties.optionAllProperties && properties.multiple) {\n        <cl-chip-list-option [index]=\"0\" [chip]=\"properties.optionAllProperties\" (optionSelected)=\"onOptionAllSelected()\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n\n      @for (chip of properties.options; track chip; let optionIndex = $index;) {\n        <cl-chip-list-option [chip]=\"chip\" [index]=\"optionIndex\" (optionSelected)=\"onChipsSelected(optionIndex)\"\n          [iconCssClasses]=\"properties.style?.iconCssClasses\" [imageCssClasses]=\"properties.style?.imageCssClasses\"\n          [listDisabled]=\"properties.disabled\">\n        </cl-chip-list-option>\n      }\n    </div>\n  </div>\n\n  @if (error) {\n    <mat-error class=\"text-warn\">{{ error }}</mat-error>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hpcC1saXN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvY2hpcC1saXN0L2NoaXAtbGlzdC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NoaXAtbGlzdC9jaGlwLWxpc3QuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUEsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUVsRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBVSxRQUFRLEVBQXdCLFNBQVMsRUFBcUQsTUFBTSxlQUFlLENBQUM7QUFFbEosT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQzFELE9BQU8sRUFBRSxlQUFlLEVBQWtCLE1BQU0sNEJBQTRCLENBQUM7QUFDN0UsT0FBTyxFQUFxQixvQkFBb0IsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ2pGLE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxNQUFNLCtDQUErQyxDQUFDO0FBQzFGLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQzs7Ozs7QUFnQnZFLE1BQU0sT0FBTyxtQkFBb0IsU0FBUSxlQUFlO0lBV3RELFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFINUQsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsTUFBVyxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFRL0IsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO1FBRXZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksb0JBQW9CLEVBQUUsQ0FBQztRQUUvQyxxQ0FBcUM7UUFDckMsMEJBQTBCO1FBRTFCLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRUQsZUFBZTtRQUNiLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRTFELGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYTtZQUN0QyxFQUFFLFNBQVMsQ0FBQyxDQUFDLE9BQVksRUFBRSxFQUFFO1lBQzNCLElBQUksT0FBTyxJQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7WUFDcEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVELHFCQUFxQjtRQUNuQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2RixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEdBQTZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQTZCLENBQUM7Z0JBQ3RHLElBQUksQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzdFLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVELDhCQUE4QjtJQUM5QixvQ0FBb0M7SUFDcEMsaUZBQWlGO0lBQ2pGLDZEQUE2RDtJQUM3RCxRQUFRO0lBQ1IsK0ZBQStGO0lBQy9GLGFBQWE7SUFDYixpRkFBaUY7SUFDakYsOERBQThEO0lBQzlELFFBQVE7SUFDUixNQUFNO0lBQ04sSUFBSTtJQUVNLGVBQWUsQ0FBQyxLQUFhO1FBRXJDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDN0MsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEMsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEMsQ0FBQztRQUVELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFUyxtQkFBbUI7UUFDM0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLFFBQVEsRUFBRSxDQUFDO1lBQ2xELE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNyQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsbUJBQW1CLENBQUMsVUFBVSxDQUFDO1lBRWpHLEtBQUssSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFRLEVBQUUsQ0FBQztnQkFDOUMsUUFBUSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FBQztZQUN2RSxDQUFDO1lBRUQsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDN0IsQ0FBQztJQUNILENBQUM7SUFFTyx1QkFBdUIsQ0FBQyxLQUFhO1FBQzNDLE1BQU0sTUFBTSxHQUFzQixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsRSxNQUFNLENBQUMsVUFBVSxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztRQUV2QyxJQUFJLENBQUMseUNBQXlDLEVBQUUsQ0FBQztJQUNuRCxDQUFDO0lBRU8scUJBQXFCLENBQUMsS0FBYTtRQUN6QyxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxFQUFFLENBQUM7WUFDOUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUM7UUFDNUIsQ0FBQztRQUVELElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7SUFDcEQsQ0FBQztJQUVPLHlDQUF5QztRQUMvQyxJQUFJLGtCQUFrQixHQUFZLElBQUksQ0FBQztRQUV2QyxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxFQUFFLENBQUM7WUFDOUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdkIsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1lBQzdCLENBQUM7UUFDSCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLEdBQUcsa0JBQWtCLENBQUM7UUFDdEUsQ0FBQztJQUNILENBQUM7SUFFTyxtQkFBbUI7UUFDekIsTUFBTSxlQUFlLEdBQXdCLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQXlCLEVBQUUsRUFBRSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUvSCxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRS9CLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUM7UUFFakMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ25ELENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVELFVBQVUsQ0FBQyxLQUFVO1FBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBQyxFQUFPO1FBQ3RCLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFPO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFUSxXQUFXO1FBQ2xCOzs7VUFHRTtRQUVGLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFDeEIsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BCLHVHQUF1RztJQUN6RyxDQUFDOzhHQXBMVSxtQkFBbUI7a0dBQW5CLG1CQUFtQixxSUM5QmhDLG8zREF5Q0EsMkNEbkJJLGFBQWEsbUxBQ2IsY0FBYyw4QkFDZCxnQkFBZ0IsOEJBQ2hCLGtCQUFrQiw0SEFDbEIseUJBQXlCLDZLQUN6QixrQkFBa0IseUdBUlIsWUFBWTs7MkZBV2IsbUJBQW1CO2tCQWQvQixTQUFTO2lDQUNJLElBQUksWUFDTixjQUFjLGNBQ1osWUFBWSxXQUVmO3dCQUNQLGFBQWE7d0JBQ2IsY0FBYzt3QkFDZCxnQkFBZ0I7d0JBQ2hCLGtCQUFrQjt3QkFDbEIseUJBQXlCO3dCQUN6QixrQkFBa0I7cUJBQ25COzswQkFhYSxRQUFROzswQkFBSSxJQUFJO3lDQVRkLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBOZ1RlbXBsYXRlT3V0bGV0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdENoaXBzTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvY2hpcHMnO1xuaW1wb3J0IHsgTWF0VG9vbHRpcE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Rvb2x0aXAnO1xuaW1wb3J0IHsgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZm9ybS1maWVsZCc7XG5pbXBvcnQgeyBOZ0NvbnRyb2wsIFZhbGlkYXRpb25FcnJvcnMsIENvbnRyb2xWYWx1ZUFjY2Vzc29yIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgU2VsZiwgSW5wdXQsIE9uSW5pdCwgT3B0aW9uYWwsIE9uQ2hhbmdlcywgT25EZXN0cm95LCBDb21wb25lbnQsIEFmdGVyVmlld0luaXQsIFNpbXBsZUNoYW5nZXMsIEFmdGVyQ29udGVudENoZWNrZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgY2xBbmltYXRpb25zIH0gZnJvbSAnQGNsYXkvdWktY29tbW9ucy9hbmNpbGxhcnknO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50LCBDbEVycm9ySGFuZGxlciB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsQ2hpcExpc3RPcHRpb25zLCBDbENoaXBMaXN0UHJvcGVydGllcyB9IGZyb20gJy4vY2hpcC1saXN0LnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xDaGlwTGlzdE9wdGlvbkNvbXBvbmVudCB9IGZyb20gJy4vY2hpcC1saXN0LW9wdGlvbi9jaGlwLWxpc3Qtb3B0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBnZXRFcnJvck1lc3NhZ2UgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL2Zvcm0tdmFsaWRhdGlvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC1jaGlwLWxpc3QnLFxuICBhbmltYXRpb25zOiBjbEFuaW1hdGlvbnMsXG4gIHRlbXBsYXRlVXJsOiAnLi9jaGlwLWxpc3QuY29tcG9uZW50Lmh0bWwnLFxuICBpbXBvcnRzOiBbXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRDaGlwc01vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBDbENoaXBMaXN0T3B0aW9uQ29tcG9uZW50LFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdXG59KVxuZXhwb3J0IGNsYXNzIENsQ2hpcExpc3RDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciwgT25Jbml0LCBPbkRlc3Ryb3ksIEFmdGVyVmlld0luaXQsIEFmdGVyQ29udGVudENoZWNrZWQge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsQ2hpcExpc3RQcm9wZXJ0aWVzO1xuXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgcHJpdmF0ZSBzdWI/OiBTdWJzY3JpcHRpb247XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuXG4gIG9uQ2hhbmdlID0gKF86IGFueSkgPT4geyB9O1xuICBvblRvdWNoZWQgPSAoX3ZhbHVlOiBhbnkpID0+IHsgfTtcblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbENoaXBMaXN0UHJvcGVydGllcygpO1xuXG4gICAgLy8gY2FsbGluZyBzZXQgZGVmYXVsdCB2YWx1ZSBmdW5jdGlvblxuICAgIC8vIHRoaXMuc2V0RGVmYXVsdFZhbHVlKCk7XG5cbiAgICBzdXBlci5uZ09uSW5pdCgpO1xuICB9XG5cbiAgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIHN1cGVyLnN1YnNjcmliZVRvVmFsdWVDaGFuZ2VzKHRoaXMud3JpdGVWYWx1ZS5iaW5kKHRoaXMpKTtcblxuICAgIC8vIHJlbW92ZSBhbGwgdGhlIGVycm9ycyB3aGVuIHRoZSBzdGF0dXMgaXMgdmFsaWRcbiAgICB0aGlzLnN1YiA9IHRoaXMubmdDb250cm9sPy5zdGF0dXNDaGFuZ2VzXG4gICAgICA/LnN1YnNjcmliZSgoY2hhbmdlczogYW55KSA9PiB7XG4gICAgICAgIGlmIChjaGFuZ2VzICYmIGNoYW5nZXMgPT09ICdWQUxJRCcpIHtcbiAgICAgICAgICB0aGlzLmVycm9yID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZCB7XG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgaWYodGhpcy5wcm9wZXJ0aWVzLmlzUmVhY3RpdmVGb3JtQ29udHJvbCkge1xuICAgICAgICBjb25zdCBrZXlzOiAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW10gPSBPYmplY3Qua2V5cyh0aGlzLm5nQ29udHJvbC5lcnJvcnMpIGFzIChrZXlvZiBDbEVycm9ySGFuZGxlcilbXTtcbiAgICAgICAgdGhpcy5lcnJvciA9IGdldEVycm9yTWVzc2FnZShrZXlzWzBdLCB0aGlzLnByb3BlcnRpZXMuZXJyb3JzTGlzdCEpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gcHJpdmF0ZSBzZXREZWZhdWx0VmFsdWUoKSB7XG4gIC8vICAgaWYgKHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCkge1xuICAvLyAgICAgaWYodGhpcy5wcm9wZXJ0aWVzLnNob3dPcHRpb25BbGwgJiYgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXMpIHtcbiAgLy8gICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXMuZGlzYWJsZWQgPSB0cnVlO1xuICAvLyAgICAgfVxuICAvLyAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbnM/LmZvckVhY2goKG9wdGlvbjogQ2xDaGlwTGlzdE9wdGlvbnMpID0+IG9wdGlvbi5kaXNhYmxlZCA9IHRydWUpO1xuICAvLyAgIH0gZWxzZSB7XG4gIC8vICAgICBpZih0aGlzLnByb3BlcnRpZXMuc2hvd09wdGlvbkFsbCAmJiB0aGlzLnByb3BlcnRpZXMub3B0aW9uQWxsUHJvcGVydGllcykge1xuICAvLyAgICAgICB0aGlzLnByb3BlcnRpZXMub3B0aW9uQWxsUHJvcGVydGllcy5kaXNhYmxlZCA9IGZhbHNlO1xuICAvLyAgICAgfVxuICAvLyAgIH1cbiAgLy8gfVxuXG4gIHByb3RlY3RlZCBvbkNoaXBzU2VsZWN0ZWQoaW5kZXg6IG51bWJlcikge1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vcHRpb25zIVtpbmRleF0uZGlzYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aGlzLm9uVG91Y2hlZCh0cnVlKTtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm11bHRpcGxlKSB7XG4gICAgICB0aGlzLnRvZ2dsZU11bHRpcGxlU2VsZWN0aW9uKGluZGV4KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy50b2dnbGVTaW5nbGVTZWxlY3Rpb24oaW5kZXgpO1xuICAgIH1cblxuICAgIHRoaXMuZW1pdFNlbGVjdGVkT3B0aW9ucygpO1xuICB9XG5cbiAgcHJvdGVjdGVkIG9uT3B0aW9uQWxsU2VsZWN0ZWQoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vcHRpb25BbGxQcm9wZXJ0aWVzPy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIHRoaXMub25Ub3VjaGVkKHRydWUpO1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub3B0aW9uQWxsUHJvcGVydGllcykge1xuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXMuaXNTZWxlY3RlZCA9ICF0aGlzLnByb3BlcnRpZXMub3B0aW9uQWxsUHJvcGVydGllcy5pc1NlbGVjdGVkO1xuXG4gICAgICBmb3IgKGxldCBlYWNoQ2hpcCBvZiB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyEpIHtcbiAgICAgICAgZWFjaENoaXAuaXNTZWxlY3RlZCA9IHRoaXMucHJvcGVydGllcy5vcHRpb25BbGxQcm9wZXJ0aWVzLmlzU2VsZWN0ZWQ7XG4gICAgICB9XG5cbiAgICAgIHRoaXMuZW1pdFNlbGVjdGVkT3B0aW9ucygpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgdG9nZ2xlTXVsdGlwbGVTZWxlY3Rpb24oaW5kZXg6IG51bWJlcikge1xuICAgIGNvbnN0IG9wdGlvbjogQ2xDaGlwTGlzdE9wdGlvbnMgPSB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyFbaW5kZXhdO1xuICAgIG9wdGlvbi5pc1NlbGVjdGVkID0gIW9wdGlvbi5pc1NlbGVjdGVkO1xuXG4gICAgdGhpcy5jaGVja0lmQWxsT3B0aW9uc0FyZVNlbGVjdGVkSW5PcHRpb25zTGlzdCgpO1xuICB9XG5cbiAgcHJpdmF0ZSB0b2dnbGVTaW5nbGVTZWxlY3Rpb24oaW5kZXg6IG51bWJlcikge1xuICAgIGZvciAoY29uc3Qgb3B0aW9uIG9mIHRoaXMucHJvcGVydGllcy5vcHRpb25zISkge1xuICAgICAgb3B0aW9uLmlzU2VsZWN0ZWQgPSBmYWxzZTtcbiAgICB9XG5cbiAgICB0aGlzLnByb3BlcnRpZXMub3B0aW9ucyFbaW5kZXhdLmlzU2VsZWN0ZWQgPSB0cnVlO1xuICB9XG5cbiAgcHJpdmF0ZSBjaGVja0lmQWxsT3B0aW9uc0FyZVNlbGVjdGVkSW5PcHRpb25zTGlzdCgpIHtcbiAgICBsZXQgYWxsT3B0aW9uc1NlbGVjdGVkOiBib29sZWFuID0gdHJ1ZTtcblxuICAgIGZvciAoY29uc3Qgb3B0aW9uIG9mIHRoaXMucHJvcGVydGllcy5vcHRpb25zISkge1xuICAgICAgaWYgKCFvcHRpb24uaXNTZWxlY3RlZCkge1xuICAgICAgICBhbGxPcHRpb25zU2VsZWN0ZWQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXMpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vcHRpb25BbGxQcm9wZXJ0aWVzLmlzU2VsZWN0ZWQgPSBhbGxPcHRpb25zU2VsZWN0ZWQ7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBlbWl0U2VsZWN0ZWRPcHRpb25zKCkge1xuICAgIGNvbnN0IHNlbGVjdGVkT3B0aW9uczogQ2xDaGlwTGlzdE9wdGlvbnNbXSA9IHRoaXMucHJvcGVydGllcy5vcHRpb25zIS5maWx0ZXIoKG9wdGlvbjogQ2xDaGlwTGlzdE9wdGlvbnMpID0+IG9wdGlvbi5pc1NlbGVjdGVkKTtcblxuICAgIHRoaXMub25DaGFuZ2Uoc2VsZWN0ZWRPcHRpb25zKTtcblxuICAgIHRoaXMud3JpdGVWYWx1ZShzZWxlY3RlZE9wdGlvbnMpO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vcHRpb25zU2VsZWN0ZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vcHRpb25zU2VsZWN0ZWQoc2VsZWN0ZWRPcHRpb25zKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQge1xuICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gIH1cblxuICByZWdpc3Rlck9uQ2hhbmdlKGZuOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cblxuICByZWdpc3Rlck9uVG91Y2hlZChmbjogYW55KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmblxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgLyoqXG4gICAgKiAhISBXYXJuaW5nICEhXG4gICAgKiBUaGUgYmVsb3cgc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICovXG5cbiAgICB0aGlzLnN1Yj8udW5zdWJzY3JpYmUoKTtcbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgfVxufVxuIiwiPGRpdiBbaWRdPVwicHJvcGVydGllcy5pZFwiIGNsYXNzPVwiZmxleCBnYXAtMiB3LWZ1bGwgZmxleC1jb2xcIj5cbiAgPGRpdlxuICAgIGNsYXNzPVwiZmxleCB7eyBwcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzIH19IHt7IHByb3BlcnRpZXMuZGlyZWN0aW9uID09ICdyb3cnID8gJ2ZsZXgtcm93IGl0ZW1zLWNlbnRlcicgOiAnZmxleC1jb2wnIH19XCI+XG5cbiAgICBAaWYgKHByb3BlcnRpZXMubGFiZWwgIT0gbnVsbCAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9ICcnICYmIHByb3BlcnRpZXMubGFiZWwgIT0gdW5kZWZpbmVkKSB7XG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIge3sgcHJvcGVydGllcy5kaXJlY3Rpb24gPT09ICdyb3cnID8gJ3ctMzInIDogJ21iLTEnIH19XCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJicmVhay1hbGwge3sgcHJvcGVydGllcy5zdHlsZT8ubGFiZWxDc3NDbGFzc2VzIH19XCI+e3sgcHJvcGVydGllcy5sYWJlbCB9fTwvZGl2PlxuXG4gICAgICAgIEBpZiAocHJvcGVydGllcy5vcHRpb25hbCkge1xuICAgICAgICAgIDxzcGFuIGNsYXNzPVwib3B0aW9uYWwtdGV4dFwiPihPcHRpb25hbCk8L3NwYW4+XG4gICAgICAgIH1cblxuICAgICAgICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgICAgICAgIDxtYXQtaWNvbiBbdG9vbHRpcF09XCJwcm9wZXJ0aWVzLmluZm9Nc2chXCJcbiAgICAgICAgICAgIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTppbmZvcm1hdGlvbi1jaXJjbGUnXCIgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICAgICAgICA8L21hdC1pY29uPlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICB9XG5cbiAgICA8ZGl2IGNsYXNzPVwiZmxleCBnYXAtMlwiPlxuICAgICAgQGlmIChwcm9wZXJ0aWVzLnNob3dPcHRpb25BbGwgJiYgcHJvcGVydGllcy5vcHRpb25BbGxQcm9wZXJ0aWVzICYmIHByb3BlcnRpZXMubXVsdGlwbGUpIHtcbiAgICAgICAgPGNsLWNoaXAtbGlzdC1vcHRpb24gW2luZGV4XT1cIjBcIiBbY2hpcF09XCJwcm9wZXJ0aWVzLm9wdGlvbkFsbFByb3BlcnRpZXNcIiAob3B0aW9uU2VsZWN0ZWQpPVwib25PcHRpb25BbGxTZWxlY3RlZCgpXCJcbiAgICAgICAgICBbaWNvbkNzc0NsYXNzZXNdPVwicHJvcGVydGllcy5zdHlsZT8uaWNvbkNzc0NsYXNzZXNcIiBbaW1hZ2VDc3NDbGFzc2VzXT1cInByb3BlcnRpZXMuc3R5bGU/LmltYWdlQ3NzQ2xhc3Nlc1wiXG4gICAgICAgICAgW2xpc3REaXNhYmxlZF09XCJwcm9wZXJ0aWVzLmRpc2FibGVkXCI+XG4gICAgICAgIDwvY2wtY2hpcC1saXN0LW9wdGlvbj5cbiAgICAgIH1cblxuICAgICAgQGZvciAoY2hpcCBvZiBwcm9wZXJ0aWVzLm9wdGlvbnM7IHRyYWNrIGNoaXA7IGxldCBvcHRpb25JbmRleCA9ICRpbmRleDspIHtcbiAgICAgICAgPGNsLWNoaXAtbGlzdC1vcHRpb24gW2NoaXBdPVwiY2hpcFwiIFtpbmRleF09XCJvcHRpb25JbmRleFwiIChvcHRpb25TZWxlY3RlZCk9XCJvbkNoaXBzU2VsZWN0ZWQob3B0aW9uSW5kZXgpXCJcbiAgICAgICAgICBbaWNvbkNzc0NsYXNzZXNdPVwicHJvcGVydGllcy5zdHlsZT8uaWNvbkNzc0NsYXNzZXNcIiBbaW1hZ2VDc3NDbGFzc2VzXT1cInByb3BlcnRpZXMuc3R5bGU/LmltYWdlQ3NzQ2xhc3Nlc1wiXG4gICAgICAgICAgW2xpc3REaXNhYmxlZF09XCJwcm9wZXJ0aWVzLmRpc2FibGVkXCI+XG4gICAgICAgIDwvY2wtY2hpcC1saXN0LW9wdGlvbj5cbiAgICAgIH1cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG5cbiAgQGlmIChlcnJvcikge1xuICAgIDxtYXQtZXJyb3IgY2xhc3M9XCJ0ZXh0LXdhcm5cIj57eyBlcnJvciB9fTwvbWF0LWVycm9yPlxuICB9XG48L2Rpdj5cbiJdfQ==