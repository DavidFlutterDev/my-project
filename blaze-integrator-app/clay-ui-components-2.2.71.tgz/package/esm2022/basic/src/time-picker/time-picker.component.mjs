import { Component, Input, Optional, Self, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialogModule } from '@angular/material/dialog';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClTimePickerContentComponent } from './time-picker-content/time-picker-content.component';
import { ClTimePickerProperties } from './time-picker.properties';
import { OverlayModule } from '@angular/cdk/overlay';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/dialog";
import * as i3 from "@angular/material/card";
import * as i4 from "@angular/material/icon";
import * as i5 from "@angular/material/input";
import * as i6 from "@angular/material/form-field";
import * as i7 from "@angular/cdk/overlay";
export class ClTimePickerComponent extends ClBaseComponent {
    //------------------------------------------
    constructor(ngControl, dialog) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.dialog = dialog;
        this.showTime = false;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnInit() {
        this.properties ??= new ClTimePickerProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
        const self = this;
        // Prevent scrolling when the dropdown is open
        window.addEventListener('scroll', function (event) {
            if (self.showTime) {
                event.preventDefault(); // Prevent default scrolling behavior
                event.stopPropagation(); // Prevent bubbling to parent elements
            }
        }, { passive: false }); // { passive: false } ensures preventDefault works
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    // this function is triggered on the opening the time picker
    openTimePicker() {
        if (this.properties.showAsDialog) {
            //show as a dialog
            this.dialog.open(this.timepickerDialog);
        }
        else {
            const scrollableDiv = document.getElementById('scrollableDiv');
            if (scrollableDiv) {
                scrollableDiv.scrollTo({
                    left: 0, // Scroll to the very left
                    behavior: 'smooth' // Smooth scrolling animation
                });
                // Delay opening the timepicker slightly to ensure scrolling completes
                setTimeout(() => {
                    this.showTime = true;
                }, 300); // Adjust timeout based on expected scroll duration
            }
            else {
                // If no scrolling is needed, directly open the timepicker
                this.showTime = true;
            }
        }
    }
    onCancel(ev) {
        if (this.properties.showAsDialog) {
            this.dialog.closeAll();
        }
        else {
            this.showTime = false;
        }
    }
    onTimeSelection(ev) {
        this.writeValue(ev);
        if (this.properties.onTimeSelected !== undefined) {
            this.properties.onTimeSelected(ev);
        }
        if (this.properties.showAsDialog) {
            this.dialog.closeAll();
        }
        else {
            this.showTime = false;
        }
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerComponent, deps: [{ token: i1.NgControl, optional: true, self: true }, { token: i2.MatDialog }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTimePickerComponent, isStandalone: true, selector: "cl-time-picker", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "timepickerDialog", first: true, predicate: ["timepickerDialog"], descendants: true, static: true }, { propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\" class=\"cl-time-picker\">\n\n  <mat-form-field subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"w-full {{ properties.style?.cssClasses }}\" cdkOverlayOrigin #customTimePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\"\n      [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\"\n      (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\"/>\n\n    @if (!properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"'fss_icons:clock'\">\n    </mat-icon>\n    }\n\n    @if (properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"properties.icon!\">\n    </mat-icon>\n    }\n  </mat-form-field>\n  <!-- This div is required to show hint text or error message for the component -->\n  <!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"customTimePicker\" [cdkConnectedOverlayOpen]=\"showTime\">\n  <mat-card>\n    <div class=\"cl-timepicker-content-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n\n\n<ng-template #timepickerDialog>\n  <mat-card>\n    <div class=\"cl-timepicker-dialog-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-time-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-time-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.cl-timepicker-content-container{width:300px}::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0!important}.cl-timepicker-dialog-container{width:420px}.cl-timepicker-dialog-container .hours-container{height:46px;width:46%}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i3.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i4.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i6.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i6.MatLabel, selector: "mat-label" }, { kind: "directive", type: i6.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i6.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i6.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: ClTimePickerContentComponent, selector: "cl-time-picker-content", inputs: ["value"], outputs: ["onApply", "onCancelClick"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i7.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i7.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTimePickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-time-picker', imports: [
                        FormsModule,
                        MatCardModule,
                        MatIconModule,
                        MatInputModule,
                        MatDialogModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTimePickerContentComponent,
                        OverlayModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\" class=\"cl-time-picker\">\n\n  <mat-form-field subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"w-full {{ properties.style?.cssClasses }}\" cdkOverlayOrigin #customTimePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\"\n      [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\"\n      (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\"/>\n\n    @if (!properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"'fss_icons:clock'\">\n    </mat-icon>\n    }\n\n    @if (properties.icon) {\n    <mat-icon matSuffix (click)=\"openTimePicker()\" class=\"cursor-pointer\" [svgIcon]=\"properties.icon!\">\n    </mat-icon>\n    }\n  </mat-form-field>\n  <!-- This div is required to show hint text or error message for the component -->\n  <!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay [cdkConnectedOverlayOrigin]=\"customTimePicker\" [cdkConnectedOverlayOpen]=\"showTime\">\n  <mat-card>\n    <div class=\"cl-timepicker-content-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n\n\n<ng-template #timepickerDialog>\n  <mat-card>\n    <div class=\"cl-timepicker-dialog-container\">\n      <cl-time-picker-content [value]=\"value\" (onApply)=\"onTimeSelection($event)\" (onCancelClick)=\"onCancel($event)\">\n      </cl-time-picker-content>\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-time-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-time-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.cl-timepicker-content-container{width:300px}::ng-deep .mat-mdc-dialog-container .mdc-dialog__surface{padding:0!important}.cl-timepicker-dialog-container{width:420px}.cl-timepicker-dialog-container .hours-container{height:46px;width:46%}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i2.MatDialog }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], timepickerDialog: [{
                type: ViewChild,
                args: ['timepickerDialog', { static: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZS1waWNrZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy90aW1lLXBpY2tlci90aW1lLXBpY2tlci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RpbWUtcGlja2VyL3RpbWUtcGlja2VyLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFVLFFBQVEsRUFBRSxJQUFJLEVBQWUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2pHLE9BQU8sRUFBd0IsV0FBVyxFQUFhLG1CQUFtQixFQUFvQixNQUFNLGdCQUFnQixDQUFDO0FBQ3JILE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsWUFBWSxFQUFFLGtCQUFrQixFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDaEYsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBQ3ZELE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSx5QkFBeUIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUU3RCxPQUFPLEVBQWEsZUFBZSxFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGVBQWUsRUFBa0IsTUFBTSw0QkFBNEIsQ0FBQztBQUM3RSxPQUFPLEVBQUUsNEJBQTRCLEVBQUUsTUFBTSxxREFBcUQsQ0FBQztBQUNuRyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDckQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDaEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLHNDQUFzQyxDQUFDOzs7Ozs7Ozs7QUE0QnZFLE1BQU0sT0FBTyxxQkFBc0IsU0FBUSxlQUFlO0lBa0J4RCw0Q0FBNEM7SUFFNUMsWUFBd0MsU0FBb0IsRUFBbUIsTUFBaUI7UUFDOUY7OztXQUdHO1FBQ0gsS0FBSyxFQUFFLENBQUM7UUFMOEIsY0FBUyxHQUFULFNBQVMsQ0FBVztRQUFtQixXQUFNLEdBQU4sTUFBTSxDQUFXO1FBaEJ6RixhQUFRLEdBQVksS0FBSyxDQUFDO1FBU2pDLGFBQVEsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLGNBQVMsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBWTFCLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztRQUV2RyxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxFQUFFLENBQUM7WUFDM0Isd0RBQXdEO1lBQ3hELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDdEMsQ0FBQztJQUNILENBQUM7SUFFRCxVQUFVLENBQUMsS0FBVTtRQUNuQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBRUQsZ0JBQWdCLENBQUMsRUFBa0I7UUFDakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVELGlCQUFpQixDQUFDLEVBQWtCO1FBQ2xDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDcEIsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksc0JBQXNCLEVBQUUsQ0FBQztRQUVqRCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELGVBQWU7UUFDYixvR0FBb0c7UUFDcEcsNEVBQTRFO1FBQzVFLHlJQUF5STtRQUV6SSxpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRTFELGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQWUsRUFBRSxFQUFFO1lBQ3RFLElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFbEIsaUNBQWlDO2dCQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBR0gsTUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2xCLDhDQUE4QztRQUM5QyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLFVBQVUsS0FBSztZQUMvQyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDbEIsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDLENBQUUscUNBQXFDO2dCQUM5RCxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxzQ0FBc0M7WUFDakUsQ0FBQztRQUNILENBQUMsRUFBRSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUMsa0RBQWtEO0lBQzVFLENBQUM7SUFFRCxxQkFBcUI7UUFDbkIsd0RBQXdEO1FBQ3hELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtRQUVwQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2RixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEdBQTZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQTZCLENBQUM7Z0JBQ3RHLElBQUksQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzdFLENBQUM7WUFFRCxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsQ0FBQztJQUNILENBQUM7SUFFTSxXQUFXO1FBQ2hCLHlFQUF5RTtRQUV6RSx1RUFBdUU7UUFDdkUsMkVBQTJFO1FBRTNFLDJFQUEyRTtRQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFFTSxZQUFZLENBQUMsS0FBVTtRQUM1QixnREFBZ0Q7UUFFaEQsd0VBQXdFO1FBQ3hFLDBFQUEwRTtRQUUxRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3BGLHdFQUF3RTtJQUMxRSxDQUFDO0lBRU8sYUFBYTtRQUNuQixJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDOUIsSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUE7UUFDbEIsQ0FBQztJQUNILENBQUM7SUFDRCw0REFBNEQ7SUFDckQsY0FBYztRQUNuQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDakMsa0JBQWtCO1lBQ2xCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQzFDLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUUvRCxJQUFJLGFBQWEsRUFBRSxDQUFDO2dCQUNsQixhQUFhLENBQUMsUUFBUSxDQUFDO29CQUNyQixJQUFJLEVBQUUsQ0FBQyxFQUFLLDBCQUEwQjtvQkFDdEMsUUFBUSxFQUFFLFFBQVEsQ0FBRSw2QkFBNkI7aUJBQ2xELENBQUMsQ0FBQztnQkFFSCxzRUFBc0U7Z0JBQ3RFLFVBQVUsQ0FBQyxHQUFHLEVBQUU7b0JBQ2QsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZCLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFFLG1EQUFtRDtZQUMvRCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sMERBQTBEO2dCQUMxRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztZQUN2QixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTSxRQUFRLENBQUMsRUFBTztRQUNyQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN6QixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLENBQUM7SUFDSCxDQUFDO0lBRU0sZUFBZSxDQUFDLEVBQU87UUFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQ2pELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JDLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN6QixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBRUYsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUN4QixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsdUdBQXVHO0lBQ3pHLENBQUM7OEdBdk1VLHFCQUFxQjtrR0FBckIscUJBQXFCLG1SQVNyQixZQUFZLHVFQ25EekIsbXBGQXFFQSw4akJEekNJLFdBQVcsOEJBQ1gsYUFBYSw0SUFDYixhQUFhLG1MQUNiLGNBQWMsNDZCQUNkLGVBQWUsOEJBQ2YsZ0JBQWdCLDhCQUNoQixrQkFBa0IsOEJBQ2xCLG1CQUFtQiwrQkFDbkIsNEJBQTRCLDRIQUM1QixhQUFhLDJyQ0FDYixrQkFBa0I7OzJGQUlULHFCQUFxQjtrQkExQmpDLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLGdCQUFnQixXQVNqQjt3QkFDUCxXQUFXO3dCQUNYLGFBQWE7d0JBQ2IsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGVBQWU7d0JBQ2YsZ0JBQWdCO3dCQUNoQixrQkFBa0I7d0JBQ2xCLG1CQUFtQjt3QkFDbkIsNEJBQTRCO3dCQUM1QixhQUFhO3dCQUNiLGtCQUFrQjtxQkFDbkI7OzBCQXVCYSxRQUFROzswQkFBSSxJQUFJO2lFQWxCZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFLbEIsZ0JBQWdCO3NCQUR0QixTQUFTO3VCQUFDLGtCQUFrQixFQUFFLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRTtnQkFLeEMsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbnB1dCwgT25Jbml0LCBPcHRpb25hbCwgU2VsZiwgVGVtcGxhdGVSZWYsIFZpZXdDaGlsZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1zTW9kdWxlLCBOZ0NvbnRyb2wsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBNYXRDYXJkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvY2FyZCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdEZvcm1GaWVsZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGQnO1xuaW1wb3J0IHsgTWF0SWNvbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2ljb24nO1xuaW1wb3J0IHsgTWF0SW5wdXRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pbnB1dCc7XG5pbXBvcnQgeyBNYXRUb29sdGlwTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdG9vbHRpcCc7XG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE1hdERpYWxvZywgTWF0RGlhbG9nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZGlhbG9nJztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCwgQ2xFcnJvckhhbmRsZXIgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbFRpbWVQaWNrZXJDb250ZW50Q29tcG9uZW50IH0gZnJvbSAnLi90aW1lLXBpY2tlci1jb250ZW50L3RpbWUtcGlja2VyLWNvbnRlbnQuY29tcG9uZW50JztcbmltcG9ydCB7IENsVGltZVBpY2tlclByb3BlcnRpZXMgfSBmcm9tICcuL3RpbWUtcGlja2VyLnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgT3ZlcmxheU1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLXRpbWUtcGlja2VyJyxcbiAgc3R5bGVVcmw6ICcuL3RpbWUtcGlja2VyLmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3RpbWUtcGlja2VyLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVzOiBbYFxuICA6aG9zdCB7XG4gICAgZGlzcGxheTogZmxleCAhaW1wb3J0YW50O1xuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcbiAgfVxuYF0sXG4gIGltcG9ydHM6IFtcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBNYXRDYXJkTW9kdWxlLFxuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0SW5wdXRNb2R1bGUsXG4gICAgTWF0RGlhbG9nTW9kdWxlLFxuICAgIE1hdFRvb2x0aXBNb2R1bGUsXG4gICAgTWF0Rm9ybUZpZWxkTW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgQ2xUaW1lUGlja2VyQ29udGVudENvbXBvbmVudCxcbiAgICBPdmVybGF5TW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdLFxufSlcblxuZXhwb3J0IGNsYXNzIENsVGltZVBpY2tlckNvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgQ29udHJvbFZhbHVlQWNjZXNzb3Ige1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsVGltZVBpY2tlclByb3BlcnRpZXM7XG5cbiAgcHVibGljIHNob3dUaW1lOiBib29sZWFuID0gZmFsc2U7XG4gIEBWaWV3Q2hpbGQoJ3RpbWVwaWNrZXJEaWFsb2cnLCB7IHN0YXRpYzogdHJ1ZSB9KVxuICBwdWJsaWMgdGltZXBpY2tlckRpYWxvZyE6IFRlbXBsYXRlUmVmPGFueT47XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIEBWaWV3Q2hpbGQoTWF0Rm9ybUZpZWxkKVxuICBwdWJsaWMgbWF0Rm9ybUZpZWxkITogTWF0Rm9ybUZpZWxkO1xuICAvLyBSZXF1aXJlZCB0byBpbXBsZW1lbnQgQ29udHJvbFZhbHVlQWNjZXNzb3JcbiAgcHJvdGVjdGVkIF92YWx1ZTogYW55O1xuICBvbkNoYW5nZSA9IChfOiBhbnkpID0+IHsgfTtcbiAgb25Ub3VjaGVkID0gKF86IGFueSkgPT4geyB9O1xuXG4gIHByaXZhdGUgc3ViPzogU3Vic2NyaXB0aW9uO1xuICBwcm90ZWN0ZWQgZXJyb3I/OiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbDtcbiAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wsIHByaXZhdGUgcmVhZG9ubHkgZGlhbG9nOiBNYXREaWFsb2cpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLl92YWx1ZSA9IHZhbHVlO1xuICB9XG5cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cblxuICByZWdpc3Rlck9uVG91Y2hlZChmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uVG91Y2hlZCA9IGZuXG4gIH1cblxuICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWVcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsVGltZVBpY2tlclByb3BlcnRpZXMoKTtcblxuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgLy8gc2V0dGluZyB0aGUgcmVmZXJlbmNlcyBvZiBOYXRpdmUgRWxlbWVudHMsIHdoaWNoIHdpbGwgYmUgdXNlZCBpbiBzZXRFcnJvclRleHQoKSBhbmQgc2V0SGludFRleHQoKVxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50ID0gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnRSZWYubmF0aXZlRWxlbWVudDtcbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQgPSB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5tYXQtbWRjLXRleHQtZmllbGQtd3JhcHBlci5tZGMtdGV4dC1maWVsZCcpO1xuXG4gICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgdGhpcy5zZXRIaW50VGV4dCgpO1xuXG4gICAgc3VwZXIuc3Vic2NyaWJlVG9WYWx1ZUNoYW5nZXModGhpcy53cml0ZVZhbHVlLmJpbmQodGhpcykpO1xuXG4gICAgLy8gcmVtb3ZlIGFsbCB0aGUgZXJyb3JzIHdoZW4gdGhlIHN0YXR1cyBpcyB2YWxpZFxuICAgIHRoaXMuc3ViID0gdGhpcy5uZ0NvbnRyb2w/LnN0YXR1c0NoYW5nZXMhLnN1YnNjcmliZSgoY2hhbmdlczogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAoY2hhbmdlcyA9PT0gJ1ZBTElEJykge1xuICAgICAgICB0aGlzLmVycm9yID0gbnVsbDtcblxuICAgICAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICAgICAgdGhpcy5zZXRIaW50VGV4dCgpO1xuICAgICAgfVxuICAgIH0pO1xuXG5cbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICAvLyBQcmV2ZW50IHNjcm9sbGluZyB3aGVuIHRoZSBkcm9wZG93biBpcyBvcGVuXG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgaWYgKHNlbGYuc2hvd1RpbWUpIHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTsgIC8vIFByZXZlbnQgZGVmYXVsdCBzY3JvbGxpbmcgYmVoYXZpb3JcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7IC8vIFByZXZlbnQgYnViYmxpbmcgdG8gcGFyZW50IGVsZW1lbnRzXG4gICAgICB9XG4gICAgfSwgeyBwYXNzaXZlOiBmYWxzZSB9KTsgLy8geyBwYXNzaXZlOiBmYWxzZSB9IGVuc3VyZXMgcHJldmVudERlZmF1bHQgd29ya3NcbiAgfVxuXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpOiB2b2lkIHtcbiAgICAvLyB0cmlnZ2VyIHRoZSBlcnJvciBwYXR0ZXJuIG9uY2UgdGhlIGNvbnRlbnQgaXMgY2hlY2tlZFxuICAgIHRoaXMuc2V0RW1wdHlWYWx1ZSgpXG5cbiAgICAvLyB0cmlnZ2VyIHRoZSBlcnJvciBwYXR0ZXJuIG9uY2UgdGhlIGNvbnRlbnQgaXMgY2hlY2tlZFxuICAgIGlmICh0aGlzLm5nQ29udHJvbCAhPSBudWxsICYmIHRoaXMubmdDb250cm9sLnRvdWNoZWQgPT09IHRydWUgJiYgdGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSB7XG4gICAgICBpZih0aGlzLnByb3BlcnRpZXMuaXNSZWFjdGl2ZUZvcm1Db250cm9sKSB7XG4gICAgICAgIGNvbnN0IGtleXM6IChrZXlvZiBDbEVycm9ySGFuZGxlcilbXSA9IE9iamVjdC5rZXlzKHRoaXMubmdDb250cm9sLmVycm9ycykgYXMgKGtleW9mIENsRXJyb3JIYW5kbGVyKVtdO1xuICAgICAgICB0aGlzLmVycm9yID0gZ2V0RXJyb3JNZXNzYWdlKGtleXNbMF0sIHRoaXMucHJvcGVydGllcy5lcnJvcnNMaXN0ISk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmVycm9yID0gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzID8gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzWydlcnJvciddIDogbnVsbDtcbiAgICAgIH1cblxuICAgICAgLy8gY2FsbGluZyBzZXQgZXJyb3IgdGV4dCBmdW5jdGlvblxuICAgICAgdGhpcy5zZXRFcnJvclRleHQodGhpcy5lcnJvcik7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHNldEhpbnRUZXh0KCkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IHRoaXMucHJvcGVydGllcy5oaW50VGV4dCA/PyAnJztcblxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21hdC1tZGMtZm9ybS1maWVsZC1oaW50Jyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG5cbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWRjLXRleHQtZmllbGQtLWludmFsaWQnKTtcbiAgICB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1mb3JtLWZpZWxkLWludmFsaWQnKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvclRleHQoZXJyb3I6IGFueSkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IGVycm9yO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcblxuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXRFbXB0eVZhbHVlKCkge1xuICAgIGlmICh0aGlzLl92YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLl92YWx1ZSA9ICcnXG4gICAgfVxuICB9XG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIG9uIHRoZSBvcGVuaW5nIHRoZSB0aW1lIHBpY2tlclxuICBwdWJsaWMgb3BlblRpbWVQaWNrZXIoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93QXNEaWFsb2cpIHtcbiAgICAgIC8vc2hvdyBhcyBhIGRpYWxvZ1xuICAgICAgdGhpcy5kaWFsb2cub3Blbih0aGlzLnRpbWVwaWNrZXJEaWFsb2cpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBzY3JvbGxhYmxlRGl2ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Njcm9sbGFibGVEaXYnKTtcblxuICAgICAgaWYgKHNjcm9sbGFibGVEaXYpIHtcbiAgICAgICAgc2Nyb2xsYWJsZURpdi5zY3JvbGxUbyh7XG4gICAgICAgICAgbGVmdDogMCwgICAgLy8gU2Nyb2xsIHRvIHRoZSB2ZXJ5IGxlZnRcbiAgICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcgIC8vIFNtb290aCBzY3JvbGxpbmcgYW5pbWF0aW9uXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIERlbGF5IG9wZW5pbmcgdGhlIHRpbWVwaWNrZXIgc2xpZ2h0bHkgdG8gZW5zdXJlIHNjcm9sbGluZyBjb21wbGV0ZXNcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5zaG93VGltZSA9IHRydWU7XG4gICAgICAgIH0sIDMwMCk7ICAvLyBBZGp1c3QgdGltZW91dCBiYXNlZCBvbiBleHBlY3RlZCBzY3JvbGwgZHVyYXRpb25cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIElmIG5vIHNjcm9sbGluZyBpcyBuZWVkZWQsIGRpcmVjdGx5IG9wZW4gdGhlIHRpbWVwaWNrZXJcbiAgICAgICAgdGhpcy5zaG93VGltZSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uQ2FuY2VsKGV2OiBhbnkpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnNob3dBc0RpYWxvZykge1xuICAgICAgdGhpcy5kaWFsb2cuY2xvc2VBbGwoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zaG93VGltZSA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvblRpbWVTZWxlY3Rpb24oZXY6IGFueSkge1xuICAgIHRoaXMud3JpdGVWYWx1ZShldik7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblRpbWVTZWxlY3RlZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLnByb3BlcnRpZXMub25UaW1lU2VsZWN0ZWQoZXYpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0FzRGlhbG9nKSB7XG4gICAgICB0aGlzLmRpYWxvZy5jbG9zZUFsbCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNob3dUaW1lID0gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGdldCBzaG93SW5mb01zZygpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2c7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2coKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBvdmVycmlkZSBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAvKipcbiAgICAqICEhIFdhcm5pbmcgISFcbiAgICAqIFRoZSBiZWxvdyBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgKi9cblxuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG59XG4iLCI8ZGl2IFtpZF09XCJwcm9wZXJ0aWVzLmlkXCIgY2xhc3M9XCJjbC10aW1lLXBpY2tlclwiPlxuXG4gIDxtYXQtZm9ybS1maWVsZCBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiIFtmbG9hdExhYmVsXT1cInByb3BlcnRpZXMuZmxvYXRMYWJlbCFcIlxuICAgIGNsYXNzPVwidy1mdWxsIHt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIiBjZGtPdmVybGF5T3JpZ2luICNjdXN0b21UaW1lUGlja2VyPVwiY2RrT3ZlcmxheU9yaWdpblwiPlxuXG4gICAgQGlmIChwcm9wZXJ0aWVzLmxhYmVsICE9IG51bGwgJiYgcHJvcGVydGllcy5sYWJlbCAhPSAnJyAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9IHVuZGVmaW5lZCkge1xuICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPHNwYW4+e3sgcHJvcGVydGllcy5sYWJlbCB9fTwvc3Bhbj5cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLm9wdGlvbmFsKSB7XG4gICAgICA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsLXRleHRcIj4oT3B0aW9uYWwpPC9zcGFuPlxuICAgICAgfVxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIlxuICAgICAgICBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgICA8L21hdC1pY29uPlxuICAgICAgfVxuICAgIDwvbWF0LWxhYmVsPlxuICAgIH1cblxuICAgIDxpbnB1dCBtYXRJbnB1dCBbdmFsdWVdPVwidmFsdWVcIlxuICAgICAgW3BsYWNlaG9sZGVyXT1cInByb3BlcnRpZXMucGxhY2Vob2xkZXIhXCJcbiAgICAgIChpbnB1dCk9XCJvbkNoYW5nZSgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKVwiXG4gICAgICAoYmx1cik9XCJvblRvdWNoZWQoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIlxuICAgICAgKGtleXVwKT1cIndyaXRlVmFsdWUoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIiBbcmVhZG9ubHldPVwidHJ1ZVwiLz5cblxuICAgIEBpZiAoIXByb3BlcnRpZXMuaWNvbikge1xuICAgIDxtYXQtaWNvbiBtYXRTdWZmaXggKGNsaWNrKT1cIm9wZW5UaW1lUGlja2VyKClcIiBjbGFzcz1cImN1cnNvci1wb2ludGVyXCIgW3N2Z0ljb25dPVwiJ2Zzc19pY29uczpjbG9jaydcIj5cbiAgICA8L21hdC1pY29uPlxuICAgIH1cblxuICAgIEBpZiAocHJvcGVydGllcy5pY29uKSB7XG4gICAgPG1hdC1pY29uIG1hdFN1ZmZpeCAoY2xpY2spPVwib3BlblRpbWVQaWNrZXIoKVwiIGNsYXNzPVwiY3Vyc29yLXBvaW50ZXJcIiBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLmljb24hXCI+XG4gICAgPC9tYXQtaWNvbj5cbiAgICB9XG4gIDwvbWF0LWZvcm0tZmllbGQ+XG4gIDwhLS0gVGhpcyBkaXYgaXMgcmVxdWlyZWQgdG8gc2hvdyBoaW50IHRleHQgb3IgZXJyb3IgbWVzc2FnZSBmb3IgdGhlIGNvbXBvbmVudCAtLT5cbiAgPCEtLSA8ZGl2ICNlcnJvck9ySGludERpdkVsZW1lbnRSZWYgY2xhc3M9XCJ7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPjwvZGl2PiAtLT5cbiAgQGlmIChlcnJvcikge1xuICA8bWF0LWVycm9yIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgICB7eyBlcnJvciB9fVxuICA8L21hdC1lcnJvcj5cbiAgfVxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgPG1hdC1oaW50IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgICB7eyBwcm9wZXJ0aWVzLmhpbnRUZXh0IH19XG4gIDwvbWF0LWhpbnQ+XG4gIH1cbjwvZGl2PlxuXG48bmctdGVtcGxhdGUgY2RrQ29ubmVjdGVkT3ZlcmxheSBbY2RrQ29ubmVjdGVkT3ZlcmxheU9yaWdpbl09XCJjdXN0b21UaW1lUGlja2VyXCIgW2Nka0Nvbm5lY3RlZE92ZXJsYXlPcGVuXT1cInNob3dUaW1lXCI+XG4gIDxtYXQtY2FyZD5cbiAgICA8ZGl2IGNsYXNzPVwiY2wtdGltZXBpY2tlci1jb250ZW50LWNvbnRhaW5lclwiPlxuICAgICAgPGNsLXRpbWUtcGlja2VyLWNvbnRlbnQgW3ZhbHVlXT1cInZhbHVlXCIgKG9uQXBwbHkpPVwib25UaW1lU2VsZWN0aW9uKCRldmVudClcIiAob25DYW5jZWxDbGljayk9XCJvbkNhbmNlbCgkZXZlbnQpXCI+XG4gICAgICA8L2NsLXRpbWUtcGlja2VyLWNvbnRlbnQ+XG4gICAgPC9kaXY+XG4gIDwvbWF0LWNhcmQ+XG48L25nLXRlbXBsYXRlPlxuXG5cbjxuZy10ZW1wbGF0ZSAjdGltZXBpY2tlckRpYWxvZz5cbiAgPG1hdC1jYXJkPlxuICAgIDxkaXYgY2xhc3M9XCJjbC10aW1lcGlja2VyLWRpYWxvZy1jb250YWluZXJcIj5cbiAgICAgIDxjbC10aW1lLXBpY2tlci1jb250ZW50IFt2YWx1ZV09XCJ2YWx1ZVwiIChvbkFwcGx5KT1cIm9uVGltZVNlbGVjdGlvbigkZXZlbnQpXCIgKG9uQ2FuY2VsQ2xpY2spPVwib25DYW5jZWwoJGV2ZW50KVwiPlxuICAgICAgPC9jbC10aW1lLXBpY2tlci1jb250ZW50PlxuICAgIDwvZGl2PlxuICA8L21hdC1jYXJkPlxuPC9uZy10ZW1wbGF0ZT5cbiJdfQ==