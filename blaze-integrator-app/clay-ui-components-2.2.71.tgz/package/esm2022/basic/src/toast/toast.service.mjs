import { Injectable } from '@angular/core';
import { ClToastComponent } from './toast.component';
import { ClToastMessageType } from './toast.properties';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/snack-bar";
export class ClToastService {
    constructor(_snackBar) {
        this._snackBar = _snackBar;
    }
    _openSnackbar(toastProperties, panelClass = '') {
        this._snackBar.openFromComponent(ClToastComponent, {
            panelClass: panelClass,
            data: { properties: toastProperties },
            duration: toastProperties.duration ?? 5000,
            verticalPosition: toastProperties.verticalPosition ?? 'top',
            horizontalPosition: toastProperties.horizontalPosition ?? 'end'
        });
    }
    // -----------------------------------------------------------------------------------------------------
    // @ Public methods
    // -----------------------------------------------------------------------------------------------------
    info(toastProperties) {
        toastProperties.messageType = ClToastMessageType.info;
        this._openSnackbar(toastProperties, 'info');
    }
    error(toastProperties) {
        toastProperties.messageType = ClToastMessageType.error;
        this._openSnackbar(toastProperties, 'error');
    }
    success(toastProperties) {
        toastProperties.messageType = ClToastMessageType.success;
        this._openSnackbar(toastProperties, 'success');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, deps: [{ token: i1.MatSnackBar }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [{ type: i1.MatSnackBar }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3Quc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9iYXNpYy9zcmMvdG9hc3QvdG9hc3Quc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRzNDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBQ3JELE9BQU8sRUFBRSxrQkFBa0IsRUFBcUIsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBRzNFLE1BQU0sT0FBTyxjQUFjO0lBQ3pCLFlBQXFCLFNBQXNCO1FBQXRCLGNBQVMsR0FBVCxTQUFTLENBQWE7SUFBSSxDQUFDO0lBRXhDLGFBQWEsQ0FBQyxlQUFrQyxFQUFFLGFBQWtCLEVBQUU7UUFDNUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FDOUIsZ0JBQWdCLEVBQ2hCO1lBQ0UsVUFBVSxFQUFFLFVBQVU7WUFDdEIsSUFBSSxFQUFFLEVBQUUsVUFBVSxFQUFFLGVBQWUsRUFBRTtZQUNyQyxRQUFRLEVBQUUsZUFBZSxDQUFDLFFBQVEsSUFBSSxJQUFJO1lBQzFDLGdCQUFnQixFQUFFLGVBQWUsQ0FBQyxnQkFBZ0IsSUFBSSxLQUFLO1lBQzNELGtCQUFrQixFQUFFLGVBQWUsQ0FBQyxrQkFBa0IsSUFBSSxLQUFLO1NBQ2hFLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRCx3R0FBd0c7SUFDeEcsbUJBQW1CO0lBQ25CLHdHQUF3RztJQUNqRyxJQUFJLENBQUMsZUFBa0M7UUFDNUMsZUFBZSxDQUFDLFdBQVcsR0FBRyxrQkFBa0IsQ0FBQyxJQUFJLENBQUM7UUFFdEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDOUMsQ0FBQztJQUVNLEtBQUssQ0FBQyxlQUFrQztRQUM3QyxlQUFlLENBQUMsV0FBVyxHQUFHLGtCQUFrQixDQUFDLEtBQUssQ0FBQztRQUV2RCxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRU0sT0FBTyxDQUFDLGVBQWtDO1FBQy9DLGVBQWUsQ0FBQyxXQUFXLEdBQUcsa0JBQWtCLENBQUMsT0FBTyxDQUFDO1FBRXpELElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBQ2pELENBQUM7OEdBbkNVLGNBQWM7a0hBQWQsY0FBYyxjQURELE1BQU07OzJGQUNuQixjQUFjO2tCQUQxQixVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE1hdFNuYWNrQmFyIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvc25hY2stYmFyJztcblxuaW1wb3J0IHsgQ2xUb2FzdENvbXBvbmVudCB9IGZyb20gJy4vdG9hc3QuY29tcG9uZW50JztcbmltcG9ydCB7IENsVG9hc3RNZXNzYWdlVHlwZSwgQ2xUb2FzdFByb3BlcnRpZXMgfSBmcm9tICcuL3RvYXN0LnByb3BlcnRpZXMnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIENsVG9hc3RTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IgKHByaXZhdGUgX3NuYWNrQmFyOiBNYXRTbmFja0JhcikgeyB9XG5cbiAgcHJpdmF0ZSBfb3BlblNuYWNrYmFyKHRvYXN0UHJvcGVydGllczogQ2xUb2FzdFByb3BlcnRpZXMsIHBhbmVsQ2xhc3M6IGFueSA9ICcnKSB7XG4gICAgdGhpcy5fc25hY2tCYXIub3BlbkZyb21Db21wb25lbnQoXG4gICAgICBDbFRvYXN0Q29tcG9uZW50LFxuICAgICAge1xuICAgICAgICBwYW5lbENsYXNzOiBwYW5lbENsYXNzLFxuICAgICAgICBkYXRhOiB7IHByb3BlcnRpZXM6IHRvYXN0UHJvcGVydGllcyB9LFxuICAgICAgICBkdXJhdGlvbjogdG9hc3RQcm9wZXJ0aWVzLmR1cmF0aW9uID8/IDUwMDAsXG4gICAgICAgIHZlcnRpY2FsUG9zaXRpb246IHRvYXN0UHJvcGVydGllcy52ZXJ0aWNhbFBvc2l0aW9uID8/ICd0b3AnLFxuICAgICAgICBob3Jpem9udGFsUG9zaXRpb246IHRvYXN0UHJvcGVydGllcy5ob3Jpem9udGFsUG9zaXRpb24gPz8gJ2VuZCdcbiAgICAgIH1cbiAgICApO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQCBQdWJsaWMgbWV0aG9kc1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBwdWJsaWMgaW5mbyh0b2FzdFByb3BlcnRpZXM6IENsVG9hc3RQcm9wZXJ0aWVzKSB7XG4gICAgdG9hc3RQcm9wZXJ0aWVzLm1lc3NhZ2VUeXBlID0gQ2xUb2FzdE1lc3NhZ2VUeXBlLmluZm87XG5cbiAgICB0aGlzLl9vcGVuU25hY2tiYXIodG9hc3RQcm9wZXJ0aWVzLCAnaW5mbycpO1xuICB9XG5cbiAgcHVibGljIGVycm9yKHRvYXN0UHJvcGVydGllczogQ2xUb2FzdFByb3BlcnRpZXMpIHtcbiAgICB0b2FzdFByb3BlcnRpZXMubWVzc2FnZVR5cGUgPSBDbFRvYXN0TWVzc2FnZVR5cGUuZXJyb3I7XG5cbiAgICB0aGlzLl9vcGVuU25hY2tiYXIodG9hc3RQcm9wZXJ0aWVzLCAnZXJyb3InKTtcbiAgfVxuXG4gIHB1YmxpYyBzdWNjZXNzKHRvYXN0UHJvcGVydGllczogQ2xUb2FzdFByb3BlcnRpZXMpIHtcbiAgICB0b2FzdFByb3BlcnRpZXMubWVzc2FnZVR5cGUgPSBDbFRvYXN0TWVzc2FnZVR5cGUuc3VjY2VzcztcblxuICAgIHRoaXMuX29wZW5TbmFja2Jhcih0b2FzdFByb3BlcnRpZXMsICdzdWNjZXNzJyk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBAIFB1YmxpYyBtZXRob2RzXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG59XG4iXX0=