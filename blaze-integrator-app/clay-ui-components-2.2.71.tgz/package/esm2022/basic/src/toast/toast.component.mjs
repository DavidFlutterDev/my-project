import { Component, Inject } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MAT_SNACK_BAR_DATA, MatSnackBarModule } from '@angular/material/snack-bar';
import { ClIconComponent } from '../icon';
import { ClComponentTypes } from '@clay/ui-components/shared';
import { ClToastMessageType } from './toast.properties';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/snack-bar";
import * as i2 from "@angular/material/form-field";
export class ClToastComponent {
    constructor(data, snackBarRef) {
        this.data = data;
        this.snackBarRef = snackBarRef;
        this.toastProperties = this.data.properties;
    }
    ngOnInit() {
        this.setIconProperties();
    }
    setIconProperties() {
        this.iconProperties = {
            id: 'toastMsgIcon',
            type: ClComponentTypes.icon,
            iconName: this.getIconName(),
            style: { cssClasses: 'text-white icon-size-5' }
        };
    }
    getIconName() {
        switch (this.toastProperties.messageType) {
            case ClToastMessageType.info:
                return 'fss_icons:info-fill-white';
            case ClToastMessageType.error:
                return 'heroicons_outline:exclamation-triangle';
            default:
                return 'fss_icons:filled-circle-check-white';
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastComponent, deps: [{ token: MAT_SNACK_BAR_DATA }, { token: i1.MatSnackBarRef }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClToastComponent, isStandalone: true, selector: "cl-toast", ngImport: i0, template: "<div class=\"flex gap-3 items-center\">\n  <cl-icon class=\"flex self-center\" [properties]=\"iconProperties\"></cl-icon>\n\n  @if (toastProperties.message) {\n    <mat-label [class]=\"toastProperties.style?.cssClasses\">{{toastProperties.message}}</mat-label>\n  }\n\n  @if (toastProperties.customMsg?.length) {\n    <div class=\"flex gap-1 items-center\">\n      @for (labelProperties of toastProperties.customMsg; track labelProperties) {\n        <mat-label class=\"{{ labelProperties.fontSize }} {{ labelProperties.lineHeight }} {{ labelProperties.fontWeight }}\">{{labelProperties.text}}</mat-label>\n      }\n    </div>\n  }\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatSnackBarModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i2.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClToastComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-toast', imports: [
                        MatSnackBarModule,
                        MatFormFieldModule,
                        ClIconComponent
                    ], template: "<div class=\"flex gap-3 items-center\">\n  <cl-icon class=\"flex self-center\" [properties]=\"iconProperties\"></cl-icon>\n\n  @if (toastProperties.message) {\n    <mat-label [class]=\"toastProperties.style?.cssClasses\">{{toastProperties.message}}</mat-label>\n  }\n\n  @if (toastProperties.customMsg?.length) {\n    <div class=\"flex gap-1 items-center\">\n      @for (labelProperties of toastProperties.customMsg; track labelProperties) {\n        <mat-label class=\"{{ labelProperties.fontSize }} {{ labelProperties.lineHeight }} {{ labelProperties.fontWeight }}\">{{labelProperties.text}}</mat-label>\n      }\n    </div>\n  }\n</div>\n" }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_SNACK_BAR_DATA]
                }] }, { type: i1.MatSnackBarRef }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3QuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy90b2FzdC90b2FzdC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RvYXN0L3RvYXN0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFVLE1BQU0sZUFBZSxDQUFDO0FBQzFELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQ2xFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxpQkFBaUIsRUFBa0IsTUFBTSw2QkFBNkIsQ0FBQztBQUVwRyxPQUFPLEVBQUUsZUFBZSxFQUFvQixNQUFNLFNBQVMsQ0FBQztBQUM1RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUM5RCxPQUFPLEVBQUUsa0JBQWtCLEVBQXFCLE1BQU0sb0JBQW9CLENBQUM7Ozs7QUFhM0UsTUFBTSxPQUFPLGdCQUFnQjtJQUkzQixZQUNxQyxJQUFTLEVBQ3JDLFdBQTZDO1FBRGpCLFNBQUksR0FBSixJQUFJLENBQUs7UUFDckMsZ0JBQVcsR0FBWCxXQUFXLENBQWtDO1FBRXBELElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7SUFDOUMsQ0FBQztJQUVELFFBQVE7UUFDTixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU8saUJBQWlCO1FBQ3ZCLElBQUksQ0FBQyxjQUFjLEdBQUc7WUFDcEIsRUFBRSxFQUFFLGNBQWM7WUFDbEIsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsUUFBUSxFQUFFLElBQUksQ0FBQyxXQUFXLEVBQUU7WUFDNUIsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLHdCQUF3QixFQUFFO1NBQ2hELENBQUM7SUFDSixDQUFDO0lBRU8sV0FBVztRQUNqQixRQUFRLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBWSxFQUFFLENBQUM7WUFDMUMsS0FBSyxrQkFBa0IsQ0FBQyxJQUFJO2dCQUMxQixPQUFPLDJCQUEyQixDQUFDO1lBRXJDLEtBQUssa0JBQWtCLENBQUMsS0FBSztnQkFDM0IsT0FBTyx3Q0FBd0MsQ0FBQztZQUVsRDtnQkFDRSxPQUFPLHFDQUFxQyxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDOzhHQW5DVSxnQkFBZ0Isa0JBS2pCLGtCQUFrQjtrR0FMakIsZ0JBQWdCLG9FQ25CN0IsbW9CQWVBLDJDREZJLGlCQUFpQiw4QkFDakIsa0JBQWtCLGdHQUVsQixlQUFlOzsyRkFHTixnQkFBZ0I7a0JBWDVCLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLFVBQVUsV0FFWDt3QkFDUCxpQkFBaUI7d0JBQ2pCLGtCQUFrQjt3QkFFbEIsZUFBZTtxQkFDaEI7OzBCQU9FLE1BQU07MkJBQUMsa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBJbmplY3QsIE9uSW5pdCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZm9ybS1maWVsZCc7XG5pbXBvcnQgeyBNQVRfU05BQ0tfQkFSX0RBVEEsIE1hdFNuYWNrQmFyTW9kdWxlLCBNYXRTbmFja0JhclJlZiB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3NuYWNrLWJhcic7XG5cbmltcG9ydCB7IENsSWNvbkNvbXBvbmVudCwgQ2xJY29uUHJvcGVydGllcyB9IGZyb20gJy4uL2ljb24nO1xuaW1wb3J0IHsgQ2xDb21wb25lbnRUeXBlcyB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsVG9hc3RNZXNzYWdlVHlwZSwgQ2xUb2FzdFByb3BlcnRpZXMgfSBmcm9tICcuL3RvYXN0LnByb3BlcnRpZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC10b2FzdCcsXG4gIHRlbXBsYXRlVXJsOiAnLi90b2FzdC5jb21wb25lbnQuaHRtbCcsXG4gIGltcG9ydHM6IFtcbiAgICBNYXRTbmFja0Jhck1vZHVsZSxcbiAgICBNYXRGb3JtRmllbGRNb2R1bGUsXG5cbiAgICBDbEljb25Db21wb25lbnRcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBDbFRvYXN0Q29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgcHVibGljIGljb25Qcm9wZXJ0aWVzITogQ2xJY29uUHJvcGVydGllcztcbiAgcHVibGljIHRvYXN0UHJvcGVydGllcyE6IENsVG9hc3RQcm9wZXJ0aWVzO1xuXG4gIGNvbnN0cnVjdG9yIChcbiAgICBASW5qZWN0KE1BVF9TTkFDS19CQVJfREFUQSkgcHVibGljIGRhdGE6IGFueSxcbiAgICBwdWJsaWMgc25hY2tCYXJSZWY6IE1hdFNuYWNrQmFyUmVmPENsVG9hc3RDb21wb25lbnQ+LFxuICApIHtcbiAgICB0aGlzLnRvYXN0UHJvcGVydGllcyA9IHRoaXMuZGF0YS5wcm9wZXJ0aWVzO1xuICB9XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5zZXRJY29uUHJvcGVydGllcygpO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXRJY29uUHJvcGVydGllcygpIHtcbiAgICB0aGlzLmljb25Qcm9wZXJ0aWVzID0ge1xuICAgICAgaWQ6ICd0b2FzdE1zZ0ljb24nLFxuICAgICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgICAgaWNvbk5hbWU6IHRoaXMuZ2V0SWNvbk5hbWUoKSxcbiAgICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICd0ZXh0LXdoaXRlIGljb24tc2l6ZS01JyB9XG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0SWNvbk5hbWUoKTogc3RyaW5nIHtcbiAgICBzd2l0Y2ggKHRoaXMudG9hc3RQcm9wZXJ0aWVzLm1lc3NhZ2VUeXBlISkge1xuICAgICAgY2FzZSBDbFRvYXN0TWVzc2FnZVR5cGUuaW5mbzpcbiAgICAgICAgcmV0dXJuICdmc3NfaWNvbnM6aW5mby1maWxsLXdoaXRlJztcblxuICAgICAgY2FzZSBDbFRvYXN0TWVzc2FnZVR5cGUuZXJyb3I6XG4gICAgICAgIHJldHVybiAnaGVyb2ljb25zX291dGxpbmU6ZXhjbGFtYXRpb24tdHJpYW5nbGUnO1xuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gJ2Zzc19pY29uczpmaWxsZWQtY2lyY2xlLWNoZWNrLXdoaXRlJztcbiAgICB9XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJmbGV4IGdhcC0zIGl0ZW1zLWNlbnRlclwiPlxuICA8Y2wtaWNvbiBjbGFzcz1cImZsZXggc2VsZi1jZW50ZXJcIiBbcHJvcGVydGllc109XCJpY29uUHJvcGVydGllc1wiPjwvY2wtaWNvbj5cblxuICBAaWYgKHRvYXN0UHJvcGVydGllcy5tZXNzYWdlKSB7XG4gICAgPG1hdC1sYWJlbCBbY2xhc3NdPVwidG9hc3RQcm9wZXJ0aWVzLnN0eWxlPy5jc3NDbGFzc2VzXCI+e3t0b2FzdFByb3BlcnRpZXMubWVzc2FnZX19PC9tYXQtbGFiZWw+XG4gIH1cblxuICBAaWYgKHRvYXN0UHJvcGVydGllcy5jdXN0b21Nc2c/Lmxlbmd0aCkge1xuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0xIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgQGZvciAobGFiZWxQcm9wZXJ0aWVzIG9mIHRvYXN0UHJvcGVydGllcy5jdXN0b21Nc2c7IHRyYWNrIGxhYmVsUHJvcGVydGllcykge1xuICAgICAgICA8bWF0LWxhYmVsIGNsYXNzPVwie3sgbGFiZWxQcm9wZXJ0aWVzLmZvbnRTaXplIH19IHt7IGxhYmVsUHJvcGVydGllcy5saW5lSGVpZ2h0IH19IHt7IGxhYmVsUHJvcGVydGllcy5mb250V2VpZ2h0IH19XCI+e3tsYWJlbFByb3BlcnRpZXMudGV4dH19PC9tYXQtbGFiZWw+XG4gICAgICB9XG4gICAgPC9kaXY+XG4gIH1cbjwvZGl2PlxuIl19