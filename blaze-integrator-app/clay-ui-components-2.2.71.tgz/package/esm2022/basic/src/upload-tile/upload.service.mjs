import { Injectable, signal } from '@angular/core';
import * as i0 from "@angular/core";
export class ClUploadService {
    constructor() {
        this.fileResult = [];
        this._selectedFiles = signal([]);
    }
    /**
     * uploadFile
     *
     * this method will open dialog to select the allowed files
     * and returns all the selected files either single or multiple
     *
     * @param event
     *
     * @returns selected files list as observable
     */
    uploadFile(event, allowedFileTypes, maxLimit, uploadError, fileGridView) {
        this.fileResult = [];
        const fileList = event.target.files;
        const acceptedFilesList = [];
        const unacceptedFilesList = [];
        // Return if canceled
        if (!fileList.length && (fileGridView == undefined || !fileGridView)) {
            this._selectedFiles.set([]);
            return this._selectedFiles;
        }
        const allowedTypes = allowedFileTypes.split(',');
        for (const file of fileList) {
            // check if file is allowed or not
            if (!allowedTypes.includes(file.type)) {
                // add to unaccepted files list if file is not allowed
                unacceptedFilesList.push(file);
                this.fileResult.push({
                    fileSize: 0,
                    fileSizeDesc: '0 b',
                    errorMessage: uploadError?.formatErrorMsg ?? 'The file type selected is not allowed.',
                });
            }
            else {
                // add to accepted files list if file is not allowed
                acceptedFilesList.push(file);
            }
        }
        for (const file of acceptedFilesList) {
            // calling get file result method
            this.fileResult.push(this.getFileResult(maxLimit, uploadError, file));
        }
        if (this.fileResult.length > 0 && this.fileResult[0].errorMessage != undefined) {
            this._selectedFiles.set([]);
        }
        else {
            this._selectedFiles.set(acceptedFilesList);
        }
        return this._selectedFiles;
    }
    /**
     * deleteFile
     *
     * This function will delete the file at selected index
     *
     * @param index
     *
     * @returns selected files as observable
     */
    deleteFile(index) {
        this.fileResult = [];
        this._selectedFiles().splice(index, 1);
        return this._selectedFiles;
    }
    /**
     * get file size
     *
     * this method will result the size of the file
     *
     * @param  maxLimit
     *
     * @param file
     *
     * @returns size of the file in b or kb or mb or gb
     */
    getFileResult(maxLimit, uploadError, file) {
        if (file == undefined) {
            return { fileSize: 0, fileSizeDesc: '0 b' };
        }
        const size = file.size;
        if (size === 0) {
            return { fileSize: 0, fileSizeDesc: '0 b' };
        }
        const base = 1024;
        const units = ['b', 'kb', 'mb', 'gb'];
        const sizeInKb = size / base;
        const displaySizeInKb = Math.log(size) / Math.log(base);
        const i = Math.floor(displaySizeInKb);
        const errorMessage = sizeInKb > maxLimit ? 'File size has exceeded max limit' : undefined;
        return {
            fileSize: +displaySizeInKb.toFixed(2),
            fileSizeDesc: `${(size / Math.pow(base, i)).toFixed(2)} ${units[i]}`,
            errorMessage: sizeInKb > maxLimit ? (uploadError?.fileSizeErrorMsg ?? errorMessage) : undefined,
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClUploadService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3VwbG9hZC10aWxlL3VwbG9hZC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDOztBQU1uRCxNQUFNLE9BQU8sZUFBZTtJQUY1QjtRQUdTLGVBQVUsR0FBbUIsRUFBRSxDQUFDO1FBQy9CLG1CQUFjLEdBQUcsTUFBTSxDQUFTLEVBQUUsQ0FBQyxDQUFDO0tBZ0g3QztJQTlHQzs7Ozs7Ozs7O09BU0c7SUFDSSxVQUFVLENBQUMsS0FBVSxFQUFFLGdCQUF3QixFQUFFLFFBQWdCLEVBQUUsV0FBNEIsRUFBRSxZQUFzQjtRQUM1SCxJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNyQixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztRQUVwQyxNQUFNLGlCQUFpQixHQUFXLEVBQUUsQ0FBQztRQUNyQyxNQUFNLG1CQUFtQixHQUFXLEVBQUUsQ0FBQztRQUV2QyxxQkFBcUI7UUFDckIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLElBQUksQ0FBQyxZQUFZLElBQUksU0FBUyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUNyRSxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUU1QixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7UUFDN0IsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVqRCxLQUFLLE1BQU0sSUFBSSxJQUFJLFFBQVEsRUFBRSxDQUFDO1lBQzVCLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDdEMsc0RBQXNEO2dCQUN0RCxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBRS9CLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO29CQUNuQixRQUFRLEVBQUUsQ0FBQztvQkFDWCxZQUFZLEVBQUUsS0FBSztvQkFDbkIsWUFBWSxFQUFFLFdBQVcsRUFBRSxjQUFjLElBQUksd0NBQXdDO2lCQUN0RixDQUFDLENBQUM7WUFDTCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sb0RBQW9EO2dCQUNwRCxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDL0IsQ0FBQztRQUNILENBQUM7UUFFRCxLQUFLLE1BQU0sSUFBSSxJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDckMsaUNBQWlDO1lBQ2pDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMvRSxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5QixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUVELE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUM3QixDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxVQUFVLENBQUMsS0FBYTtRQUM3QixJQUFJLENBQUMsVUFBVSxHQUFHLEVBQUUsQ0FBQztRQUNyQixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztRQUV2QyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUM7SUFDN0IsQ0FBQztJQUVEOzs7Ozs7Ozs7O09BVUc7SUFDSSxhQUFhLENBQUMsUUFBZ0IsRUFBRSxXQUE0QixFQUFFLElBQVc7UUFDOUUsSUFBSSxJQUFJLElBQUksU0FBUyxFQUFFLENBQUM7WUFDdEIsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQzlDLENBQUM7UUFFRCxNQUFNLElBQUksR0FBVyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBRS9CLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2YsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDLEVBQUUsWUFBWSxFQUFFLEtBQUssRUFBRSxDQUFDO1FBQzlDLENBQUM7UUFFRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUM7UUFDbEIsTUFBTSxLQUFLLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUV0QyxNQUFNLFFBQVEsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQzdCLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUV4RCxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3RDLE1BQU0sWUFBWSxHQUFHLFFBQVEsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFFMUYsT0FBTztZQUNMLFFBQVEsRUFBRSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ3JDLFlBQVksRUFBRSxHQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBRSxJQUFLLEtBQUssQ0FBQyxDQUFDLENBQUUsRUFBRTtZQUN4RSxZQUFZLEVBQUUsUUFBUSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsZ0JBQWdCLElBQUksWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7U0FDaEcsQ0FBQztJQUNKLENBQUM7OEdBakhVLGVBQWU7a0hBQWYsZUFBZSxjQUZGLE1BQU07OzJGQUVuQixlQUFlO2tCQUYzQixVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIHNpZ25hbCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBDbEZpbGVSZXN1bHQsIElDbFVwbG9hZEVycm9yIH0gZnJvbSAnLi91cGxvYWQucHJvcGVydGllcyc7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5cbmV4cG9ydCBjbGFzcyBDbFVwbG9hZFNlcnZpY2Uge1xuICBwdWJsaWMgZmlsZVJlc3VsdDogQ2xGaWxlUmVzdWx0W10gPSBbXTtcbiAgcHJpdmF0ZSBfc2VsZWN0ZWRGaWxlcyA9IHNpZ25hbDxGaWxlW10+KFtdKTtcblxuICAvKipcbiAgICogdXBsb2FkRmlsZVxuICAgKlxuICAgKiB0aGlzIG1ldGhvZCB3aWxsIG9wZW4gZGlhbG9nIHRvIHNlbGVjdCB0aGUgYWxsb3dlZCBmaWxlc1xuICAgKiBhbmQgcmV0dXJucyBhbGwgdGhlIHNlbGVjdGVkIGZpbGVzIGVpdGhlciBzaW5nbGUgb3IgbXVsdGlwbGVcbiAgICpcbiAgICogQHBhcmFtIGV2ZW50XG4gICAqXG4gICAqIEByZXR1cm5zIHNlbGVjdGVkIGZpbGVzIGxpc3QgYXMgb2JzZXJ2YWJsZVxuICAgKi9cbiAgcHVibGljIHVwbG9hZEZpbGUoZXZlbnQ6IGFueSwgYWxsb3dlZEZpbGVUeXBlczogc3RyaW5nLCBtYXhMaW1pdDogbnVtYmVyLCB1cGxvYWRFcnJvcj86IElDbFVwbG9hZEVycm9yLCBmaWxlR3JpZFZpZXc/OiBib29sZWFuKSB7XG4gICAgdGhpcy5maWxlUmVzdWx0ID0gW107XG4gICAgY29uc3QgZmlsZUxpc3QgPSBldmVudC50YXJnZXQuZmlsZXM7XG5cbiAgICBjb25zdCBhY2NlcHRlZEZpbGVzTGlzdDogRmlsZVtdID0gW107XG4gICAgY29uc3QgdW5hY2NlcHRlZEZpbGVzTGlzdDogRmlsZVtdID0gW107XG5cbiAgICAvLyBSZXR1cm4gaWYgY2FuY2VsZWRcbiAgICBpZiAoIWZpbGVMaXN0Lmxlbmd0aCAmJiAoZmlsZUdyaWRWaWV3ID09IHVuZGVmaW5lZCB8fCAhZmlsZUdyaWRWaWV3KSkge1xuICAgICAgdGhpcy5fc2VsZWN0ZWRGaWxlcy5zZXQoW10pO1xuXG4gICAgICByZXR1cm4gdGhpcy5fc2VsZWN0ZWRGaWxlcztcbiAgICB9XG5cbiAgICBjb25zdCBhbGxvd2VkVHlwZXMgPSBhbGxvd2VkRmlsZVR5cGVzLnNwbGl0KCcsJyk7XG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZUxpc3QpIHtcbiAgICAgIC8vIGNoZWNrIGlmIGZpbGUgaXMgYWxsb3dlZCBvciBub3RcbiAgICAgIGlmICghYWxsb3dlZFR5cGVzLmluY2x1ZGVzKGZpbGUudHlwZSkpIHtcbiAgICAgICAgLy8gYWRkIHRvIHVuYWNjZXB0ZWQgZmlsZXMgbGlzdCBpZiBmaWxlIGlzIG5vdCBhbGxvd2VkXG4gICAgICAgIHVuYWNjZXB0ZWRGaWxlc0xpc3QucHVzaChmaWxlKTtcblxuICAgICAgICB0aGlzLmZpbGVSZXN1bHQucHVzaCh7XG4gICAgICAgICAgZmlsZVNpemU6IDAsXG4gICAgICAgICAgZmlsZVNpemVEZXNjOiAnMCBiJyxcbiAgICAgICAgICBlcnJvck1lc3NhZ2U6IHVwbG9hZEVycm9yPy5mb3JtYXRFcnJvck1zZyA/PyAnVGhlIGZpbGUgdHlwZSBzZWxlY3RlZCBpcyBub3QgYWxsb3dlZC4nLFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIGFkZCB0byBhY2NlcHRlZCBmaWxlcyBsaXN0IGlmIGZpbGUgaXMgbm90IGFsbG93ZWRcbiAgICAgICAgYWNjZXB0ZWRGaWxlc0xpc3QucHVzaChmaWxlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGZpbGUgb2YgYWNjZXB0ZWRGaWxlc0xpc3QpIHtcbiAgICAgIC8vIGNhbGxpbmcgZ2V0IGZpbGUgcmVzdWx0IG1ldGhvZFxuICAgICAgdGhpcy5maWxlUmVzdWx0LnB1c2godGhpcy5nZXRGaWxlUmVzdWx0KG1heExpbWl0LCB1cGxvYWRFcnJvciwgZmlsZSkpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmZpbGVSZXN1bHQubGVuZ3RoID4gMCAmJiB0aGlzLmZpbGVSZXN1bHRbMF0uZXJyb3JNZXNzYWdlICE9IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5fc2VsZWN0ZWRGaWxlcy5zZXQoW10pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9zZWxlY3RlZEZpbGVzLnNldChhY2NlcHRlZEZpbGVzTGlzdCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRoaXMuX3NlbGVjdGVkRmlsZXM7XG4gIH1cblxuICAvKipcbiAgICogZGVsZXRlRmlsZVxuICAgKlxuICAgKiBUaGlzIGZ1bmN0aW9uIHdpbGwgZGVsZXRlIHRoZSBmaWxlIGF0IHNlbGVjdGVkIGluZGV4XG4gICAqXG4gICAqIEBwYXJhbSBpbmRleFxuICAgKlxuICAgKiBAcmV0dXJucyBzZWxlY3RlZCBmaWxlcyBhcyBvYnNlcnZhYmxlXG4gICAqL1xuICBwdWJsaWMgZGVsZXRlRmlsZShpbmRleDogbnVtYmVyKSB7XG4gICAgdGhpcy5maWxlUmVzdWx0ID0gW107XG4gICAgdGhpcy5fc2VsZWN0ZWRGaWxlcygpLnNwbGljZShpbmRleCwgMSk7XG5cbiAgICByZXR1cm4gdGhpcy5fc2VsZWN0ZWRGaWxlcztcbiAgfVxuXG4gIC8qKlxuICAgKiBnZXQgZmlsZSBzaXplXG4gICAqXG4gICAqIHRoaXMgbWV0aG9kIHdpbGwgcmVzdWx0IHRoZSBzaXplIG9mIHRoZSBmaWxlXG4gICAqXG4gICAqIEBwYXJhbSAgbWF4TGltaXRcbiAgICpcbiAgICogQHBhcmFtIGZpbGVcbiAgICpcbiAgICogQHJldHVybnMgc2l6ZSBvZiB0aGUgZmlsZSBpbiBiIG9yIGtiIG9yIG1iIG9yIGdiXG4gICAqL1xuICBwdWJsaWMgZ2V0RmlsZVJlc3VsdChtYXhMaW1pdDogbnVtYmVyLCB1cGxvYWRFcnJvcj86IElDbFVwbG9hZEVycm9yLCBmaWxlPzogRmlsZSk6IENsRmlsZVJlc3VsdCB7XG4gICAgaWYgKGZpbGUgPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4geyBmaWxlU2l6ZTogMCwgZmlsZVNpemVEZXNjOiAnMCBiJyB9O1xuICAgIH1cblxuICAgIGNvbnN0IHNpemU6IG51bWJlciA9IGZpbGUuc2l6ZTtcblxuICAgIGlmIChzaXplID09PSAwKSB7XG4gICAgICByZXR1cm4geyBmaWxlU2l6ZTogMCwgZmlsZVNpemVEZXNjOiAnMCBiJyB9O1xuICAgIH1cblxuICAgIGNvbnN0IGJhc2UgPSAxMDI0O1xuICAgIGNvbnN0IHVuaXRzID0gWydiJywgJ2tiJywgJ21iJywgJ2diJ107XG5cbiAgICBjb25zdCBzaXplSW5LYiA9IHNpemUgLyBiYXNlO1xuICAgIGNvbnN0IGRpc3BsYXlTaXplSW5LYiA9IE1hdGgubG9nKHNpemUpIC8gTWF0aC5sb2coYmFzZSk7XG5cbiAgICBjb25zdCBpID0gTWF0aC5mbG9vcihkaXNwbGF5U2l6ZUluS2IpO1xuICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IHNpemVJbktiID4gbWF4TGltaXQgPyAnRmlsZSBzaXplIGhhcyBleGNlZWRlZCBtYXggbGltaXQnIDogdW5kZWZpbmVkO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGZpbGVTaXplOiArZGlzcGxheVNpemVJbktiLnRvRml4ZWQoMiksXG4gICAgICBmaWxlU2l6ZURlc2M6IGAkeyAoc2l6ZSAvIE1hdGgucG93KGJhc2UsIGkpKS50b0ZpeGVkKDIpIH0gJHsgdW5pdHNbaV0gfWAsXG4gICAgICBlcnJvck1lc3NhZ2U6IHNpemVJbktiID4gbWF4TGltaXQgPyAodXBsb2FkRXJyb3I/LmZpbGVTaXplRXJyb3JNc2cgPz8gZXJyb3JNZXNzYWdlKSA6IHVuZGVmaW5lZCxcbiAgICB9O1xuICB9XG59XG4iXX0=