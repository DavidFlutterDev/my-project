import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormField, MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, Input, Optional, Self, ViewChild } from '@angular/core';
import { ClBaseComponent } from '@clay/ui-components/shared';
import { ClTextareaProperties } from './textarea.properties';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/input";
import * as i4 from "@angular/material/form-field";
export class ClTextareaComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClTextareaProperties();
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.hintOrErrorTextDivElement = this.hintOrErrorTextDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    onValueChange(ev) {
        let value = ev.value;
        this.writeValue(value);
        this.onChange(this._value);
        if (this.properties.onValueChange) {
            this.properties.onValueChange(this._value);
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextareaComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTextareaComponent, isStandalone: true, selector: "cl-textarea", inputs: { properties: "properties" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <textarea matInput #textarea [value]=\"value\" [disabled]=\"disabled\" [rows]=\"properties.rows\"\n    [type]=\"properties.behaviorType!\" [minLength]=\"properties.minLength\" [maxLength]=\"properties.maxLength\"\n    [placeholder]=\"properties.placeholder!\" (input)=\"onValueChange($event.target)\"\n    (blur)=\"onTouched($any($event.target).value)\" (keyup)=\"writeValue($any($event.target).value)\">\n  </textarea>\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"flex w-full items-center justify-between {{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  <!-- <div #hintOrErrorTextDiv class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n    <mat-error class=\"w-full\">{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint class=\"w-full\">{{ properties.hintText }}</mat-hint>\n  }\n\n  @if (properties.showCounter && properties.maxLength) {\n    <div #counterTextDiv class=\"flex place-content-end {{ error ? 'w-1/4' : 'w-full' }}\">{{ textarea.value ? textarea.value.length : 0 }} / {{ properties.maxLength }}</div>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i3.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTextareaComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-textarea', imports: [
                        FormsModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  [floatLabel]=\"properties.floatLabel!\" class=\"{{ properties.style?.cssClasses }}\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <textarea matInput #textarea [value]=\"value\" [disabled]=\"disabled\" [rows]=\"properties.rows\"\n    [type]=\"properties.behaviorType!\" [minLength]=\"properties.minLength\" [maxLength]=\"properties.maxLength\"\n    [placeholder]=\"properties.placeholder!\" (input)=\"onValueChange($event.target)\"\n    (blur)=\"onTouched($any($event.target).value)\" (keyup)=\"writeValue($any($event.target).value)\">\n  </textarea>\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<div class=\"flex w-full items-center justify-between {{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  <!-- <div #hintOrErrorTextDiv class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n  @if (error) {\n    <mat-error class=\"w-full\">{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint class=\"w-full\">{{ properties.hintText }}</mat-hint>\n  }\n\n  @if (properties.showCounter && properties.maxLength) {\n    <div #counterTextDiv class=\"flex place-content-end {{ error ? 'w-1/4' : 'w-full' }}\">{{ textarea.value ? textarea.value.length : 0 }} / {{ properties.maxLength }}</div>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGV4dGFyZWEuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy90ZXh0YXJlYS90ZXh0YXJlYS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL3RleHRhcmVhL3RleHRhcmVhLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQztBQUN2RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSwyQkFBMkIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3ZFLE9BQU8sRUFBd0IsV0FBVyxFQUFhLG1CQUFtQixFQUFvQixNQUFNLGdCQUFnQixDQUFDO0FBQ3JILE9BQU8sRUFBc0MsU0FBUyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUVoSCxPQUFPLEVBQUUsZUFBZSxFQUFrQixNQUFNLDRCQUE0QixDQUFDO0FBQzdFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQzs7Ozs7O0FBcUJ2RSxNQUFNLE9BQU8sbUJBQW9CLFNBQVEsZUFBZTtJQTJCdEQsOENBQThDO0lBRTlDLFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFKckQsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFTakMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDckMsdUdBQXVHO1FBRXZHLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMzQix3REFBd0Q7WUFDeEQsMERBQTBEO1lBQzFELElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVRLFFBQVE7UUFDZixJQUFJLENBQUMsVUFBVSxLQUFLLElBQUksb0JBQW9CLEVBQUUsQ0FBQztRQUMvQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVELGVBQWU7UUFDYixvR0FBb0c7UUFDcEcsb0ZBQW9GO1FBQ3BGLHlJQUF5STtRQUV6SSxpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRW5CLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRTFELGlEQUFpRDtRQUNqRCxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsYUFBYyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRTtZQUM1RCxJQUFJLE9BQU8sS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7Z0JBRWxCLGlDQUFpQztnQkFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxxQkFBcUI7UUFDbkIsdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2RixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEdBQTZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQTZCLENBQUM7Z0JBQ3RHLElBQUksQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzdFLENBQUM7WUFFRCxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsQ0FBQztJQUNILENBQUM7SUFFTSxVQUFVLENBQUMsS0FBVTtRQUMxQixJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUN0QixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsRUFBa0I7UUFDeEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUM7SUFDckIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLEVBQWtCO1FBQ3pDLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0lBQ3JCLENBQUM7SUFFRCxJQUFXLEtBQUs7UUFDZCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDcEIsQ0FBQztJQUVPLGFBQWE7UUFDbkIsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFBO1FBQ2xCLENBQUM7SUFDSCxDQUFDO0lBRU8sV0FBVztRQUNqQix5RUFBeUU7UUFFekUsdUVBQXVFO1FBQ3ZFLDJFQUEyRTtRQUUzRSwyRUFBMkU7UUFDM0UsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBRU0sWUFBWSxDQUFDLEtBQVU7UUFDNUIsZ0RBQWdEO1FBRWhELHdFQUF3RTtRQUN4RSwwRUFBMEU7UUFFMUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztRQUNwRix3RUFBd0U7SUFDMUUsQ0FBQztJQUVELElBQVcsUUFBUTtRQUNqQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQzFDLElBQUksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDakQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztZQUNsQyxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3BDLENBQUM7UUFFRCxPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRCxJQUFXLFdBQVc7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ3BELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7WUFDckMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN2QyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsYUFBYSxDQUFDLEVBQU87UUFDbkIsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFUSxXQUFXO1FBQ2xCOzs7VUFHRTtRQUVGLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFDeEIsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3BCLHVHQUF1RztJQUN6RyxDQUFDOzhHQTlLVSxtQkFBbUI7a0dBQW5CLG1CQUFtQiwySkFLbkIsWUFBWSx1RUNwQ3pCLHU2REF5Q0Esd0hEbEJJLFdBQVcsOEJBQ1gsYUFBYSxtTEFDYixjQUFjLDJ5QkFDZCxnQkFBZ0IsOEJBQ2hCLG1CQUFtQiwrQkFDbkIsa0JBQWtCOzsyRkFHVCxtQkFBbUI7a0JBbkIvQixTQUFTO2lDQUNJLElBQUksWUFDTixhQUFhLFdBUWQ7d0JBQ1AsV0FBVzt3QkFDWCxhQUFhO3dCQUNiLGNBQWM7d0JBQ2QsZ0JBQWdCO3dCQUNoQixtQkFBbUI7d0JBQ25CLGtCQUFrQjtxQkFDbkI7OzBCQStCYSxRQUFROzswQkFBSSxJQUFJO3lDQTFCZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxZQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBNYXRJY29uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaWNvbic7XG5pbXBvcnQgeyBNYXRUb29sdGlwTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvdG9vbHRpcCc7XG5pbXBvcnQgeyBNYXRGb3JtRmllbGQsIE1hdElucHV0TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaW5wdXQnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1zTW9kdWxlLCBOZ0NvbnRyb2wsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBBZnRlckNvbnRlbnRDaGVja2VkLCBBZnRlclZpZXdJbml0LCBDb21wb25lbnQsIElucHV0LCBPcHRpb25hbCwgU2VsZiwgVmlld0NoaWxkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCwgQ2xFcnJvckhhbmRsZXIgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZCc7XG5pbXBvcnQgeyBDbFRleHRhcmVhUHJvcGVydGllcyB9IGZyb20gJy4vdGV4dGFyZWEucHJvcGVydGllcyc7XG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5pbXBvcnQgeyBnZXRFcnJvck1lc3NhZ2UgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL2Zvcm0tdmFsaWRhdGlvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC10ZXh0YXJlYScsXG4gIHRlbXBsYXRlVXJsOiAnLi90ZXh0YXJlYS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlczogW2BcbiAgICA6aG9zdCB7XG4gICAgICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXSxcbiAgaW1wb3J0czogW1xuICAgIEZvcm1zTW9kdWxlLFxuICAgIE1hdEljb25Nb2R1bGUsXG4gICAgTWF0SW5wdXRNb2R1bGUsXG4gICAgTWF0VG9vbHRpcE1vZHVsZSxcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBDbFRleHRhcmVhQ29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29tcG9uZW50IGltcGxlbWVudHMgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEFmdGVyVmlld0luaXQsIEFmdGVyQ29udGVudENoZWNrZWQge1xuICAvLyBQbGVhc2UgcHV0IGFsbCB0aGUgYW5ndWxhciBkZWNvcmF0ZWQgdmFyaWFibGVzIGJlbG93IHRoaXNcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbFRleHRhcmVhUHJvcGVydGllcztcblxuICBAVmlld0NoaWxkKE1hdEZvcm1GaWVsZClcbiAgcHVibGljIG1hdEZvcm1GaWVsZCE6IE1hdEZvcm1GaWVsZDtcblxuICAvLyBAVmlld0NoaWxkKCdjb3VudGVyVGV4dERpdicpXG4gIC8vIHB1YmxpYyBjb3VudGVyVGV4dERpdkVsZW1lbnRSZWYhOiBFbGVtZW50UmVmO1xuXG4gIC8vIEBWaWV3Q2hpbGQoJ21hdFRleHRGaWVsZCcpXG4gIC8vIHB1YmxpYyBtYXRUZXh0RmllbGREaXZFbGVtZW50UmVmITogRWxlbWVudFJlZjtcblxuICAvLyBAVmlld0NoaWxkKCdoaW50T3JFcnJvclRleHREaXYnKVxuICAvLyBwdWJsaWMgaGludE9yRXJyb3JUZXh0RGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gcHJpdmF0ZSBtYXRUZXh0RmllbGREaXZFbGVtZW50ITogSFRNTERpdkVsZW1lbnQ7XG4gIC8vIHByaXZhdGUgaGludE9yRXJyb3JUZXh0RGl2RWxlbWVudCE6IEhUTUxEaXZFbGVtZW50O1xuXG4gIC8vIFJlcXVpcmVkIHRvIGltcGxlbWVudCBDb250cm9sVmFsdWVBY2Nlc3NvclxuICBwcm90ZWN0ZWQgX3ZhbHVlOiBhbnk7XG4gIHByaXZhdGUgc3ViPzogU3Vic2NyaXB0aW9uO1xuICBwcm90ZWN0ZWQgZXJyb3I/OiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbDtcblxuICBwdWJsaWMgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIHB1YmxpYyBvblRvdWNoZWQgPSAoXzogYW55KSA9PiB7IH07XG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbFRleHRhcmVhUHJvcGVydGllcygpO1xuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgLy8gc2V0dGluZyB0aGUgcmVmZXJlbmNlcyBvZiBOYXRpdmUgRWxlbWVudHMsIHdoaWNoIHdpbGwgYmUgdXNlZCBpbiBzZXRFcnJvclRleHQoKSBhbmQgc2V0SGludFRleHQoKVxuICAgIC8vIHRoaXMuaGludE9yRXJyb3JUZXh0RGl2RWxlbWVudCA9IHRoaXMuaGludE9yRXJyb3JUZXh0RGl2RWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudCA9IHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1hdC1tZGMtdGV4dC1maWVsZC13cmFwcGVyLm1kYy10ZXh0LWZpZWxkJyk7XG5cbiAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG5cbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICAvLyByZW1vdmUgYWxsIHRoZSBlcnJvcnMgd2hlbiB0aGUgc3RhdHVzIGlzIHZhbGlkXG4gICAgdGhpcy5zdWIgPSB0aGlzLm5nQ29udHJvbD8uc3RhdHVzQ2hhbmdlcyEuc3Vic2NyaWJlKGNoYW5nZXMgPT4ge1xuICAgICAgaWYgKGNoYW5nZXMgPT09ICdWQUxJRCcpIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IG51bGw7XG5cbiAgICAgICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgICAgIHRoaXMuc2V0SGludFRleHQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpOiB2b2lkIHtcbiAgICAvLyBiZWxvdyBpcyB0byBhdm9pZCBkaXNwbGF5aW5nICd1bmRlZmluZWQnIG9uIHNjcmVlbiB3aGVuIG1vZGVsIGlzIG5vdCBkZWZpbmVkIC4uIHlldC5cbiAgICB0aGlzLnNldEVtcHR5VmFsdWUoKTtcblxuICAgIC8vIHRyaWdnZXIgdGhlIGVycm9yIHBhdHRlcm4gb25jZSB0aGUgY29udGVudCBpcyBjaGVja2VkXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwgJiYgdGhpcy5uZ0NvbnRyb2wudG91Y2hlZCA9PT0gdHJ1ZSAmJiB0aGlzLm5nQ29udHJvbC5lcnJvcnMpIHtcbiAgICAgIGlmKHRoaXMucHJvcGVydGllcy5pc1JlYWN0aXZlRm9ybUNvbnRyb2wpIHtcbiAgICAgICAgY29uc3Qga2V5czogKGtleW9mIENsRXJyb3JIYW5kbGVyKVtdID0gT2JqZWN0LmtleXModGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSBhcyAoa2V5b2YgQ2xFcnJvckhhbmRsZXIpW107XG4gICAgICAgIHRoaXMuZXJyb3IgPSBnZXRFcnJvck1lc3NhZ2Uoa2V5c1swXSwgdGhpcy5wcm9wZXJ0aWVzLmVycm9yc0xpc3QhKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZXJyb3IgPSB0aGlzLm5nQ29udHJvbC5lcnJvcnMgPyB0aGlzLm5nQ29udHJvbC5lcnJvcnNbJ2Vycm9yJ10gOiBudWxsO1xuICAgICAgfVxuXG4gICAgICAvLyBjYWxsaW5nIHNldCBlcnJvciB0ZXh0IGZ1bmN0aW9uXG4gICAgICB0aGlzLnNldEVycm9yVGV4dCh0aGlzLmVycm9yKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHB1YmxpYyByZWdpc3Rlck9uQ2hhbmdlKGZuOiAoXzogYW55KSA9PiB7fSk6IHZvaWQge1xuICAgIHRoaXMub25DaGFuZ2UgPSBmbjtcbiAgfVxuXG4gIHB1YmxpYyByZWdpc3Rlck9uVG91Y2hlZChmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uVG91Y2hlZCA9IGZuXG4gIH1cblxuICBwdWJsaWMgZ2V0IHZhbHVlKCk6IGFueSB7XG4gICAgcmV0dXJuIHRoaXMuX3ZhbHVlXG4gIH1cblxuICBwcml2YXRlIHNldEVtcHR5VmFsdWUoKSB7XG4gICAgaWYgKHRoaXMuX3ZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuX3ZhbHVlID0gJydcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldEhpbnRUZXh0KCkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IHRoaXMucHJvcGVydGllcy5oaW50VGV4dCA/PyAnJztcblxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21hdC1tZGMtZm9ybS1maWVsZC1oaW50Jyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG5cbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWRjLXRleHQtZmllbGQtLWludmFsaWQnKTtcbiAgICB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ21hdC1mb3JtLWZpZWxkLWludmFsaWQnKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvclRleHQoZXJyb3I6IGFueSkge1xuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50LmlubmVyVGV4dCA9IGVycm9yO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWVycm9yJyk7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcblxuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICB9XG5cbiAgcHVibGljIGdldCBkaXNhYmxlZCgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQ7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuZGlzYWJsZWQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZ2V0IHNob3dJbmZvTXNnKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgIT0gdW5kZWZpbmVkKSB7XG4gICAgICBpZiAodHlwZW9mIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZztcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZygpO1xuICAgIH1cblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIG9uVmFsdWVDaGFuZ2UoZXY6IGFueSkge1xuICAgIGxldCB2YWx1ZSA9IGV2LnZhbHVlO1xuICAgIHRoaXMud3JpdGVWYWx1ZSh2YWx1ZSk7XG4gICAgdGhpcy5vbkNoYW5nZSh0aGlzLl92YWx1ZSk7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uVmFsdWVDaGFuZ2UpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAvKipcbiAgICAqICEhIFdhcm5pbmcgISFcbiAgICAqIFRoZSBiZWxvdyBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgKi9cblxuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG59XG4iLCI8bWF0LWZvcm0tZmllbGQgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiXG4gIFtmbG9hdExhYmVsXT1cInByb3BlcnRpZXMuZmxvYXRMYWJlbCFcIiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIj5cblxuICBAaWYgKHByb3BlcnRpZXMubGFiZWwgIT0gbnVsbCAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9ICcnICYmIHByb3BlcnRpZXMubGFiZWwgIT0gdW5kZWZpbmVkKSB7XG4gICAgPG1hdC1sYWJlbCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICA8c3Bhbj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9zcGFuPlxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwpIHtcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJvcHRpb25hbC10ZXh0XCI+KE9wdGlvbmFsKTwvc3Bhbj5cbiAgICAgIH1cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIlxuICAgICAgICAgIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTppbmZvcm1hdGlvbi1jaXJjbGUnXCIgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgIH1cbiAgICA8L21hdC1sYWJlbD5cbiAgfVxuXG4gIDx0ZXh0YXJlYSBtYXRJbnB1dCAjdGV4dGFyZWEgW3ZhbHVlXT1cInZhbHVlXCIgW2Rpc2FibGVkXT1cImRpc2FibGVkXCIgW3Jvd3NdPVwicHJvcGVydGllcy5yb3dzXCJcbiAgICBbdHlwZV09XCJwcm9wZXJ0aWVzLmJlaGF2aW9yVHlwZSFcIiBbbWluTGVuZ3RoXT1cInByb3BlcnRpZXMubWluTGVuZ3RoXCIgW21heExlbmd0aF09XCJwcm9wZXJ0aWVzLm1heExlbmd0aFwiXG4gICAgW3BsYWNlaG9sZGVyXT1cInByb3BlcnRpZXMucGxhY2Vob2xkZXIhXCIgKGlucHV0KT1cIm9uVmFsdWVDaGFuZ2UoJGV2ZW50LnRhcmdldClcIlxuICAgIChibHVyKT1cIm9uVG91Y2hlZCgkYW55KCRldmVudC50YXJnZXQpLnZhbHVlKVwiIChrZXl1cCk9XCJ3cml0ZVZhbHVlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCI+XG4gIDwvdGV4dGFyZWE+XG48L21hdC1mb3JtLWZpZWxkPlxuXG48IS0tIFRoaXMgZGl2IGlzIHJlcXVpcmVkIHRvIHNob3cgaGludCB0ZXh0IG9yIGVycm9yIG1lc3NhZ2UgZm9yIHRoZSBjb21wb25lbnQgLS0+XG48ZGl2IGNsYXNzPVwiZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB7eyBwcm9wZXJ0aWVzLnN1YnNjcmlwdFNpemluZyA9PT0gJ2ZpeGVkJyA/ICdoLTUnOiAnJyB9fVwiPlxuICA8IS0tIDxkaXYgI2hpbnRPckVycm9yVGV4dERpdiBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3Vic2NyaXB0U2l6aW5nID09PSAnZml4ZWQnID8gJ2gtNSc6ICcnIH19XCI+PC9kaXY+IC0tPlxuICBAaWYgKGVycm9yKSB7XG4gICAgPG1hdC1lcnJvciBjbGFzcz1cInctZnVsbFwiPnt7IGVycm9yIH19PC9tYXQtZXJyb3I+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgICA8bWF0LWhpbnQgY2xhc3M9XCJ3LWZ1bGxcIj57eyBwcm9wZXJ0aWVzLmhpbnRUZXh0IH19PC9tYXQtaGludD5cbiAgfVxuXG4gIEBpZiAocHJvcGVydGllcy5zaG93Q291bnRlciAmJiBwcm9wZXJ0aWVzLm1heExlbmd0aCkge1xuICAgIDxkaXYgI2NvdW50ZXJUZXh0RGl2IGNsYXNzPVwiZmxleCBwbGFjZS1jb250ZW50LWVuZCB7eyBlcnJvciA/ICd3LTEvNCcgOiAndy1mdWxsJyB9fVwiPnt7IHRleHRhcmVhLnZhbHVlID8gdGV4dGFyZWEudmFsdWUubGVuZ3RoIDogMCB9fSAvIHt7IHByb3BlcnRpZXMubWF4TGVuZ3RoIH19PC9kaXY+XG4gIH1cbjwvZGl2PlxuIl19