import { ENTER } from '@angular/cdk/keycodes';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatChipsModule } from '@angular/material/chips';
import { ReactiveFormsModule } from '@angular/forms';
import { Component, EventEmitter, Input, Optional, Output, Self, ViewChild, inject } from '@angular/core';
import { ClChipsInputProperties } from './chips-input.properties';
import { ClBaseComponent, ClComponentTypes } from '@clay/ui-components/shared';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import { getErrorMessage } from '@clay/ui-components/form-validations';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/material/icon";
import * as i3 from "@angular/material/chips";
import * as i4 from "@angular/material/form-field";
export class ClChipsInputComponent extends ClBaseComponent {
    //--------------------------------------------
    constructor(ngControl) {
        /**
         * !! Warning !!
         * The below two super calls are always to be implemented for any component. Otherwise nothing will work.
         */
        super();
        this.ngControl = ngControl;
        // @ViewChild('matTextField')
        // public matTextFieldDivElementRef!: ElementRef;
        // @ViewChild('errorOrHintDivElementRef')
        // public errorOrHintDivElementRef!: ElementRef;
        // private errorOrHintDivElement!: HTMLDivElement;
        // private matTextFieldDivElement!: HTMLDivElement;
        this.optionsAdded = new EventEmitter();
        this.options = [];
        this.announcer = inject(LiveAnnouncer);
        this.separatorKeysCodes = [ENTER];
        this.iconProperties = {
            id: 'chipCloseIcon',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:x-mark',
        };
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        super.setProperties(this.properties);
        //-----------------------------------------------------------------------------------------------------
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    ngOnInit() {
        this.properties ??= new ClChipsInputProperties();
        this.options = this.properties?.options ?? [];
        super.ngOnInit();
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        this.valueChangesSub = this.ngControl?.valueChanges?.subscribe((value) => {
            if (this._value != value) {
                this.writeValue(value);
            }
            if (value) {
                if (value.length > 0 && this.options != value) {
                    this.options = value;
                }
            }
        });
        super.subscribeToValueChanges(this.writeValue.bind(this));
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe(changes => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    ngAfterContentChecked() {
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            if (this.properties.isReactiveFormControl) {
                const keys = Object.keys(this.ngControl.errors);
                this.error = getErrorMessage(keys[0], this.properties.errorsList);
            }
            else {
                this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            }
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    add(event) {
        const value = (event.value || '').trim();
        if (value) {
            this.options.push(value);
        }
        // Clear the input value
        event.chipInput.clear();
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    remove(option) {
        const index = this.options.indexOf(option);
        if (index >= 0) {
            this.options.splice(index, 1);
            this.announcer.announce(`Removed $option`);
        }
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    edit(option, event) {
        const value = event.value.trim();
        // Remove option if it no longer has a name
        if (!value) {
            this.remove(option);
            return;
        }
        // Edit existing option
        const index = this.options.indexOf(option);
        if (index >= 0) {
            this.options[index] = value;
        }
        this.writeValue(this.options);
        this.onChange(this._value);
        // calling push selected options
        this.pushSelectedOptions();
    }
    pushSelectedOptions() {
        if (this.properties.onOptionsAdded != undefined) {
            this.properties.onOptionsAdded(this.options);
        }
        this.optionsAdded.emit(this.options);
    }
    get disabled() {
        if (this.properties.disabled != undefined) {
            if (typeof this.properties.disabled == 'boolean') {
                return this.properties.disabled;
            }
            return this.properties.disabled();
        }
        return false;
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        this.valueChangesSub?.unsubscribe();
        // this.valueChanges?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipsInputComponent, deps: [{ token: i1.NgControl, optional: true, self: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClChipsInputComponent, isStandalone: true, selector: "cl-chips-input", inputs: { properties: "properties" }, outputs: { optionsAdded: "optionsAdded" }, viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }], usesInheritance: true, ngImport: i0, template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  class=\"{{ properties.style?.cssClasses }}\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-chip-grid #chipGrid aria-label=\"Enter options\" class=\"max-h-10 overflow-auto\" [disabled]=\"disabled\">\n\n    @for (option of options; track option) {\n      <mat-chip-row [editable]=\"true\" (removed)=\"remove(option)\" (edited)=\"edit(option, $event)\"\n        [aria-description]=\"'press enter to edit ' + option\">\n\n        <span class=\"flex gap-1 items-center\">\n          <mat-label class=\"text-primary-700\">{{ option }}</mat-label>\n\n          <mat-icon (click)=\"remove(option)\" class=\"icon-size-4 text-primary-700\" [svgIcon]=\"'heroicons_outline:x-mark'\">\n          </mat-icon>\n        </span>\n      </mat-chip-row>\n    }\n\n    <input [matChipInputFor]=\"chipGrid\" [matChipInputAddOnBlur]=\"true\" (matChipInputTokenEnd)=\"add($event)\"\n      placeholder=\"{{properties.placeholder}}\" (blur)=\"onTouched($any($event.target).value)\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\" />\n\n  </mat-chip-grid>\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.cl-input-chip-grid{max-height:2.5rem!important;overflow:auto!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i3.MatChipGrid, selector: "mat-chip-grid", inputs: ["disabled", "placeholder", "required", "value", "errorStateMatcher"], outputs: ["change", "valueChange"] }, { kind: "directive", type: i3.MatChipInput, selector: "input[matChipInputFor]", inputs: ["matChipInputFor", "matChipInputAddOnBlur", "matChipInputSeparatorKeyCodes", "placeholder", "id", "disabled"], outputs: ["matChipInputTokenEnd"], exportAs: ["matChipInput", "matChipInputFor"] }, { kind: "component", type: i3.MatChipRow, selector: "mat-chip-row, [mat-chip-row], mat-basic-chip-row, [mat-basic-chip-row]", inputs: ["editable"], outputs: ["edited"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClChipsInputComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-chips-input', imports: [
                        MatIconModule,
                        MatChipsModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        ClTooltipDirective
                    ], template: "<mat-form-field [id]=\"properties.id\" subscriptSizing=\"dynamic\" [appearance]=\"properties.appearance!\"\n  class=\"{{ properties.style?.cssClasses }}\" [floatLabel]=\"properties.floatLabel!\">\n\n  @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n        <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n        <mat-icon [tooltip]=\"properties.infoMsg!\"\n          [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n        </mat-icon>\n      }\n    </mat-label>\n  }\n\n  <mat-chip-grid #chipGrid aria-label=\"Enter options\" class=\"max-h-10 overflow-auto\" [disabled]=\"disabled\">\n\n    @for (option of options; track option) {\n      <mat-chip-row [editable]=\"true\" (removed)=\"remove(option)\" (edited)=\"edit(option, $event)\"\n        [aria-description]=\"'press enter to edit ' + option\">\n\n        <span class=\"flex gap-1 items-center\">\n          <mat-label class=\"text-primary-700\">{{ option }}</mat-label>\n\n          <mat-icon (click)=\"remove(option)\" class=\"icon-size-4 text-primary-700\" [svgIcon]=\"'heroicons_outline:x-mark'\">\n          </mat-icon>\n        </span>\n      </mat-chip-row>\n    }\n\n    <input [matChipInputFor]=\"chipGrid\" [matChipInputAddOnBlur]=\"true\" (matChipInputTokenEnd)=\"add($event)\"\n      placeholder=\"{{properties.placeholder}}\" (blur)=\"onTouched($any($event.target).value)\"\n      [matChipInputSeparatorKeyCodes]=\"separatorKeysCodes\" />\n\n  </mat-chip-grid>\n\n  @if (properties.suffixIcon) {\n    <mat-icon matSuffix class=\"icon-size-5\" [svgIcon]=\"properties.suffixIcon!\">\n    </mat-icon>\n  }\n\n  @if (properties.prefixIcon) {\n    <mat-icon icon matPrefix class=\"icon-size-5\" [svgIcon]=\"properties.prefixIcon!\">\n    </mat-icon>\n  }\n</mat-form-field>\n\n<!-- This div is required to show hint text or error message for the component -->\n<!-- <div #errorOrHintDivElementRef class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\"></div> -->\n<div class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n  @if (error) {\n    <mat-error>{{ error }}</mat-error>\n  }\n\n  @if (properties.hintText) {\n    <mat-hint>{{ properties.hintText }}</mat-hint>\n  }\n</div>\n", styles: [":host{display:flex!important;flex-direction:column!important}.cl-input-chip-grid{max-height:2.5rem!important;overflow:auto!important}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], optionsAdded: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hpcHMtaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Jhc2ljL3NyYy9jaGlwcy1pbnB1dC9jaGlwcy1pbnB1dC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMvc3JjL2NoaXBzLWlucHV0L2NoaXBzLWlucHV0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUM5QyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDbEQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBRXZELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxZQUFZLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRixPQUFPLEVBQXlDLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ2hHLE9BQU8sRUFBbUMsbUJBQW1CLEVBQW9CLE1BQU0sZ0JBQWdCLENBQUM7QUFDeEcsT0FBTyxFQUFzQyxTQUFTLEVBQ3BELFlBQVksRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUd4RixPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUNsRSxPQUFPLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFrQixNQUFNLDRCQUE0QixDQUFDO0FBQy9GLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxzQ0FBc0MsQ0FBQzs7Ozs7O0FBdUJ2RSxNQUFNLE9BQU8scUJBQXNCLFNBQVEsZUFBZTtJQXlDeEQsOENBQThDO0lBRTlDLFlBQXdDLFNBQW9CO1FBQzFEOzs7V0FHRztRQUNILEtBQUssRUFBRSxDQUFDO1FBTDhCLGNBQVMsR0FBVCxTQUFTLENBQVc7UUFuQzVELDZCQUE2QjtRQUM3QixpREFBaUQ7UUFFakQseUNBQXlDO1FBQ3pDLGdEQUFnRDtRQUVoRCxrREFBa0Q7UUFDbEQsbURBQW1EO1FBRzVDLGlCQUFZLEdBQTJCLElBQUksWUFBWSxFQUFZLENBQUM7UUFFakUsWUFBTyxHQUFhLEVBQUUsQ0FBQztRQUN2QixjQUFTLEdBQWtCLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUVsRCx1QkFBa0IsR0FBRyxDQUFDLEtBQUssQ0FBVSxDQUFDO1FBRXJDLG1CQUFjLEdBQXFCO1lBQzNDLEVBQUUsRUFBRSxlQUFlO1lBQ25CLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLFFBQVEsRUFBRSwwQkFBMEI7U0FDckMsQ0FBQztRQUtGLGFBQVEsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQzNCLGNBQVMsR0FBRyxDQUFDLENBQU0sRUFBRSxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBYzFCLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3JDLHVHQUF1RztRQUV2RyxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxFQUFFLENBQUM7WUFDM0Isd0RBQXdEO1lBQ3hELDBEQUEwRDtZQUMxRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDdEMsQ0FBQztJQUNILENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLHNCQUFzQixFQUFFLENBQUM7UUFFakQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sSUFBSSxFQUFFLENBQUM7UUFDOUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ25CLENBQUM7SUFFRCxlQUFlO1FBQ2Isb0dBQW9HO1FBQ3BHLDRFQUE0RTtRQUM1RSx5SUFBeUk7UUFFekksaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUVuQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQzVFLElBQUcsSUFBSSxDQUFDLE1BQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QixDQUFDO1lBQ0QsSUFBRyxLQUFLLEVBQUMsQ0FBQztnQkFDUixJQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksS0FBSyxFQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUN2QixDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsS0FBSyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFMUQsaURBQWlEO1FBQ2pELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFjLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzVELElBQUksT0FBTyxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztnQkFFbEIsaUNBQWlDO2dCQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHFCQUFxQjtRQUNuQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2RixJQUFHLElBQUksQ0FBQyxVQUFVLENBQUMscUJBQXFCLEVBQUUsQ0FBQztnQkFDekMsTUFBTSxJQUFJLEdBQTZCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQTZCLENBQUM7Z0JBQ3RHLElBQUksQ0FBQyxLQUFLLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVcsQ0FBQyxDQUFDO1lBQ3JFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQzdFLENBQUM7WUFDRCxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsQ0FBQztJQUNILENBQUM7SUFFTyxXQUFXO1FBQ2pCLHlFQUF5RTtRQUV6RSx1RUFBdUU7UUFDdkUsMkVBQTJFO1FBRTNFLDJFQUEyRTtRQUMzRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0lBQ3pGLENBQUM7SUFFTSxZQUFZLENBQUMsS0FBVTtRQUM1QixnREFBZ0Q7UUFFaEQsd0VBQXdFO1FBQ3hFLDBFQUEwRTtRQUUxRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQ3BGLHdFQUF3RTtJQUMxRSxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDbkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFrQjtRQUNsQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQTtJQUNyQixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFBO0lBQ3BCLENBQUM7SUFFTSxHQUFHLENBQUMsS0FBd0I7UUFDakMsTUFBTSxLQUFLLEdBQVcsQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBRWpELElBQUksS0FBSyxFQUFFLENBQUM7WUFDVixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUMzQixDQUFDO1FBRUQsd0JBQXdCO1FBQ3hCLEtBQUssQ0FBQyxTQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7UUFFekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFFOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFM0IsZ0NBQWdDO1FBQ2hDLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO0lBQzdCLENBQUM7SUFFTSxNQUFNLENBQUMsTUFBYztRQUMxQixNQUFNLEtBQUssR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVuRCxJQUFJLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNmLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztZQUU5QixJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQzdDLENBQUM7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzQixnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVNLElBQUksQ0FBQyxNQUFjLEVBQUUsS0FBeUI7UUFDbkQsTUFBTSxLQUFLLEdBQVcsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUV6QywyQ0FBMkM7UUFDM0MsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ1gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVwQixPQUFPO1FBQ1QsQ0FBQztRQUVELHVCQUF1QjtRQUN2QixNQUFNLEtBQUssR0FBVyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVuRCxJQUFJLEtBQUssSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNmLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQzlCLENBQUM7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMzQixnQ0FBZ0M7UUFDaEMsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7SUFDN0IsQ0FBQztJQUVNLG1CQUFtQjtRQUN4QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQyxDQUFDO1FBRUQsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUFXLFFBQVE7UUFDakIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUMxQyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ2pELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbEMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNwQyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBQ0QsSUFBVyxXQUFXO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7WUFDN0MsSUFBSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDO1lBQ3JDLENBQUM7WUFFRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsQ0FBQztRQUVELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBRUYsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUN4QixJQUFJLENBQUMsZUFBZSxFQUFFLFdBQVcsRUFBRSxDQUFDO1FBQ3BDLG9DQUFvQztRQUVwQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsdUdBQXVHO0lBQ3pHLENBQUM7OEdBdlBVLHFCQUFxQjtrR0FBckIscUJBQXFCLHlNQUlyQixZQUFZLHVFQzFDekIsMDZFQThEQSxtUURqQ0ksYUFBYSxtTEFDYixjQUFjLGdxQkFDZCxnQkFBZ0IsOEJBQ2hCLGtCQUFrQixpdUJBQ2xCLG1CQUFtQiwrQkFDbkIsa0JBQWtCOzsyRkFJVCxxQkFBcUI7a0JBckJqQyxTQUFTO2lDQUNJLElBQUksWUFDTixnQkFBZ0IsV0FTakI7d0JBQ1AsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsa0JBQWtCO3dCQUNsQixtQkFBbUI7d0JBQ25CLGtCQUFrQjtxQkFDbkI7OzBCQThDYSxRQUFROzswQkFBSSxJQUFJO3lDQXpDZCxVQUFVO3NCQUR6QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFJbEIsWUFBWTtzQkFEbEIsU0FBUzt1QkFBQyxZQUFZO2dCQWNoQixZQUFZO3NCQURsQixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRU5URVIgfSBmcm9tICdAYW5ndWxhci9jZGsva2V5Y29kZXMnO1xuaW1wb3J0IHsgTGl2ZUFubm91bmNlciB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9hMTF5JztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMvaW50ZXJuYWwvU3Vic2NyaXB0aW9uJztcbmltcG9ydCB7IE1hdFRvb2x0aXBNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC90b29sdGlwJztcbmltcG9ydCB7IE1hdEZvcm1GaWVsZCwgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZm9ybS1maWVsZCc7XG5pbXBvcnQgeyBNYXRDaGlwRWRpdGVkRXZlbnQsIE1hdENoaXBJbnB1dEV2ZW50LCBNYXRDaGlwc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NoaXBzJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBOZ0NvbnRyb2wsIFJlYWN0aXZlRm9ybXNNb2R1bGUsIFZhbGlkYXRpb25FcnJvcnMgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBBZnRlckNvbnRlbnRDaGVja2VkLCBBZnRlclZpZXdJbml0LCBDb21wb25lbnQsXG4gIEV2ZW50RW1pdHRlciwgSW5wdXQsIE9wdGlvbmFsLCBPdXRwdXQsIFNlbGYsIFZpZXdDaGlsZCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IENsSWNvblByb3BlcnRpZXMgfSBmcm9tICcuLi9pY29uJztcbmltcG9ydCB7IENsQ2hpcHNJbnB1dFByb3BlcnRpZXMgfSBmcm9tICcuL2NoaXBzLWlucHV0LnByb3BlcnRpZXMnO1xuaW1wb3J0IHsgQ2xCYXNlQ29tcG9uZW50LCBDbENvbXBvbmVudFR5cGVzLCBDbEVycm9ySGFuZGxlciB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENsVG9vbHRpcERpcmVjdGl2ZSB9IGZyb20gJ0BjbGF5L2FwcC1zaGVsbC9zdHJ1Y3R1cmFsJztcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBzZWxlY3RvcjogJ2NsLWNoaXBzLWlucHV0JyxcbiAgc3R5bGVVcmw6ICcuL2NoaXBzLWlucHV0LmNvbXBvbmVudC5zY3NzJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NoaXBzLWlucHV0LmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVzOiBbYFxuICAgIDpob3N0IHtcbiAgICAgIGRpc3BsYXk6IGZsZXggIWltcG9ydGFudDtcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW4gIWltcG9ydGFudDtcbiAgICB9XG4gIGBdLFxuICBpbXBvcnRzOiBbXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRDaGlwc01vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBSZWFjdGl2ZUZvcm1zTW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdLFxufSlcblxuZXhwb3J0IGNsYXNzIENsQ2hpcHNJbnB1dENvbXBvbmVudCBleHRlbmRzIENsQmFzZUNvbXBvbmVudCBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBBZnRlclZpZXdJbml0LCBBZnRlckNvbnRlbnRDaGVja2VkIHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbENoaXBzSW5wdXRQcm9wZXJ0aWVzO1xuXG4gIEBWaWV3Q2hpbGQoTWF0Rm9ybUZpZWxkKVxuICBwdWJsaWMgbWF0Rm9ybUZpZWxkITogTWF0Rm9ybUZpZWxkO1xuICBwcml2YXRlIHZhbHVlQ2hhbmdlc1N1Yj86IFN1YnNjcmlwdGlvbjtcblxuICAvLyBAVmlld0NoaWxkKCdtYXRUZXh0RmllbGQnKVxuICAvLyBwdWJsaWMgbWF0VGV4dEZpZWxkRGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gQFZpZXdDaGlsZCgnZXJyb3JPckhpbnREaXZFbGVtZW50UmVmJylcbiAgLy8gcHVibGljIGVycm9yT3JIaW50RGl2RWxlbWVudFJlZiE6IEVsZW1lbnRSZWY7XG5cbiAgLy8gcHJpdmF0ZSBlcnJvck9ySGludERpdkVsZW1lbnQhOiBIVE1MRGl2RWxlbWVudDtcbiAgLy8gcHJpdmF0ZSBtYXRUZXh0RmllbGREaXZFbGVtZW50ITogSFRNTERpdkVsZW1lbnQ7XG5cbiAgQE91dHB1dCgpXG4gIHB1YmxpYyBvcHRpb25zQWRkZWQ6IEV2ZW50RW1pdHRlcjxzdHJpbmdbXT4gPSBuZXcgRXZlbnRFbWl0dGVyPHN0cmluZ1tdPigpO1xuXG4gIHByb3RlY3RlZCBvcHRpb25zOiBzdHJpbmdbXSA9IFtdO1xuICBwcm90ZWN0ZWQgYW5ub3VuY2VyOiBMaXZlQW5ub3VuY2VyID0gaW5qZWN0KExpdmVBbm5vdW5jZXIpO1xuXG4gIHJlYWRvbmx5IHNlcGFyYXRvcktleXNDb2RlcyA9IFtFTlRFUl0gYXMgY29uc3Q7XG5cbiAgcHJvdGVjdGVkIGljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAnY2hpcENsb3NlSWNvbicsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIGljb25OYW1lOiAnaGVyb2ljb25zX291dGxpbmU6eC1tYXJrJyxcbiAgfTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gUmVxdWlyZWQgdG8gaW1wbGVtZW50IENvbnRyb2xWYWx1ZUFjY2Vzc29yXG4gIHByb3RlY3RlZCBfdmFsdWU6IGFueTtcbiAgb25DaGFuZ2UgPSAoXzogYW55KSA9PiB7IH07XG4gIG9uVG91Y2hlZCA9IChfOiBhbnkpID0+IHsgfTtcblxuICBwcml2YXRlIHN1Yj86IFN1YnNjcmlwdGlvbjtcbiAgLy8gcHJpdmF0ZSB2YWx1ZUNoYW5nZXM/OiBTdWJzY3JpcHRpb247XG5cbiAgcHJvdGVjdGVkIGVycm9yPzogVmFsaWRhdGlvbkVycm9ycyB8IG51bGw7XG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cblxuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wpIHtcbiAgICAvKipcbiAgICAgKiAhISBXYXJuaW5nICEhXG4gICAgICogVGhlIGJlbG93IHR3byBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgICovXG4gICAgc3VwZXIoKTtcbiAgICBzdXBlci5zZXRQcm9wZXJ0aWVzKHRoaXMucHJvcGVydGllcyk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gICAgaWYgKHRoaXMubmdDb250cm9sICE9IG51bGwpIHtcbiAgICAgIC8vIFNldHRpbmcgdGhlIHZhbHVlIGFjY2Vzc29yIGRpcmVjdGx5IChpbnN0ZWFkIG9mIHVzaW5nXG4gICAgICAvLyB0aGUgcHJvdmlkZXJzKSB0byBhdm9pZCBydW5uaW5nIGludG8gYSBjaXJjdWxhciBpbXBvcnQuXG4gICAgICB0aGlzLm5nQ29udHJvbC52YWx1ZUFjY2Vzc29yID0gdGhpcztcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLnByb3BlcnRpZXMgPz89IG5ldyBDbENoaXBzSW5wdXRQcm9wZXJ0aWVzKCk7XG5cbiAgICB0aGlzLm9wdGlvbnMgPSB0aGlzLnByb3BlcnRpZXM/Lm9wdGlvbnMgPz8gW107XG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICAvLyBzZXR0aW5nIHRoZSByZWZlcmVuY2VzIG9mIE5hdGl2ZSBFbGVtZW50cywgd2hpY2ggd2lsbCBiZSB1c2VkIGluIHNldEVycm9yVGV4dCgpIGFuZCBzZXRIaW50VGV4dCgpXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQgPSB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudCA9IHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcignLm1hdC1tZGMtdGV4dC1maWVsZC13cmFwcGVyLm1kYy10ZXh0LWZpZWxkJyk7XG5cbiAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICB0aGlzLnNldEhpbnRUZXh0KCk7XG5cbiAgICB0aGlzLnZhbHVlQ2hhbmdlc1N1YiA9IHRoaXMubmdDb250cm9sPy52YWx1ZUNoYW5nZXM/LnN1YnNjcmliZSgodmFsdWU6IGFueSkgPT4ge1xuICAgICAgaWYodGhpcy5fdmFsdWUgIT0gdmFsdWUpIHtcbiAgICAgICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIGlmKHZhbHVlKXtcbiAgICAgICAgaWYodmFsdWUubGVuZ3RoID4gMCAmJiB0aGlzLm9wdGlvbnMgIT0gdmFsdWUpe1xuICAgICAgICAgIHRoaXMub3B0aW9ucyA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBzdXBlci5zdWJzY3JpYmVUb1ZhbHVlQ2hhbmdlcyh0aGlzLndyaXRlVmFsdWUuYmluZCh0aGlzKSk7XG5cbiAgICAvLyByZW1vdmUgYWxsIHRoZSBlcnJvcnMgd2hlbiB0aGUgc3RhdHVzIGlzIHZhbGlkXG4gICAgdGhpcy5zdWIgPSB0aGlzLm5nQ29udHJvbD8uc3RhdHVzQ2hhbmdlcyEuc3Vic2NyaWJlKGNoYW5nZXMgPT4ge1xuICAgICAgaWYgKGNoYW5nZXMgPT09ICdWQUxJRCcpIHtcbiAgICAgICAgdGhpcy5lcnJvciA9IG51bGw7XG5cbiAgICAgICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgICAgIHRoaXMuc2V0SGludFRleHQoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG5nQWZ0ZXJDb250ZW50Q2hlY2tlZCgpOiB2b2lkIHtcbiAgICAvLyB0cmlnZ2VyIHRoZSBlcnJvciBwYXR0ZXJuIG9uY2UgdGhlIGNvbnRlbnQgaXMgY2hlY2tlZFxuICAgIGlmICh0aGlzLm5nQ29udHJvbCAhPSBudWxsICYmIHRoaXMubmdDb250cm9sLnRvdWNoZWQgPT09IHRydWUgJiYgdGhpcy5uZ0NvbnRyb2wuZXJyb3JzKSB7XG4gICAgICBpZih0aGlzLnByb3BlcnRpZXMuaXNSZWFjdGl2ZUZvcm1Db250cm9sKSB7XG4gICAgICAgIGNvbnN0IGtleXM6IChrZXlvZiBDbEVycm9ySGFuZGxlcilbXSA9IE9iamVjdC5rZXlzKHRoaXMubmdDb250cm9sLmVycm9ycykgYXMgKGtleW9mIENsRXJyb3JIYW5kbGVyKVtdO1xuICAgICAgICB0aGlzLmVycm9yID0gZ2V0RXJyb3JNZXNzYWdlKGtleXNbMF0sIHRoaXMucHJvcGVydGllcy5lcnJvcnNMaXN0ISk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmVycm9yID0gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzID8gdGhpcy5uZ0NvbnRyb2wuZXJyb3JzWydlcnJvciddIDogbnVsbDtcbiAgICAgIH1cbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0SGludFRleHQoKSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gdGhpcy5wcm9wZXJ0aWVzLmhpbnRUZXh0ID8/ICcnO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcblxuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICB9XG5cbiAgcHVibGljIHNldEVycm9yVGV4dChlcnJvcjogYW55KSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gZXJyb3I7XG5cbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtaGludCcpO1xuXG4gICAgdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtZm9ybS1maWVsZC1pbnZhbGlkJyk7XG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21kYy10ZXh0LWZpZWxkLS1pbnZhbGlkJyk7XG4gIH1cblxuICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLl92YWx1ZSA9IHZhbHVlO1xuICB9XG5cbiAgcmVnaXN0ZXJPbkNoYW5nZShmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uQ2hhbmdlID0gZm47XG4gIH1cblxuICByZWdpc3Rlck9uVG91Y2hlZChmbjogKF86IGFueSkgPT4ge30pOiB2b2lkIHtcbiAgICB0aGlzLm9uVG91Y2hlZCA9IGZuXG4gIH1cblxuICBnZXQgdmFsdWUoKTogYW55IHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWVcbiAgfVxuXG4gIHB1YmxpYyBhZGQoZXZlbnQ6IE1hdENoaXBJbnB1dEV2ZW50KTogdm9pZCB7XG4gICAgY29uc3QgdmFsdWU6IHN0cmluZyA9IChldmVudC52YWx1ZSB8fCAnJykudHJpbSgpO1xuXG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICB0aGlzLm9wdGlvbnMucHVzaCh2YWx1ZSk7XG4gICAgfVxuXG4gICAgLy8gQ2xlYXIgdGhlIGlucHV0IHZhbHVlXG4gICAgZXZlbnQuY2hpcElucHV0IS5jbGVhcigpO1xuXG4gICAgdGhpcy53cml0ZVZhbHVlKHRoaXMub3B0aW9ucyk7XG5cbiAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcblxuICAgIC8vIGNhbGxpbmcgcHVzaCBzZWxlY3RlZCBvcHRpb25zXG4gICAgdGhpcy5wdXNoU2VsZWN0ZWRPcHRpb25zKCk7XG4gIH1cblxuICBwdWJsaWMgcmVtb3ZlKG9wdGlvbjogc3RyaW5nKTogdm9pZCB7XG4gICAgY29uc3QgaW5kZXg6IG51bWJlciA9IHRoaXMub3B0aW9ucy5pbmRleE9mKG9wdGlvbik7XG5cbiAgICBpZiAoaW5kZXggPj0gMCkge1xuICAgICAgdGhpcy5vcHRpb25zLnNwbGljZShpbmRleCwgMSk7XG5cbiAgICAgIHRoaXMuYW5ub3VuY2VyLmFubm91bmNlKGBSZW1vdmVkICRvcHRpb25gKTtcbiAgICB9XG5cbiAgICB0aGlzLndyaXRlVmFsdWUodGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcbiAgICAvLyBjYWxsaW5nIHB1c2ggc2VsZWN0ZWQgb3B0aW9uc1xuICAgIHRoaXMucHVzaFNlbGVjdGVkT3B0aW9ucygpO1xuICB9XG5cbiAgcHVibGljIGVkaXQob3B0aW9uOiBzdHJpbmcsIGV2ZW50OiBNYXRDaGlwRWRpdGVkRXZlbnQpIHtcbiAgICBjb25zdCB2YWx1ZTogc3RyaW5nID0gZXZlbnQudmFsdWUudHJpbSgpO1xuXG4gICAgLy8gUmVtb3ZlIG9wdGlvbiBpZiBpdCBubyBsb25nZXIgaGFzIGEgbmFtZVxuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHRoaXMucmVtb3ZlKG9wdGlvbik7XG5cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBFZGl0IGV4aXN0aW5nIG9wdGlvblxuICAgIGNvbnN0IGluZGV4OiBudW1iZXIgPSB0aGlzLm9wdGlvbnMuaW5kZXhPZihvcHRpb24pO1xuXG4gICAgaWYgKGluZGV4ID49IDApIHtcbiAgICAgIHRoaXMub3B0aW9uc1tpbmRleF0gPSB2YWx1ZTtcbiAgICB9XG5cbiAgICB0aGlzLndyaXRlVmFsdWUodGhpcy5vcHRpb25zKTtcbiAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcbiAgICAvLyBjYWxsaW5nIHB1c2ggc2VsZWN0ZWQgb3B0aW9uc1xuICAgIHRoaXMucHVzaFNlbGVjdGVkT3B0aW9ucygpO1xuICB9XG5cbiAgcHVibGljIHB1c2hTZWxlY3RlZE9wdGlvbnMoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vbk9wdGlvbnNBZGRlZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vbk9wdGlvbnNBZGRlZCh0aGlzLm9wdGlvbnMpO1xuICAgIH1cblxuICAgIHRoaXMub3B0aW9uc0FkZGVkLmVtaXQodGhpcy5vcHRpb25zKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXQgZGlzYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5kaXNhYmxlZCAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLmRpc2FibGVkKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHB1YmxpYyBnZXQgc2hvd0luZm9Nc2coKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93SW5mb01zZyAhPSB1bmRlZmluZWQpIHtcbiAgICAgIGlmICh0eXBlb2YgdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnID09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgLyoqXG4gICAgKiAhISBXYXJuaW5nICEhXG4gICAgKiBUaGUgYmVsb3cgc3VwZXIgY2FsbHMgYXJlIGFsd2F5cyB0byBiZSBpbXBsZW1lbnRlZCBmb3IgYW55IGNvbXBvbmVudC4gT3RoZXJ3aXNlIG5vdGhpbmcgd2lsbCB3b3JrLlxuICAgICovXG5cbiAgICB0aGlzLnN1Yj8udW5zdWJzY3JpYmUoKTtcbiAgICB0aGlzLnZhbHVlQ2hhbmdlc1N1Yj8udW5zdWJzY3JpYmUoKTtcbiAgICAvLyB0aGlzLnZhbHVlQ2hhbmdlcz8udW5zdWJzY3JpYmUoKTtcblxuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG59XG4iLCI8bWF0LWZvcm0tZmllbGQgW2lkXT1cInByb3BlcnRpZXMuaWRcIiBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgW2FwcGVhcmFuY2VdPVwicHJvcGVydGllcy5hcHBlYXJhbmNlIVwiXG4gIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdHlsZT8uY3NzQ2xhc3NlcyB9fVwiIFtmbG9hdExhYmVsXT1cInByb3BlcnRpZXMuZmxvYXRMYWJlbCFcIj5cblxuICBAaWYgKHByb3BlcnRpZXMubGFiZWwgIT0gbnVsbCAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9ICcnICYmIHByb3BlcnRpZXMubGFiZWwgIT0gdW5kZWZpbmVkKSB7XG4gICAgPG1hdC1sYWJlbCBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICA8c3Bhbj57eyBwcm9wZXJ0aWVzLmxhYmVsIH19PC9zcGFuPlxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwpIHtcbiAgICAgICAgPHNwYW4gY2xhc3M9XCJvcHRpb25hbC10ZXh0XCI+KE9wdGlvbmFsKTwvc3Bhbj5cbiAgICAgIH1cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLmluZm9Nc2cgJiYgc2hvd0luZm9Nc2cpIHtcbiAgICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIlxuICAgICAgICAgIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTppbmZvcm1hdGlvbi1jaXJjbGUnXCIgY2xhc3M9XCJtbC0xIGljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyIHRleHQtbmV1dHJhbC02MDBcIj5cbiAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgIH1cbiAgICA8L21hdC1sYWJlbD5cbiAgfVxuXG4gIDxtYXQtY2hpcC1ncmlkICNjaGlwR3JpZCBhcmlhLWxhYmVsPVwiRW50ZXIgb3B0aW9uc1wiIGNsYXNzPVwibWF4LWgtMTAgb3ZlcmZsb3ctYXV0b1wiIFtkaXNhYmxlZF09XCJkaXNhYmxlZFwiPlxuXG4gICAgQGZvciAob3B0aW9uIG9mIG9wdGlvbnM7IHRyYWNrIG9wdGlvbikge1xuICAgICAgPG1hdC1jaGlwLXJvdyBbZWRpdGFibGVdPVwidHJ1ZVwiIChyZW1vdmVkKT1cInJlbW92ZShvcHRpb24pXCIgKGVkaXRlZCk9XCJlZGl0KG9wdGlvbiwgJGV2ZW50KVwiXG4gICAgICAgIFthcmlhLWRlc2NyaXB0aW9uXT1cIidwcmVzcyBlbnRlciB0byBlZGl0ICcgKyBvcHRpb25cIj5cblxuICAgICAgICA8c3BhbiBjbGFzcz1cImZsZXggZ2FwLTEgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPG1hdC1sYWJlbCBjbGFzcz1cInRleHQtcHJpbWFyeS03MDBcIj57eyBvcHRpb24gfX08L21hdC1sYWJlbD5cblxuICAgICAgICAgIDxtYXQtaWNvbiAoY2xpY2spPVwicmVtb3ZlKG9wdGlvbilcIiBjbGFzcz1cImljb24tc2l6ZS00IHRleHQtcHJpbWFyeS03MDBcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6eC1tYXJrJ1wiPlxuICAgICAgICAgIDwvbWF0LWljb24+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgIDwvbWF0LWNoaXAtcm93PlxuICAgIH1cblxuICAgIDxpbnB1dCBbbWF0Q2hpcElucHV0Rm9yXT1cImNoaXBHcmlkXCIgW21hdENoaXBJbnB1dEFkZE9uQmx1cl09XCJ0cnVlXCIgKG1hdENoaXBJbnB1dFRva2VuRW5kKT1cImFkZCgkZXZlbnQpXCJcbiAgICAgIHBsYWNlaG9sZGVyPVwie3twcm9wZXJ0aWVzLnBsYWNlaG9sZGVyfX1cIiAoYmx1cik9XCJvblRvdWNoZWQoJGFueSgkZXZlbnQudGFyZ2V0KS52YWx1ZSlcIlxuICAgICAgW21hdENoaXBJbnB1dFNlcGFyYXRvcktleUNvZGVzXT1cInNlcGFyYXRvcktleXNDb2Rlc1wiIC8+XG5cbiAgPC9tYXQtY2hpcC1ncmlkPlxuXG4gIEBpZiAocHJvcGVydGllcy5zdWZmaXhJY29uKSB7XG4gICAgPG1hdC1pY29uIG1hdFN1ZmZpeCBjbGFzcz1cImljb24tc2l6ZS01XCIgW3N2Z0ljb25dPVwicHJvcGVydGllcy5zdWZmaXhJY29uIVwiPlxuICAgIDwvbWF0LWljb24+XG4gIH1cblxuICBAaWYgKHByb3BlcnRpZXMucHJlZml4SWNvbikge1xuICAgIDxtYXQtaWNvbiBpY29uIG1hdFByZWZpeCBjbGFzcz1cImljb24tc2l6ZS01XCIgW3N2Z0ljb25dPVwicHJvcGVydGllcy5wcmVmaXhJY29uIVwiPlxuICAgIDwvbWF0LWljb24+XG4gIH1cbjwvbWF0LWZvcm0tZmllbGQ+XG5cbjwhLS0gVGhpcyBkaXYgaXMgcmVxdWlyZWQgdG8gc2hvdyBoaW50IHRleHQgb3IgZXJyb3IgbWVzc2FnZSBmb3IgdGhlIGNvbXBvbmVudCAtLT5cbjwhLS0gPGRpdiAjZXJyb3JPckhpbnREaXZFbGVtZW50UmVmIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj48L2Rpdj4gLS0+XG48ZGl2IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgQGlmIChlcnJvcikge1xuICAgIDxtYXQtZXJyb3I+e3sgZXJyb3IgfX08L21hdC1lcnJvcj5cbiAgfVxuXG4gIEBpZiAocHJvcGVydGllcy5oaW50VGV4dCkge1xuICAgIDxtYXQtaGludD57eyBwcm9wZXJ0aWVzLmhpbnRUZXh0IH19PC9tYXQtaGludD5cbiAgfVxuPC9kaXY+XG4iXX0=