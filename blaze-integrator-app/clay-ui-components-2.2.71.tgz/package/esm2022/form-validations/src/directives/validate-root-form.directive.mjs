import { Directive, input } from '@angular/core';
import { NG_ASYNC_VALIDATORS, } from '@angular/forms';
import { debounceTime, Observable, of, ReplaySubject, Subject, switchMap, take, takeUntil, } from 'rxjs';
import { cloneDeep, set } from '../utils/form-utils';
import * as i0 from "@angular/core";
export class ValidateRootFormDirective {
    constructor() {
        this.validationOptions = input({ debounceTime: 0 });
        this.destroy$$ = new Subject();
        this.formValue = input(null);
        this.suite = input(null);
        /**
         * Whether the root form should be validated or not
         * This will use the field rootForm
         */
        this.validateRootForm = input(false);
        /**
         * Used to debounce formValues to make sure vest isn't triggered all the time
         */
        this.formValueCache = {};
    }
    validate(control) {
        if (!this.suite() || !this.formValue()) {
            return of(null);
        }
        return this.createAsyncValidator('rootForm', this.validationOptions())(control.getRawValue());
    }
    createAsyncValidator(field, validationOptions) {
        if (!this.suite()) {
            return () => of(null);
        }
        return (value) => {
            if (!this.formValue()) {
                return of(null);
            }
            const mod = cloneDeep(value);
            set(mod, field, value); // Update the property with path
            if (!this.formValueCache[field]) {
                this.formValueCache[field] = {
                    sub$$: new ReplaySubject(1), // Keep track of the last model
                };
                this.formValueCache[field].debounced = this.formValueCache[field].sub$$.pipe(debounceTime(validationOptions.debounceTime));
            }
            // Next the latest model in the cache for a certain field
            this.formValueCache[field].sub$$.next(mod);
            return this.formValueCache[field].debounced.pipe(
            // When debounced, take the latest value and perform the asynchronous vest validation
            take(1), switchMap(() => {
                return new Observable((observer) => {
                    this.suite()(mod, field).done((result) => {
                        const errors = result.getErrors()[field];
                        observer.next(errors ? { error: errors[0], errors } : null);
                        observer.complete();
                    });
                });
            }), takeUntil(this.destroy$$));
        };
    }
    ngOnDestroy() {
        this.destroy$$.next();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ValidateRootFormDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "18.2.8", type: ValidateRootFormDirective, isStandalone: true, selector: "form[validateRootForm][formValue][suite]", inputs: { validationOptions: { classPropertyName: "validationOptions", publicName: "validationOptions", isSignal: true, isRequired: false, transformFunction: null }, formValue: { classPropertyName: "formValue", publicName: "formValue", isSignal: true, isRequired: false, transformFunction: null }, suite: { classPropertyName: "suite", publicName: "suite", isSignal: true, isRequired: false, transformFunction: null }, validateRootForm: { classPropertyName: "validateRootForm", publicName: "validateRootForm", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_ASYNC_VALIDATORS,
                useExisting: ValidateRootFormDirective,
                multi: true,
            },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ValidateRootFormDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'form[validateRootForm][formValue][suite]',
                    standalone: true,
                    providers: [
                        {
                            provide: NG_ASYNC_VALIDATORS,
                            useExisting: ValidateRootFormDirective,
                            multi: true,
                        },
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidmFsaWRhdGUtcm9vdC1mb3JtLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9mb3JtLXZhbGlkYXRpb25zL3NyYy9kaXJlY3RpdmVzL3ZhbGlkYXRlLXJvb3QtZm9ybS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQWEsTUFBTSxlQUFlLENBQUM7QUFDNUQsT0FBTyxFQUlMLG1CQUFtQixHQUVwQixNQUFNLGdCQUFnQixDQUFDO0FBQ3hCLE9BQU8sRUFDTCxZQUFZLEVBQ1osVUFBVSxFQUNWLEVBQUUsRUFDRixhQUFhLEVBQ2IsT0FBTyxFQUNQLFNBQVMsRUFDVCxJQUFJLEVBQ0osU0FBUyxHQUNWLE1BQU0sTUFBTSxDQUFDO0FBRWQsT0FBTyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQzs7QUFjckQsTUFBTSxPQUFPLHlCQUF5QjtJQVh0QztRQVlTLHNCQUFpQixHQUFHLEtBQUssQ0FBb0IsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN4RCxjQUFTLEdBQUcsSUFBSSxPQUFPLEVBQVEsQ0FBQztRQUVqQyxjQUFTLEdBQUcsS0FBSyxDQUFXLElBQUksQ0FBQyxDQUFDO1FBQ2xDLFVBQUssR0FBRyxLQUFLLENBSW5CLElBQUksQ0FBQyxDQUFDO1FBRWhCOzs7V0FHRztRQUNhLHFCQUFnQixHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUVoRDs7V0FFRztRQUNjLG1CQUFjLEdBSzNCLEVBQUUsQ0FBQztLQXNEUjtJQXBEUSxRQUFRLENBQ2IsT0FBa0M7UUFFbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDO1lBQ3ZDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xCLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FDcEUsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUNpQixDQUFDO0lBQzNDLENBQUM7SUFFTSxvQkFBb0IsQ0FBQyxLQUFhLEVBQUUsaUJBQW9DO1FBQzdFLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQztZQUNsQixPQUFPLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixDQUFDO1FBQ0QsT0FBTyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQztnQkFDdEIsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDbEIsQ0FBQztZQUNELE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFVLENBQUMsQ0FBQztZQUNsQyxHQUFHLENBQUMsR0FBYSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLGdDQUFnQztZQUNsRSxJQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxHQUFHO29CQUMzQixLQUFLLEVBQUUsSUFBSSxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUUsK0JBQStCO2lCQUM3RCxDQUFDO2dCQUNGLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxjQUFjLENBQ3hELEtBQUssQ0FDTixDQUFDLEtBQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDOUQsQ0FBQztZQUNELHlEQUF5RDtZQUN6RCxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7WUFFNUMsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVUsQ0FBQyxJQUFJO1lBQy9DLHFGQUFxRjtZQUNyRixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQ1AsU0FBUyxDQUFDLEdBQUcsRUFBRTtnQkFDYixPQUFPLElBQUksVUFBVSxDQUFDLENBQUMsUUFBUSxFQUFFLEVBQUU7b0JBQ2pDLElBQUksQ0FBQyxLQUFLLEVBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLEVBQUU7d0JBQ3hDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDekMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBQzVELFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFDdEIsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUF3QyxDQUFDO1lBQzVDLENBQUMsQ0FBQyxFQUNGLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQzFCLENBQUM7UUFDSixDQUFDLENBQUM7SUFDSixDQUFDO0lBRU0sV0FBVztRQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3hCLENBQUM7OEdBOUVVLHlCQUF5QjtrR0FBekIseUJBQXlCLG9wQkFSekI7WUFDVDtnQkFDRSxPQUFPLEVBQUUsbUJBQW1CO2dCQUM1QixXQUFXLEVBQUUseUJBQXlCO2dCQUN0QyxLQUFLLEVBQUUsSUFBSTthQUNaO1NBQ0Y7OzJGQUVVLHlCQUF5QjtrQkFYckMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsMENBQTBDO29CQUNwRCxVQUFVLEVBQUUsSUFBSTtvQkFDaEIsU0FBUyxFQUFFO3dCQUNUOzRCQUNFLE9BQU8sRUFBRSxtQkFBbUI7NEJBQzVCLFdBQVcsMkJBQTJCOzRCQUN0QyxLQUFLLEVBQUUsSUFBSTt5QkFDWjtxQkFDRjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERpcmVjdGl2ZSwgaW5wdXQsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgQWJzdHJhY3RDb250cm9sLFxuICBBc3luY1ZhbGlkYXRvcixcbiAgQXN5bmNWYWxpZGF0b3JGbixcbiAgTkdfQVNZTkNfVkFMSURBVE9SUyxcbiAgVmFsaWRhdGlvbkVycm9ycyxcbn0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHtcbiAgZGVib3VuY2VUaW1lLFxuICBPYnNlcnZhYmxlLFxuICBvZixcbiAgUmVwbGF5U3ViamVjdCxcbiAgU3ViamVjdCxcbiAgc3dpdGNoTWFwLFxuICB0YWtlLFxuICB0YWtlVW50aWwsXG59IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgU3RhdGljU3VpdGUgfSBmcm9tICd2ZXN0JztcbmltcG9ydCB7IGNsb25lRGVlcCwgc2V0IH0gZnJvbSAnLi4vdXRpbHMvZm9ybS11dGlscyc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uT3B0aW9ucyB9IGZyb20gJy4vdmFsaWRhdGlvbi1vcHRpb25zJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnZm9ybVt2YWxpZGF0ZVJvb3RGb3JtXVtmb3JtVmFsdWVdW3N1aXRlXScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE5HX0FTWU5DX1ZBTElEQVRPUlMsXG4gICAgICB1c2VFeGlzdGluZzogVmFsaWRhdGVSb290Rm9ybURpcmVjdGl2ZSxcbiAgICAgIG11bHRpOiB0cnVlLFxuICAgIH0sXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIFZhbGlkYXRlUm9vdEZvcm1EaXJlY3RpdmU8VD4gaW1wbGVtZW50cyBBc3luY1ZhbGlkYXRvciwgT25EZXN0cm95IHtcbiAgcHVibGljIHZhbGlkYXRpb25PcHRpb25zID0gaW5wdXQ8VmFsaWRhdGlvbk9wdGlvbnM+KHsgZGVib3VuY2VUaW1lOiAwIH0pO1xuICBwcml2YXRlIHJlYWRvbmx5IGRlc3Ryb3kkJCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG5cbiAgcHVibGljIHJlYWRvbmx5IGZvcm1WYWx1ZSA9IGlucHV0PFQgfCBudWxsPihudWxsKTtcbiAgcHVibGljIHJlYWRvbmx5IHN1aXRlID0gaW5wdXQ8U3RhdGljU3VpdGU8XG4gICAgc3RyaW5nLFxuICAgIHN0cmluZyxcbiAgICAobW9kZWw6IFQsIGZpZWxkOiBzdHJpbmcpID0+IHZvaWRcbiAgPiB8IG51bGw+KG51bGwpO1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZSByb290IGZvcm0gc2hvdWxkIGJlIHZhbGlkYXRlZCBvciBub3RcbiAgICogVGhpcyB3aWxsIHVzZSB0aGUgZmllbGQgcm9vdEZvcm1cbiAgICovXG4gIHB1YmxpYyByZWFkb25seSB2YWxpZGF0ZVJvb3RGb3JtID0gaW5wdXQoZmFsc2UpO1xuXG4gIC8qKlxuICAgKiBVc2VkIHRvIGRlYm91bmNlIGZvcm1WYWx1ZXMgdG8gbWFrZSBzdXJlIHZlc3QgaXNuJ3QgdHJpZ2dlcmVkIGFsbCB0aGUgdGltZVxuICAgKi9cbiAgcHJpdmF0ZSByZWFkb25seSBmb3JtVmFsdWVDYWNoZToge1xuICAgIFtmaWVsZDogc3RyaW5nXTogUGFydGlhbDx7XG4gICAgICBzdWIkJDogUmVwbGF5U3ViamVjdDx1bmtub3duPjtcbiAgICAgIGRlYm91bmNlZDogT2JzZXJ2YWJsZTxhbnk+O1xuICAgIH0+O1xuICB9ID0ge307XG5cbiAgcHVibGljIHZhbGlkYXRlKFxuICAgIGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbDxhbnksIGFueT5cbiAgKTogT2JzZXJ2YWJsZTxWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbD4ge1xuICAgIGlmICghdGhpcy5zdWl0ZSgpIHx8ICF0aGlzLmZvcm1WYWx1ZSgpKSB7XG4gICAgICByZXR1cm4gb2YobnVsbCk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmNyZWF0ZUFzeW5jVmFsaWRhdG9yKCdyb290Rm9ybScsIHRoaXMudmFsaWRhdGlvbk9wdGlvbnMoKSkoXG4gICAgICBjb250cm9sLmdldFJhd1ZhbHVlKClcbiAgICApIGFzIE9ic2VydmFibGU8VmFsaWRhdGlvbkVycm9ycyB8IG51bGw+O1xuICB9XG5cbiAgcHVibGljIGNyZWF0ZUFzeW5jVmFsaWRhdG9yKGZpZWxkOiBzdHJpbmcsIHZhbGlkYXRpb25PcHRpb25zOiBWYWxpZGF0aW9uT3B0aW9ucyk6IEFzeW5jVmFsaWRhdG9yRm4ge1xuICAgIGlmICghdGhpcy5zdWl0ZSgpKSB7XG4gICAgICByZXR1cm4gKCkgPT4gb2YobnVsbCk7XG4gICAgfVxuICAgIHJldHVybiAodmFsdWU6IGFueSkgPT4ge1xuICAgICAgaWYgKCF0aGlzLmZvcm1WYWx1ZSgpKSB7XG4gICAgICAgIHJldHVybiBvZihudWxsKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1vZCA9IGNsb25lRGVlcCh2YWx1ZSBhcyBUKTtcbiAgICAgIHNldChtb2QgYXMgb2JqZWN0LCBmaWVsZCwgdmFsdWUpOyAvLyBVcGRhdGUgdGhlIHByb3BlcnR5IHdpdGggcGF0aFxuICAgICAgaWYgKCF0aGlzLmZvcm1WYWx1ZUNhY2hlW2ZpZWxkXSkge1xuICAgICAgICB0aGlzLmZvcm1WYWx1ZUNhY2hlW2ZpZWxkXSA9IHtcbiAgICAgICAgICBzdWIkJDogbmV3IFJlcGxheVN1YmplY3QoMSksIC8vIEtlZXAgdHJhY2sgb2YgdGhlIGxhc3QgbW9kZWxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5mb3JtVmFsdWVDYWNoZVtmaWVsZF0uZGVib3VuY2VkID0gdGhpcy5mb3JtVmFsdWVDYWNoZVtcbiAgICAgICAgICBmaWVsZFxuICAgICAgICBdLnN1YiQkIS5waXBlKGRlYm91bmNlVGltZSh2YWxpZGF0aW9uT3B0aW9ucy5kZWJvdW5jZVRpbWUpKTtcbiAgICAgIH1cbiAgICAgIC8vIE5leHQgdGhlIGxhdGVzdCBtb2RlbCBpbiB0aGUgY2FjaGUgZm9yIGEgY2VydGFpbiBmaWVsZFxuICAgICAgdGhpcy5mb3JtVmFsdWVDYWNoZVtmaWVsZF0uc3ViJCQhLm5leHQobW9kKTtcblxuICAgICAgcmV0dXJuIHRoaXMuZm9ybVZhbHVlQ2FjaGVbZmllbGRdLmRlYm91bmNlZCEucGlwZShcbiAgICAgICAgLy8gV2hlbiBkZWJvdW5jZWQsIHRha2UgdGhlIGxhdGVzdCB2YWx1ZSBhbmQgcGVyZm9ybSB0aGUgYXN5bmNocm9ub3VzIHZlc3QgdmFsaWRhdGlvblxuICAgICAgICB0YWtlKDEpLFxuICAgICAgICBzd2l0Y2hNYXAoKCkgPT4ge1xuICAgICAgICAgIHJldHVybiBuZXcgT2JzZXJ2YWJsZSgob2JzZXJ2ZXIpID0+IHtcbiAgICAgICAgICAgIHRoaXMuc3VpdGUoKSEobW9kLCBmaWVsZCkuZG9uZSgocmVzdWx0KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IHJlc3VsdC5nZXRFcnJvcnMoKVtmaWVsZF07XG4gICAgICAgICAgICAgIG9ic2VydmVyLm5leHQoZXJyb3JzID8geyBlcnJvcjogZXJyb3JzWzBdLCBlcnJvcnMgfSA6IG51bGwpO1xuICAgICAgICAgICAgICBvYnNlcnZlci5jb21wbGV0ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSkgYXMgT2JzZXJ2YWJsZTxWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbD47XG4gICAgICAgIH0pLFxuICAgICAgICB0YWtlVW50aWwodGhpcy5kZXN0cm95JCQpXG4gICAgICApO1xuICAgIH07XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy5kZXN0cm95JCQubmV4dCgpO1xuICB9XG59XG4iXX0=