import { Directive, inject, input } from '@angular/core';
import { NG_ASYNC_VALIDATORS, } from '@angular/forms';
import { FormDirective } from './form.directive';
import { getFormGroupField } from '../utils/form-utils';
import * as i0 from "@angular/core";
/**
 * Hooks into the ngModelGroup selector and triggers an asynchronous validation for a form group
 * It will use a vest suite behind the scenes
 */
export class FormModelGroupDirective {
    constructor() {
        this.validationOptions = input({ debounceTime: 0 });
        this.formDirective = inject(FormDirective);
    }
    validate(control) {
        const { ngForm } = this.formDirective;
        const field = getFormGroupField(ngForm.control, control);
        return this.formDirective.createAsyncValidator(field, this.validationOptions())(control.value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormModelGroupDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "18.2.8", type: FormModelGroupDirective, isStandalone: true, selector: "[ngModelGroup]", inputs: { validationOptions: { classPropertyName: "validationOptions", publicName: "validationOptions", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_ASYNC_VALIDATORS,
                useExisting: FormModelGroupDirective,
                multi: true,
            },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormModelGroupDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngModelGroup]',
                    standalone: true,
                    providers: [
                        {
                            provide: NG_ASYNC_VALIDATORS,
                            useExisting: FormModelGroupDirective,
                            multi: true,
                        },
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1tb2RlbC1ncm91cC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucy9zcmMvZGlyZWN0aXZlcy9mb3JtLW1vZGVsLWdyb3VwLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUdMLG1CQUFtQixHQUVwQixNQUFNLGdCQUFnQixDQUFDO0FBQ3hCLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUVqRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQzs7QUFHeEQ7OztHQUdHO0FBWUgsTUFBTSxPQUFPLHVCQUF1QjtJQVhwQztRQVlTLHNCQUFpQixHQUFHLEtBQUssQ0FBb0IsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN4RCxrQkFBYSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQVd4RDtJQVRRLFFBQVEsQ0FDYixPQUF3QjtRQUV4QixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN0QyxNQUFNLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3pELE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FDN0UsT0FBTyxDQUFDLEtBQUssQ0FDeUIsQ0FBQztJQUMzQyxDQUFDOzhHQVpVLHVCQUF1QjtrR0FBdkIsdUJBQXVCLHFPQVJ2QjtZQUNUO2dCQUNFLE9BQU8sRUFBRSxtQkFBbUI7Z0JBQzVCLFdBQVcsRUFBRSx1QkFBdUI7Z0JBQ3BDLEtBQUssRUFBRSxJQUFJO2FBQ1o7U0FDRjs7MkZBRVUsdUJBQXVCO2tCQVhuQyxTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSxnQkFBZ0I7b0JBQzFCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixTQUFTLEVBQUU7d0JBQ1Q7NEJBQ0UsT0FBTyxFQUFFLG1CQUFtQjs0QkFDNUIsV0FBVyx5QkFBeUI7NEJBQ3BDLEtBQUssRUFBRSxJQUFJO3lCQUNaO3FCQUNGO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBpbmplY3QsIGlucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICBBYnN0cmFjdENvbnRyb2wsXG4gIEFzeW5jVmFsaWRhdG9yLFxuICBOR19BU1lOQ19WQUxJREFUT1JTLFxuICBWYWxpZGF0aW9uRXJyb3JzLFxufSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBGb3JtRGlyZWN0aXZlIH0gZnJvbSAnLi9mb3JtLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBnZXRGb3JtR3JvdXBGaWVsZCB9IGZyb20gJy4uL3V0aWxzL2Zvcm0tdXRpbHMnO1xuaW1wb3J0IHsgVmFsaWRhdGlvbk9wdGlvbnMgfSBmcm9tICcuL3ZhbGlkYXRpb24tb3B0aW9ucyc7XG5cbi8qKlxuICogSG9va3MgaW50byB0aGUgbmdNb2RlbEdyb3VwIHNlbGVjdG9yIGFuZCB0cmlnZ2VycyBhbiBhc3luY2hyb25vdXMgdmFsaWRhdGlvbiBmb3IgYSBmb3JtIGdyb3VwXG4gKiBJdCB3aWxsIHVzZSBhIHZlc3Qgc3VpdGUgYmVoaW5kIHRoZSBzY2VuZXNcbiAqL1xuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW25nTW9kZWxHcm91cF0nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBwcm92aWRlcnM6IFtcbiAgICB7XG4gICAgICBwcm92aWRlOiBOR19BU1lOQ19WQUxJREFUT1JTLFxuICAgICAgdXNlRXhpc3Rpbmc6IEZvcm1Nb2RlbEdyb3VwRGlyZWN0aXZlLFxuICAgICAgbXVsdGk6IHRydWUsXG4gICAgfSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRm9ybU1vZGVsR3JvdXBEaXJlY3RpdmUgaW1wbGVtZW50cyBBc3luY1ZhbGlkYXRvciB7XG4gIHB1YmxpYyB2YWxpZGF0aW9uT3B0aW9ucyA9IGlucHV0PFZhbGlkYXRpb25PcHRpb25zPih7IGRlYm91bmNlVGltZTogMCB9KTtcbiAgcHJpdmF0ZSByZWFkb25seSBmb3JtRGlyZWN0aXZlID0gaW5qZWN0KEZvcm1EaXJlY3RpdmUpO1xuXG4gIHB1YmxpYyB2YWxpZGF0ZShcbiAgICBjb250cm9sOiBBYnN0cmFjdENvbnRyb2xcbiAgKTogT2JzZXJ2YWJsZTxWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbD4ge1xuICAgIGNvbnN0IHsgbmdGb3JtIH0gPSB0aGlzLmZvcm1EaXJlY3RpdmU7XG4gICAgY29uc3QgZmllbGQgPSBnZXRGb3JtR3JvdXBGaWVsZChuZ0Zvcm0uY29udHJvbCwgY29udHJvbCk7XG4gICAgcmV0dXJuIHRoaXMuZm9ybURpcmVjdGl2ZS5jcmVhdGVBc3luY1ZhbGlkYXRvcihmaWVsZCwgdGhpcy52YWxpZGF0aW9uT3B0aW9ucygpKShcbiAgICAgIGNvbnRyb2wudmFsdWVcbiAgICApIGFzIE9ic2VydmFibGU8VmFsaWRhdGlvbkVycm9ycyB8IG51bGw+O1xuICB9XG59XG4iXX0=