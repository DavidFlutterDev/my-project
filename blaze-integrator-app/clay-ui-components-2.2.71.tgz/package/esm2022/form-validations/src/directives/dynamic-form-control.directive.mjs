import { Directive, Input } from '@angular/core';
import { FormControl, NG_VALUE_ACCESSOR, NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export class DynamicFormControlDirective extends NgControl {
    constructor(injector // Use Injector to resolve the ControlValueAccessor dynamically
    ) {
        super();
        this.injector = injector;
        this.valueAccessor = null;
        // Dynamically resolve the valueAccessor (ControlValueAccessor implementation)
        const valueAccessors = this.injector.get(NG_VALUE_ACCESSOR, []);
    }
    ngOnInit() {
        if (this.formGroup && this.controlName) {
            this.formControl = new FormControl('', this.validators);
            this.formGroup.addControl(this.controlName, this.control);
            // Assign the dynamic component as value accessor
            if (this.valueAccessor) {
                this.valueAccessor.registerOnChange(this.control.setValue.bind(this.control));
                this.valueAccessor.registerOnTouched(this.control.markAsTouched.bind(this.control));
            }
        }
    }
    ngOnDestroy() {
        if (this.formGroup && this.controlName) {
            this.formGroup.removeControl(this.controlName);
        }
    }
    get path() {
        return this.controlName ? [this.controlName] : null;
    }
    get control() {
        return this.formControl;
    }
    viewToModelUpdate(newValue) {
        this.valueAccessor?.writeValue(newValue);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicFormControlDirective, deps: [{ token: i0.Injector }], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "18.2.8", type: DynamicFormControlDirective, isStandalone: true, selector: "[clDynamicFormControl]", inputs: { controlName: ["dynamicFormControl", "controlName"], formGroup: "formGroup", validators: "validators" }, providers: [
            {
                provide: NgControl,
                useExisting: DynamicFormControlDirective,
            },
        ], usesInheritance: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DynamicFormControlDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[clDynamicFormControl]',
                    standalone: true,
                    providers: [
                        {
                            provide: NgControl,
                            useExisting: DynamicFormControlDirective,
                        },
                    ],
                }]
        }], ctorParameters: () => [{ type: i0.Injector }], propDecorators: { controlName: [{
                type: Input,
                args: ['dynamicFormControl']
            }], formGroup: [{
                type: Input
            }], validators: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1pYy1mb3JtLWNvbnRyb2wuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Zvcm0tdmFsaWRhdGlvbnMvc3JjL2RpcmVjdGl2ZXMvZHluYW1pYy1mb3JtLWNvbnRyb2wuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQVksS0FBSyxFQUFrQixNQUFNLGVBQWUsQ0FBQztBQUMzRSxPQUFPLEVBQXlDLFdBQVcsRUFBYSxpQkFBaUIsRUFBRSxTQUFTLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQzs7QUFZN0gsTUFBTSxPQUFPLDJCQUE0QixTQUFRLFNBQVM7SUFVeEQsWUFDVSxRQUFrQixDQUFDLCtEQUErRDs7UUFFMUYsS0FBSyxFQUFFLENBQUM7UUFGQSxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBSG5CLGtCQUFhLEdBQWdDLElBQUksQ0FBQztRQU96RCw4RUFBOEU7UUFDOUUsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQ3RDLGlCQUFpQixFQUNqQixFQUFFLENBQ0gsQ0FBQztJQUNKLENBQUM7SUFFRCxRQUFRO1FBQ04sSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFMUQsaURBQWlEO1lBQ2pELElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztnQkFDOUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDdEYsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsV0FBVztRQUNULElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRUQsSUFBYSxJQUFJO1FBQ2YsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0lBQ3RELENBQUM7SUFFRCxJQUFhLE9BQU87UUFDbEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxRQUFhO1FBQzdCLElBQUksQ0FBQyxhQUFhLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzNDLENBQUM7OEdBbkRVLDJCQUEyQjtrR0FBM0IsMkJBQTJCLHVMQVAzQjtZQUNUO2dCQUNFLE9BQU8sRUFBRSxTQUFTO2dCQUNsQixXQUFXLEVBQUUsMkJBQTJCO2FBQ3pDO1NBQ0Y7OzJGQUVVLDJCQUEyQjtrQkFWdkMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0JBQXdCO29CQUNsQyxVQUFVLEVBQUUsSUFBSTtvQkFDaEIsU0FBUyxFQUFFO3dCQUNUOzRCQUNFLE9BQU8sRUFBRSxTQUFTOzRCQUNsQixXQUFXLDZCQUE2Qjt5QkFDekM7cUJBQ0Y7aUJBQ0Y7NkVBRThCLFdBQVc7c0JBQXZDLEtBQUs7dUJBQUMsb0JBQW9CO2dCQUNsQixTQUFTO3NCQUFqQixLQUFLO2dCQUlHLFVBQVU7c0JBQWxCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIEluamVjdG9yLCBJbnB1dCwgT3B0aW9uYWwsIFNlbGYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEFic3RyYWN0Q29udHJvbCwgQ29udHJvbFZhbHVlQWNjZXNzb3IsIEZvcm1Db250cm9sLCBGb3JtR3JvdXAsIE5HX1ZBTFVFX0FDQ0VTU09SLCBOZ0NvbnRyb2wgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tjbER5bmFtaWNGb3JtQ29udHJvbF0nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBwcm92aWRlcnM6IFtcbiAgICB7XG4gICAgICBwcm92aWRlOiBOZ0NvbnRyb2wsXG4gICAgICB1c2VFeGlzdGluZzogRHluYW1pY0Zvcm1Db250cm9sRGlyZWN0aXZlLFxuICAgIH0sXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIER5bmFtaWNGb3JtQ29udHJvbERpcmVjdGl2ZSBleHRlbmRzIE5nQ29udHJvbCB7XG4gIEBJbnB1dCgnZHluYW1pY0Zvcm1Db250cm9sJykgY29udHJvbE5hbWUhOiBzdHJpbmc7XG4gIEBJbnB1dCgpIGZvcm1Hcm91cD86IEZvcm1Hcm91cDtcblxuICBmb3JtQ29udHJvbCE6IEZvcm1Db250cm9sO1xuXG4gIEBJbnB1dCgpIHZhbGlkYXRvcnM/OiBbXTtcblxuICBvdmVycmlkZSB2YWx1ZUFjY2Vzc29yOiBDb250cm9sVmFsdWVBY2Nlc3NvciB8IG51bGwgPSBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgaW5qZWN0b3I6IEluamVjdG9yIC8vIFVzZSBJbmplY3RvciB0byByZXNvbHZlIHRoZSBDb250cm9sVmFsdWVBY2Nlc3NvciBkeW5hbWljYWxseVxuICApIHtcbiAgICBzdXBlcigpO1xuXG4gICAgLy8gRHluYW1pY2FsbHkgcmVzb2x2ZSB0aGUgdmFsdWVBY2Nlc3NvciAoQ29udHJvbFZhbHVlQWNjZXNzb3IgaW1wbGVtZW50YXRpb24pXG4gICAgY29uc3QgdmFsdWVBY2Nlc3NvcnMgPSB0aGlzLmluamVjdG9yLmdldDxDb250cm9sVmFsdWVBY2Nlc3NvcltdPihcbiAgICAgIE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgICAgW11cbiAgICApO1xuICB9XG5cbiAgbmdPbkluaXQoKSB7XG4gICAgaWYgKHRoaXMuZm9ybUdyb3VwICYmIHRoaXMuY29udHJvbE5hbWUpIHtcbiAgICAgIHRoaXMuZm9ybUNvbnRyb2wgPSBuZXcgRm9ybUNvbnRyb2woJycsIHRoaXMudmFsaWRhdG9ycyk7XG4gICAgICB0aGlzLmZvcm1Hcm91cC5hZGRDb250cm9sKHRoaXMuY29udHJvbE5hbWUsIHRoaXMuY29udHJvbCk7XG5cbiAgICAgIC8vIEFzc2lnbiB0aGUgZHluYW1pYyBjb21wb25lbnQgYXMgdmFsdWUgYWNjZXNzb3JcbiAgICAgIGlmICh0aGlzLnZhbHVlQWNjZXNzb3IpIHtcbiAgICAgICAgdGhpcy52YWx1ZUFjY2Vzc29yLnJlZ2lzdGVyT25DaGFuZ2UodGhpcy5jb250cm9sLnNldFZhbHVlLmJpbmQodGhpcy5jb250cm9sKSk7XG4gICAgICAgIHRoaXMudmFsdWVBY2Nlc3Nvci5yZWdpc3Rlck9uVG91Y2hlZCh0aGlzLmNvbnRyb2wubWFya0FzVG91Y2hlZC5iaW5kKHRoaXMuY29udHJvbCkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLmZvcm1Hcm91cCAmJiB0aGlzLmNvbnRyb2xOYW1lKSB7XG4gICAgICB0aGlzLmZvcm1Hcm91cC5yZW1vdmVDb250cm9sKHRoaXMuY29udHJvbE5hbWUpO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIGdldCBwYXRoKCk6IHN0cmluZ1tdIHwgbnVsbCB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbE5hbWUgPyBbdGhpcy5jb250cm9sTmFtZV0gOiBudWxsO1xuICB9XG5cbiAgb3ZlcnJpZGUgZ2V0IGNvbnRyb2woKTogQWJzdHJhY3RDb250cm9sIHtcbiAgICByZXR1cm4gdGhpcy5mb3JtQ29udHJvbDtcbiAgfVxuXG4gIHZpZXdUb01vZGVsVXBkYXRlKG5ld1ZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLnZhbHVlQWNjZXNzb3I/LndyaXRlVmFsdWUobmV3VmFsdWUpO1xuICB9XG59XG4iXX0=