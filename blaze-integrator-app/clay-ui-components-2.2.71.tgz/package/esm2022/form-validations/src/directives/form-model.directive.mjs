import { Directive, inject, input } from '@angular/core';
import { FormGroup, NG_ASYNC_VALIDATORS, FormArray, FormControl } from '@angular/forms';
import { FormDirective } from './form.directive';
import { getFormControlField } from '../utils/form-utils';
import * as i0 from "@angular/core";
/**
 * Hooks into the ngModel selector and triggers an asynchronous validation for a form model
 * It will use a vest suite behind the scenes
 */
export class FormModelDirective {
    constructor() {
        this.validationOptions = input({ debounceTime: 0 });
        this.dynamicControlOptions = input({ dynamicControlName: '', dynamicTree: false, dynamicTreeId: '', deletedNodeIds: [] });
        this.formDirective = inject(FormDirective);
    }
    validate(control) {
        const { ngForm, suite, formValue } = this.formDirective;
        const dynamicControlOptions = this.dynamicControlOptions();
        if (dynamicControlOptions.dynamicTree) {
            if (!dynamicControlOptions.deletedNodeIds.includes(dynamicControlOptions.nodeId)) {
                this.addDynamicTreeControls(control, ngForm, dynamicControlOptions);
            }
        }
        // ngForm.form.addControl(controlName, control);
        // control.setParent(ngForm.form);
        let field = getFormControlField(ngForm.control, control);
        if (dynamicControlOptions.dynamicTree) {
            const path = this.getNestedFormControlPath(ngForm.control, dynamicControlOptions);
            field = path;
        }
        return this.formDirective.createAsyncValidator(field, this.validationOptions(), dynamicControlOptions)(control.getRawValue());
    }
    addDynamicTreeControls(control, ngForm, dynamicControlOptions) {
        if (dynamicControlOptions.dynamicControlName && dynamicControlOptions.dynamicControlName != '' && !control.parent) {
            // update the control in ngForm and add the ngForm as the parent to the control
            const controlName = dynamicControlOptions.dynamicControlName;
            if (dynamicControlOptions.dynamicTreeId != '') {
                // form array added
                if (!ngForm.form.contains('nodes')) {
                    //add the form array at the root level for the first time when using dynamic tree view
                    const formArray = new FormArray([]);
                    ngForm.form.addControl('nodes', formArray);
                }
                // check the length of the formarray
                // step1
                // if it has some length then check whether their is any formgroup with the control matching with the parentId
                let formArray = ngForm.form.get('nodes');
                if (formArray.length) {
                    // if form array has some formgroups inside it
                    if (dynamicControlOptions.parentNodes.length) {
                        // get the matching formGroup;
                        let parentFormGroup = this.findTheFormGroup(formArray, dynamicControlOptions.parentNodes);
                        // after getting the parentFormGroup
                        // check whether it has a nodes formArray
                        if (parentFormGroup.get('nodes')) {
                            // check whether the parentFormGroup has
                            const nodesFormArray = parentFormGroup.get("nodes");
                            // find the form group inside the nodesFormArray
                            let formGroups = nodesFormArray.controls;
                            let formGroup;
                            for (let i = 0; i < formGroups.length; i++) {
                                const controls = formGroups[i].controls;
                                if (controls.hasOwnProperty(dynamicControlOptions.nodeId)) {
                                    formGroup = formGroups[i];
                                }
                            }
                            if (formGroup) {
                                //if formGroup is there
                                // add the control
                                if (!formGroup.get(controlName)) {
                                    formGroup.addControl(controlName, control);
                                    control.setParent(formGroup);
                                }
                            }
                            else {
                                let formGroup = new FormGroup({});
                                formGroup.addControl(dynamicControlOptions.nodeId, new FormControl(''));
                                formGroup.addControl(controlName, control);
                                nodesFormArray.push(formGroup);
                                control.setParent(formGroup);
                            }
                        }
                        else {
                            // there is no nodes formarray inside the formarray
                            // create a new formArray
                            const newFormArray = new FormArray([]);
                            let formGroup = new FormGroup({});
                            formGroup.addControl(dynamicControlOptions.nodeId, new FormControl(''));
                            formGroup.addControl(controlName, control);
                            newFormArray.push(formGroup);
                            control.setParent(formGroup);
                            parentFormGroup.addControl("nodes", newFormArray);
                        }
                        ;
                    }
                    else {
                        // parentNodes are empty but the formarray has some form group means this control should be added to the root formgroup in the form array.
                        const formGroups = formArray.controls;
                        let formGroup;
                        for (let i = 0; i < formGroups.length; i++) {
                            const controls = formGroups[i].controls;
                            if (controls.hasOwnProperty(dynamicControlOptions.nodeId)) {
                                formGroup = formGroups[i];
                            }
                        }
                        if (!formGroup) {
                            let formGroup = new FormGroup({});
                            formGroup.addControl(dynamicControlOptions.nodeId, new FormControl(''));
                            formArray.push(formGroup);
                        }
                        formGroup?.addControl(controlName, control);
                        control.setParent(formGroup);
                    }
                }
                else {
                    // form array is empty
                    // we need to add a formgroup with the controls
                    if (dynamicControlOptions.parentNodes.length == 0) {
                        let formGroup = new FormGroup({});
                        formGroup.addControl(dynamicControlOptions.nodeId, new FormControl(''));
                        formGroup.addControl(controlName, control);
                        formArray.push(formGroup);
                        control.setParent(formGroup);
                    }
                }
            }
        }
    }
    findTheFormGroup(fmArray, parentIds) {
        // for loop the parentIds
        // try to find the formGroup that matches with the id
        // if exists return the formgroup
        let formGroup;
        let formArray;
        parentIds.forEach((parentId, index) => {
            let formGroups;
            if (index == 0) {
                formGroups = fmArray.controls;
            }
            else {
                formGroups = formArray.controls;
            }
            for (let i = 0; i < formGroups.length; i++) {
                const controls = formGroups[i].controls;
                if (controls.hasOwnProperty(parentId)) {
                    formGroup = formGroups[i];
                    if (index == parentIds.length - 1) {
                        return formGroup;
                    }
                    else {
                        formArray = formGroup.get("nodes");
                    }
                }
            }
        });
        return formGroup;
    }
    getNestedFormControlPath(ngForm, dynamicControlOptions) {
        const controlName = dynamicControlOptions.dynamicControlName;
        const parentIds = dynamicControlOptions.parentNodes;
        let controlPath = 'nodes';
        let treeControls = ngForm.get('nodes').controls;
        if (parentIds.length) {
            let formArr = treeControls;
            let addNode = false;
            parentIds.forEach((parentId, index) => {
                const obj = this.getNestedControlPath(formArr, parentId, controlPath, addNode);
                addNode = true;
                controlPath = obj.controlPath;
                formArr = obj.formGroup.controls['nodes'].controls;
                if (index == parentIds.length - 1) {
                    //if its the last index
                    formArr.forEach((formGroup, index) => {
                        if (formGroup.contains(dynamicControlOptions.nodeId)) {
                            // controlPath = controlPath + `.[${index}].${dynamicControlOptions.nodeId}.${controlName}`;
                            controlPath = controlPath + `.nodes[${index}].${controlName}`;
                        }
                    });
                }
            });
        }
        else {
            treeControls.forEach((formGroup, index) => {
                if (formGroup.contains(dynamicControlOptions.nodeId)) {
                    // controlPath = controlPath + `.[${index}].${dynamicControlOptions.nodeId}.${controlName}`;
                    controlPath = controlPath + `[${index}].${controlName}`;
                }
            });
        }
        return controlPath;
    }
    getNestedControlPath(formArr, parentId, controlPath, addNode) {
        // find the formGroup which has the control with the given parentId
        if (formArr.length) {
            for (let i = 0; i < formArr.length; i++) {
                if (formArr[i].controls.hasOwnProperty(parentId)) {
                    //parentFound
                    // controlPath = controlPath+ `.[${i}].${parentId}`;
                    if (addNode) {
                        controlPath = controlPath + `.nodes[${i}]`;
                    }
                    else {
                        controlPath = controlPath + `[${i}]`;
                    }
                    let obj = { controlPath: controlPath, formGroup: formArr[i] };
                    return obj;
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormModelDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "18.2.8", type: FormModelDirective, isStandalone: true, selector: "[ngModel]", inputs: { validationOptions: { classPropertyName: "validationOptions", publicName: "validationOptions", isSignal: true, isRequired: false, transformFunction: null }, dynamicControlOptions: { classPropertyName: "dynamicControlOptions", publicName: "dynamicControlOptions", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            {
                provide: NG_ASYNC_VALIDATORS,
                useExisting: FormModelDirective,
                multi: true,
            },
        ], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FormModelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngModel]',
                    standalone: true,
                    providers: [
                        {
                            provide: NG_ASYNC_VALIDATORS,
                            useExisting: FormModelDirective,
                            multi: true,
                        },
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS1tb2RlbC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvZm9ybS12YWxpZGF0aW9ucy9zcmMvZGlyZWN0aXZlcy9mb3JtLW1vZGVsLmRpcmVjdGl2ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekQsT0FBTyxFQUdMLFNBQVMsRUFDVCxtQkFBbUIsRUFHbkIsU0FBUyxFQUNULFdBQVcsRUFDWixNQUFNLGdCQUFnQixDQUFDO0FBQ3hCLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUVqRCxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQzs7QUFHMUQ7OztHQUdHO0FBWUgsTUFBTSxPQUFPLGtCQUFrQjtJQVgvQjtRQVlTLHNCQUFpQixHQUFHLEtBQUssQ0FBb0IsRUFBRSxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUVsRSwwQkFBcUIsR0FBTyxLQUFLLENBQU0sRUFBRSxrQkFBa0IsRUFBRSxFQUFFLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxhQUFhLEVBQUUsRUFBRSxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUMsQ0FBQyxDQUFDO1FBQ25ILGtCQUFhLEdBQUcsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0tBMk54RDtJQXpOUSxRQUFRLENBQ2IsT0FBd0I7UUFFeEIsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUN4RCxNQUFNLHFCQUFxQixHQUFHLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzNELElBQUcscUJBQXFCLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDckMsSUFBRyxDQUFDLHFCQUFxQixDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztnQkFDaEYsSUFBSSxDQUFDLHNCQUFzQixDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUscUJBQXFCLENBQUMsQ0FBQztZQUN0RSxDQUFDO1FBQ0gsQ0FBQztRQUVELGdEQUFnRDtRQUM5QyxrQ0FBa0M7UUFDcEMsSUFBSSxLQUFLLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN6RCxJQUFHLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDLENBQUM7WUFDbEYsS0FBSyxHQUFHLElBQUksQ0FBQztRQUNmLENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLHFCQUFxQixDQUFDLENBQ3BHLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FDaUIsQ0FBQztJQUMzQyxDQUFDO0lBRUQsc0JBQXNCLENBQUMsT0FBdUIsRUFBRSxNQUFXLEVBQUUscUJBQXlCO1FBQ3BGLElBQUcscUJBQXFCLENBQUMsa0JBQWtCLElBQUkscUJBQXFCLENBQUMsa0JBQWtCLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pILCtFQUErRTtZQUMvRSxNQUFNLFdBQVcsR0FBRyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FBQztZQUM3RCxJQUFHLHFCQUFxQixDQUFDLGFBQWEsSUFBSSxFQUFFLEVBQUUsQ0FBQztnQkFDN0MsbUJBQW1CO2dCQUNuQixJQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztvQkFDbEMsc0ZBQXNGO29CQUN0RixNQUFNLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDcEMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUM3QyxDQUFDO2dCQUVELG9DQUFvQztnQkFDbkMsUUFBUTtnQkFDUiw4R0FBOEc7Z0JBRS9HLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBYyxDQUFDO2dCQUN0RCxJQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDcEIsOENBQThDO29CQUM5QyxJQUFHLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxNQUFNLEVBQUUsQ0FBQzt3QkFDNUMsOEJBQThCO3dCQUM5QixJQUFJLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLHFCQUFxQixDQUFDLFdBQVcsQ0FBQyxDQUFDO3dCQUMxRixvQ0FBb0M7d0JBQ3BDLHlDQUF5Qzt3QkFFekMsSUFBRyxlQUFlLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7NEJBQ2hDLHdDQUF3Qzs0QkFDeEMsTUFBTSxjQUFjLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQzs0QkFDcEQsZ0RBQWdEOzRCQUNoRCxJQUFJLFVBQVUsR0FBUyxjQUFjLENBQUMsUUFBUSxDQUFDOzRCQUMvQyxJQUFJLFNBQWMsQ0FBQzs0QkFDbkIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztnQ0FDM0MsTUFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQ0FDeEMsSUFBRyxRQUFRLENBQUMsY0FBYyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7b0NBQ3pELFNBQVMsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFjLENBQUM7Z0NBQ3pDLENBQUM7NEJBQ0gsQ0FBQzs0QkFHRCxJQUFHLFNBQVMsRUFBRSxDQUFDO2dDQUNiLHVCQUF1QjtnQ0FDdkIsa0JBQWtCO2dDQUNsQixJQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO29DQUMvQixTQUFTLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztvQ0FDM0MsT0FBTyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtnQ0FDOUIsQ0FBQzs0QkFDSCxDQUFDO2lDQUFNLENBQUM7Z0NBQ04sSUFBSSxTQUFTLEdBQWMsSUFBSSxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7Z0NBQzdDLFNBQVMsQ0FBQyxVQUFVLENBQUMscUJBQXFCLENBQUMsTUFBTSxFQUFFLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3hFLFNBQVMsQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dDQUMzQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dDQUMvQixPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDOzRCQUMvQixDQUFDO3dCQUVILENBQUM7NkJBQU0sQ0FBQzs0QkFDTixtREFBbUQ7NEJBQ25ELHlCQUF5Qjs0QkFDekIsTUFBTSxZQUFZLEdBQTBCLElBQUksU0FBUyxDQUFZLEVBQUUsQ0FBQyxDQUFDOzRCQUN6RSxJQUFJLFNBQVMsR0FBYyxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQzs0QkFDN0MsU0FBUyxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzs0QkFDeEUsU0FBUyxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7NEJBQzNDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQzdCLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7NEJBQzdCLGVBQWUsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxDQUFDO3dCQUNwRCxDQUFDO3dCQUFBLENBQUM7b0JBR0osQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLDBJQUEwSTt3QkFDMUksTUFBTSxVQUFVLEdBQVMsU0FBUyxDQUFDLFFBQVEsQ0FBQzt3QkFDNUMsSUFBSSxTQUFjLENBQUM7d0JBQ25CLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUM7NEJBQzNDLE1BQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7NEJBQ3hDLElBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO2dDQUN6RCxTQUFTLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBYyxDQUFDOzRCQUN6QyxDQUFDO3dCQUNILENBQUM7d0JBRUQsSUFBRyxDQUFDLFNBQVMsRUFBRSxDQUFDOzRCQUNkLElBQUksU0FBUyxHQUFlLElBQUksU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDOzRCQUM5QyxTQUFTLENBQUMsVUFBVSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sRUFBRSxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDOzRCQUN4RSxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUM1QixDQUFDO3dCQUVELFNBQVMsRUFBRSxVQUFVLENBQUMsV0FBVyxFQUFFLE9BQU8sQ0FBQyxDQUFBO3dCQUMzQyxPQUFPLENBQUMsU0FBUyxDQUFDLFNBQVUsQ0FBQyxDQUFDO29CQUNoQyxDQUFDO2dCQUVILENBQUM7cUJBQU0sQ0FBQztvQkFDTixzQkFBc0I7b0JBQ3RCLCtDQUErQztvQkFFL0MsSUFBRyxxQkFBcUIsQ0FBQyxXQUFXLENBQUMsTUFBTSxJQUFJLENBQUMsRUFBRSxDQUFDO3dCQUNqRCxJQUFJLFNBQVMsR0FBZSxJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDOUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQzt3QkFDeEUsU0FBUyxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLENBQUM7d0JBRTNDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQzFCLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7b0JBQy9CLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7UUFFSCxDQUFDO0lBR0gsQ0FBQztJQUVELGdCQUFnQixDQUFDLE9BQVksRUFBRSxTQUFjO1FBQzNDLHlCQUF5QjtRQUN6QixxREFBcUQ7UUFDckQsaUNBQWlDO1FBRWpDLElBQUksU0FBYyxDQUFDO1FBQ25CLElBQUksU0FBYyxDQUFDO1FBRW5CLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFZLEVBQUUsS0FBVSxFQUFFLEVBQUU7WUFDN0MsSUFBSSxVQUFlLENBQUE7WUFDbkIsSUFBRyxLQUFLLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2QsVUFBVSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUM7WUFDaEMsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFVBQVUsR0FBRyxTQUFTLENBQUMsUUFBUSxDQUFDO1lBQ2xDLENBQUM7WUFDRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUMzQyxNQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO2dCQUN4QyxJQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztvQkFDckMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQWMsQ0FBQztvQkFDdkMsSUFBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUMsQ0FBQzt3QkFDaEMsT0FBTyxTQUFTLENBQUM7b0JBQ25CLENBQUM7eUJBQU0sQ0FBQzt3QkFDTixTQUFTLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQWMsQ0FBQztvQkFDbEQsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFBO1FBRUYsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVELHdCQUF3QixDQUFDLE1BQVcsRUFBRSxxQkFBeUI7UUFDN0QsTUFBTSxXQUFXLEdBQUcscUJBQXFCLENBQUMsa0JBQWtCLENBQUM7UUFDN0QsTUFBTSxTQUFTLEdBQUcscUJBQXFCLENBQUMsV0FBVyxDQUFDO1FBQ3BELElBQUksV0FBVyxHQUFHLE9BQU8sQ0FBQztRQUMxQixJQUFJLFlBQVksR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQztRQUVoRCxJQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNwQixJQUFJLE9BQU8sR0FBTyxZQUFZLENBQUM7WUFDL0IsSUFBSSxPQUFPLEdBQUcsS0FBSyxDQUFDO1lBQ3BCLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFZLEVBQUUsS0FBYSxFQUFFLEVBQUU7Z0JBQ2hELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDL0UsT0FBTyxHQUFHLElBQUksQ0FBQztnQkFDZixXQUFXLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDOUIsT0FBTyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQztnQkFDbkQsSUFBRyxLQUFLLElBQUksU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztvQkFDakMsdUJBQXVCO29CQUN2QixPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBYyxFQUFFLEtBQWEsRUFBQyxFQUFFO3dCQUMvQyxJQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQzs0QkFDcEQsNEZBQTRGOzRCQUM1RixXQUFXLEdBQUcsV0FBVyxHQUFHLFVBQVUsS0FBSyxLQUFLLFdBQVcsRUFBRSxDQUFDO3dCQUNoRSxDQUFDO29CQUNILENBQUMsQ0FBQyxDQUFBO2dCQUNKLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQW1CLEVBQUUsS0FBWSxFQUFFLEVBQUU7Z0JBQ3pELElBQUcsU0FBUyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO29CQUNwRCw0RkFBNEY7b0JBQzVGLFdBQVcsR0FBRyxXQUFXLEdBQUcsSUFBSSxLQUFLLEtBQUssV0FBVyxFQUFFLENBQUM7Z0JBQzFELENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQTtRQUNKLENBQUM7UUFFRCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQsb0JBQW9CLENBQUMsT0FBYyxFQUFFLFFBQWdCLEVBQUUsV0FBZ0IsRUFBRSxPQUFlO1FBQ3RGLG1FQUFtRTtRQUNuRSxJQUFHLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNsQixLQUFJLElBQUksQ0FBQyxHQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUNyQyxJQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7b0JBQ2hELGFBQWE7b0JBQ2Isb0RBQW9EO29CQUNwRCxJQUFHLE9BQU8sRUFBRSxDQUFDO3dCQUNYLFdBQVcsR0FBRyxXQUFXLEdBQUUsVUFBVSxDQUFDLEdBQUcsQ0FBQztvQkFDNUMsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLFdBQVcsR0FBRyxXQUFXLEdBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQztvQkFDdEMsQ0FBQztvQkFDRCxJQUFJLEdBQUcsR0FBUSxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBQyxDQUFDO29CQUNsRSxPQUFPLEdBQUcsQ0FBQztnQkFDYixDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDOzhHQTlOVSxrQkFBa0I7a0dBQWxCLGtCQUFrQix3WUFSbEI7WUFDVDtnQkFDRSxPQUFPLEVBQUUsbUJBQW1CO2dCQUM1QixXQUFXLEVBQUUsa0JBQWtCO2dCQUMvQixLQUFLLEVBQUUsSUFBSTthQUNaO1NBQ0Y7OzJGQUVVLGtCQUFrQjtrQkFYOUIsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsV0FBVztvQkFDckIsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFNBQVMsRUFBRTt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsbUJBQW1COzRCQUM1QixXQUFXLG9CQUFvQjs0QkFDL0IsS0FBSyxFQUFFLElBQUk7eUJBQ1o7cUJBQ0Y7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIGluamVjdCwgaW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG4gIEFic3RyYWN0Q29udHJvbCxcbiAgQXN5bmNWYWxpZGF0b3IsXG4gIEZvcm1Hcm91cCxcbiAgTkdfQVNZTkNfVkFMSURBVE9SUyxcbiAgVmFsaWRhdGlvbkVycm9ycyxcbiAgQ29udHJvbENvbnRhaW5lcixcbiAgRm9ybUFycmF5LFxuICBGb3JtQ29udHJvbFxufSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBGb3JtRGlyZWN0aXZlIH0gZnJvbSAnLi9mb3JtLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBnZXRGb3JtQ29udHJvbEZpZWxkIH0gZnJvbSAnLi4vdXRpbHMvZm9ybS11dGlscyc7XG5pbXBvcnQgeyBWYWxpZGF0aW9uT3B0aW9ucyB9IGZyb20gJy4vdmFsaWRhdGlvbi1vcHRpb25zJztcblxuLyoqXG4gKiBIb29rcyBpbnRvIHRoZSBuZ01vZGVsIHNlbGVjdG9yIGFuZCB0cmlnZ2VycyBhbiBhc3luY2hyb25vdXMgdmFsaWRhdGlvbiBmb3IgYSBmb3JtIG1vZGVsXG4gKiBJdCB3aWxsIHVzZSBhIHZlc3Qgc3VpdGUgYmVoaW5kIHRoZSBzY2VuZXNcbiAqL1xuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW25nTW9kZWxdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgcHJvdmlkZXJzOiBbXG4gICAge1xuICAgICAgcHJvdmlkZTogTkdfQVNZTkNfVkFMSURBVE9SUyxcbiAgICAgIHVzZUV4aXN0aW5nOiBGb3JtTW9kZWxEaXJlY3RpdmUsXG4gICAgICBtdWx0aTogdHJ1ZSxcbiAgICB9LFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBGb3JtTW9kZWxEaXJlY3RpdmUgaW1wbGVtZW50cyBBc3luY1ZhbGlkYXRvciB7XG4gIHB1YmxpYyB2YWxpZGF0aW9uT3B0aW9ucyA9IGlucHV0PFZhbGlkYXRpb25PcHRpb25zPih7IGRlYm91bmNlVGltZTogMCB9KTtcblxuICBwdWJsaWMgZHluYW1pY0NvbnRyb2xPcHRpb25zOmFueSA9IGlucHV0PGFueT4oeyBkeW5hbWljQ29udHJvbE5hbWU6ICcnLCBkeW5hbWljVHJlZTogZmFsc2UsIGR5bmFtaWNUcmVlSWQ6ICcnLCBkZWxldGVkTm9kZUlkczogW119KTtcbiAgcHJpdmF0ZSByZWFkb25seSBmb3JtRGlyZWN0aXZlID0gaW5qZWN0KEZvcm1EaXJlY3RpdmUpO1xuXG4gIHB1YmxpYyB2YWxpZGF0ZShcbiAgICBjb250cm9sOiBBYnN0cmFjdENvbnRyb2xcbiAgKTogT2JzZXJ2YWJsZTxWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbD4ge1xuICAgIGNvbnN0IHsgbmdGb3JtLCBzdWl0ZSwgZm9ybVZhbHVlIH0gPSB0aGlzLmZvcm1EaXJlY3RpdmU7XG4gICAgY29uc3QgZHluYW1pY0NvbnRyb2xPcHRpb25zID0gdGhpcy5keW5hbWljQ29udHJvbE9wdGlvbnMoKTtcbiAgICBpZihkeW5hbWljQ29udHJvbE9wdGlvbnMuZHluYW1pY1RyZWUpIHtcbiAgICAgIGlmKCFkeW5hbWljQ29udHJvbE9wdGlvbnMuZGVsZXRlZE5vZGVJZHMuaW5jbHVkZXMoZHluYW1pY0NvbnRyb2xPcHRpb25zLm5vZGVJZCkpIHtcbiAgICAgICAgdGhpcy5hZGREeW5hbWljVHJlZUNvbnRyb2xzKGNvbnRyb2wsIG5nRm9ybSwgZHluYW1pY0NvbnRyb2xPcHRpb25zKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBuZ0Zvcm0uZm9ybS5hZGRDb250cm9sKGNvbnRyb2xOYW1lLCBjb250cm9sKTtcbiAgICAgIC8vIGNvbnRyb2wuc2V0UGFyZW50KG5nRm9ybS5mb3JtKTtcbiAgICBsZXQgZmllbGQgPSBnZXRGb3JtQ29udHJvbEZpZWxkKG5nRm9ybS5jb250cm9sLCBjb250cm9sKTtcbiAgICBpZihkeW5hbWljQ29udHJvbE9wdGlvbnMuZHluYW1pY1RyZWUpIHtcbiAgICAgIGNvbnN0IHBhdGggPSB0aGlzLmdldE5lc3RlZEZvcm1Db250cm9sUGF0aChuZ0Zvcm0uY29udHJvbCwgZHluYW1pY0NvbnRyb2xPcHRpb25zKTtcbiAgICAgIGZpZWxkID0gcGF0aDtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5mb3JtRGlyZWN0aXZlLmNyZWF0ZUFzeW5jVmFsaWRhdG9yKGZpZWxkLCB0aGlzLnZhbGlkYXRpb25PcHRpb25zKCksIGR5bmFtaWNDb250cm9sT3B0aW9ucykoXG4gICAgICBjb250cm9sLmdldFJhd1ZhbHVlKClcbiAgICApIGFzIE9ic2VydmFibGU8VmFsaWRhdGlvbkVycm9ycyB8IG51bGw+O1xuICB9XG5cbiAgYWRkRHluYW1pY1RyZWVDb250cm9scyhjb250cm9sOkFic3RyYWN0Q29udHJvbCwgbmdGb3JtOiBhbnksIGR5bmFtaWNDb250cm9sT3B0aW9uczphbnkpIHtcbiAgICBpZihkeW5hbWljQ29udHJvbE9wdGlvbnMuZHluYW1pY0NvbnRyb2xOYW1lICYmIGR5bmFtaWNDb250cm9sT3B0aW9ucy5keW5hbWljQ29udHJvbE5hbWUgIT0gJycgJiYgIWNvbnRyb2wucGFyZW50KSB7XG4gICAgICAvLyB1cGRhdGUgdGhlIGNvbnRyb2wgaW4gbmdGb3JtIGFuZCBhZGQgdGhlIG5nRm9ybSBhcyB0aGUgcGFyZW50IHRvIHRoZSBjb250cm9sXG4gICAgICBjb25zdCBjb250cm9sTmFtZSA9IGR5bmFtaWNDb250cm9sT3B0aW9ucy5keW5hbWljQ29udHJvbE5hbWU7XG4gICAgICBpZihkeW5hbWljQ29udHJvbE9wdGlvbnMuZHluYW1pY1RyZWVJZCAhPSAnJykge1xuICAgICAgICAvLyBmb3JtIGFycmF5IGFkZGVkXG4gICAgICAgIGlmKCFuZ0Zvcm0uZm9ybS5jb250YWlucygnbm9kZXMnKSkge1xuICAgICAgICAgIC8vYWRkIHRoZSBmb3JtIGFycmF5IGF0IHRoZSByb290IGxldmVsIGZvciB0aGUgZmlyc3QgdGltZSB3aGVuIHVzaW5nIGR5bmFtaWMgdHJlZSB2aWV3XG4gICAgICAgICAgY29uc3QgZm9ybUFycmF5ID0gbmV3IEZvcm1BcnJheShbXSk7XG4gICAgICAgICAgbmdGb3JtLmZvcm0uYWRkQ29udHJvbCgnbm9kZXMnLCBmb3JtQXJyYXkpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gY2hlY2sgdGhlIGxlbmd0aCBvZiB0aGUgZm9ybWFycmF5XG4gICAgICAgICAvLyBzdGVwMVxuICAgICAgICAgLy8gaWYgaXQgaGFzIHNvbWUgbGVuZ3RoIHRoZW4gY2hlY2sgd2hldGhlciB0aGVpciBpcyBhbnkgZm9ybWdyb3VwIHdpdGggdGhlIGNvbnRyb2wgbWF0Y2hpbmcgd2l0aCB0aGUgcGFyZW50SWRcblxuICAgICAgICBsZXQgZm9ybUFycmF5ID0gbmdGb3JtLmZvcm0uZ2V0KCdub2RlcycpIGFzIEZvcm1BcnJheTtcbiAgICAgICAgaWYoZm9ybUFycmF5Lmxlbmd0aCkge1xuICAgICAgICAgIC8vIGlmIGZvcm0gYXJyYXkgaGFzIHNvbWUgZm9ybWdyb3VwcyBpbnNpZGUgaXRcbiAgICAgICAgICBpZihkeW5hbWljQ29udHJvbE9wdGlvbnMucGFyZW50Tm9kZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAvLyBnZXQgdGhlIG1hdGNoaW5nIGZvcm1Hcm91cDtcbiAgICAgICAgICAgIGxldCBwYXJlbnRGb3JtR3JvdXAgPSB0aGlzLmZpbmRUaGVGb3JtR3JvdXAoZm9ybUFycmF5LCBkeW5hbWljQ29udHJvbE9wdGlvbnMucGFyZW50Tm9kZXMpO1xuICAgICAgICAgICAgLy8gYWZ0ZXIgZ2V0dGluZyB0aGUgcGFyZW50Rm9ybUdyb3VwXG4gICAgICAgICAgICAvLyBjaGVjayB3aGV0aGVyIGl0IGhhcyBhIG5vZGVzIGZvcm1BcnJheVxuXG4gICAgICAgICAgICBpZihwYXJlbnRGb3JtR3JvdXAuZ2V0KCdub2RlcycpKSB7XG4gICAgICAgICAgICAgIC8vIGNoZWNrIHdoZXRoZXIgdGhlIHBhcmVudEZvcm1Hcm91cCBoYXNcbiAgICAgICAgICAgICAgY29uc3Qgbm9kZXNGb3JtQXJyYXkgPSBwYXJlbnRGb3JtR3JvdXAuZ2V0KFwibm9kZXNcIik7XG4gICAgICAgICAgICAgIC8vIGZpbmQgdGhlIGZvcm0gZ3JvdXAgaW5zaWRlIHRoZSBub2Rlc0Zvcm1BcnJheVxuICAgICAgICAgICAgICBsZXQgZm9ybUdyb3VwcyA6IGFueSA9IG5vZGVzRm9ybUFycmF5LmNvbnRyb2xzO1xuICAgICAgICAgICAgICBsZXQgZm9ybUdyb3VwOiBhbnk7XG4gICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm9ybUdyb3Vwcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbnRyb2xzID0gZm9ybUdyb3Vwc1tpXS5jb250cm9scztcbiAgICAgICAgICAgICAgICBpZihjb250cm9scy5oYXNPd25Qcm9wZXJ0eShkeW5hbWljQ29udHJvbE9wdGlvbnMubm9kZUlkKSkge1xuICAgICAgICAgICAgICAgICAgZm9ybUdyb3VwID0gZm9ybUdyb3Vwc1tpXSBhcyBGb3JtR3JvdXA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgICBpZihmb3JtR3JvdXApIHtcbiAgICAgICAgICAgICAgICAvL2lmIGZvcm1Hcm91cCBpcyB0aGVyZVxuICAgICAgICAgICAgICAgIC8vIGFkZCB0aGUgY29udHJvbFxuICAgICAgICAgICAgICAgIGlmKCFmb3JtR3JvdXAuZ2V0KGNvbnRyb2xOYW1lKSkge1xuICAgICAgICAgICAgICAgICAgZm9ybUdyb3VwLmFkZENvbnRyb2woY29udHJvbE5hbWUsIGNvbnRyb2wpO1xuICAgICAgICAgICAgICAgICAgY29udHJvbC5zZXRQYXJlbnQoZm9ybUdyb3VwKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBsZXQgZm9ybUdyb3VwOiBGb3JtR3JvdXAgPSBuZXcgRm9ybUdyb3VwKHt9KTtcbiAgICAgICAgICAgICAgICBmb3JtR3JvdXAuYWRkQ29udHJvbChkeW5hbWljQ29udHJvbE9wdGlvbnMubm9kZUlkLCBuZXcgRm9ybUNvbnRyb2woJycpKTtcbiAgICAgICAgICAgICAgICBmb3JtR3JvdXAuYWRkQ29udHJvbChjb250cm9sTmFtZSwgY29udHJvbCk7XG4gICAgICAgICAgICAgICAgbm9kZXNGb3JtQXJyYXkucHVzaChmb3JtR3JvdXApO1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuc2V0UGFyZW50KGZvcm1Hcm91cCk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gdGhlcmUgaXMgbm8gbm9kZXMgZm9ybWFycmF5IGluc2lkZSB0aGUgZm9ybWFycmF5XG4gICAgICAgICAgICAgIC8vIGNyZWF0ZSBhIG5ldyBmb3JtQXJyYXlcbiAgICAgICAgICAgICAgY29uc3QgbmV3Rm9ybUFycmF5OiBGb3JtQXJyYXkgPEZvcm1Hcm91cD4gPSBuZXcgRm9ybUFycmF5PEZvcm1Hcm91cD4oW10pO1xuICAgICAgICAgICAgICBsZXQgZm9ybUdyb3VwOiBGb3JtR3JvdXAgPSBuZXcgRm9ybUdyb3VwKHt9KTtcbiAgICAgICAgICAgICAgZm9ybUdyb3VwLmFkZENvbnRyb2woZHluYW1pY0NvbnRyb2xPcHRpb25zLm5vZGVJZCwgbmV3IEZvcm1Db250cm9sKCcnKSk7XG4gICAgICAgICAgICAgIGZvcm1Hcm91cC5hZGRDb250cm9sKGNvbnRyb2xOYW1lLCBjb250cm9sKTtcbiAgICAgICAgICAgICAgbmV3Rm9ybUFycmF5LnB1c2goZm9ybUdyb3VwKTtcbiAgICAgICAgICAgICAgY29udHJvbC5zZXRQYXJlbnQoZm9ybUdyb3VwKTtcbiAgICAgICAgICAgICAgcGFyZW50Rm9ybUdyb3VwLmFkZENvbnRyb2woXCJub2Rlc1wiLCBuZXdGb3JtQXJyYXkpO1xuICAgICAgICAgICAgfTtcblxuXG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIHBhcmVudE5vZGVzIGFyZSBlbXB0eSBidXQgdGhlIGZvcm1hcnJheSBoYXMgc29tZSBmb3JtIGdyb3VwIG1lYW5zIHRoaXMgY29udHJvbCBzaG91bGQgYmUgYWRkZWQgdG8gdGhlIHJvb3QgZm9ybWdyb3VwIGluIHRoZSBmb3JtIGFycmF5LlxuICAgICAgICAgICAgY29uc3QgZm9ybUdyb3VwcyA6IGFueSA9IGZvcm1BcnJheS5jb250cm9scztcbiAgICAgICAgICAgIGxldCBmb3JtR3JvdXA6IGFueTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm9ybUdyb3Vwcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICBjb25zdCBjb250cm9scyA9IGZvcm1Hcm91cHNbaV0uY29udHJvbHM7XG4gICAgICAgICAgICAgIGlmKGNvbnRyb2xzLmhhc093blByb3BlcnR5KGR5bmFtaWNDb250cm9sT3B0aW9ucy5ub2RlSWQpKSB7XG4gICAgICAgICAgICAgICAgZm9ybUdyb3VwID0gZm9ybUdyb3Vwc1tpXSBhcyBGb3JtR3JvdXA7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYoIWZvcm1Hcm91cCkge1xuICAgICAgICAgICAgICBsZXQgZm9ybUdyb3VwIDogRm9ybUdyb3VwID0gbmV3IEZvcm1Hcm91cCh7fSk7XG4gICAgICAgICAgICAgIGZvcm1Hcm91cC5hZGRDb250cm9sKGR5bmFtaWNDb250cm9sT3B0aW9ucy5ub2RlSWQsIG5ldyBGb3JtQ29udHJvbCgnJykpO1xuICAgICAgICAgICAgICBmb3JtQXJyYXkucHVzaChmb3JtR3JvdXApO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmb3JtR3JvdXA/LmFkZENvbnRyb2woY29udHJvbE5hbWUsIGNvbnRyb2wpXG4gICAgICAgICAgICBjb250cm9sLnNldFBhcmVudChmb3JtR3JvdXAhKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBmb3JtIGFycmF5IGlzIGVtcHR5XG4gICAgICAgICAgLy8gd2UgbmVlZCB0byBhZGQgYSBmb3JtZ3JvdXAgd2l0aCB0aGUgY29udHJvbHNcblxuICAgICAgICAgIGlmKGR5bmFtaWNDb250cm9sT3B0aW9ucy5wYXJlbnROb2Rlcy5sZW5ndGggPT0gMCkge1xuICAgICAgICAgICAgbGV0IGZvcm1Hcm91cCA6IEZvcm1Hcm91cCA9IG5ldyBGb3JtR3JvdXAoe30pO1xuICAgICAgICAgICAgZm9ybUdyb3VwLmFkZENvbnRyb2woZHluYW1pY0NvbnRyb2xPcHRpb25zLm5vZGVJZCwgbmV3IEZvcm1Db250cm9sKCcnKSk7XG4gICAgICAgICAgICBmb3JtR3JvdXAuYWRkQ29udHJvbChjb250cm9sTmFtZSwgY29udHJvbCk7XG5cbiAgICAgICAgICAgIGZvcm1BcnJheS5wdXNoKGZvcm1Hcm91cCk7XG4gICAgICAgICAgICBjb250cm9sLnNldFBhcmVudChmb3JtR3JvdXApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgfVxuXG5cbiAgfVxuXG4gIGZpbmRUaGVGb3JtR3JvdXAoZm1BcnJheTogYW55LCBwYXJlbnRJZHM6IGFueSkge1xuICAgIC8vIGZvciBsb29wIHRoZSBwYXJlbnRJZHNcbiAgICAvLyB0cnkgdG8gZmluZCB0aGUgZm9ybUdyb3VwIHRoYXQgbWF0Y2hlcyB3aXRoIHRoZSBpZFxuICAgIC8vIGlmIGV4aXN0cyByZXR1cm4gdGhlIGZvcm1ncm91cFxuXG4gICAgbGV0IGZvcm1Hcm91cDogYW55O1xuICAgIGxldCBmb3JtQXJyYXk6IGFueTtcblxuICAgIHBhcmVudElkcy5mb3JFYWNoKChwYXJlbnRJZDphbnksIGluZGV4IDphbnkpID0+IHtcbiAgICAgIGxldCBmb3JtR3JvdXBzOiBhbnlcbiAgICAgIGlmKGluZGV4ID09IDApIHtcbiAgICAgICAgZm9ybUdyb3VwcyA9IGZtQXJyYXkuY29udHJvbHM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmb3JtR3JvdXBzID0gZm9ybUFycmF5LmNvbnRyb2xzO1xuICAgICAgfVxuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBmb3JtR3JvdXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNvbnRyb2xzID0gZm9ybUdyb3Vwc1tpXS5jb250cm9scztcbiAgICAgICAgaWYoY29udHJvbHMuaGFzT3duUHJvcGVydHkocGFyZW50SWQpKSB7XG4gICAgICAgICAgZm9ybUdyb3VwID0gZm9ybUdyb3Vwc1tpXSBhcyBGb3JtR3JvdXA7XG4gICAgICAgICAgaWYoaW5kZXggPT0gcGFyZW50SWRzLmxlbmd0aCAtIDEpe1xuICAgICAgICAgICAgcmV0dXJuIGZvcm1Hcm91cDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9ybUFycmF5ID0gZm9ybUdyb3VwLmdldChcIm5vZGVzXCIpIGFzIEZvcm1BcnJheTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuXG4gICAgcmV0dXJuIGZvcm1Hcm91cDtcbiAgfVxuXG4gIGdldE5lc3RlZEZvcm1Db250cm9sUGF0aChuZ0Zvcm06IGFueSwgZHluYW1pY0NvbnRyb2xPcHRpb25zOmFueSkge1xuICAgIGNvbnN0IGNvbnRyb2xOYW1lID0gZHluYW1pY0NvbnRyb2xPcHRpb25zLmR5bmFtaWNDb250cm9sTmFtZTtcbiAgICBjb25zdCBwYXJlbnRJZHMgPSBkeW5hbWljQ29udHJvbE9wdGlvbnMucGFyZW50Tm9kZXM7XG4gICAgbGV0IGNvbnRyb2xQYXRoID0gJ25vZGVzJztcbiAgICBsZXQgdHJlZUNvbnRyb2xzID0gbmdGb3JtLmdldCgnbm9kZXMnKS5jb250cm9scztcblxuICAgIGlmKHBhcmVudElkcy5sZW5ndGgpIHtcbiAgICAgIGxldCBmb3JtQXJyOmFueSA9IHRyZWVDb250cm9scztcbiAgICAgIGxldCBhZGROb2RlID0gZmFsc2U7XG4gICAgICBwYXJlbnRJZHMuZm9yRWFjaCgocGFyZW50SWQ6YW55LCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgIGNvbnN0IG9iaiA9IHRoaXMuZ2V0TmVzdGVkQ29udHJvbFBhdGgoZm9ybUFyciwgcGFyZW50SWQsIGNvbnRyb2xQYXRoLCBhZGROb2RlKTtcbiAgICAgICAgYWRkTm9kZSA9IHRydWU7XG4gICAgICAgIGNvbnRyb2xQYXRoID0gb2JqLmNvbnRyb2xQYXRoO1xuICAgICAgICBmb3JtQXJyID0gb2JqLmZvcm1Hcm91cC5jb250cm9sc1snbm9kZXMnXS5jb250cm9scztcbiAgICAgICAgaWYoaW5kZXggPT0gcGFyZW50SWRzLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICAvL2lmIGl0cyB0aGUgbGFzdCBpbmRleFxuICAgICAgICAgIGZvcm1BcnIuZm9yRWFjaCgoZm9ybUdyb3VwOiBhbnksIGluZGV4OiBudW1iZXIpPT4ge1xuICAgICAgICAgICAgaWYoZm9ybUdyb3VwLmNvbnRhaW5zKGR5bmFtaWNDb250cm9sT3B0aW9ucy5ub2RlSWQpKSB7XG4gICAgICAgICAgICAgIC8vIGNvbnRyb2xQYXRoID0gY29udHJvbFBhdGggKyBgLlske2luZGV4fV0uJHtkeW5hbWljQ29udHJvbE9wdGlvbnMubm9kZUlkfS4ke2NvbnRyb2xOYW1lfWA7XG4gICAgICAgICAgICAgIGNvbnRyb2xQYXRoID0gY29udHJvbFBhdGggKyBgLm5vZGVzWyR7aW5kZXh9XS4ke2NvbnRyb2xOYW1lfWA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgdHJlZUNvbnRyb2xzLmZvckVhY2goKGZvcm1Hcm91cDpGb3JtR3JvdXAsIGluZGV4Om51bWJlcikgPT4ge1xuICAgICAgICBpZihmb3JtR3JvdXAuY29udGFpbnMoZHluYW1pY0NvbnRyb2xPcHRpb25zLm5vZGVJZCkpIHtcbiAgICAgICAgICAvLyBjb250cm9sUGF0aCA9IGNvbnRyb2xQYXRoICsgYC5bJHtpbmRleH1dLiR7ZHluYW1pY0NvbnRyb2xPcHRpb25zLm5vZGVJZH0uJHtjb250cm9sTmFtZX1gO1xuICAgICAgICAgIGNvbnRyb2xQYXRoID0gY29udHJvbFBhdGggKyBgWyR7aW5kZXh9XS4ke2NvbnRyb2xOYW1lfWA7XG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgfVxuXG4gICAgcmV0dXJuIGNvbnRyb2xQYXRoO1xuICB9XG5cbiAgZ2V0TmVzdGVkQ29udHJvbFBhdGgoZm9ybUFycjogYW55W10sIHBhcmVudElkOiBzdHJpbmcsIGNvbnRyb2xQYXRoIDphbnksIGFkZE5vZGU6Ym9vbGVhbikge1xuICAgIC8vIGZpbmQgdGhlIGZvcm1Hcm91cCB3aGljaCBoYXMgdGhlIGNvbnRyb2wgd2l0aCB0aGUgZ2l2ZW4gcGFyZW50SWRcbiAgICBpZihmb3JtQXJyLmxlbmd0aCkge1xuICAgICAgZm9yKGxldCBpPTA7IGkgPCBmb3JtQXJyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmKGZvcm1BcnJbaV0uY29udHJvbHMuaGFzT3duUHJvcGVydHkocGFyZW50SWQpKSB7XG4gICAgICAgICAgLy9wYXJlbnRGb3VuZFxuICAgICAgICAgIC8vIGNvbnRyb2xQYXRoID0gY29udHJvbFBhdGgrIGAuWyR7aX1dLiR7cGFyZW50SWR9YDtcbiAgICAgICAgICBpZihhZGROb2RlKSB7XG4gICAgICAgICAgICBjb250cm9sUGF0aCA9IGNvbnRyb2xQYXRoKyBgLm5vZGVzWyR7aX1dYDtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29udHJvbFBhdGggPSBjb250cm9sUGF0aCsgYFske2l9XWA7XG4gICAgICAgICAgfVxuICAgICAgICAgIGxldCBvYmo6IGFueSA9IHsgY29udHJvbFBhdGg6IGNvbnRyb2xQYXRoLCBmb3JtR3JvdXA6IGZvcm1BcnJbaV19O1xuICAgICAgICAgIHJldHVybiBvYmo7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ==