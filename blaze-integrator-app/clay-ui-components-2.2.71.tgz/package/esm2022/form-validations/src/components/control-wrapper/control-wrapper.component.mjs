import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ContentChild, HostBinding, inject, } from '@angular/core';
import { NgModel, NgModelGroup } from '@angular/forms';
import { mergeWith, of, Subject, switchMap, takeUntil } from 'rxjs';
import { FormDirective } from '../../directives/form.directive';
import * as i0 from "@angular/core";
export class ControlWrapperComponent {
    constructor() {
        this.ngModelGroup = inject(NgModelGroup, {
            optional: true,
            self: true,
        });
        this.destroy$$ = new Subject();
        this.cdRef = inject(ChangeDetectorRef);
        this.formDirective = inject(FormDirective);
    }
    get invalid() {
        return this.control?.touched && this.errors;
    }
    get errors() {
        if (this.control?.pending) {
            return this.previousError;
        }
        else {
            this.previousError = this.control?.errors?.['errors'];
        }
        return this.control?.errors?.['errors'];
    }
    get control() {
        return this.ngModelGroup
            ? this.ngModelGroup.control
            : this.ngModel?.control;
    }
    ngOnDestroy() {
        this.destroy$$.next();
    }
    ngAfterViewInit() {
        // Wait until the form is idle
        // Then, listen to all events of the ngModelGroup or ngModel
        // and mark the component and its ancestors as dirty
        // This allows us to use the OnPush ChangeDetection Strategy
        this.formDirective.idle$
            .pipe(switchMap(() => this.ngModelGroup?.control?.events || of(null)), mergeWith(this.control?.events || of(null)), takeUntil(this.destroy$$))
            .subscribe(() => {
            this.cdRef.markForCheck();
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ControlWrapperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ControlWrapperComponent, isStandalone: true, selector: "[cl-control-wrapper]", host: { properties: { "class.cl-control-wrapper--invalid": "this.invalid" } }, queries: [{ propertyName: "ngModel", first: true, predicate: NgModel, descendants: true }], ngImport: i0, template: "<div class=\"cl-control-wrapper\">\n  <div class=\"cl-control-wrapper__content\">\n    <ng-content></ng-content>\n  </div>\n  <div class=\"cl-control-wrapper__errors mat-mdc-form-field-error\">\n    <ul [hidden]=\"!invalid\">\n      @for (error of errors; track error) {\n      <li>{{ error }}</li>\n      }\n    </ul>\n  </div>\n</div>\n", styles: [""], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ControlWrapperComponent, decorators: [{
            type: Component,
            args: [{ selector: '[cl-control-wrapper]', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"cl-control-wrapper\">\n  <div class=\"cl-control-wrapper__content\">\n    <ng-content></ng-content>\n  </div>\n  <div class=\"cl-control-wrapper__errors mat-mdc-form-field-error\">\n    <ul [hidden]=\"!invalid\">\n      @for (error of errors; track error) {\n      <li>{{ error }}</li>\n      }\n    </ul>\n  </div>\n</div>\n" }]
        }], propDecorators: { ngModel: [{
                type: ContentChild,
                args: [NgModel]
            }], invalid: [{
                type: HostBinding,
                args: ['class.cl-control-wrapper--invalid']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udHJvbC13cmFwcGVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9mb3JtLXZhbGlkYXRpb25zL3NyYy9jb21wb25lbnRzL2NvbnRyb2wtd3JhcHBlci9jb250cm9sLXdyYXBwZXIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2Zvcm0tdmFsaWRhdGlvbnMvc3JjL2NvbXBvbmVudHMvY29udHJvbC13cmFwcGVyL2NvbnRyb2wtd3JhcHBlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsWUFBWSxFQUNaLFdBQVcsRUFDWCxNQUFNLEdBRVAsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFtQixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDeEUsT0FBTyxFQUFFLFNBQVMsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDcEUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLGlDQUFpQyxDQUFDOztBQVNoRSxNQUFNLE9BQU8sdUJBQXVCO0lBUHBDO1FBU2tCLGlCQUFZLEdBQXdCLE1BQU0sQ0FBQyxZQUFZLEVBQUU7WUFDdkUsUUFBUSxFQUFFLElBQUk7WUFDZCxJQUFJLEVBQUUsSUFBSTtTQUNYLENBQUMsQ0FBQztRQUNjLGNBQVMsR0FBRyxJQUFJLE9BQU8sRUFBUSxDQUFDO1FBQ2hDLFVBQUssR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNsQyxrQkFBYSxHQUFHLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQTJDeEQ7SUF2Q0MsSUFDVyxPQUFPO1FBQ2hCLE9BQU8sSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztJQUM5QyxDQUFDO0lBRUQsSUFBVyxNQUFNO1FBQ2YsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDO1lBQzFCLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM1QixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN4RCxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQzFDLENBQUM7SUFFRCxJQUFZLE9BQU87UUFDakIsT0FBTyxJQUFJLENBQUMsWUFBWTtZQUN0QixDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPO1lBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztJQUM1QixDQUFDO0lBRU0sV0FBVztRQUNoQixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFTSxlQUFlO1FBQ3BCLDhCQUE4QjtRQUM5Qiw0REFBNEQ7UUFDNUQsb0RBQW9EO1FBQ3BELDREQUE0RDtRQUM1RCxJQUFJLENBQUMsYUFBYSxDQUFDLEtBQUs7YUFDckIsSUFBSSxDQUNILFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLE9BQU8sRUFBRSxNQUFNLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQy9ELFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsRUFDM0MsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FDMUI7YUFDQSxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7OEdBbERVLHVCQUF1QjtrR0FBdkIsdUJBQXVCLG9NQUNwQixPQUFPLGdEQ3ZCdkIsb1ZBWUE7OzJGRFVhLHVCQUF1QjtrQkFQbkMsU0FBUzsrQkFDRSxzQkFBc0IsY0FDcEIsSUFBSSxtQkFHQyx1QkFBdUIsQ0FBQyxNQUFNOzhCQUdqQixPQUFPO3NCQUFwQyxZQUFZO3VCQUFDLE9BQU87Z0JBWVYsT0FBTztzQkFEakIsV0FBVzt1QkFBQyxtQ0FBbUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgQ29udGVudENoaWxkLFxuICBIb3N0QmluZGluZyxcbiAgaW5qZWN0LFxuICBPbkRlc3Ryb3ksXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBBYnN0cmFjdENvbnRyb2wsIE5nTW9kZWwsIE5nTW9kZWxHcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IG1lcmdlV2l0aCwgb2YsIFN1YmplY3QsIHN3aXRjaE1hcCwgdGFrZVVudGlsIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBGb3JtRGlyZWN0aXZlIH0gZnJvbSAnLi4vLi4vZGlyZWN0aXZlcy9mb3JtLmRpcmVjdGl2ZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ1tjbC1jb250cm9sLXdyYXBwZXJdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbnRyb2wtd3JhcHBlci5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2NvbnRyb2wtd3JhcHBlci5jb21wb25lbnQuc2NzcyddLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbn0pXG5leHBvcnQgY2xhc3MgQ29udHJvbFdyYXBwZXJDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICBAQ29udGVudENoaWxkKE5nTW9kZWwpIHB1YmxpYyBuZ01vZGVsPzogTmdNb2RlbDsgLy8gT3B0aW9uYWwgbmdNb2RlbFxuICBwdWJsaWMgcmVhZG9ubHkgbmdNb2RlbEdyb3VwOiBOZ01vZGVsR3JvdXAgfCBudWxsID0gaW5qZWN0KE5nTW9kZWxHcm91cCwge1xuICAgIG9wdGlvbmFsOiB0cnVlLFxuICAgIHNlbGY6IHRydWUsXG4gIH0pO1xuICBwcml2YXRlIHJlYWRvbmx5IGRlc3Ryb3kkJCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG4gIHByaXZhdGUgcmVhZG9ubHkgY2RSZWYgPSBpbmplY3QoQ2hhbmdlRGV0ZWN0b3JSZWYpO1xuICBwcml2YXRlIHJlYWRvbmx5IGZvcm1EaXJlY3RpdmUgPSBpbmplY3QoRm9ybURpcmVjdGl2ZSk7XG4gIC8vIENhY2hlIHRoZSBwcmV2aW91cyBlcnJvciB0byBhdm9pZCAnZmxpY2tlcmluZydcbiAgcHJpdmF0ZSBwcmV2aW91c0Vycm9yPzogc3RyaW5nW107XG5cbiAgQEhvc3RCaW5kaW5nKCdjbGFzcy5jbC1jb250cm9sLXdyYXBwZXItLWludmFsaWQnKVxuICBwdWJsaWMgZ2V0IGludmFsaWQoKSB7XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbD8udG91Y2hlZCAmJiB0aGlzLmVycm9ycztcbiAgfVxuXG4gIHB1YmxpYyBnZXQgZXJyb3JzKCk6IHN0cmluZ1tdIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAodGhpcy5jb250cm9sPy5wZW5kaW5nKSB7XG4gICAgICByZXR1cm4gdGhpcy5wcmV2aW91c0Vycm9yO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnByZXZpb3VzRXJyb3IgPSB0aGlzLmNvbnRyb2w/LmVycm9ycz8uWydlcnJvcnMnXTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY29udHJvbD8uZXJyb3JzPy5bJ2Vycm9ycyddO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXQgY29udHJvbCgpOiBBYnN0cmFjdENvbnRyb2wgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLm5nTW9kZWxHcm91cFxuICAgICAgPyB0aGlzLm5nTW9kZWxHcm91cC5jb250cm9sXG4gICAgICA6IHRoaXMubmdNb2RlbD8uY29udHJvbDtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICB0aGlzLmRlc3Ryb3kkJC5uZXh0KCk7XG4gIH1cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCk6IHZvaWQge1xuICAgIC8vIFdhaXQgdW50aWwgdGhlIGZvcm0gaXMgaWRsZVxuICAgIC8vIFRoZW4sIGxpc3RlbiB0byBhbGwgZXZlbnRzIG9mIHRoZSBuZ01vZGVsR3JvdXAgb3IgbmdNb2RlbFxuICAgIC8vIGFuZCBtYXJrIHRoZSBjb21wb25lbnQgYW5kIGl0cyBhbmNlc3RvcnMgYXMgZGlydHlcbiAgICAvLyBUaGlzIGFsbG93cyB1cyB0byB1c2UgdGhlIE9uUHVzaCBDaGFuZ2VEZXRlY3Rpb24gU3RyYXRlZ3lcbiAgICB0aGlzLmZvcm1EaXJlY3RpdmUuaWRsZSRcbiAgICAgIC5waXBlKFxuICAgICAgICBzd2l0Y2hNYXAoKCkgPT4gdGhpcy5uZ01vZGVsR3JvdXA/LmNvbnRyb2w/LmV2ZW50cyB8fCBvZihudWxsKSksXG4gICAgICAgIG1lcmdlV2l0aCh0aGlzLmNvbnRyb2w/LmV2ZW50cyB8fCBvZihudWxsKSksXG4gICAgICAgIHRha2VVbnRpbCh0aGlzLmRlc3Ryb3kkJClcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICB0aGlzLmNkUmVmLm1hcmtGb3JDaGVjaygpO1xuICAgICAgfSk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJjbC1jb250cm9sLXdyYXBwZXJcIj5cbiAgPGRpdiBjbGFzcz1cImNsLWNvbnRyb2wtd3JhcHBlcl9fY29udGVudFwiPlxuICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbiAgPC9kaXY+XG4gIDxkaXYgY2xhc3M9XCJjbC1jb250cm9sLXdyYXBwZXJfX2Vycm9ycyBtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3JcIj5cbiAgICA8dWwgW2hpZGRlbl09XCIhaW52YWxpZFwiPlxuICAgICAgQGZvciAoZXJyb3Igb2YgZXJyb3JzOyB0cmFjayBlcnJvcikge1xuICAgICAgPGxpPnt7IGVycm9yIH19PC9saT5cbiAgICAgIH1cbiAgICA8L3VsPlxuICA8L2Rpdj5cbjwvZGl2PlxuIl19