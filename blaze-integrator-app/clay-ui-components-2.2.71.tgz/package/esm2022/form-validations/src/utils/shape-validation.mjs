import { isDevMode } from '@angular/core';
/**
 * Clean error that improves the DX when making typo's in the `name` or `ngModelGroup` attributes
 */
export class ShapeMismatchError extends Error {
    constructor(errorList) {
        super(`Shape mismatch:\n\n${errorList.join('\n')}\n\n`);
    }
}
/**
 * Validates a form value against a shape
 * When there is something in the form value that is not in the shape, throw an error
 * This is how we throw runtime errors in develop when the developer has made a typo in the `name` or `ngModelGroup`
 * attributes.
 * @param formVal
 * @param shape
 */
export function validateShape(formVal, shape) {
    // Only execute in dev mode
    if (isDevMode()) {
        const errors = validateFormValue(formVal, shape);
        if (errors.length) {
            throw new ShapeMismatchError(errors);
        }
    }
}
/**
 * Validates a form value against a shape value to see if it matches
 * Returns clean errors that have a good DX
 * @param formValue
 * @param shape
 * @param path
 */
function validateFormValue(formValue, shape, path = '') {
    const errors = [];
    for (const key in formValue) {
        if (Object.keys(formValue).includes(key)) {
            // In form arrays we don't know how many items there are
            // This means that we always need to provide one record in the shape of our form array
            // so every time reset the key to '0' when the key is a number and is bigger than 0
            let keyToCompareWith = key;
            if (parseFloat(key) > 0) {
                keyToCompareWith = '0';
            }
            const newPath = path ? `${path}.${key}` : key;
            if (typeof formValue[key] === 'object' && formValue[key] !== null) {
                if ((typeof shape[keyToCompareWith] !== 'object' ||
                    shape[keyToCompareWith] === null) &&
                    isNaN(parseFloat(key))) {
                    errors.push(`[ngModelGroup] Mismatch: '${newPath}'`);
                }
                errors.push(...validateFormValue(formValue[key], shape[keyToCompareWith], newPath));
            }
            else if ((shape ? !(key in shape) : true) && isNaN(parseFloat(key))) {
                errors.push(`[ngModel] Mismatch '${newPath}'`);
            }
        }
    }
    return errors;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2hhcGUtdmFsaWRhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9mb3JtLXZhbGlkYXRpb25zL3NyYy91dGlscy9zaGFwZS12YWxpZGF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFMUM7O0dBRUc7QUFDSCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsS0FBSztJQUMzQyxZQUFhLFNBQW1CO1FBQzlCLEtBQUssQ0FBQyxzQkFBdUIsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUUsTUFBTSxDQUFDLENBQUM7SUFDNUQsQ0FBQztDQUNGO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILE1BQU0sVUFBVSxhQUFhLENBQzNCLE9BQTRCLEVBQzVCLEtBQTBCO0lBRTFCLDJCQUEyQjtJQUMzQixJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUM7UUFDaEIsTUFBTSxNQUFNLEdBQUcsaUJBQWlCLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBQ2pELElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xCLE1BQU0sSUFBSSxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztBQUNILENBQUM7QUFFRDs7Ozs7O0dBTUc7QUFDSCxTQUFTLGlCQUFpQixDQUN4QixTQUE4QixFQUM5QixLQUEwQixFQUMxQixPQUFlLEVBQUU7SUFFakIsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO0lBQzVCLEtBQUssTUFBTSxHQUFHLElBQUksU0FBUyxFQUFFLENBQUM7UUFDNUIsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ3pDLHdEQUF3RDtZQUN4RCxzRkFBc0Y7WUFDdEYsbUZBQW1GO1lBQ25GLElBQUksZ0JBQWdCLEdBQUcsR0FBRyxDQUFDO1lBQzNCLElBQUksVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO2dCQUN4QixnQkFBZ0IsR0FBRyxHQUFHLENBQUM7WUFDekIsQ0FBQztZQUNELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBSSxJQUFLLElBQUssR0FBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUNsRCxJQUFJLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFFBQVEsSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7Z0JBQ2xFLElBQ0UsQ0FBQyxPQUFPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLFFBQVE7b0JBQzFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLElBQUksQ0FBQztvQkFDbkMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUN0QixDQUFDO29CQUNELE1BQU0sQ0FBQyxJQUFJLENBQUMsNkJBQThCLE9BQVEsR0FBRyxDQUFDLENBQUM7Z0JBQ3pELENBQUM7Z0JBQ0QsTUFBTSxDQUFDLElBQUksQ0FDVCxHQUFHLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FDdkUsQ0FBQztZQUNKLENBQUM7aUJBQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ3RFLE1BQU0sQ0FBQyxJQUFJLENBQUMsdUJBQXdCLE9BQVEsR0FBRyxDQUFDLENBQUM7WUFDbkQsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBQ0QsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzRGV2TW9kZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG4vKipcbiAqIENsZWFuIGVycm9yIHRoYXQgaW1wcm92ZXMgdGhlIERYIHdoZW4gbWFraW5nIHR5cG8ncyBpbiB0aGUgYG5hbWVgIG9yIGBuZ01vZGVsR3JvdXBgIGF0dHJpYnV0ZXNcbiAqL1xuZXhwb3J0IGNsYXNzIFNoYXBlTWlzbWF0Y2hFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IgKGVycm9yTGlzdDogc3RyaW5nW10pIHtcbiAgICBzdXBlcihgU2hhcGUgbWlzbWF0Y2g6XFxuXFxuJHsgZXJyb3JMaXN0LmpvaW4oJ1xcbicpIH1cXG5cXG5gKTtcbiAgfVxufVxuXG4vKipcbiAqIFZhbGlkYXRlcyBhIGZvcm0gdmFsdWUgYWdhaW5zdCBhIHNoYXBlXG4gKiBXaGVuIHRoZXJlIGlzIHNvbWV0aGluZyBpbiB0aGUgZm9ybSB2YWx1ZSB0aGF0IGlzIG5vdCBpbiB0aGUgc2hhcGUsIHRocm93IGFuIGVycm9yXG4gKiBUaGlzIGlzIGhvdyB3ZSB0aHJvdyBydW50aW1lIGVycm9ycyBpbiBkZXZlbG9wIHdoZW4gdGhlIGRldmVsb3BlciBoYXMgbWFkZSBhIHR5cG8gaW4gdGhlIGBuYW1lYCBvciBgbmdNb2RlbEdyb3VwYFxuICogYXR0cmlidXRlcy5cbiAqIEBwYXJhbSBmb3JtVmFsXG4gKiBAcGFyYW0gc2hhcGVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHZhbGlkYXRlU2hhcGUoXG4gIGZvcm1WYWw6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4gIHNoYXBlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+XG4pOiB2b2lkIHtcbiAgLy8gT25seSBleGVjdXRlIGluIGRldiBtb2RlXG4gIGlmIChpc0Rldk1vZGUoKSkge1xuICAgIGNvbnN0IGVycm9ycyA9IHZhbGlkYXRlRm9ybVZhbHVlKGZvcm1WYWwsIHNoYXBlKTtcbiAgICBpZiAoZXJyb3JzLmxlbmd0aCkge1xuICAgICAgdGhyb3cgbmV3IFNoYXBlTWlzbWF0Y2hFcnJvcihlcnJvcnMpO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFZhbGlkYXRlcyBhIGZvcm0gdmFsdWUgYWdhaW5zdCBhIHNoYXBlIHZhbHVlIHRvIHNlZSBpZiBpdCBtYXRjaGVzXG4gKiBSZXR1cm5zIGNsZWFuIGVycm9ycyB0aGF0IGhhdmUgYSBnb29kIERYXG4gKiBAcGFyYW0gZm9ybVZhbHVlXG4gKiBAcGFyYW0gc2hhcGVcbiAqIEBwYXJhbSBwYXRoXG4gKi9cbmZ1bmN0aW9uIHZhbGlkYXRlRm9ybVZhbHVlKFxuICBmb3JtVmFsdWU6IFJlY29yZDxzdHJpbmcsIGFueT4sXG4gIHNoYXBlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+LFxuICBwYXRoOiBzdHJpbmcgPSAnJ1xuKTogc3RyaW5nW10ge1xuICBjb25zdCBlcnJvcnM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3Qga2V5IGluIGZvcm1WYWx1ZSkge1xuICAgIGlmIChPYmplY3Qua2V5cyhmb3JtVmFsdWUpLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgIC8vIEluIGZvcm0gYXJyYXlzIHdlIGRvbid0IGtub3cgaG93IG1hbnkgaXRlbXMgdGhlcmUgYXJlXG4gICAgICAvLyBUaGlzIG1lYW5zIHRoYXQgd2UgYWx3YXlzIG5lZWQgdG8gcHJvdmlkZSBvbmUgcmVjb3JkIGluIHRoZSBzaGFwZSBvZiBvdXIgZm9ybSBhcnJheVxuICAgICAgLy8gc28gZXZlcnkgdGltZSByZXNldCB0aGUga2V5IHRvICcwJyB3aGVuIHRoZSBrZXkgaXMgYSBudW1iZXIgYW5kIGlzIGJpZ2dlciB0aGFuIDBcbiAgICAgIGxldCBrZXlUb0NvbXBhcmVXaXRoID0ga2V5O1xuICAgICAgaWYgKHBhcnNlRmxvYXQoa2V5KSA+IDApIHtcbiAgICAgICAga2V5VG9Db21wYXJlV2l0aCA9ICcwJztcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5ld1BhdGggPSBwYXRoID8gYCR7IHBhdGggfS4keyBrZXkgfWAgOiBrZXk7XG4gICAgICBpZiAodHlwZW9mIGZvcm1WYWx1ZVtrZXldID09PSAnb2JqZWN0JyAmJiBmb3JtVmFsdWVba2V5XSAhPT0gbnVsbCkge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgKHR5cGVvZiBzaGFwZVtrZXlUb0NvbXBhcmVXaXRoXSAhPT0gJ29iamVjdCcgfHxcbiAgICAgICAgICAgIHNoYXBlW2tleVRvQ29tcGFyZVdpdGhdID09PSBudWxsKSAmJlxuICAgICAgICAgIGlzTmFOKHBhcnNlRmxvYXQoa2V5KSlcbiAgICAgICAgKSB7XG4gICAgICAgICAgZXJyb3JzLnB1c2goYFtuZ01vZGVsR3JvdXBdIE1pc21hdGNoOiAnJHsgbmV3UGF0aCB9J2ApO1xuICAgICAgICB9XG4gICAgICAgIGVycm9ycy5wdXNoKFxuICAgICAgICAgIC4uLnZhbGlkYXRlRm9ybVZhbHVlKGZvcm1WYWx1ZVtrZXldLCBzaGFwZVtrZXlUb0NvbXBhcmVXaXRoXSwgbmV3UGF0aClcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSBpZiAoKHNoYXBlID8gIShrZXkgaW4gc2hhcGUpIDogdHJ1ZSkgJiYgaXNOYU4ocGFyc2VGbG9hdChrZXkpKSkge1xuICAgICAgICBlcnJvcnMucHVzaChgW25nTW9kZWxdIE1pc21hdGNoICckeyBuZXdQYXRoIH0nYCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBlcnJvcnM7XG59XG4iXX0=