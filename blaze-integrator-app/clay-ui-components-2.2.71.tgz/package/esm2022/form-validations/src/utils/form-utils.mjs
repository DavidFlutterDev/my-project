import { FormArray, FormGroup } from '@angular/forms';
import { ROOT_FORM } from './../constants';
// import { ClErrorHandler } from '@clay/ui-components/containers';
/**
 * Recursively calculates the path of a form control
 * @param formGroup
 * @param control
 */
function getControlPath(formGroup, control) {
    for (const key in formGroup.controls) {
        if (formGroup.controls.hasOwnProperty(key)) {
            const ctrl = formGroup.get(key);
            if (ctrl instanceof FormGroup) {
                const path = getControlPath(ctrl, control);
                if (path) {
                    return key + '.' + path;
                }
            }
            else if (ctrl === control) {
                return key;
            }
        }
    }
    return '';
}
/**
 * Recursively calculates the path of a form group
 * @param formGroup
 * @param control
 */
function getGroupPath(formGroup, control) {
    for (const key in formGroup.controls) {
        if (formGroup.controls.hasOwnProperty(key)) {
            const ctrl = formGroup.get(key);
            if (ctrl === control) {
                return key;
            }
            if (ctrl instanceof FormGroup) {
                const path = getGroupPath(ctrl, control);
                if (path) {
                    return key + '.' + path;
                }
            }
        }
    }
    return '';
}
/**
 * Calculates the field name of a form control: Eg: addresses.shippingAddress.street
 * @param rootForm
 * @param control
 */
export function getFormControlField(rootForm, control) {
    return getControlPath(rootForm, control);
}
/**
 * Calcuates the field name of a form group Eg: addresses.shippingAddress
 * @param rootForm
 * @param control
 */
export function getFormGroupField(rootForm, control) {
    return getGroupPath(rootForm, control);
}
/**
 * This RxJS operator merges the value of the form with the raw value.
 * By doing this we can assure that we don't lose values of disabled form fields
 * @param form
 */
export function mergeValuesAndRawValues(form) {
    // Retrieve the standard values (respecting references)
    const value = { ...form.value };
    // Retrieve the raw values (including disabled values)
    const rawValue = form.getRawValue();
    // Recursive function to merge rawValue into value
    function mergeRecursive(target, source) {
        Object.keys(source).forEach((key) => {
            if (target[key] === undefined) {
                // If the key is not in the target, add it directly (for disabled fields)
                target[key] = source[key];
            }
            else if (typeof source[key] === 'object' &&
                source[key] !== null &&
                !Array.isArray(source[key])) {
                // If the value is an object, merge it recursively
                mergeRecursive(target[key], source[key]);
            }
            // If the target already has the key with a primitive value, it's left as is to maintain references
        });
    }
    mergeRecursive(value, rawValue);
    return value;
}
function isPrimitive(value) {
    return (value === null || (typeof value !== 'object' && typeof value !== 'function'));
}
/**
 * Performs a deep-clone of an object
 * @param obj
 */
export function cloneDeep(obj) {
    // Handle primitives (null, undefined, boolean, string, number, function)
    if (isPrimitive(obj)) {
        return obj;
    }
    // Handle Date
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }
    // Handle Array
    if (Array.isArray(obj)) {
        return obj.map((item) => cloneDeep(item));
    }
    // Handle Object
    if (obj instanceof Object) {
        const clonedObj = {};
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                clonedObj[key] = cloneDeep(obj[key]);
            }
        }
        return clonedObj;
    }
    throw new Error("Unable to copy object! Its type isn't supported.");
}
/**
 * Sets a value in an object in the correct path
 * @param obj
 * @param path
 * @param value
 */
export function set(obj, path, value) {
    const keys = path.split('.');
    let current = obj;
    for (let i = 0; i < keys.length - 1; i++) {
        const key = keys[i];
        if (!current[key]) {
            current[key] = {};
        }
        current = current[key];
    }
    current[keys[keys.length - 1]] = value;
}
/**
 * Sets a value in an nested object in the correct path
 * @param obj
 * @param path
 * @param value
 */
export function setNested(obj, path, value) {
    let keys = path.split(".");
    if (keys.length && Object.keys(obj).length) {
        keys.forEach((key) => {
            const match = key.match(/^([^\[]+)\[(\d+)\]$/);
            if (match) {
                const propertyKey = match[1];
                const index = match[2];
                if (obj[propertyKey] != undefined && obj[propertyKey].length) {
                    obj = obj[propertyKey][index];
                }
                else {
                    return;
                }
            }
            else if (obj != undefined) {
                obj[key] = value;
            }
        });
    }
}
/**
 * Traverses the form and returns the errors by path
 * @param form
 */
export function getAllFormErrors(form) {
    const errors = {};
    if (!form) {
        return errors;
    }
    function collect(control, path) {
        if (control instanceof FormGroup || control instanceof FormArray) {
            Object.keys(control.controls).forEach((key) => {
                const childControl = control.get(key);
                const controlPath = path ? `${path}.${key}` : key;
                if (path && control.errors && control.enabled) {
                    Object.keys(control.errors).forEach((errorKey) => {
                        errors[path] = control.errors[errorKey];
                    });
                }
                if (childControl) {
                    collect(childControl, controlPath);
                }
            });
        }
        else {
            if (control.errors && control.enabled) {
                Object.keys(control.errors).forEach((errorKey) => {
                    errors[path] = control.errors[errorKey];
                });
            }
        }
    }
    collect(form, '');
    if (form.errors && form.errors['errors']) {
        errors[ROOT_FORM] = form.errors && form.errors['errors'];
    }
    return errors;
}
export function getErrorMessage(key, errorList) {
    return errorList[key] || null;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9ybS11dGlscy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9mb3JtLXZhbGlkYXRpb25zL3NyYy91dGlscy9mb3JtLXV0aWxzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBbUIsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLGdCQUFnQixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUUzQyxtRUFBbUU7QUFFbkU7Ozs7R0FJRztBQUNILFNBQVMsY0FBYyxDQUNyQixTQUFvQixFQUNwQixPQUF3QjtJQUV4QixLQUFLLE1BQU0sR0FBRyxJQUFJLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNyQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDM0MsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNoQyxJQUFJLElBQUksWUFBWSxTQUFTLEVBQUUsQ0FBQztnQkFDOUIsTUFBTSxJQUFJLEdBQUcsY0FBYyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxJQUFJLEVBQUUsQ0FBQztvQkFDVCxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO2dCQUMxQixDQUFDO1lBQ0gsQ0FBQztpQkFBTSxJQUFJLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDNUIsT0FBTyxHQUFHLENBQUM7WUFDYixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFDRCxPQUFPLEVBQUUsQ0FBQztBQUNaLENBQUM7QUFHRDs7OztHQUlHO0FBQ0gsU0FBUyxZQUFZLENBQUMsU0FBb0IsRUFBRSxPQUF3QjtJQUNsRSxLQUFLLE1BQU0sR0FBRyxJQUFJLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNyQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDM0MsTUFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNoQyxJQUFJLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDckIsT0FBTyxHQUFHLENBQUM7WUFDYixDQUFDO1lBQ0QsSUFBSSxJQUFJLFlBQVksU0FBUyxFQUFFLENBQUM7Z0JBQzlCLE1BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBQ3pDLElBQUksSUFBSSxFQUFFLENBQUM7b0JBQ1QsT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQztnQkFDMUIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUNELE9BQU8sRUFBRSxDQUFDO0FBQ1osQ0FBQztBQUVEOzs7O0dBSUc7QUFDSCxNQUFNLFVBQVUsbUJBQW1CLENBQ2pDLFFBQW1CLEVBQ25CLE9BQXdCO0lBRXhCLE9BQU8sY0FBYyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUMzQyxDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sVUFBVSxpQkFBaUIsQ0FDL0IsUUFBbUIsRUFDbkIsT0FBd0I7SUFFeEIsT0FBTyxZQUFZLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3pDLENBQUM7QUFFRDs7OztHQUlHO0FBQ0gsTUFBTSxVQUFVLHVCQUF1QixDQUFJLElBQWU7SUFDeEQsdURBQXVEO0lBQ3ZELE1BQU0sS0FBSyxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7SUFFaEMsc0RBQXNEO0lBQ3RELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUVwQyxrREFBa0Q7SUFDbEQsU0FBUyxjQUFjLENBQUMsTUFBVyxFQUFFLE1BQVc7UUFDOUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtZQUNsQyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxTQUFTLEVBQUUsQ0FBQztnQkFDOUIseUVBQXlFO2dCQUN6RSxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVCLENBQUM7aUJBQU0sSUFDTCxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxRQUFRO2dCQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssSUFBSTtnQkFDcEIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUMzQixDQUFDO2dCQUNELGtEQUFrRDtnQkFDbEQsY0FBYyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUMzQyxDQUFDO1lBQ0QsbUdBQW1HO1FBQ3JHLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGNBQWMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFDaEMsT0FBTyxLQUFLLENBQUM7QUFDZixDQUFDO0FBSUQsU0FBUyxXQUFXLENBQUMsS0FBVTtJQUM3QixPQUFPLENBQ0wsS0FBSyxLQUFLLElBQUksSUFBSSxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxPQUFPLEtBQUssS0FBSyxVQUFVLENBQUMsQ0FDN0UsQ0FBQztBQUNKLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLFVBQVUsU0FBUyxDQUFJLEdBQU07SUFDakMseUVBQXlFO0lBQ3pFLElBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDckIsT0FBTyxHQUFHLENBQUM7SUFDYixDQUFDO0lBRUQsY0FBYztJQUNkLElBQUksR0FBRyxZQUFZLElBQUksRUFBRSxDQUFDO1FBQ3hCLE9BQU8sSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFhLENBQUM7SUFDN0MsQ0FBQztJQUVELGVBQWU7SUFDZixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUN2QixPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBYSxDQUFDO0lBQ3hELENBQUM7SUFFRCxnQkFBZ0I7SUFDaEIsSUFBSSxHQUFHLFlBQVksTUFBTSxFQUFFLENBQUM7UUFDMUIsTUFBTSxTQUFTLEdBQVEsRUFBRSxDQUFDO1FBQzFCLEtBQUssTUFBTSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUM7WUFDdEIsSUFBSSxHQUFHLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQzVCLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLENBQUUsR0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDaEQsQ0FBQztRQUNILENBQUM7UUFDRCxPQUFPLFNBQWMsQ0FBQztJQUN4QixDQUFDO0lBRUQsTUFBTSxJQUFJLEtBQUssQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO0FBQ3RFLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILE1BQU0sVUFBVSxHQUFHLENBQUMsR0FBVyxFQUFFLElBQVksRUFBRSxLQUFVO0lBQ3ZELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDN0IsSUFBSSxPQUFPLEdBQVEsR0FBRyxDQUFDO0lBRXZCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO1FBQ3pDLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNwQixJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNwQixDQUFDO1FBQ0QsT0FBTyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBRUQsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLENBQUM7QUFFRDs7Ozs7R0FLRztBQUNILE1BQU0sVUFBVSxTQUFTLENBQUMsR0FBUSxFQUFFLElBQVksRUFBRSxLQUFTO0lBQ3pELElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDM0IsSUFBRyxJQUFJLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDMUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQVUsRUFBRSxFQUFFO1lBQzFCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQztZQUMvQyxJQUFHLEtBQUssRUFBRSxDQUFDO2dCQUNULE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDN0IsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUV2QixJQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxTQUFTLElBQUksR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUM1RCxHQUFHLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNoQyxDQUFDO3FCQUFNLENBQUM7b0JBQ04sT0FBTztnQkFDVCxDQUFDO1lBQ0gsQ0FBQztpQkFBTSxJQUFHLEdBQUcsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDM0IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQTtZQUNsQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0FBQ0gsQ0FBQztBQUVEOzs7R0FHRztBQUNILE1BQU0sVUFBVSxnQkFBZ0IsQ0FDOUIsSUFBc0I7SUFFdEIsTUFBTSxNQUFNLEdBQTJCLEVBQUUsQ0FBQztJQUMxQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDVixPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQsU0FBUyxPQUFPLENBQUMsT0FBd0IsRUFBRSxJQUFZO1FBQ3JELElBQUksT0FBTyxZQUFZLFNBQVMsSUFBSSxPQUFPLFlBQVksU0FBUyxFQUFFLENBQUM7WUFDakUsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUU7Z0JBQzVDLE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBSSxJQUFLLElBQUssR0FBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztnQkFDdEQsSUFBSSxJQUFJLElBQUksT0FBTyxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQzlDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO3dCQUMvQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDM0MsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztnQkFDRCxJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixPQUFPLENBQUMsWUFBWSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUNyQyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksT0FBTyxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3RDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsRUFBRSxFQUFFO29CQUMvQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDM0MsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxPQUFPLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ2xCLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7UUFDMUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUM1RCxDQUFDO0lBRUQsT0FBTyxNQUFNLENBQUM7QUFDaEIsQ0FBQztBQUdELE1BQU0sVUFBVSxlQUFlLENBQzdCLEdBQXlCLEVBQ3pCLFNBQXlCO0lBRXpCLE9BQU8sU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQztBQUNoQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWJzdHJhY3RDb250cm9sLCBGb3JtQXJyYXksIEZvcm1Hcm91cCB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcbmltcG9ydCB7IFJPT1RfRk9STSB9IGZyb20gJy4vLi4vY29uc3RhbnRzJztcbmltcG9ydCB7IENsRXJyb3JIYW5kbGVyLCBDbFZhbGlkYXRpb25UeXBlcyB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbi8vIGltcG9ydCB7IENsRXJyb3JIYW5kbGVyIH0gZnJvbSAnQGNsYXkvdWktY29tcG9uZW50cy9jb250YWluZXJzJztcblxuLyoqXG4gKiBSZWN1cnNpdmVseSBjYWxjdWxhdGVzIHRoZSBwYXRoIG9mIGEgZm9ybSBjb250cm9sXG4gKiBAcGFyYW0gZm9ybUdyb3VwXG4gKiBAcGFyYW0gY29udHJvbFxuICovXG5mdW5jdGlvbiBnZXRDb250cm9sUGF0aChcbiAgZm9ybUdyb3VwOiBGb3JtR3JvdXAsXG4gIGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbFxuKTogc3RyaW5nIHtcbiAgZm9yIChjb25zdCBrZXkgaW4gZm9ybUdyb3VwLmNvbnRyb2xzKSB7XG4gICAgaWYgKGZvcm1Hcm91cC5jb250cm9scy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICBjb25zdCBjdHJsID0gZm9ybUdyb3VwLmdldChrZXkpO1xuICAgICAgaWYgKGN0cmwgaW5zdGFuY2VvZiBGb3JtR3JvdXApIHtcbiAgICAgICAgY29uc3QgcGF0aCA9IGdldENvbnRyb2xQYXRoKGN0cmwsIGNvbnRyb2wpO1xuICAgICAgICBpZiAocGF0aCkge1xuICAgICAgICAgIHJldHVybiBrZXkgKyAnLicgKyBwYXRoO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGN0cmwgPT09IGNvbnRyb2wpIHtcbiAgICAgICAgcmV0dXJuIGtleTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuICcnO1xufVxuXG5cbi8qKlxuICogUmVjdXJzaXZlbHkgY2FsY3VsYXRlcyB0aGUgcGF0aCBvZiBhIGZvcm0gZ3JvdXBcbiAqIEBwYXJhbSBmb3JtR3JvdXBcbiAqIEBwYXJhbSBjb250cm9sXG4gKi9cbmZ1bmN0aW9uIGdldEdyb3VwUGF0aChmb3JtR3JvdXA6IEZvcm1Hcm91cCwgY29udHJvbDogQWJzdHJhY3RDb250cm9sKTogc3RyaW5nIHtcbiAgZm9yIChjb25zdCBrZXkgaW4gZm9ybUdyb3VwLmNvbnRyb2xzKSB7XG4gICAgaWYgKGZvcm1Hcm91cC5jb250cm9scy5oYXNPd25Qcm9wZXJ0eShrZXkpKSB7XG4gICAgICBjb25zdCBjdHJsID0gZm9ybUdyb3VwLmdldChrZXkpO1xuICAgICAgaWYgKGN0cmwgPT09IGNvbnRyb2wpIHtcbiAgICAgICAgcmV0dXJuIGtleTtcbiAgICAgIH1cbiAgICAgIGlmIChjdHJsIGluc3RhbmNlb2YgRm9ybUdyb3VwKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBnZXRHcm91cFBhdGgoY3RybCwgY29udHJvbCk7XG4gICAgICAgIGlmIChwYXRoKSB7XG4gICAgICAgICAgcmV0dXJuIGtleSArICcuJyArIHBhdGg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuICcnO1xufVxuXG4vKipcbiAqIENhbGN1bGF0ZXMgdGhlIGZpZWxkIG5hbWUgb2YgYSBmb3JtIGNvbnRyb2w6IEVnOiBhZGRyZXNzZXMuc2hpcHBpbmdBZGRyZXNzLnN0cmVldFxuICogQHBhcmFtIHJvb3RGb3JtXG4gKiBAcGFyYW0gY29udHJvbFxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Rm9ybUNvbnRyb2xGaWVsZChcbiAgcm9vdEZvcm06IEZvcm1Hcm91cCxcbiAgY29udHJvbDogQWJzdHJhY3RDb250cm9sXG4pOiBzdHJpbmcge1xuICByZXR1cm4gZ2V0Q29udHJvbFBhdGgocm9vdEZvcm0sIGNvbnRyb2wpO1xufVxuXG4vKipcbiAqIENhbGN1YXRlcyB0aGUgZmllbGQgbmFtZSBvZiBhIGZvcm0gZ3JvdXAgRWc6IGFkZHJlc3Nlcy5zaGlwcGluZ0FkZHJlc3NcbiAqIEBwYXJhbSByb290Rm9ybVxuICogQHBhcmFtIGNvbnRyb2xcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZvcm1Hcm91cEZpZWxkKFxuICByb290Rm9ybTogRm9ybUdyb3VwLFxuICBjb250cm9sOiBBYnN0cmFjdENvbnRyb2xcbik6IHN0cmluZyB7XG4gIHJldHVybiBnZXRHcm91cFBhdGgocm9vdEZvcm0sIGNvbnRyb2wpO1xufVxuXG4vKipcbiAqIFRoaXMgUnhKUyBvcGVyYXRvciBtZXJnZXMgdGhlIHZhbHVlIG9mIHRoZSBmb3JtIHdpdGggdGhlIHJhdyB2YWx1ZS5cbiAqIEJ5IGRvaW5nIHRoaXMgd2UgY2FuIGFzc3VyZSB0aGF0IHdlIGRvbid0IGxvc2UgdmFsdWVzIG9mIGRpc2FibGVkIGZvcm0gZmllbGRzXG4gKiBAcGFyYW0gZm9ybVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VWYWx1ZXNBbmRSYXdWYWx1ZXM8VD4oZm9ybTogRm9ybUdyb3VwKTogVCB7XG4gIC8vIFJldHJpZXZlIHRoZSBzdGFuZGFyZCB2YWx1ZXMgKHJlc3BlY3RpbmcgcmVmZXJlbmNlcylcbiAgY29uc3QgdmFsdWUgPSB7IC4uLmZvcm0udmFsdWUgfTtcblxuICAvLyBSZXRyaWV2ZSB0aGUgcmF3IHZhbHVlcyAoaW5jbHVkaW5nIGRpc2FibGVkIHZhbHVlcylcbiAgY29uc3QgcmF3VmFsdWUgPSBmb3JtLmdldFJhd1ZhbHVlKCk7XG5cbiAgLy8gUmVjdXJzaXZlIGZ1bmN0aW9uIHRvIG1lcmdlIHJhd1ZhbHVlIGludG8gdmFsdWVcbiAgZnVuY3Rpb24gbWVyZ2VSZWN1cnNpdmUodGFyZ2V0OiBhbnksIHNvdXJjZTogYW55KSB7XG4gICAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGlmICh0YXJnZXRba2V5XSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vIElmIHRoZSBrZXkgaXMgbm90IGluIHRoZSB0YXJnZXQsIGFkZCBpdCBkaXJlY3RseSAoZm9yIGRpc2FibGVkIGZpZWxkcylcbiAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIHR5cGVvZiBzb3VyY2Vba2V5XSA9PT0gJ29iamVjdCcgJiZcbiAgICAgICAgc291cmNlW2tleV0gIT09IG51bGwgJiZcbiAgICAgICAgIUFycmF5LmlzQXJyYXkoc291cmNlW2tleV0pXG4gICAgICApIHtcbiAgICAgICAgLy8gSWYgdGhlIHZhbHVlIGlzIGFuIG9iamVjdCwgbWVyZ2UgaXQgcmVjdXJzaXZlbHlcbiAgICAgICAgbWVyZ2VSZWN1cnNpdmUodGFyZ2V0W2tleV0sIHNvdXJjZVtrZXldKTtcbiAgICAgIH1cbiAgICAgIC8vIElmIHRoZSB0YXJnZXQgYWxyZWFkeSBoYXMgdGhlIGtleSB3aXRoIGEgcHJpbWl0aXZlIHZhbHVlLCBpdCdzIGxlZnQgYXMgaXMgdG8gbWFpbnRhaW4gcmVmZXJlbmNlc1xuICAgIH0pO1xuICB9XG5cbiAgbWVyZ2VSZWN1cnNpdmUodmFsdWUsIHJhd1ZhbHVlKTtcbiAgcmV0dXJuIHZhbHVlO1xufVxuXG50eXBlIFByaW1pdGl2ZSA9IHVuZGVmaW5lZCB8IG51bGwgfCBib29sZWFuIHwgc3RyaW5nIHwgbnVtYmVyIHwgRnVuY3Rpb247XG5cbmZ1bmN0aW9uIGlzUHJpbWl0aXZlKHZhbHVlOiBhbnkpOiB2YWx1ZSBpcyBQcmltaXRpdmUge1xuICByZXR1cm4gKFxuICAgIHZhbHVlID09PSBudWxsIHx8ICh0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnICYmIHR5cGVvZiB2YWx1ZSAhPT0gJ2Z1bmN0aW9uJylcbiAgKTtcbn1cblxuLyoqXG4gKiBQZXJmb3JtcyBhIGRlZXAtY2xvbmUgb2YgYW4gb2JqZWN0XG4gKiBAcGFyYW0gb2JqXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbG9uZURlZXA8VD4ob2JqOiBUKTogVCB7XG4gIC8vIEhhbmRsZSBwcmltaXRpdmVzIChudWxsLCB1bmRlZmluZWQsIGJvb2xlYW4sIHN0cmluZywgbnVtYmVyLCBmdW5jdGlvbilcbiAgaWYgKGlzUHJpbWl0aXZlKG9iaikpIHtcbiAgICByZXR1cm4gb2JqO1xuICB9XG5cbiAgLy8gSGFuZGxlIERhdGVcbiAgaWYgKG9iaiBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICByZXR1cm4gbmV3IERhdGUob2JqLmdldFRpbWUoKSkgYXMgYW55IGFzIFQ7XG4gIH1cblxuICAvLyBIYW5kbGUgQXJyYXlcbiAgaWYgKEFycmF5LmlzQXJyYXkob2JqKSkge1xuICAgIHJldHVybiBvYmoubWFwKChpdGVtKSA9PiBjbG9uZURlZXAoaXRlbSkpIGFzIGFueSBhcyBUO1xuICB9XG5cbiAgLy8gSGFuZGxlIE9iamVjdFxuICBpZiAob2JqIGluc3RhbmNlb2YgT2JqZWN0KSB7XG4gICAgY29uc3QgY2xvbmVkT2JqOiBhbnkgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICBjbG9uZWRPYmpba2V5XSA9IGNsb25lRGVlcCgob2JqIGFzIGFueSlba2V5XSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjbG9uZWRPYmogYXMgVDtcbiAgfVxuXG4gIHRocm93IG5ldyBFcnJvcihcIlVuYWJsZSB0byBjb3B5IG9iamVjdCEgSXRzIHR5cGUgaXNuJ3Qgc3VwcG9ydGVkLlwiKTtcbn1cblxuLyoqXG4gKiBTZXRzIGEgdmFsdWUgaW4gYW4gb2JqZWN0IGluIHRoZSBjb3JyZWN0IHBhdGhcbiAqIEBwYXJhbSBvYmpcbiAqIEBwYXJhbSBwYXRoXG4gKiBAcGFyYW0gdmFsdWVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldChvYmo6IG9iamVjdCwgcGF0aDogc3RyaW5nLCB2YWx1ZTogYW55KTogdm9pZCB7XG4gIGNvbnN0IGtleXMgPSBwYXRoLnNwbGl0KCcuJyk7XG4gIGxldCBjdXJyZW50OiBhbnkgPSBvYmo7XG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgaWYgKCFjdXJyZW50W2tleV0pIHtcbiAgICAgIGN1cnJlbnRba2V5XSA9IHt9O1xuICAgIH1cbiAgICBjdXJyZW50ID0gY3VycmVudFtrZXldO1xuICB9XG5cbiAgY3VycmVudFtrZXlzW2tleXMubGVuZ3RoIC0gMV1dID0gdmFsdWU7XG59XG5cbi8qKlxuICogU2V0cyBhIHZhbHVlIGluIGFuIG5lc3RlZCBvYmplY3QgaW4gdGhlIGNvcnJlY3QgcGF0aFxuICogQHBhcmFtIG9ialxuICogQHBhcmFtIHBhdGhcbiAqIEBwYXJhbSB2YWx1ZVxuICovXG5leHBvcnQgZnVuY3Rpb24gc2V0TmVzdGVkKG9iajogYW55LCBwYXRoOiBzdHJpbmcsIHZhbHVlOmFueSk6IHZvaWQge1xuICBsZXQga2V5cyA9IHBhdGguc3BsaXQoXCIuXCIpO1xuICBpZihrZXlzLmxlbmd0aCAmJiBPYmplY3Qua2V5cyhvYmopLmxlbmd0aCkge1xuICAgIGtleXMuZm9yRWFjaCgoa2V5OnN0cmluZykgPT4ge1xuICAgICAgY29uc3QgbWF0Y2ggPSBrZXkubWF0Y2goL14oW15cXFtdKylcXFsoXFxkKylcXF0kLyk7XG4gICAgICBpZihtYXRjaCkge1xuICAgICAgICBjb25zdCBwcm9wZXJ0eUtleSA9IG1hdGNoWzFdO1xuICAgICAgICBjb25zdCBpbmRleCA9IG1hdGNoWzJdO1xuXG4gICAgICAgIGlmKG9ialtwcm9wZXJ0eUtleV0gIT0gdW5kZWZpbmVkICYmIG9ialtwcm9wZXJ0eUtleV0ubGVuZ3RoKSB7XG4gICAgICAgICAgb2JqID0gb2JqW3Byb3BlcnR5S2V5XVtpbmRleF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYob2JqICE9IHVuZGVmaW5lZCkge1xuICAgICAgICBvYmpba2V5XSA9IHZhbHVlXG4gICAgICB9XG4gICAgfSlcbiAgfVxufVxuXG4vKipcbiAqIFRyYXZlcnNlcyB0aGUgZm9ybSBhbmQgcmV0dXJucyB0aGUgZXJyb3JzIGJ5IHBhdGhcbiAqIEBwYXJhbSBmb3JtXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRBbGxGb3JtRXJyb3JzKFxuICBmb3JtPzogQWJzdHJhY3RDb250cm9sXG4pOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgY29uc3QgZXJyb3JzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gIGlmICghZm9ybSkge1xuICAgIHJldHVybiBlcnJvcnM7XG4gIH1cblxuICBmdW5jdGlvbiBjb2xsZWN0KGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCwgcGF0aDogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKGNvbnRyb2wgaW5zdGFuY2VvZiBGb3JtR3JvdXAgfHwgY29udHJvbCBpbnN0YW5jZW9mIEZvcm1BcnJheSkge1xuICAgICAgT2JqZWN0LmtleXMoY29udHJvbC5jb250cm9scykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IGNoaWxkQ29udHJvbCA9IGNvbnRyb2wuZ2V0KGtleSk7XG4gICAgICAgIGNvbnN0IGNvbnRyb2xQYXRoID0gcGF0aCA/IGAkeyBwYXRoIH0uJHsga2V5IH1gIDoga2V5O1xuICAgICAgICBpZiAocGF0aCAmJiBjb250cm9sLmVycm9ycyAmJiBjb250cm9sLmVuYWJsZWQpIHtcbiAgICAgICAgICBPYmplY3Qua2V5cyhjb250cm9sLmVycm9ycykuZm9yRWFjaCgoZXJyb3JLZXkpID0+IHtcbiAgICAgICAgICAgIGVycm9yc1twYXRoXSA9IGNvbnRyb2wuZXJyb3JzIVtlcnJvcktleV07XG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNoaWxkQ29udHJvbCkge1xuICAgICAgICAgIGNvbGxlY3QoY2hpbGRDb250cm9sLCBjb250cm9sUGF0aCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoY29udHJvbC5lcnJvcnMgJiYgY29udHJvbC5lbmFibGVkKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKGNvbnRyb2wuZXJyb3JzKS5mb3JFYWNoKChlcnJvcktleSkgPT4ge1xuICAgICAgICAgIGVycm9yc1twYXRoXSA9IGNvbnRyb2wuZXJyb3JzIVtlcnJvcktleV07XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGNvbGxlY3QoZm9ybSwgJycpO1xuICBpZiAoZm9ybS5lcnJvcnMgJiYgZm9ybS5lcnJvcnMhWydlcnJvcnMnXSkge1xuICAgIGVycm9yc1tST09UX0ZPUk1dID0gZm9ybS5lcnJvcnMgJiYgZm9ybS5lcnJvcnMhWydlcnJvcnMnXTtcbiAgfVxuXG4gIHJldHVybiBlcnJvcnM7XG59XG5cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEVycm9yTWVzc2FnZShcbiAga2V5OiBrZXlvZiBDbEVycm9ySGFuZGxlcixcbiAgZXJyb3JMaXN0OiBDbEVycm9ySGFuZGxlclxuKTogYW55IHtcbiAgcmV0dXJuIGVycm9yTGlzdFtrZXldIHx8IG51bGw7XG59XG4iXX0=