import { enforce, omitWhen, staticSuite, test } from 'vest';
export const createSignUpFormValidationSuite = (userList) => {
    return staticSuite((model, field) => {
        test('firstName', 'First name is required.', () => {
            enforce(model.firstName).isNotBlank();
        });
        test('lastName', 'Last name is required.', () => {
            enforce(model.lastName).isNotBlank();
        });
        test('email', 'Email is required.', () => {
            enforce(model.email).isNotBlank();
        });
        omitWhen(!model.email, () => {
            test('email', 'Email already registered.', () => {
                const existingEmailIds = userList.map(user => user.email?.toLowerCase());
                return !existingEmailIds.includes(model.email?.toLowerCase());
            });
        });
        test('userName', 'User name is required.', () => {
            enforce(model.userName).isNotBlank();
        });
        omitWhen(!model.userName, () => {
            test('userName', 'User name already exists.', () => {
                const existingUserIds = userList.map(user => user.username.toLowerCase());
                return !existingUserIds.includes(model.userName?.toLowerCase());
            });
        });
        // test('password', 'Password is required.', () => {
        //   enforce(model.password).isNotBlank();
        // });
        // omitWhen(!model.password, () => {
        //   test('password', 'Password is invalid.', () => {
        //     const passwordFormatRegEx: RegExp = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/;
        //     return passwordFormatRegEx.test(model.password!);
        //   });
        //   test('confirmPassword', 'Confirm password is required.', () => {
        //     enforce(model.confirmPassword).isNotBlank();
        //   }
        //   );
        // });
        // omitWhen(!model.password || !model.confirmPassword, () => {
        //   test('confirmPassword', 'Passwords do not match.', () => {
        //     enforce(model.confirmPassword).equals(model.password);
        //   });
        // });
        // test('termsAndConditions', 'Please select terms and conditions.', () => {
        //   enforce(model.termsAndConditions).isTruthy();
        // });
    });
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lnbi11cC52YWxpZGF0aW9ucy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9hdXRoL3NyYy9zaWduLXVwL3NpZ24tdXAudmFsaWRhdGlvbnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUc1RCxNQUFNLENBQUMsTUFBTSwrQkFBK0IsR0FBRyxDQUFDLFFBQXFCLEVBQUUsRUFBRTtJQUN2RSxPQUFPLFdBQVcsQ0FBQyxDQUFDLEtBQXNCLEVBQUUsS0FBYyxFQUFFLEVBQUU7UUFFNUQsSUFBSSxDQUFDLFdBQVcsRUFBRSx5QkFBeUIsRUFBRSxHQUFHLEVBQUU7WUFDaEQsT0FBTyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUN4QyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLEVBQUUsR0FBRyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixFQUFFLEdBQUcsRUFBRTtZQUN2QyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBRUgsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7WUFDMUIsSUFBSSxDQUFDLE9BQU8sRUFBRSwyQkFBMkIsRUFBRSxHQUFHLEVBQUU7Z0JBQzlDLE1BQU0sZ0JBQWdCLEdBQWEsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsV0FBVyxFQUFFLENBQUMsQ0FBQztnQkFDbkYsT0FBTyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLFdBQVcsRUFBRyxDQUFDLENBQUM7WUFDakUsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxVQUFVLEVBQUUsd0JBQXdCLEVBQUUsR0FBRyxFQUFFO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDdkMsQ0FBQyxDQUFDLENBQUM7UUFFSCxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRTtZQUM3QixJQUFJLENBQUMsVUFBVSxFQUFFLDJCQUEyQixFQUFFLEdBQUcsRUFBRTtnQkFDakQsTUFBTSxlQUFlLEdBQWEsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztnQkFDcEYsT0FBTyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUcsQ0FBQyxDQUFDO1lBQ25FLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFFSCxvREFBb0Q7UUFDcEQsMENBQTBDO1FBQzFDLE1BQU07UUFFTixvQ0FBb0M7UUFDcEMscURBQXFEO1FBQ3JELG9IQUFvSDtRQUNwSCx3REFBd0Q7UUFDeEQsUUFBUTtRQUVSLHFFQUFxRTtRQUNyRSxtREFBbUQ7UUFDbkQsTUFBTTtRQUNOLE9BQU87UUFDUCxNQUFNO1FBRU4sOERBQThEO1FBQzlELCtEQUErRDtRQUMvRCw2REFBNkQ7UUFDN0QsUUFBUTtRQUNSLE1BQU07UUFFTiw0RUFBNEU7UUFDNUUsa0RBQWtEO1FBQ2xELE1BQU07SUFDUixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGVuZm9yY2UsIG9taXRXaGVuLCBzdGF0aWNTdWl0ZSwgdGVzdCB9IGZyb20gJ3Zlc3QnO1xuaW1wb3J0IHsgU2lnblVwRm9ybU1vZGVsLCBVc2VyTW9kZWwgfSBmcm9tICcuL3NpZ24tdXAubW9kZWwnO1xuXG5leHBvcnQgY29uc3QgY3JlYXRlU2lnblVwRm9ybVZhbGlkYXRpb25TdWl0ZSA9ICh1c2VyTGlzdDogVXNlck1vZGVsW10pID0+IHtcbiAgcmV0dXJuIHN0YXRpY1N1aXRlKChtb2RlbDogU2lnblVwRm9ybU1vZGVsLCBmaWVsZD86IHN0cmluZykgPT4ge1xuXG4gICAgdGVzdCgnZmlyc3ROYW1lJywgJ0ZpcnN0IG5hbWUgaXMgcmVxdWlyZWQuJywgKCkgPT4ge1xuICAgICAgZW5mb3JjZShtb2RlbC5maXJzdE5hbWUpLmlzTm90QmxhbmsoKTtcbiAgICB9KTtcblxuICAgIHRlc3QoJ2xhc3ROYW1lJywgJ0xhc3QgbmFtZSBpcyByZXF1aXJlZC4nLCAoKSA9PiB7XG4gICAgICBlbmZvcmNlKG1vZGVsLmxhc3ROYW1lKS5pc05vdEJsYW5rKCk7XG4gICAgfSk7XG5cbiAgICB0ZXN0KCdlbWFpbCcsICdFbWFpbCBpcyByZXF1aXJlZC4nLCAoKSA9PiB7XG4gICAgICBlbmZvcmNlKG1vZGVsLmVtYWlsKS5pc05vdEJsYW5rKCk7XG4gICAgfSk7XG5cbiAgICBvbWl0V2hlbighbW9kZWwuZW1haWwsICgpID0+IHtcbiAgICAgIHRlc3QoJ2VtYWlsJywgJ0VtYWlsIGFscmVhZHkgcmVnaXN0ZXJlZC4nLCAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGV4aXN0aW5nRW1haWxJZHM6IHN0cmluZ1tdID0gdXNlckxpc3QubWFwKHVzZXIgPT4gdXNlci5lbWFpbD8udG9Mb3dlckNhc2UoKSk7XG4gICAgICAgIHJldHVybiAhZXhpc3RpbmdFbWFpbElkcy5pbmNsdWRlcyhtb2RlbC5lbWFpbD8udG9Mb3dlckNhc2UoKSEpO1xuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICB0ZXN0KCd1c2VyTmFtZScsICdVc2VyIG5hbWUgaXMgcmVxdWlyZWQuJywgKCkgPT4ge1xuICAgICAgZW5mb3JjZShtb2RlbC51c2VyTmFtZSkuaXNOb3RCbGFuaygpO1xuICAgIH0pO1xuXG4gICAgb21pdFdoZW4oIW1vZGVsLnVzZXJOYW1lLCAoKSA9PiB7XG4gICAgICB0ZXN0KCd1c2VyTmFtZScsICdVc2VyIG5hbWUgYWxyZWFkeSBleGlzdHMuJywgKCkgPT4ge1xuICAgICAgICBjb25zdCBleGlzdGluZ1VzZXJJZHM6IHN0cmluZ1tdID0gdXNlckxpc3QubWFwKHVzZXIgPT4gdXNlci51c2VybmFtZS50b0xvd2VyQ2FzZSgpKTtcbiAgICAgICAgcmV0dXJuICFleGlzdGluZ1VzZXJJZHMuaW5jbHVkZXMobW9kZWwudXNlck5hbWU/LnRvTG93ZXJDYXNlKCkhKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8gdGVzdCgncGFzc3dvcmQnLCAnUGFzc3dvcmQgaXMgcmVxdWlyZWQuJywgKCkgPT4ge1xuICAgIC8vICAgZW5mb3JjZShtb2RlbC5wYXNzd29yZCkuaXNOb3RCbGFuaygpO1xuICAgIC8vIH0pO1xuXG4gICAgLy8gb21pdFdoZW4oIW1vZGVsLnBhc3N3b3JkLCAoKSA9PiB7XG4gICAgLy8gICB0ZXN0KCdwYXNzd29yZCcsICdQYXNzd29yZCBpcyBpbnZhbGlkLicsICgpID0+IHtcbiAgICAvLyAgICAgY29uc3QgcGFzc3dvcmRGb3JtYXRSZWdFeDogUmVnRXhwID0gL14oPz0uKlthLXpdKSg/PS4qW0EtWl0pKD89LipcXGQpKD89LipbIUAjJCVeJipdKVtBLVphLXpcXGQhQCMkJV4mKl17OCx9JC87XG4gICAgLy8gICAgIHJldHVybiBwYXNzd29yZEZvcm1hdFJlZ0V4LnRlc3QobW9kZWwucGFzc3dvcmQhKTtcbiAgICAvLyAgIH0pO1xuXG4gICAgLy8gICB0ZXN0KCdjb25maXJtUGFzc3dvcmQnLCAnQ29uZmlybSBwYXNzd29yZCBpcyByZXF1aXJlZC4nLCAoKSA9PiB7XG4gICAgLy8gICAgIGVuZm9yY2UobW9kZWwuY29uZmlybVBhc3N3b3JkKS5pc05vdEJsYW5rKCk7XG4gICAgLy8gICB9XG4gICAgLy8gICApO1xuICAgIC8vIH0pO1xuXG4gICAgLy8gb21pdFdoZW4oIW1vZGVsLnBhc3N3b3JkIHx8ICFtb2RlbC5jb25maXJtUGFzc3dvcmQsICgpID0+IHtcbiAgICAvLyAgIHRlc3QoJ2NvbmZpcm1QYXNzd29yZCcsICdQYXNzd29yZHMgZG8gbm90IG1hdGNoLicsICgpID0+IHtcbiAgICAvLyAgICAgZW5mb3JjZShtb2RlbC5jb25maXJtUGFzc3dvcmQpLmVxdWFscyhtb2RlbC5wYXNzd29yZCk7XG4gICAgLy8gICB9KTtcbiAgICAvLyB9KTtcblxuICAgIC8vIHRlc3QoJ3Rlcm1zQW5kQ29uZGl0aW9ucycsICdQbGVhc2Ugc2VsZWN0IHRlcm1zIGFuZCBjb25kaXRpb25zLicsICgpID0+IHtcbiAgICAvLyAgIGVuZm9yY2UobW9kZWwudGVybXNBbmRDb25kaXRpb25zKS5pc1RydXRoeSgpO1xuICAgIC8vIH0pO1xuICB9KTtcbn07XG4iXX0=