import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import * as i0 from "@angular/core";
export class ClBreadCrumbService {
    constructor() {
        this.pageTitle = new BehaviorSubject('');
        this.breadcrumbString = new BehaviorSubject('');
        this.breadcrumbActionButtons = new BehaviorSubject([]);
    }
    /**
     * this function will set the page title and replace it with breadcrumb
     *
     * @param value title of the page
     */
    setPageTitle(value) {
        this.pageTitle.next(value);
    }
    /**
     * this function will reset the page title
     */
    resetPageTitle() {
        this.pageTitle.next('');
    }
    /**
     * this function will add a custom string at the end of breadcrumb
     *
     * @param string to be added
     */
    setBreadCrumbString(value) {
        this.breadcrumbString.next(value);
    }
    /**
     * this function will reset the custom string
     */
    resetBreadCrumbString() {
        this.breadcrumbString.next('');
    }
    /**
     * this function will add action buttons at the extreme end of breadcrumb row
     *
     * @param button properties
     */
    setBreadCrumbActionButtons(actionButtons) {
        this.breadcrumbActionButtons.next(actionButtons);
    }
    /**
     * this function will reset the action buttons
     */
    resetBreadCrumbActionButtons() {
        this.breadcrumbActionButtons.next([]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClBreadCrumbService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnJlYWRjcnVtYi5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbXBsZXgvc3JjL2JyZWFkY3J1bWIvYnJlYWRjcnVtYi5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFM0MsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLCtCQUErQixDQUFDOztBQUloRSxNQUFNLE9BQU8sbUJBQW1CO0lBRmhDO1FBR1MsY0FBUyxHQUE0QixJQUFJLGVBQWUsQ0FBUyxFQUFFLENBQUMsQ0FBQztRQUNyRSxxQkFBZ0IsR0FBNEIsSUFBSSxlQUFlLENBQVMsRUFBRSxDQUFDLENBQUM7UUFDNUUsNEJBQXVCLEdBQTBDLElBQUksZUFBZSxDQUF1QixFQUFFLENBQUMsQ0FBQztLQWlEdkg7SUEvQ0M7Ozs7T0FJRztJQUNJLFlBQVksQ0FBQyxLQUFhO1FBQy9CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7T0FFRztJQUNJLGNBQWM7UUFDbkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDMUIsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxtQkFBbUIsQ0FBQyxLQUFhO1FBQ3RDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOztPQUVHO0lBQ0kscUJBQXFCO1FBQzFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSwwQkFBMEIsQ0FBQyxhQUFtQztRQUNuRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ25ELENBQUM7SUFFRDs7T0FFRztJQUNJLDRCQUE0QjtRQUNqQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7OEdBbkRVLG1CQUFtQjtrSEFBbkIsbUJBQW1CLGNBRk4sTUFBTTs7MkZBRW5CLG1CQUFtQjtrQkFGL0IsVUFBVTttQkFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDbEJ1dHRvblByb3BlcnRpZXMgfSBmcm9tICdAY2xheS91aS1jb21wb25lbnRzL2Jhc2ljJztcbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMvaW50ZXJuYWwvQmVoYXZpb3JTdWJqZWN0JztcblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcblxuZXhwb3J0IGNsYXNzIENsQnJlYWRDcnVtYlNlcnZpY2Uge1xuICBwdWJsaWMgcGFnZVRpdGxlOiBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPiA9IG5ldyBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPignJyk7XG4gIHB1YmxpYyBicmVhZGNydW1iU3RyaW5nOiBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPiA9IG5ldyBCZWhhdmlvclN1YmplY3Q8c3RyaW5nPignJyk7XG4gIHB1YmxpYyBicmVhZGNydW1iQWN0aW9uQnV0dG9uczogQmVoYXZpb3JTdWJqZWN0PENsQnV0dG9uUHJvcGVydGllc1tdPiA9IG5ldyBCZWhhdmlvclN1YmplY3Q8Q2xCdXR0b25Qcm9wZXJ0aWVzW10+KFtdKTtcblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIHNldCB0aGUgcGFnZSB0aXRsZSBhbmQgcmVwbGFjZSBpdCB3aXRoIGJyZWFkY3J1bWJcbiAgICpcbiAgICogQHBhcmFtIHZhbHVlIHRpdGxlIG9mIHRoZSBwYWdlXG4gICAqL1xuICBwdWJsaWMgc2V0UGFnZVRpdGxlKHZhbHVlOiBzdHJpbmcpIHtcbiAgICB0aGlzLnBhZ2VUaXRsZS5uZXh0KHZhbHVlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgcmVzZXQgdGhlIHBhZ2UgdGl0bGVcbiAgICovXG4gIHB1YmxpYyByZXNldFBhZ2VUaXRsZSgpIHtcbiAgICB0aGlzLnBhZ2VUaXRsZS5uZXh0KCcnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgYWRkIGEgY3VzdG9tIHN0cmluZyBhdCB0aGUgZW5kIG9mIGJyZWFkY3J1bWJcbiAgICpcbiAgICogQHBhcmFtIHN0cmluZyB0byBiZSBhZGRlZFxuICAgKi9cbiAgcHVibGljIHNldEJyZWFkQ3J1bWJTdHJpbmcodmFsdWU6IHN0cmluZykge1xuICAgIHRoaXMuYnJlYWRjcnVtYlN0cmluZy5uZXh0KHZhbHVlKTtcbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgcmVzZXQgdGhlIGN1c3RvbSBzdHJpbmdcbiAgICovXG4gIHB1YmxpYyByZXNldEJyZWFkQ3J1bWJTdHJpbmcoKSB7XG4gICAgdGhpcy5icmVhZGNydW1iU3RyaW5nLm5leHQoJycpO1xuICB9XG5cbiAgLyoqXG4gICAqIHRoaXMgZnVuY3Rpb24gd2lsbCBhZGQgYWN0aW9uIGJ1dHRvbnMgYXQgdGhlIGV4dHJlbWUgZW5kIG9mIGJyZWFkY3J1bWIgcm93XG4gICAqXG4gICAqIEBwYXJhbSBidXR0b24gcHJvcGVydGllc1xuICAgKi9cbiAgcHVibGljIHNldEJyZWFkQ3J1bWJBY3Rpb25CdXR0b25zKGFjdGlvbkJ1dHRvbnM6IENsQnV0dG9uUHJvcGVydGllc1tdKSB7XG4gICAgdGhpcy5icmVhZGNydW1iQWN0aW9uQnV0dG9ucy5uZXh0KGFjdGlvbkJ1dHRvbnMpO1xuICB9XG5cbiAgLyoqXG4gICAqIHRoaXMgZnVuY3Rpb24gd2lsbCByZXNldCB0aGUgYWN0aW9uIGJ1dHRvbnNcbiAgICovXG4gIHB1YmxpYyByZXNldEJyZWFkQ3J1bWJBY3Rpb25CdXR0b25zKCkge1xuICAgIHRoaXMuYnJlYWRjcnVtYkFjdGlvbkJ1dHRvbnMubmV4dChbXSk7XG4gIH1cbn1cbiJdfQ==