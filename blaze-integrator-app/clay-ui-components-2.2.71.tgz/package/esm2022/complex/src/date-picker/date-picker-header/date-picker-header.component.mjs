import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, Inject, ViewEncapsulation } from '@angular/core';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { Subject, takeUntil } from 'rxjs';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatIconModule } from '@angular/material/icon';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "@angular/material/datepicker";
import * as i3 from "@angular/material/core";
import * as i4 from "../datepicker.service";
import * as i5 from "@angular/material/icon";
export class DatePickerHeaderComponent {
    constructor(datePipe, cdr, calendar, _dateAdapter, datepickerService, _dateFormats) {
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.calendar = calendar;
        this._dateAdapter = _dateAdapter;
        this.datepickerService = datepickerService;
        this._dateFormats = _dateFormats;
        this._destroyed = new Subject();
        this.range = false;
        this.toLabel = 'To';
        this.fromLabel = 'From';
        this.displayFormat = 'dd MMM YY';
        this.endDate = '--/--/--';
        this.endDateTime = '00 hr: 00 min';
        this.startDate = '--/--/--';
        this.startDateTime = '00 hr: 00 min';
        this.showTime = true;
        this.showYearAndMonth = false;
        calendar.stateChanges.pipe(takeUntil(this._destroyed)).subscribe(() => cdr.markForCheck());
        this.subscription = this.datepickerService.dataSubject.subscribe((value) => {
            this.parseData(value);
        });
    }
    /** Handles user clicks on the period label. */
    currentPeriodClicked() {
        if (this.showYearAndMonth) {
            this.calendar.currentView = 'multi-year';
            return;
        }
        this.calendar.currentView = this.calendar.currentView == 'month' ? 'multi-year' : 'month';
    }
    /** Handles user clicks on the previous button. */
    customPrev() {
        if (this.showYearAndMonth) {
            this.calendar.activeDate = this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
        }
        else {
            let mode = 'month';
            this.calendar.activeDate =
                mode === 'month'
                    ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, -1)
                    : this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
        }
    }
    /** Handles user clicks on the next button. */
    customNext() {
        if (this.showYearAndMonth) {
            this.calendar.activeDate = this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
            return;
        }
        let mode = 'month';
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, 1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
    }
    // this function is triggered whenever user click on the right arrow in the date picker to switch to the previous month or year
    previousClicked(mode) {
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, -1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, -1);
    }
    // this function is triggered whenever user click on the right arrow in the date picker to switch to the next month or year
    nextClicked(mode) {
        this.calendar.activeDate =
            mode === 'month'
                ? this._dateAdapter.addCalendarMonths(this.calendar.activeDate, 1)
                : this._dateAdapter.addCalendarYears(this.calendar.activeDate, 1);
    }
    //this function returns the period label (month and year name)
    get periodLabel() {
        return this._dateAdapter
            .format(this.calendar.activeDate, this._dateFormats.display.monthYearLabel)
            .toLocaleUpperCase();
    }
    // this function will be triggered when ever there is a change in date or time picker
    // to display the updated value
    parseData(data) {
        this.range = data.range;
        this.showYearAndMonth = data.showOnlyMonthYear;
        if (this.range) {
            this.startDateTime = data.startDateTime;
            if (data.startDate != '' && data.startDate != null) {
                this.startDate = this.datePipe.transform(data.startDate, this.displayFormat);
            }
            else {
                this.startDate = '--/--/--';
            }
            this.endDateTime = data.endDateTime;
            if (data.endDate != '' && data.endDate != null) {
                this.endDate = this.datePipe.transform(data.endDate, this.displayFormat);
            }
            else {
                this.endDate = '--/--/--';
            }
        }
        else {
            this.startDateTime = data.startDateTime;
            if (data.startDate != '' && data.startDate != null) {
                this.startDate = this.datePipe.transform(data.startDate, this.displayFormat);
            }
            else {
                this.startDate = '--/--/--';
            }
        }
        this.showTime = data.showTime;
        this.cdr.markForCheck();
    }
    ngOnDestroy() {
        this._destroyed.next();
        this._destroyed.complete();
        this.subscription.unsubscribe();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerHeaderComponent, deps: [{ token: i1.DatePipe }, { token: i0.ChangeDetectorRef }, { token: i2.MatCalendar }, { token: i3.DateAdapter }, { token: i4.DatePickerService }, { token: MAT_DATE_FORMATS }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: DatePickerHeaderComponent, isStandalone: true, selector: "cl-date-picker-header", providers: [DatePipe], ngImport: i0, template: "<div class=\"mat-calendar-header\">\n\n  @if (range) {\n    <div class=\"flex justify-between\">\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\">\n        <label class=\"label text-neutral-800 text-xs\">From date</label>\n        <label class=\"text-base\">{{startDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{startDateTime}}</label>\n        }\n      </div>\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\" >\n        <label class=\"label text-neutral-800 text-xs\">To date</label>\n        <label class=\"text-base\">{{endDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{endDateTime}}</label>\n        }\n      </div>\n    </div>\n  }\n\n  <div class=\"mat-calendar-controls\">\n\n    <mat-icon (click)=\"customPrev()\" [svgIcon]=\"'heroicons_outline:arrow-left'\" class=\"icon-size-4 cursor-pointer\">\n    </mat-icon>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <button mat-button type=\"button\" class=\"mat-calendar-period-button\" (click)=\"currentPeriodClicked()\"\n      [attr.aria-label]=\"periodLabel\" cdkAriaLive=\"polite\">\n      {{periodLabel}}\n    </button>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <mat-icon (click)=\"customNext()\" class=\"icon-size-4 cursor-pointer\" [svgIcon]=\"'heroicons_outline:arrow-right'\">\n    </mat-icon>\n\n  </div>\n</div>\n", styles: [".mat-calendar-header .label-container{width:48%}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i5.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatDatepickerModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: DatePickerHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'cl-date-picker-header', standalone: true, imports: [MatIconModule, MatInputModule, MatDatepickerModule], providers: [DatePipe], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"mat-calendar-header\">\n\n  @if (range) {\n    <div class=\"flex justify-between\">\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\">\n        <label class=\"label text-neutral-800 text-xs\">From date</label>\n        <label class=\"text-base\">{{startDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{startDateTime}}</label>\n        }\n      </div>\n      <div class=\"label-container flex flex-col border border-neutral-400 py-2 px-3 rounded-md\" >\n        <label class=\"label text-neutral-800 text-xs\">To date</label>\n        <label class=\"text-base\">{{endDate}}</label>\n        @if (showTime) {\n          <label class=\"text-base\">{{endDateTime}}</label>\n        }\n      </div>\n    </div>\n  }\n\n  <div class=\"mat-calendar-controls\">\n\n    <mat-icon (click)=\"customPrev()\" [svgIcon]=\"'heroicons_outline:arrow-left'\" class=\"icon-size-4 cursor-pointer\">\n    </mat-icon>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <button mat-button type=\"button\" class=\"mat-calendar-period-button\" (click)=\"currentPeriodClicked()\"\n      [attr.aria-label]=\"periodLabel\" cdkAriaLive=\"polite\">\n      {{periodLabel}}\n    </button>\n\n    <div class=\"mat-calendar-spacer\"></div>\n\n    <mat-icon (click)=\"customNext()\" class=\"icon-size-4 cursor-pointer\" [svgIcon]=\"'heroicons_outline:arrow-right'\">\n    </mat-icon>\n\n  </div>\n</div>\n", styles: [".mat-calendar-header .label-container{width:48%}\n"] }]
        }], ctorParameters: () => [{ type: i1.DatePipe }, { type: i0.ChangeDetectorRef }, { type: i2.MatCalendar }, { type: i3.DateAdapter }, { type: i4.DatePickerService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DATE_FORMATS]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS1waWNrZXItaGVhZGVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb21wbGV4L3NyYy9kYXRlLXBpY2tlci9kYXRlLXBpY2tlci1oZWFkZXIvZGF0ZS1waWNrZXItaGVhZGVyLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb21wbGV4L3NyYy9kYXRlLXBpY2tlci9kYXRlLXBpY2tlci1oZWFkZXIvZGF0ZS1waWNrZXItaGVhZGVyLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMzQyxPQUFPLEVBQUUsdUJBQXVCLEVBQXFCLFNBQVMsRUFBRSxNQUFNLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDakgsT0FBTyxFQUFlLGdCQUFnQixFQUFrQixNQUFNLHdCQUF3QixDQUFDO0FBQ3ZGLE9BQU8sRUFBRSxPQUFPLEVBQWdCLFNBQVMsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUN4RCxPQUFPLEVBQWUsbUJBQW1CLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRixPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHdCQUF3QixDQUFDOzs7Ozs7O0FBYXZELE1BQU0sT0FBTyx5QkFBeUI7SUFtQnBDLFlBQ1UsUUFBa0IsRUFDbEIsR0FBc0IsRUFDdEIsUUFBMEIsRUFDMUIsWUFBOEIsRUFDOUIsaUJBQW9DLEVBQ1YsWUFBNEI7UUFMdEQsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNsQixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUN0QixhQUFRLEdBQVIsUUFBUSxDQUFrQjtRQUMxQixpQkFBWSxHQUFaLFlBQVksQ0FBa0I7UUFDOUIsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFtQjtRQUNWLGlCQUFZLEdBQVosWUFBWSxDQUFnQjtRQXZCeEQsZUFBVSxHQUFHLElBQUksT0FBTyxFQUFRLENBQUM7UUFFbEMsVUFBSyxHQUFZLEtBQUssQ0FBQztRQUV2QixZQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ2YsY0FBUyxHQUFHLE1BQU0sQ0FBQztRQUVsQixrQkFBYSxHQUFXLFdBQVcsQ0FBQztRQUVyQyxZQUFPLEdBQVcsVUFBVSxDQUFDO1FBQzdCLGdCQUFXLEdBQVcsZUFBZSxDQUFDO1FBRXRDLGNBQVMsR0FBVyxVQUFVLENBQUM7UUFDL0Isa0JBQWEsR0FBVyxlQUFlLENBQUM7UUFDeEMsYUFBUSxHQUFZLElBQUksQ0FBQztRQUN6QixxQkFBZ0IsR0FBWSxLQUFLLENBQUM7UUFVdkMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztRQUUzRixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBUyxFQUFFLEVBQUU7WUFDN0UsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QixDQUFDLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFFRCwrQ0FBK0M7SUFDL0Msb0JBQW9CO1FBQ2xCLElBQUcsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsWUFBWSxDQUFDO1lBQ3pDLE9BQU87UUFDVCxDQUFDO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztJQUM1RixDQUFDO0lBRUQsa0RBQWtEO0lBQ2xELFVBQVU7UUFDUixJQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM5RixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksSUFBSSxHQUFHLE9BQU8sQ0FBQztZQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVU7Z0JBQ3RCLElBQUksS0FBSyxPQUFPO29CQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNuRSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pFLENBQUM7SUFDSCxDQUFDO0lBRUQsOENBQThDO0lBQzlDLFVBQVU7UUFDUixJQUFHLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDM0YsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLElBQUksR0FBRyxPQUFPLENBQUM7UUFFbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVO1lBQ3RCLElBQUksS0FBSyxPQUFPO2dCQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztnQkFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDeEUsQ0FBQztJQUVELCtIQUErSDtJQUMvSCxlQUFlLENBQUMsSUFBc0I7UUFDcEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVO1lBQ3RCLElBQUksS0FBSyxPQUFPO2dCQUNkLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO2dCQUNuRSxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFRCwySEFBMkg7SUFDM0gsV0FBVyxDQUFDLElBQXNCO1FBQ2hDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVTtZQUN0QixJQUFJLEtBQUssT0FBTztnQkFDZCxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7Z0JBQ2xFLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3hFLENBQUM7SUFFRCw4REFBOEQ7SUFDOUQsSUFBSSxXQUFXO1FBQ2IsT0FBTyxJQUFJLENBQUMsWUFBWTthQUNyQixNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDO2FBQzFFLGlCQUFpQixFQUFFLENBQUM7SUFDekIsQ0FBQztJQUVELHFGQUFxRjtJQUNyRiwrQkFBK0I7SUFDL0IsU0FBUyxDQUFDLElBQVM7UUFDakIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFFL0MsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7WUFFeEMsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO2dCQUNuRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBRSxDQUFDO1lBQ2hGLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQztZQUM5QixDQUFDO1lBRUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO1lBRXBDLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDL0MsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUUsQ0FBQztZQUM1RSxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLE9BQU8sR0FBRyxVQUFVLENBQUM7WUFDNUIsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBRXhDLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQztnQkFDbkQsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUUsQ0FBQztZQUNoRixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUM7WUFDOUIsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFFOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRUQsV0FBVztRQUNULElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2xDLENBQUM7OEdBdElVLHlCQUF5QixrS0F5QjFCLGdCQUFnQjtrR0F6QmYseUJBQXlCLG9FQU56QixDQUFDLFFBQVEsQ0FBQywwQkNidkIsKzdDQXdDQSwyR0Q1QlksYUFBYSxtTEFBRSxjQUFjLDhCQUFFLG1CQUFtQjs7MkZBT2pELHlCQUF5QjtrQkFWckMsU0FBUzsrQkFDRSx1QkFBdUIsY0FDckIsSUFBSSxXQUNQLENBQUMsYUFBYSxFQUFFLGNBQWMsRUFBRSxtQkFBbUIsQ0FBQyxhQUNsRCxDQUFDLFFBQVEsQ0FBQyxpQkFHTixpQkFBaUIsQ0FBQyxJQUFJLG1CQUNwQix1QkFBdUIsQ0FBQyxNQUFNOzswQkEyQjVDLE1BQU07MkJBQUMsZ0JBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGF0ZVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENoYW5nZURldGVjdG9yUmVmLCBDb21wb25lbnQsIEluamVjdCwgVmlld0VuY2Fwc3VsYXRpb24gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERhdGVBZGFwdGVyLCBNQVRfREFURV9GT1JNQVRTLCBNYXREYXRlRm9ybWF0cyB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NvcmUnO1xuaW1wb3J0IHsgU3ViamVjdCwgU3Vic2NyaXB0aW9uLCB0YWtlVW50aWwgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IE1hdENhbGVuZGFyLCBNYXREYXRlcGlja2VyTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvZGF0ZXBpY2tlcic7XG5pbXBvcnQgeyBNYXRJbnB1dE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2lucHV0JztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IERhdGVQaWNrZXJTZXJ2aWNlIH0gZnJvbSAnLi4vZGF0ZXBpY2tlci5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnY2wtZGF0ZS1waWNrZXItaGVhZGVyJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW01hdEljb25Nb2R1bGUsIE1hdElucHV0TW9kdWxlLCBNYXREYXRlcGlja2VyTW9kdWxlXSxcbiAgcHJvdmlkZXJzOiBbRGF0ZVBpcGVdLFxuICB0ZW1wbGF0ZVVybDogJy4vZGF0ZS1waWNrZXItaGVhZGVyLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmw6ICcuL2RhdGUtcGlja2VyLWhlYWRlci5jb21wb25lbnQuc2NzcycsXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEYXRlUGlja2VySGVhZGVyQ29tcG9uZW50IHtcbiAgcHJpdmF0ZSBzdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcbiAgcHJpdmF0ZSBfZGVzdHJveWVkID0gbmV3IFN1YmplY3Q8dm9pZD4oKTtcblxuICBwdWJsaWMgcmFuZ2U6IGJvb2xlYW4gPSBmYWxzZTtcblxuICBwdWJsaWMgdG9MYWJlbCA9ICdUbyc7XG4gIHB1YmxpYyBmcm9tTGFiZWwgPSAnRnJvbSc7XG5cbiAgcHJpdmF0ZSBkaXNwbGF5Rm9ybWF0OiBzdHJpbmcgPSAnZGQgTU1NIFlZJztcblxuICBwdWJsaWMgZW5kRGF0ZTogc3RyaW5nID0gJy0tLy0tLy0tJztcbiAgcHVibGljIGVuZERhdGVUaW1lOiBzdHJpbmcgPSAnMDAgaHI6IDAwIG1pbic7XG5cbiAgcHVibGljIHN0YXJ0RGF0ZTogc3RyaW5nID0gJy0tLy0tLy0tJztcbiAgcHVibGljIHN0YXJ0RGF0ZVRpbWU6IHN0cmluZyA9ICcwMCBocjogMDAgbWluJztcbiAgcHVibGljIHNob3dUaW1lOiBib29sZWFuID0gdHJ1ZTtcbiAgcHVibGljIHNob3dZZWFyQW5kTW9udGg6IGJvb2xlYW4gPSBmYWxzZTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGRhdGVQaXBlOiBEYXRlUGlwZSxcbiAgICBwcml2YXRlIGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgcHJpdmF0ZSBjYWxlbmRhcjogTWF0Q2FsZW5kYXI8YW55PixcbiAgICBwcml2YXRlIF9kYXRlQWRhcHRlcjogRGF0ZUFkYXB0ZXI8YW55PixcbiAgICBwcml2YXRlIGRhdGVwaWNrZXJTZXJ2aWNlOiBEYXRlUGlja2VyU2VydmljZSxcbiAgICBASW5qZWN0KE1BVF9EQVRFX0ZPUk1BVFMpIHByaXZhdGUgX2RhdGVGb3JtYXRzOiBNYXREYXRlRm9ybWF0cyxcbiAgKSB7XG4gICAgY2FsZW5kYXIuc3RhdGVDaGFuZ2VzLnBpcGUodGFrZVVudGlsKHRoaXMuX2Rlc3Ryb3llZCkpLnN1YnNjcmliZSgoKSA9PiBjZHIubWFya0ZvckNoZWNrKCkpO1xuXG4gICAgdGhpcy5zdWJzY3JpcHRpb24gPSB0aGlzLmRhdGVwaWNrZXJTZXJ2aWNlLmRhdGFTdWJqZWN0LnN1YnNjcmliZSgodmFsdWU6YW55KSA9PiB7XG4gICAgICB0aGlzLnBhcnNlRGF0YSh2YWx1ZSk7XG4gICAgfSlcbiAgfVxuXG4gIC8qKiBIYW5kbGVzIHVzZXIgY2xpY2tzIG9uIHRoZSBwZXJpb2QgbGFiZWwuICovXG4gIGN1cnJlbnRQZXJpb2RDbGlja2VkKCk6IHZvaWQge1xuICAgIGlmKHRoaXMuc2hvd1llYXJBbmRNb250aCkge1xuICAgICAgdGhpcy5jYWxlbmRhci5jdXJyZW50VmlldyA9ICdtdWx0aS15ZWFyJztcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5jYWxlbmRhci5jdXJyZW50VmlldyA9IHRoaXMuY2FsZW5kYXIuY3VycmVudFZpZXcgPT0gJ21vbnRoJyA/ICdtdWx0aS15ZWFyJyA6ICdtb250aCc7XG4gIH1cblxuICAvKiogSGFuZGxlcyB1c2VyIGNsaWNrcyBvbiB0aGUgcHJldmlvdXMgYnV0dG9uLiAqL1xuICBjdXN0b21QcmV2KCk6IHZvaWQge1xuICAgIGlmKHRoaXMuc2hvd1llYXJBbmRNb250aCkge1xuICAgICAgdGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlID0gdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJZZWFycyh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIC0xKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IG1vZGUgPSAnbW9udGgnO1xuICAgICAgdGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlID1cbiAgICAgICAgbW9kZSA9PT0gJ21vbnRoJ1xuICAgICAgICAgID8gdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJNb250aHModGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlLCAtMSlcbiAgICAgICAgICA6IHRoaXMuX2RhdGVBZGFwdGVyLmFkZENhbGVuZGFyWWVhcnModGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlLCAtMSk7XG4gICAgfVxuICB9XG5cbiAgLyoqIEhhbmRsZXMgdXNlciBjbGlja3Mgb24gdGhlIG5leHQgYnV0dG9uLiAqL1xuICBjdXN0b21OZXh0KCk6IHZvaWQge1xuICAgIGlmKHRoaXMuc2hvd1llYXJBbmRNb250aCkge1xuICAgICAgdGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlID0gdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJZZWFycyh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIDEpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGxldCBtb2RlID0gJ21vbnRoJztcblxuICAgIHRoaXMuY2FsZW5kYXIuYWN0aXZlRGF0ZSA9XG4gICAgICBtb2RlID09PSAnbW9udGgnXG4gICAgICAgID8gdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJNb250aHModGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlLCAxKVxuICAgICAgICA6IHRoaXMuX2RhdGVBZGFwdGVyLmFkZENhbGVuZGFyWWVhcnModGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlLCAxKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW5ldmVyIHVzZXIgY2xpY2sgb24gdGhlIHJpZ2h0IGFycm93IGluIHRoZSBkYXRlIHBpY2tlciB0byBzd2l0Y2ggdG8gdGhlIHByZXZpb3VzIG1vbnRoIG9yIHllYXJcbiAgcHJldmlvdXNDbGlja2VkKG1vZGU6ICdtb250aCcgfCAneWVhcicpIHtcbiAgICB0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUgPVxuICAgICAgbW9kZSA9PT0gJ21vbnRoJ1xuICAgICAgICA/IHRoaXMuX2RhdGVBZGFwdGVyLmFkZENhbGVuZGFyTW9udGhzKHRoaXMuY2FsZW5kYXIuYWN0aXZlRGF0ZSwgLTEpXG4gICAgICAgIDogdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJZZWFycyh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIC0xKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW5ldmVyIHVzZXIgY2xpY2sgb24gdGhlIHJpZ2h0IGFycm93IGluIHRoZSBkYXRlIHBpY2tlciB0byBzd2l0Y2ggdG8gdGhlIG5leHQgbW9udGggb3IgeWVhclxuICBuZXh0Q2xpY2tlZChtb2RlOiAnbW9udGgnIHwgJ3llYXInKSB7XG4gICAgdGhpcy5jYWxlbmRhci5hY3RpdmVEYXRlID1cbiAgICAgIG1vZGUgPT09ICdtb250aCdcbiAgICAgICAgPyB0aGlzLl9kYXRlQWRhcHRlci5hZGRDYWxlbmRhck1vbnRocyh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIDEpXG4gICAgICAgIDogdGhpcy5fZGF0ZUFkYXB0ZXIuYWRkQ2FsZW5kYXJZZWFycyh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIDEpO1xuICB9XG5cbiAgLy90aGlzIGZ1bmN0aW9uIHJldHVybnMgdGhlIHBlcmlvZCBsYWJlbCAobW9udGggYW5kIHllYXIgbmFtZSlcbiAgZ2V0IHBlcmlvZExhYmVsKCkge1xuICAgIHJldHVybiB0aGlzLl9kYXRlQWRhcHRlclxuICAgICAgLmZvcm1hdCh0aGlzLmNhbGVuZGFyLmFjdGl2ZURhdGUsIHRoaXMuX2RhdGVGb3JtYXRzLmRpc3BsYXkubW9udGhZZWFyTGFiZWwpXG4gICAgICAudG9Mb2NhbGVVcHBlckNhc2UoKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gd2lsbCBiZSB0cmlnZ2VyZWQgd2hlbiBldmVyIHRoZXJlIGlzIGEgY2hhbmdlIGluIGRhdGUgb3IgdGltZSBwaWNrZXJcbiAgLy8gdG8gZGlzcGxheSB0aGUgdXBkYXRlZCB2YWx1ZVxuICBwYXJzZURhdGEoZGF0YTogYW55KSB7XG4gICAgdGhpcy5yYW5nZSA9IGRhdGEucmFuZ2U7XG4gICAgdGhpcy5zaG93WWVhckFuZE1vbnRoID0gZGF0YS5zaG93T25seU1vbnRoWWVhcjtcblxuICAgIGlmICh0aGlzLnJhbmdlKSB7XG4gICAgICB0aGlzLnN0YXJ0RGF0ZVRpbWUgPSBkYXRhLnN0YXJ0RGF0ZVRpbWU7XG5cbiAgICAgIGlmIChkYXRhLnN0YXJ0RGF0ZSAhPSAnJyAmJiBkYXRhLnN0YXJ0RGF0ZSAhPSBudWxsKSB7XG4gICAgICAgIHRoaXMuc3RhcnREYXRlID0gdGhpcy5kYXRlUGlwZS50cmFuc2Zvcm0oZGF0YS5zdGFydERhdGUsIHRoaXMuZGlzcGxheUZvcm1hdCkhO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5zdGFydERhdGUgPSAnLS0vLS0vLS0nO1xuICAgICAgfVxuXG4gICAgICB0aGlzLmVuZERhdGVUaW1lID0gZGF0YS5lbmREYXRlVGltZTtcblxuICAgICAgaWYgKGRhdGEuZW5kRGF0ZSAhPSAnJyAmJiBkYXRhLmVuZERhdGUgIT0gbnVsbCkge1xuICAgICAgICB0aGlzLmVuZERhdGUgPSB0aGlzLmRhdGVQaXBlLnRyYW5zZm9ybShkYXRhLmVuZERhdGUsIHRoaXMuZGlzcGxheUZvcm1hdCkhO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lbmREYXRlID0gJy0tLy0tLy0tJztcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdGFydERhdGVUaW1lID0gZGF0YS5zdGFydERhdGVUaW1lO1xuXG4gICAgICBpZiAoZGF0YS5zdGFydERhdGUgIT0gJycgJiYgZGF0YS5zdGFydERhdGUgIT0gbnVsbCkge1xuICAgICAgICB0aGlzLnN0YXJ0RGF0ZSA9IHRoaXMuZGF0ZVBpcGUudHJhbnNmb3JtKGRhdGEuc3RhcnREYXRlLCB0aGlzLmRpc3BsYXlGb3JtYXQpITtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuc3RhcnREYXRlID0gJy0tLy0tLy0tJztcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5zaG93VGltZSA9IGRhdGEuc2hvd1RpbWU7XG5cbiAgICB0aGlzLmNkci5tYXJrRm9yQ2hlY2soKTtcbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuX2Rlc3Ryb3llZC5uZXh0KCk7XG4gICAgdGhpcy5fZGVzdHJveWVkLmNvbXBsZXRlKCk7XG4gICAgdGhpcy5zdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cIm1hdC1jYWxlbmRhci1oZWFkZXJcIj5cblxuICBAaWYgKHJhbmdlKSB7XG4gICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWwtY29udGFpbmVyIGZsZXggZmxleC1jb2wgYm9yZGVyIGJvcmRlci1uZXV0cmFsLTQwMCBweS0yIHB4LTMgcm91bmRlZC1tZFwiPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJsYWJlbCB0ZXh0LW5ldXRyYWwtODAwIHRleHQteHNcIj5Gcm9tIGRhdGU8L2xhYmVsPlxuICAgICAgICA8bGFiZWwgY2xhc3M9XCJ0ZXh0LWJhc2VcIj57e3N0YXJ0RGF0ZX19PC9sYWJlbD5cbiAgICAgICAgQGlmIChzaG93VGltZSkge1xuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQtYmFzZVwiPnt7c3RhcnREYXRlVGltZX19PC9sYWJlbD5cbiAgICAgICAgfVxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwibGFiZWwtY29udGFpbmVyIGZsZXggZmxleC1jb2wgYm9yZGVyIGJvcmRlci1uZXV0cmFsLTQwMCBweS0yIHB4LTMgcm91bmRlZC1tZFwiID5cbiAgICAgICAgPGxhYmVsIGNsYXNzPVwibGFiZWwgdGV4dC1uZXV0cmFsLTgwMCB0ZXh0LXhzXCI+VG8gZGF0ZTwvbGFiZWw+XG4gICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQtYmFzZVwiPnt7ZW5kRGF0ZX19PC9sYWJlbD5cbiAgICAgICAgQGlmIChzaG93VGltZSkge1xuICAgICAgICAgIDxsYWJlbCBjbGFzcz1cInRleHQtYmFzZVwiPnt7ZW5kRGF0ZVRpbWV9fTwvbGFiZWw+XG4gICAgICAgIH1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICB9XG5cbiAgPGRpdiBjbGFzcz1cIm1hdC1jYWxlbmRhci1jb250cm9sc1wiPlxuXG4gICAgPG1hdC1pY29uIChjbGljayk9XCJjdXN0b21QcmV2KClcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6YXJyb3ctbGVmdCdcIiBjbGFzcz1cImljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyXCI+XG4gICAgPC9tYXQtaWNvbj5cblxuICAgIDxkaXYgY2xhc3M9XCJtYXQtY2FsZW5kYXItc3BhY2VyXCI+PC9kaXY+XG5cbiAgICA8YnV0dG9uIG1hdC1idXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwibWF0LWNhbGVuZGFyLXBlcmlvZC1idXR0b25cIiAoY2xpY2spPVwiY3VycmVudFBlcmlvZENsaWNrZWQoKVwiXG4gICAgICBbYXR0ci5hcmlhLWxhYmVsXT1cInBlcmlvZExhYmVsXCIgY2RrQXJpYUxpdmU9XCJwb2xpdGVcIj5cbiAgICAgIHt7cGVyaW9kTGFiZWx9fVxuICAgIDwvYnV0dG9uPlxuXG4gICAgPGRpdiBjbGFzcz1cIm1hdC1jYWxlbmRhci1zcGFjZXJcIj48L2Rpdj5cblxuICAgIDxtYXQtaWNvbiAoY2xpY2spPVwiY3VzdG9tTmV4dCgpXCIgY2xhc3M9XCJpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlclwiIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTphcnJvdy1yaWdodCdcIj5cbiAgICA8L21hdC1pY29uPlxuXG4gIDwvZGl2PlxuPC9kaXY+XG4iXX0=