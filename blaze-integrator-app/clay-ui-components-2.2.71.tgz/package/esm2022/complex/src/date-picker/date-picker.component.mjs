import { DatePipe } from '@angular/common';
import { Component, Input, Optional, Self, ViewChild, ViewChildren, ViewEncapsulation, signal } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatNativeDateModule } from '@angular/material/core';
import { DateRange, MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormField, MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClButtonBehavior, ClButtonComponent, IClButtonType } from '@clay/ui-components/basic';
import { DatePickerHeaderComponent } from './date-picker-header/date-picker-header.component';
import { ClDatePickerProperties } from './date-picker.properties';
import { ClBaseComponent, ClComponentTypes } from '@clay/ui-components/shared';
import { FullscreenOverlayContainer, OverlayContainer, OverlayModule } from '@angular/cdk/overlay';
import { ClTooltipDirective } from '@clay/app-shell/structural';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
import * as i2 from "@angular/common";
import * as i3 from "./datepicker.service";
import * as i4 from "@angular/cdk/overlay";
import * as i5 from "@angular/material/card";
import * as i6 from "@angular/material/icon";
import * as i7 from "@angular/material/input";
import * as i8 from "@angular/material/form-field";
import * as i9 from "@angular/material/datepicker";
export class ClDatepickerComponent extends ClBaseComponent {
    constructor(ngControl, datePipe, cdr, datepickerService, overlay) {
        super();
        this.ngControl = ngControl;
        this.datePipe = datePipe;
        this.cdr = cdr;
        this.datepickerService = datepickerService;
        this.overlay = overlay;
        this.range = false;
        this.showCalendar = false;
        this.positions = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom',
            },
            {
                originX: 'center',
                originY: 'center',
                overlayX: 'start',
                overlayY: 'center',
            }
        ];
        this.scrollStrategy = this.overlay.scrollStrategies.reposition();
        this.startAt = new Date();
        this.customHeader = DatePickerHeaderComponent;
        this.singleDateSelection = { range: false, startDate: '', startDateTime: '' };
        this.multiDateSelection = { endDate: '', range: true, startDate: '', endDateTime: '', startDateTime: '' };
        this.applyButtonDisable = signal(true);
        this.applyButtonProperties = {
            label: 'Apply',
            disabled: this.applyButtonDisable,
            id: 'btnDatePickerApply',
            buttonType: IClButtonType.button,
            buttonBehavior: ClButtonBehavior.flat,
            type: ClComponentTypes.button,
            onSubmit: this.apply.bind(this),
            style: {
                cssClasses: 'apply-btn bg-primary',
                labelCssClasses: 'text-white text-base'
            },
        };
        this.cancelButtonProperties = {
            label: 'Cancel',
            id: 'btnDatePickerCancel',
            buttonType: IClButtonType.button,
            buttonBehavior: ClButtonBehavior.flat,
            type: ClComponentTypes.button,
            onSubmit: this.cancel.bind(this),
            style: {
                cssClasses: 'bg-tertiary',
                labelCssClasses: 'text-base',
            },
        };
        this.startDateHoursMinutes = new FormGroup({
            hours: new FormControl(''),
            minutes: new FormControl('')
        });
        this.endDateHoursMinutes = new FormGroup({
            hours: new FormControl(''),
            minutes: new FormControl('')
        });
        this.showEndTime = false;
        this.showStartTime = true;
        this.displayFormatWithoutTime = 'd MMM, y';
        this.displayFormatWithTime = 'd MMM, y HH:mm';
        this.selectedDate = new Date();
        this.previousRange = false;
        this.onChange = (_) => { };
        this.onTouched = (_) => { };
        this.disableFromDate = (d) => {
            const date = d || new Date();
            const fromDate = this.properties.fromDate ? new Date(this.properties.fromDate) : null;
            if (!fromDate) {
                return ''; // If fromDate is undefined, return an empty string, no date will be disabled
            }
            return this.formatDateToYyyyMmDd(date) === this.formatDateToYyyyMmDd(fromDate) ? 'disabled-date' : '';
        };
        super.setProperties(this.properties);
        if (this.ngControl != null) {
            // Setting the value accessor directly (instead of using
            // the providers) to avoid running into a circular import.
            this.ngControl.valueAccessor = this;
        }
    }
    writeValue(value) {
        this._value = value;
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    get value() {
        return this._value;
    }
    ngOnInit() {
        this.properties ??= new ClDatePickerProperties();
        const startDateHour = this.selectedDateRange?.start ? this.selectedDateRange?.start.getHours() : 0;
        const startDateMinutes = this.selectedDateRange?.start ? this.selectedDateRange?.start.getMinutes() : 0;
        const endDateHour = this.selectedDateRange?.end ? this.selectedDateRange?.end.getHours() : 23;
        const endDateMinutes = this.selectedDateRange?.end ? this.selectedDateRange?.end.getMinutes() : 59;
        this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
        this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
        this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(endDateHour));
        this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(endDateMinutes));
        // assign the range value from the properties object
        // this.range = this.properties?.range ?  : false;
        this.setValues();
        this.properties.showTime ??= true;
        if (this.properties.fromDate || this.properties.toDate) {
            if (this.properties.fromDate) {
                this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
                this.previousFromDate = this.properties.fromDate;
            }
            if (this.properties.toDate) {
                this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
                this.previousToDate = this.properties.toDate;
            }
            this.setValues();
        }
        this.ngControl?.valueChanges?.subscribe((value) => {
            this.setValuesFromFormGroup(value);
            this.setValues();
        });
        super.ngOnInit();
    }
    ngDoCheck() {
        if (this.properties?.range !== this.previousRange) {
            if (this.properties?.range !== undefined) {
                this.previousRange = this.properties?.range;
                if (this.properties.fromDate && this.properties.fromDate != '') {
                    this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
                }
                if (this.properties.toDate && this.properties.toDate != '') {
                    this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
                }
                this.setValues();
            }
        }
        // if (this.properties.fromDate || this.properties.toDate) {
        this.updateFromAndToDate();
        if (this.previousShowTime != this.properties.showTime) {
            this.prepareHeaderDateObject();
            this.previousShowTime = this.properties.showTime;
        }
        if (this.properties.minDate != this.previousMinDate) {
            this.updateMinDate();
            this.previousMinDate = this.properties.minDate;
        }
        if (this.properties.maxDate != this.previousMaxDate) {
            this.updateMaxDate();
            this.previousMaxDate = this.properties.maxDate;
        }
    }
    ngAfterViewInit() {
        // setting the references of Native Elements, which will be used in setErrorText() and setHintText()
        // this.errorOrHintDivElement = this.errorOrHintDivElementRef.nativeElement;
        // this.matTextFieldDivElement = this.matFormField._elementRef.nativeElement.querySelector('.mat-mdc-text-field-wrapper.mdc-text-field');
        // calling set hint text function
        this.setHintText();
        // remove all the errors when the status is valid
        this.sub = this.ngControl?.statusChanges.subscribe((changes) => {
            if (changes === 'VALID') {
                this.error = null;
                // calling set hint text function
                this.setHintText();
            }
        });
    }
    updateFromAndToDate() {
        if (this.properties.fromDate && this.properties.fromDate != '' && this.properties.fromDate != this.previousFromDate) {
            this.setValuesFromFormGroupStart(this.properties.fromDate, 'startDate');
            this.previousFromDate = this.properties.fromDate;
            this.setValues();
        }
        else if (this.properties.fromDate == '' && this.properties.fromDate != this.previousFromDate) {
            this.updateMinDate();
            this.previousFromDate = this.properties.fromDate;
        }
        if (this.properties.toDate && this.properties.toDate != '' && this.properties.toDate != this.previousToDate) {
            this.setValuesFromFormGroupStart(this.properties.toDate, 'endDate');
            this.previousToDate = this.properties.toDate;
            this.setValues();
        }
        else if (this.properties.toDate == '' && this.properties.toDate != this.previousToDate) {
            this.updateMaxDate();
            this.previousToDate = this.properties.toDate;
        }
    }
    ngAfterContentChecked() {
        // below is to avoid displaying 'undefined' on screen when model is not defined .. yet.
        this.setEmptyValue();
        // trigger the error pattern once the content is checked
        if (this.ngControl != null && this.ngControl.touched === true && this.ngControl.errors) {
            this.error = this.ngControl.errors ? this.ngControl.errors['error'] : null;
            // calling set error text function
            this.setErrorText(this.error);
        }
    }
    setHintText() {
        // this.errorOrHintDivElement.innerText = this.properties.hintText ?? '';
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-hint');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-error');
        // this.matTextFieldDivElement.classList.remove('mdc-text-field--invalid');
        this.matFormField._elementRef.nativeElement.classList.remove('mat-form-field-invalid');
    }
    setErrorText(error) {
        // this.errorOrHintDivElement.innerText = error;
        // this.errorOrHintDivElement.classList.add('mat-mdc-form-field-error');
        // this.errorOrHintDivElement.classList.remove('mat-mdc-form-field-hint');
        this.matFormField._elementRef.nativeElement.classList.add('mat-form-field-invalid');
        // this.matTextFieldDivElement.classList.add('mdc-text-field--invalid');
    }
    setEmptyValue() {
        if (this._value === undefined) {
            this._value = '';
        }
    }
    ngOnDestroy() {
        /**
        * !! Warning !!
        * The below super calls are always to be implemented for any component. Otherwise nothing will work.
        */
        this.sub?.unsubscribe();
        super.ngOnDestroy();
        //-----------------------------------------------------------------------------------------------------
    }
    setValuesFromFormGroup(value) {
        if (this.properties.range) {
            //split the date with '-'
            if (value != undefined) {
                let selectedDates = value.split('-');
                const startDate = new Date(selectedDates[0]);
                const endDate = new Date(selectedDates[1]);
                this.selectedDateRange = new DateRange(startDate, endDate);
            }
        }
        else {
            this.selectedDate = new Date(value);
        }
    }
    formatDateToYyyyMmDd(date) {
        if (!date)
            return '';
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-indexed
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    setValuesFromFormGroupStart(value, dateKey) {
        if (this.properties.range) {
            //split the date with '-'
            const dateValue = new Date(value);
            if (dateKey == 'startDate') {
                this.selectedDateRange = new DateRange(dateValue, null);
                this.updateMinDate();
            }
            else if (dateKey == 'endDate') {
                this.selectedDateRange = new DateRange(null, dateValue);
                this.updateMaxDate();
            }
        }
        else {
            this.selectedDate = new Date(value);
        }
    }
    updateMinDate() {
        if (this.properties.minDate) {
            const parsedDate = new Date(this.properties.minDate);
            if (!isNaN(parsedDate.getTime())) {
                this.minDate = parsedDate;
            }
            else {
                this.minDate = null;
            }
        }
        else if (this.properties.fromDate && this.properties.fromDate != '') {
            this.minDate = new Date(this.properties.fromDate);
        }
        else {
            this.minDate = null;
        }
    }
    updateMaxDate() {
        if (this.properties.maxDate) {
            const parsedDate = new Date(this.properties.maxDate);
            if (!isNaN(parsedDate.getTime())) {
                this.maxDate = parsedDate;
            }
            else {
                this.maxDate = null;
            }
        }
        else if (this.properties.toDate && this.properties.toDate != '') {
            this.maxDate = new Date(this.properties.toDate);
        }
        else {
            this.maxDate = null;
        }
    }
    setValues() {
        if (this.properties.range) {
            const startDateHour = this.selectedDateRange?.start ? this.selectedDateRange?.start.getHours() : 0;
            const startDateMinutes = this.selectedDateRange?.start ? this.selectedDateRange?.start.getMinutes() : 0;
            const endDateHour = this.selectedDateRange?.end ? this.selectedDateRange?.end.getHours() : 23;
            const endDateMinutes = this.selectedDateRange?.end ? this.selectedDateRange?.end.getMinutes() : 59;
            this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
            this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
            this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(endDateHour));
            this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(endDateMinutes));
        }
        else {
            const startDateHour = this.selectedDate ? this.selectedDate.getHours() : 0;
            const startDateMinutes = this.selectedDate ? this.selectedDate.getMinutes() : 0;
            this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(startDateHour));
            this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(startDateMinutes));
        }
        //sending the header obj to datepicker header
        this.prepareHeaderDateObject();
    }
    // this function is triggered on the opening the calendar panel
    openCalendar() {
        const scrollableDiv = document.getElementById('scrollableDiv');
        if (scrollableDiv) {
            scrollableDiv.scrollTo({
                left: 0, // Scroll to the very left
                behavior: 'smooth' // Smooth scrolling animation
            });
            // Delay opening the calendar slightly to ensure scrolling completes
            setTimeout(() => {
                // this.openCalendarAfterScroll();
                this.showCalendar = !this.showCalendar;
            }, 300); // Adjust timeout based on expected scroll duration
        }
        else {
            // If no scrolling is needed, directly open the calendar
            // this.openCalendarAfterScroll();
            this.showCalendar = !this.showCalendar;
        }
    }
    openCalendarAfterScroll() {
        // if (this.customDatePicker) {
        //   const { left, right, bottom } = this.customDatePicker.nativeElement.getBoundingClientRect();
        //   this.datePickerLeft = left;
        //   this.datePickerTop = bottom - 20;
        // } else {
        //   this.datePickerLeft = screen.availWidth / 2;
        //   this.datePickerTop = screen.availHeight / 2 - 20;
        // }
        // Show the calendar after positioning
        this.showCalendar = true;
    }
    closeCalendar() {
        this.showCalendar = false;
    }
    dateChange(date) {
        if (this.properties.range) {
            if (this.selectedDateRange && this.selectedDateRange.start && date >= this.selectedDateRange.start && !this.selectedDateRange.end) {
                // this.applyButtonProperties.disabled = false;
                // this.applyButtonDisable.set(false);
                this.selectedDateRange = new DateRange(this.selectedDateRange.start, date);
                this.showEndTime = true;
                this.showStartTime = false;
            }
            else {
                // this.applyButtonProperties.disabled = true;
                // this.applyButtonDisable.set(true);
                this.showEndTime = false;
                this.showStartTime = true;
                if (this.properties.fromDate) {
                    // this.applyButtonDisable.set(false);
                    this.selectedDateRange = new DateRange(new Date(this.properties.fromDate), date);
                    this.showEndTime = true;
                    this.showStartTime = false;
                }
                else {
                    if (this.properties.toDate) {
                        this.selectedDateRange = new DateRange(date, new Date(this.properties.toDate));
                    }
                    else {
                        this.selectedDateRange = new DateRange(date, null);
                    }
                    // this.applyButtonDisable.set(false);
                }
            }
            if (this.selectedDateRange && this.selectedDateRange.start && this.selectedDateRange.end) {
                this.applyButtonDisable.set(false);
            }
            else {
                this.applyButtonDisable.set(true);
            }
        }
        else {
            this.selectedDate = date;
            // this.applyButtonProperties.disabled = false;
            this.applyButtonDisable.set(false);
            this.showStartTime = true;
            this.showEndTime = false;
        }
        this.prepareHeaderDateObject();
    }
    decreaseMins(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.minutes.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.minutes.value);
        }
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    increaseMins(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.minutes.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.minutes.value);
        }
        if (currentValue >= 59) {
            currentValue = 59;
        }
        else {
            currentValue++;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.minutes.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    increaseHours(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.hours.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.hours.value);
        }
        if (currentValue >= 23) {
            currentValue = 23;
        }
        else {
            currentValue++;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    decreaseHours(type) {
        let currentValue;
        if (type == 'start') {
            currentValue = Number(this.startDateHoursMinutes.controls.hours.value);
        }
        else {
            currentValue = Number(this.endDateHoursMinutes.controls.hours.value);
        }
        if (currentValue <= 0) {
            currentValue = 0;
        }
        else {
            currentValue--;
        }
        if (type == 'start') {
            this.startDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        else {
            this.endDateHoursMinutes.controls.hours.setValue(this.convertTwoDigitNumber(currentValue));
        }
        this.prepareHeaderDateObject();
    }
    convertTwoDigitNumber(currentValue) {
        let convertString = currentValue.toString();
        return convertString.padStart(2, '0');
    }
    // function to prepare the header object to send to the header component
    prepareHeaderDateObject() {
        let obj;
        if (this.properties.range) {
            let endHours, endMins, startHours, startMins;
            obj = Object.assign({}, this.multiDateSelection);
            endHours = this.endDateHoursMinutes.controls.hours.value;
            endMins = this.endDateHoursMinutes.controls.minutes.value;
            startHours = this.startDateHoursMinutes.controls.hours.value;
            startMins = this.startDateHoursMinutes.controls.minutes.value;
            obj.startDate = this.selectedDateRange?.start ? this.selectedDateRange.start : null;
            obj.endDate = this.selectedDateRange?.end ? this.selectedDateRange.end : null;
            obj.endDateTime = endHours + ' hr:' + endMins + ' min';
            obj.startDateTime = startHours + ' hr:' + startMins + ' min';
            obj.range = this.properties.range;
        }
        else {
            let startHours, startMins;
            startHours = this.startDateHoursMinutes.controls.hours.value;
            startMins = this.startDateHoursMinutes.controls.minutes.value;
            obj = Object.assign({}, this.singleDateSelection);
            obj.startDate = this.selectedDateRange ? this.selectedDateRange : null;
            obj.startDateTime = startHours + ' hr:' + startMins + ' min';
            // range should be false
            obj.range = false;
        }
        obj.showTime = this.properties.showTime;
        this.previousShowTime = this.properties.showTime;
        obj.showOnlyMonthYear = this.properties.showOnlyMonthYear ? this.properties.showOnlyMonthYear : false;
        this.sendChangesToHeader(obj);
    }
    // this function gets triggered when the user clicks on the apply button
    apply() {
        let selectedDate, value;
        let format = this.properties.showTime ? this.displayFormatWithTime : this.displayFormatWithoutTime;
        format = (this.properties.format && this.properties.format != '') ? this.properties.format : format;
        if (this.properties.range) {
            let startTimeHours, startTimeMinutes, endTimeHours, endTimeMinutes;
            startTimeHours = Number(this.startDateHoursMinutes.controls['hours'].value);
            startTimeMinutes = Number(this.startDateHoursMinutes.controls['minutes'].value);
            endTimeHours = Number(this.endDateHoursMinutes.controls['hours'].value);
            endTimeMinutes = Number(this.endDateHoursMinutes.controls['minutes'].value);
            selectedDate = new DateRange(this.getSelectedDateAndTime(this.selectedDateRange.start, startTimeHours, startTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0), this.getSelectedDateAndTime(this.selectedDateRange.end, endTimeHours, endTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0));
            const startDate = this.datePipe.transform(selectedDate.start, format);
            const endDate = this.datePipe.transform(selectedDate?.end, format);
            value = startDate + ' - ' + endDate;
        }
        else {
            let startTimeHours, startTimeMinutes;
            startTimeHours = isNaN(Number(this.startDateHoursMinutes.controls['hours'].value)) ? 0 : Number(this.startDateHoursMinutes.controls['hours'].value);
            startTimeMinutes = isNaN(Number(this.startDateHoursMinutes.controls['minutes'].value)) ? 0 : Number(this.startDateHoursMinutes.controls['minutes'].value);
            if (this.properties.showOnlyMonthYear) {
                selectedDate = this.selectedDate;
            }
            else {
                selectedDate = new Date(this.getSelectedDateAndTime(this.selectedDate, startTimeHours, startTimeMinutes) ?? this.getSelectedDateAndTime(new Date(), 0, 0));
            }
            const startDate = this.datePipe.transform(selectedDate, format);
            value = startDate;
        }
        this.writeValue(value);
        this.onChange(this._value);
        this.showCalendar = false;
        if (this.properties.onValueChange !== undefined) {
            this.properties.onValueChange(value);
        }
    }
    getSelectedDateAndTime(date, hours, minutes) {
        const month = date.getMonth(); //months from 1-12
        const day = date.getDate();
        const year = date.getFullYear();
        return new Date(year, month, day, hours, minutes);
    }
    // this function is triggered on the click of the cancel button
    cancel() {
        this.showCalendar = false;
        let value = this.ngControl.value;
        if (value != undefined && value != '') {
            this.setValuesFromFormGroup(value);
            this.setValues();
        }
    }
    // function to send the changes to the date picker header component
    sendChangesToHeader(obj) {
        this.datepickerService.dataSubject.next(obj);
    }
    // this function is triggered when there is any change in the startTime hours Input
    startTimeHoursInputValueChanges(event) {
        const currentHoursValue = Number(event.target.value);
        if (currentHoursValue >= 23) {
            this.startDateHoursMinutes.controls['hours'].setValue('23');
        }
        else if (currentHoursValue <= 0) {
            this.startDateHoursMinutes.controls['hours'].setValue('');
        }
        else {
            this.startDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? currentHoursValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of startTime hours Input
    startTimeHoursInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.startDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the startTime minutes Input
    startTimeMinutesInputValueChanges(event) {
        const currentMinutesValue = Number(event.target.value);
        if (currentMinutesValue <= 0) {
            this.startDateHoursMinutes.controls['minutes'].setValue('');
        }
        else if (currentMinutesValue >= 59) {
            this.startDateHoursMinutes.controls['minutes'].setValue('59');
        }
        else {
            this.startDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentMinutesValue) ? currentMinutesValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of startTime mins Input
    startTimeMinutesInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.startDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the endTime hours Input
    endTimeHoursInputValueChanges(event) {
        const currentHoursValue = Number(event.target.value);
        if (currentHoursValue >= 23) {
            this.endDateHoursMinutes.controls['hours'].setValue('23');
        }
        else if (currentHoursValue <= 0) {
            this.endDateHoursMinutes.controls['hours'].setValue('');
        }
        else {
            this.endDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? currentHoursValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of endTime Hours Input
    endTimeHoursInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.endDateHoursMinutes.controls['hours'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    // this function is triggered when there is any change in the endTime mins Input
    endTimeMinutesInputValueChanges(event) {
        const currentMinutesValue = Number(event.target.value);
        if (currentMinutesValue <= 0) {
            this.endDateHoursMinutes.controls['minutes'].setValue('');
        }
        else if (currentMinutesValue >= 59) {
            this.endDateHoursMinutes.controls['minutes'].setValue('59');
        }
        else {
            this.endDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentMinutesValue) ? currentMinutesValue.toString() : '');
        }
        this.prepareHeaderDateObject();
    }
    // this function is triggered on blur of endTime mins Input
    endTimeMinutesInputOnBlur(event) {
        const currentHoursValue = Number(event.target.value);
        this.endDateHoursMinutes.controls['minutes'].setValue(!Number.isNaN(currentHoursValue) ? this.convertTwoDigitNumber(currentHoursValue) : '');
        this.prepareHeaderDateObject();
    }
    getErrorMessage() {
        if (this.properties.optional) {
            return null;
        }
    }
    monthSelected(ev, matCalendar) {
        let year = ev.getFullYear();
        let month = ev.getMonth();
        let value = new Date();
        value.setFullYear(year);
        value.setMonth(month);
        this.selectedDate = value;
        matCalendar.selected = value;
        // this.applyButtonProperties.disabled = false;
        this.applyButtonDisable.set(false);
        this.cdr.detach();
    }
    viewChangedHandler(ev, matCalendar) {
        if (ev == 'month') {
            matCalendar.currentView = 'year';
        }
        this.cdr.reattach();
    }
    get showInfoMsg() {
        if (this.properties.showInfoMsg != undefined) {
            if (typeof this.properties.showInfoMsg == 'boolean') {
                return this.properties.showInfoMsg;
            }
            return this.properties.showInfoMsg();
        }
        return false;
    }
    clearSelection() {
        this.writeValue('');
        this.onChange('');
        this.showCalendar = false;
        this.startDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(0));
        this.startDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(0));
        this.endDateHoursMinutes.controls['hours'].setValue(this.convertTwoDigitNumber(23));
        this.endDateHoursMinutes.controls['minutes'].setValue(this.convertTwoDigitNumber(59));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDatepickerComponent, deps: [{ token: i1.NgControl, optional: true, self: true }, { token: i2.DatePipe }, { token: i0.ChangeDetectorRef }, { token: i3.DatePickerService }, { token: i4.Overlay }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClDatepickerComponent, isStandalone: true, selector: "cl-datepicker", inputs: { properties: "properties" }, providers: [DatePipe,
            { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
        ], viewQueries: [{ propertyName: "matFormField", first: true, predicate: MatFormField, descendants: true }, { propertyName: "matIcons", predicate: ["mat-icon"], descendants: true }], usesInheritance: true, ngImport: i0, template: "<div [id]=\"properties.id\">\n  <mat-form-field [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"{{ properties.style?.cssClasses }}\" subscriptSizing=\"dynamic\" cdkOverlayOrigin\n    #customDatePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\" [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\">\n\n    @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"cursor-pointer\" [svgIcon]=\"properties.prefixIcon\">\n    </mat-icon>\n    }\n\n    @if (properties.optional && value != '') {\n      <mat-icon class=\"cl-datepicker-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n    }\n\n    <mat-icon matSuffix (click)=\"openCalendar()\" class=\"cursor-pointer\"\n      [svgIcon]=\"properties.suffixIcon ?? 'heroicons_outline:calendar'\">\n    </mat-icon>\n  </mat-form-field>\n\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"customDatePicker\"\n  [cdkConnectedOverlayOpen]=\"showCalendar\"\n  [cdkConnectedOverlayPositions]=\"positions\"\n  [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n  (backdropClick)=\"closeCalendar()\"\n  [cdkConnectedOverlayHasBackdrop]=\"true\">\n\n  <mat-card class=\"overlay-content\">\n    <mat-calendar #matCalendar [headerComponent]=\"customHeader\" [startAt]=\"selectedDate\" [minDate]=\"minDate || null\"\n      [maxDate]=\"maxDate || null\" (selectedChange)=\"dateChange($event)\"\n      [startView]=\"properties.startView ? properties.startView : 'month'\"\n      [selected]=\"properties.range ? selectedDateRange: selectedDate\" [dateClass]=\"disableFromDate\"\n      (monthSelected)=\"properties.showOnlyMonthYear ? monthSelected($event, matCalendar) : null\"\n      (viewChanged)=\"properties.showOnlyMonthYear ? viewChangedHandler($event, matCalendar) : null\">\n    </mat-calendar>\n\n    <div class=\"time-container px-4 pb-4 pt-3\">\n      @if (showStartTime && properties.showTime) {\n      <form [formGroup]=\"startDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input matInput class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"startTimeHoursInputValueChanges($event)\"\n              (blur)=\"startTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"startTimeMinutesInputValueChanges($event)\"\n              (blur)=\"startTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      @if (showEndTime && properties.showTime) {\n      <form [formGroup]=\"endDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"endTimeHoursInputValueChanges($event)\"\n              (blur)=\"endTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"endTimeMinutesInputValueChanges($event)\"\n              (blur)=\"endTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      <div class=\"flex justify-between datepicker-buttonsdiv pt-3 border-neutral-200\">\n        <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button>\n      </div>\n\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-date-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-date-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.mat-calendar{width:300px}.mat-calendar-content{padding:8px 16px!important}.hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-cell-content{font-size:.875rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-in-range:before{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-100-rgb),var(--tw-bg-opacity))!important}.datepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity))}.mat-calendar-period-button{font-size:1.125rem;font-weight:600;--tw-text-opacity: 1;color:rgb(0 0 0 / var(--tw-text-opacity))}.hoursInput{width:40px!important}.mat-calendar-body-selected{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-400-rgb),var(--tw-bg-opacity))!important}.mat-datepicker-actions{display:block!important}.matdatepicker-cancel{--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.disabled-date{pointer-events:none;opacity:.5}.cl-datepicker-clear-icon{position:absolute;right:3rem;cursor:pointer;width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.cl-datepicker-clear-icon svg{width:1.25rem;height:1.25rem}\n", ":host{display:flex!important;flex-direction:column!important}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.PatternValidator, selector: "[pattern][formControlName],[pattern][formControl],[pattern][ngModel]", inputs: ["pattern"] }, { kind: "ngmodule", type: MatCardModule }, { kind: "component", type: i5.MatCard, selector: "mat-card", inputs: ["appearance"], exportAs: ["matCard"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i6.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i7.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly"], exportAs: ["matInput"] }, { kind: "component", type: i8.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i8.MatLabel, selector: "mat-label" }, { kind: "directive", type: i8.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i8.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i8.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i8.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i9.MatCalendar, selector: "mat-calendar", inputs: ["headerComponent", "startAt", "startView", "selected", "minDate", "maxDate", "dateFilter", "dateClass", "comparisonStart", "comparisonEnd", "startDateAccessibleName", "endDateAccessibleName"], outputs: ["selectedChange", "yearSelected", "monthSelected", "viewChanged", "_userSelection", "_userDragDrop"], exportAs: ["matCalendar"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i1.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i1.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatNativeDateModule }, { kind: "component", type: ClButtonComponent, selector: "cl-button", inputs: ["disabled", "showFailed", "showSuccess", "showLoading", "properties"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "directive", type: i4.CdkConnectedOverlay, selector: "[cdk-connected-overlay], [connected-overlay], [cdkConnectedOverlay]", inputs: ["cdkConnectedOverlayOrigin", "cdkConnectedOverlayPositions", "cdkConnectedOverlayPositionStrategy", "cdkConnectedOverlayOffsetX", "cdkConnectedOverlayOffsetY", "cdkConnectedOverlayWidth", "cdkConnectedOverlayHeight", "cdkConnectedOverlayMinWidth", "cdkConnectedOverlayMinHeight", "cdkConnectedOverlayBackdropClass", "cdkConnectedOverlayPanelClass", "cdkConnectedOverlayViewportMargin", "cdkConnectedOverlayScrollStrategy", "cdkConnectedOverlayOpen", "cdkConnectedOverlayDisableClose", "cdkConnectedOverlayTransformOriginOn", "cdkConnectedOverlayHasBackdrop", "cdkConnectedOverlayLockPosition", "cdkConnectedOverlayFlexibleDimensions", "cdkConnectedOverlayGrowAfterOpen", "cdkConnectedOverlayPush", "cdkConnectedOverlayDisposeOnNavigation"], outputs: ["backdropClick", "positionChange", "attach", "detach", "overlayKeydown", "overlayOutsideClick"], exportAs: ["cdkConnectedOverlay"] }, { kind: "directive", type: i4.CdkOverlayOrigin, selector: "[cdk-overlay-origin], [overlay-origin], [cdkOverlayOrigin]", exportAs: ["cdkOverlayOrigin"] }, { kind: "directive", type: ClTooltipDirective, selector: "[tooltip]", inputs: ["tooltip"], outputs: ["events"], exportAs: ["tooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClDatepickerComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, providers: [DatePipe,
                        { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
                    ], selector: 'cl-datepicker', encapsulation: ViewEncapsulation.None, imports: [
                        FormsModule,
                        MatCardModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        MatFormFieldModule,
                        MatDatepickerModule,
                        ReactiveFormsModule,
                        MatNativeDateModule,
                        ClButtonComponent,
                        OverlayModule,
                        ClTooltipDirective
                    ], template: "<div [id]=\"properties.id\">\n  <mat-form-field [appearance]=\"properties.appearance!\" [floatLabel]=\"properties.floatLabel!\"\n    class=\"{{ properties.style?.cssClasses }}\" subscriptSizing=\"dynamic\" cdkOverlayOrigin\n    #customDatePicker=\"cdkOverlayOrigin\">\n\n    @if (properties.label != null && properties.label != '' && properties.label != undefined) {\n    <mat-label class=\"flex items-center\">\n      <span>{{ properties.label }}</span>\n\n      @if (properties.optional) {\n      <span class=\"optional-text\">(Optional)</span>\n      }\n\n      @if (properties.infoMsg && showInfoMsg) {\n      <mat-icon [tooltip]=\"properties.infoMsg!\"\n        [svgIcon]=\"'heroicons_outline:information-circle'\" class=\"ml-1 icon-size-4 cursor-pointer text-neutral-600\">\n      </mat-icon>\n      }\n    </mat-label>\n    }\n\n    <input matInput [value]=\"value\" [placeholder]=\"properties.placeholder!\"\n      (input)=\"onChange($any($event.target).value)\" (blur)=\"onTouched($any($event.target).value)\"\n      (keyup)=\"writeValue($any($event.target).value)\" [readonly]=\"true\">\n\n    @if (properties.prefixIcon) {\n    <mat-icon matPrefix class=\"cursor-pointer\" [svgIcon]=\"properties.prefixIcon\">\n    </mat-icon>\n    }\n\n    @if (properties.optional && value != '') {\n      <mat-icon class=\"cl-datepicker-clear-icon\" (click)=\"clearSelection()\">close</mat-icon>\n    }\n\n    <mat-icon matSuffix (click)=\"openCalendar()\" class=\"cursor-pointer\"\n      [svgIcon]=\"properties.suffixIcon ?? 'heroicons_outline:calendar'\">\n    </mat-icon>\n  </mat-form-field>\n\n  @if (error) {\n  <mat-error class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ error }}\n  </mat-error>\n  }\n  @if (properties.hintText) {\n  <mat-hint class=\"{{ properties.subscriptSizing === 'fixed' ? 'h-5': '' }}\">\n    {{ properties.hintText }}\n  </mat-hint>\n  }\n</div>\n\n<ng-template cdkConnectedOverlay\n  [cdkConnectedOverlayOrigin]=\"customDatePicker\"\n  [cdkConnectedOverlayOpen]=\"showCalendar\"\n  [cdkConnectedOverlayPositions]=\"positions\"\n  [cdkConnectedOverlayScrollStrategy]=\"scrollStrategy\"\n  (backdropClick)=\"closeCalendar()\"\n  [cdkConnectedOverlayHasBackdrop]=\"true\">\n\n  <mat-card class=\"overlay-content\">\n    <mat-calendar #matCalendar [headerComponent]=\"customHeader\" [startAt]=\"selectedDate\" [minDate]=\"minDate || null\"\n      [maxDate]=\"maxDate || null\" (selectedChange)=\"dateChange($event)\"\n      [startView]=\"properties.startView ? properties.startView : 'month'\"\n      [selected]=\"properties.range ? selectedDateRange: selectedDate\" [dateClass]=\"disableFromDate\"\n      (monthSelected)=\"properties.showOnlyMonthYear ? monthSelected($event, matCalendar) : null\"\n      (viewChanged)=\"properties.showOnlyMonthYear ? viewChangedHandler($event, matCalendar) : null\">\n    </mat-calendar>\n\n    <div class=\"time-container px-4 pb-4 pt-3\">\n      @if (showStartTime && properties.showTime) {\n      <form [formGroup]=\"startDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input matInput class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"startTimeHoursInputValueChanges($event)\"\n              (blur)=\"startTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"startTimeMinutesInputValueChanges($event)\"\n              (blur)=\"startTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('start')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      @if (showEndTime && properties.showTime) {\n      <form [formGroup]=\"endDateHoursMinutes\">\n        <div class=\"flex justify-between bg-white pb-3\">\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Hours</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"hours\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"23\" placeholder=\"00\" (keyup)=\"endTimeHoursInputValueChanges($event)\"\n              (blur)=\"endTimeHoursInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseHours('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n\n          <div class=\"flex items-center hours-container justify-center bg-neutral-50\">\n\n            <mat-label class=\"text-md text-neutral-700\">Minutes</mat-label>\n\n            <input class=\"hoursInput pl-2.5\" formControlName=\"minutes\" type=\"text\" matInput maxlength=\"2\"\n              pattern=\"[0-9]{2}\" min=\"0\" max=\"59\" placeholder=\"00\" (keyup)=\"endTimeMinutesInputValueChanges($event)\"\n              (blur)=\"endTimeMinutesInputOnBlur($event)\">\n\n            <div class=\"flex flex-col\">\n              <mat-icon (click)=\"increaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-up'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n\n              <mat-icon (click)=\"decreaseMins('end')\" [svgIcon]=\"'heroicons_outline:chevron-down'\"\n                class=\"icon-size-4 cursor-pointer\">\n              </mat-icon>\n            </div>\n          </div>\n        </div>\n      </form>\n      }\n\n      <div class=\"flex justify-between datepicker-buttonsdiv pt-3 border-neutral-200\">\n        <cl-button [properties]=\"cancelButtonProperties\"></cl-button>\n        <cl-button [properties]=\"applyButtonProperties\"></cl-button>\n      </div>\n\n    </div>\n  </mat-card>\n</ng-template>\n", styles: [".custom-date-picker-overlay{inset:0;z-index:99;width:100%;height:100%;position:fixed;overflow-y:auto}.custom-date-picker-main-container{position:absolute!important;display:flex;flex-direction:column;z-index:100}.mat-calendar{width:300px}.mat-calendar-content{padding:8px 16px!important}.hours-container{height:46px;width:45%}.hoursInput{font-size:1.25rem;font-weight:700;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-cell-content{font-size:.875rem;--tw-text-opacity: 1;color:rgb(23 23 23 / var(--tw-text-opacity))}.mat-calendar-body-in-range:before{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-100-rgb),var(--tw-bg-opacity))!important}.datepicker-buttonsdiv{border-top:1px solid;--tw-border-opacity: 1;border-color:rgb(229 229 229 / var(--tw-border-opacity))}.mat-calendar-period-button{font-size:1.125rem;font-weight:600;--tw-text-opacity: 1;color:rgb(0 0 0 / var(--tw-text-opacity))}.hoursInput{width:40px!important}.mat-calendar-body-selected{--tw-bg-opacity: 1 !important;background-color:rgba(var(--cl-primary-400-rgb),var(--tw-bg-opacity))!important}.mat-datepicker-actions{display:block!important}.matdatepicker-cancel{--tw-text-opacity: 1;color:rgba(var(--cl-primary-600-rgb),var(--tw-text-opacity))}.disabled-date{pointer-events:none;opacity:.5}.cl-datepicker-clear-icon{position:absolute;right:3rem;cursor:pointer;width:1.25rem;height:1.25rem;min-width:1.25rem;min-height:1.25rem;font-size:1.25rem;line-height:1.25rem}.cl-datepicker-clear-icon svg{width:1.25rem;height:1.25rem}\n", ":host{display:flex!important;flex-direction:column!important}\n"] }]
        }], ctorParameters: () => [{ type: i1.NgControl, decorators: [{
                    type: Optional
                }, {
                    type: Self
                }] }, { type: i2.DatePipe }, { type: i0.ChangeDetectorRef }, { type: i3.DatePickerService }, { type: i4.Overlay }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }], matFormField: [{
                type: ViewChild,
                args: [MatFormField]
            }], matIcons: [{
                type: ViewChildren,
                args: ['mat-icon']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZS1waWNrZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvY2xheS91aS1jb21wb25lbnRzL2NvbXBsZXgvc3JjL2RhdGUtcGlja2VyL2RhdGUtcGlja2VyLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb21wbGV4L3NyYy9kYXRlLXBpY2tlci9kYXRlLXBpY2tlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQSxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDM0MsT0FBTyxFQUM2QixTQUFTLEVBQWMsS0FBSyxFQUFxQixRQUFRLEVBQzNGLElBQUksRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFDekQsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUF3QixXQUFXLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBYSxtQkFBbUIsRUFBb0IsTUFBTSxnQkFBZ0IsQ0FBQztBQUM3SSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDN0QsT0FBTyxFQUFFLFNBQVMsRUFBZSxtQkFBbUIsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzNGLE9BQU8sRUFBRSxZQUFZLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUNoRixPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDdkQsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHlCQUF5QixDQUFDO0FBQ3pELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzdELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxpQkFBaUIsRUFBc0IsYUFBYSxFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFFbkgsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sbURBQW1ELENBQUM7QUFDOUYsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sMEJBQTBCLENBQUM7QUFDbEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQy9FLE9BQU8sRUFBcUIsMEJBQTBCLEVBQVcsZ0JBQWdCLEVBQUUsYUFBYSxFQUFrQixNQUFNLHNCQUFzQixDQUFDO0FBQy9JLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7Ozs7Ozs7OztBQWdDaEUsTUFBTSxPQUFPLHFCQUFzQixTQUFRLGVBQWU7SUEwR3hELFlBQXdDLFNBQW9CLEVBQ3pDLFFBQWtCLEVBQ2xCLEdBQXNCLEVBQ3RCLGlCQUFvQyxFQUM3QyxPQUFnQjtRQUV4QixLQUFLLEVBQUUsQ0FBQztRQU44QixjQUFTLEdBQVQsU0FBUyxDQUFXO1FBQ3pDLGFBQVEsR0FBUixRQUFRLENBQVU7UUFDbEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsc0JBQWlCLEdBQWpCLGlCQUFpQixDQUFtQjtRQUM3QyxZQUFPLEdBQVAsT0FBTyxDQUFTO1FBeEduQixVQUFLLEdBQVksS0FBSyxDQUFDO1FBRXZCLGlCQUFZLEdBQVksS0FBSyxDQUFDO1FBQ3JDLGNBQVMsR0FBd0I7WUFDL0I7Z0JBQ0UsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixRQUFRLEVBQUUsT0FBTztnQkFDakIsUUFBUSxFQUFFLEtBQUs7YUFDaEI7WUFDRDtnQkFDRSxPQUFPLEVBQUUsT0FBTztnQkFDaEIsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsUUFBUSxFQUFFLE9BQU87Z0JBQ2pCLFFBQVEsRUFBRSxRQUFRO2FBQ25CO1lBQ0Q7Z0JBQ0UsT0FBTyxFQUFFLFFBQVE7Z0JBQ2pCLE9BQU8sRUFBRSxRQUFRO2dCQUNqQixRQUFRLEVBQUUsT0FBTztnQkFDakIsUUFBUSxFQUFFLFFBQVE7YUFDbkI7U0FDRixDQUFDO1FBRUYsbUJBQWMsR0FBbUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNyRSxZQUFPLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNyQixpQkFBWSxHQUFHLHlCQUF5QixDQUFDO1FBSS9CLHdCQUFtQixHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxFQUFFLEVBQUUsQ0FBQztRQUN6RSx1QkFBa0IsR0FBRyxFQUFFLE9BQU8sRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxFQUFFLFdBQVcsRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFFLEVBQUUsRUFBRSxDQUFDO1FBRXJHLHVCQUFrQixHQUFHLE1BQU0sQ0FBVSxJQUFJLENBQUMsQ0FBQztRQUVyRCwwQkFBcUIsR0FBdUI7WUFDakQsS0FBSyxFQUFFLE9BQU87WUFDZCxRQUFRLEVBQUUsSUFBSSxDQUFDLGtCQUFrQjtZQUNqQyxFQUFFLEVBQUUsb0JBQW9CO1lBQ3hCLFVBQVUsRUFBRSxhQUFhLENBQUMsTUFBTTtZQUNoQyxjQUFjLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUNyQyxJQUFJLEVBQUUsZ0JBQWdCLENBQUMsTUFBTTtZQUM3QixRQUFRLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1lBQy9CLEtBQUssRUFBRTtnQkFDTCxVQUFVLEVBQUUsc0JBQXNCO2dCQUNsQyxlQUFlLEVBQUUsc0JBQXNCO2FBQ3hDO1NBQ0YsQ0FBQztRQUVLLDJCQUFzQixHQUF1QjtZQUNsRCxLQUFLLEVBQUUsUUFBUTtZQUNmLEVBQUUsRUFBRSxxQkFBcUI7WUFDekIsVUFBVSxFQUFFLGFBQWEsQ0FBQyxNQUFNO1lBQ2hDLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQ3JDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxNQUFNO1lBQzdCLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDaEMsS0FBSyxFQUFFO2dCQUNMLFVBQVUsRUFBRSxhQUFhO2dCQUN6QixlQUFlLEVBQUUsV0FBVzthQUM3QjtTQUNGLENBQUM7UUFLSywwQkFBcUIsR0FBRyxJQUFJLFNBQVMsQ0FBQztZQUMzQyxLQUFLLEVBQUUsSUFBSSxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQzFCLE9BQU8sRUFBRSxJQUFJLFdBQVcsQ0FBQyxFQUFFLENBQUM7U0FDN0IsQ0FBQyxDQUFDO1FBRUksd0JBQW1CLEdBQUcsSUFBSSxTQUFTLENBQUM7WUFDekMsS0FBSyxFQUFFLElBQUksV0FBVyxDQUFDLEVBQUUsQ0FBQztZQUMxQixPQUFPLEVBQUUsSUFBSSxXQUFXLENBQUMsRUFBRSxDQUFDO1NBQzdCLENBQUMsQ0FBQztRQUVJLGdCQUFXLEdBQVksS0FBSyxDQUFDO1FBQzdCLGtCQUFhLEdBQVksSUFBSSxDQUFDO1FBRXBCLDZCQUF3QixHQUFXLFVBQVUsQ0FBQztRQUM5QywwQkFBcUIsR0FBVyxnQkFBZ0IsQ0FBQztRQUMzRCxpQkFBWSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7UUFDMUIsa0JBQWEsR0FBWSxLQUFLLENBQUM7UUFHdEMsYUFBUSxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDM0IsY0FBUyxHQUFHLENBQUMsQ0FBTSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFnT2xCLG9CQUFlLEdBQUcsQ0FBQyxDQUFPLEVBQVUsRUFBRTtZQUM5QyxNQUFNLElBQUksR0FBRyxDQUFDLElBQUksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUM3QixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRXRGLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDZCxPQUFPLEVBQUUsQ0FBQyxDQUFDLDZFQUE2RTtZQUMxRixDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUN4RyxDQUFDLENBQUE7UUFuTkMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFckMsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQzNCLHdEQUF3RDtZQUN4RCwwREFBMEQ7WUFDMUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQVU7UUFDbkIsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFDdEIsQ0FBQztJQUVELGdCQUFnQixDQUFDLEVBQWtCO1FBQ2pDLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxFQUFrQjtRQUNsQyxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQztJQUN0QixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3JCLENBQUM7SUFFUSxRQUFRO1FBQ2YsSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLHNCQUFzQixFQUFFLENBQUM7UUFFakQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25HLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3hHLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUM5RixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFbkcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7UUFDakcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztRQUN0RyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztRQUM3RixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztRQUVsRyxvREFBb0Q7UUFDcEQsa0RBQWtEO1FBRWxELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUVqQixJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUM7UUFFbEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLFdBQVcsQ0FBQyxDQUFDO2dCQUN4RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDbkQsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNwRSxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO1lBQy9DLENBQUM7WUFFRCxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbkIsQ0FBQztRQUVELElBQUksQ0FBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3JELElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUVuQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7UUFFSCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUdELFNBQVM7UUFDUCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsS0FBSyxLQUFLLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNsRCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsS0FBSyxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUN6QyxJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDO2dCQUM1QyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLEVBQUUsRUFBRSxDQUFDO29CQUMvRCxJQUFJLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQzFFLENBQUM7Z0JBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQztvQkFDM0QsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RSxDQUFDO2dCQUNELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixDQUFDO1FBQ0gsQ0FBQztRQUNELDREQUE0RDtRQUU1RCxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUUzQixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3RELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO1lBQy9CLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVMsQ0FBQztRQUNwRCxDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDcEQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUM7UUFDakQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3BELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRUQsZUFBZTtRQUNiLG9HQUFvRztRQUNwRyw0RUFBNEU7UUFDNUUseUlBQXlJO1FBRXpJLGlDQUFpQztRQUNqQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkIsaURBQWlEO1FBQ2pELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBZSxFQUFFLEVBQUU7WUFDdEUsSUFBSSxPQUFPLEtBQUssT0FBTyxFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO2dCQUVsQixpQ0FBaUM7Z0JBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsbUJBQW1CO1FBQ2pCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3BILElBQUksQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxXQUFXLENBQUMsQ0FBQztZQUN4RSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7WUFDakQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUMvRixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1FBQ25ELENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDNUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1lBQ3BFLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7WUFDN0MsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDekYsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDL0MsQ0FBQztJQUNILENBQUM7SUFFRCxxQkFBcUI7UUFDbkIsdUZBQXVGO1FBQ3ZGLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUVyQix3REFBd0Q7UUFDeEQsSUFBSSxJQUFJLENBQUMsU0FBUyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUN2RixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRTNFLGtDQUFrQztZQUNsQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNoQyxDQUFDO0lBQ0gsQ0FBQztJQUVPLFdBQVc7UUFDakIseUVBQXlFO1FBRXpFLHVFQUF1RTtRQUN2RSwyRUFBMkU7UUFFM0UsMkVBQTJFO1FBQzNFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLHdCQUF3QixDQUFDLENBQUM7SUFDekYsQ0FBQztJQUVNLFlBQVksQ0FBQyxLQUFVO1FBQzVCLGdEQUFnRDtRQUVoRCx3RUFBd0U7UUFDeEUsMEVBQTBFO1FBRTFFLElBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7UUFDcEYsd0VBQXdFO0lBQzFFLENBQUM7SUFFTyxhQUFhO1FBQ25CLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQTtRQUNsQixDQUFDO0lBQ0gsQ0FBQztJQUVRLFdBQVc7UUFDbEI7OztVQUdFO1FBRUYsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUN4QixLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDcEIsdUdBQXVHO0lBQ3pHLENBQUM7SUFFTSxzQkFBc0IsQ0FBQyxLQUFVO1FBQ3RDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMxQix5QkFBeUI7WUFDekIsSUFBSSxLQUFLLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ3ZCLElBQUksYUFBYSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3JDLE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUM3QyxNQUFNLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksU0FBUyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQztZQUM3RCxDQUFDO1FBQ0gsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLENBQUM7SUFDSCxDQUFDO0lBYU8sb0JBQW9CLENBQUMsSUFBVTtRQUNyQyxJQUFJLENBQUMsSUFBSTtZQUFFLE9BQU8sRUFBRSxDQUFDO1FBRXJCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNoQyxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQywwQkFBMEI7UUFDdEYsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFFcEQsT0FBTyxHQUFJLElBQUssSUFBSyxLQUFNLElBQUssR0FBSSxFQUFFLENBQUM7SUFDekMsQ0FBQztJQUVNLDJCQUEyQixDQUFDLEtBQVUsRUFBRSxPQUFlO1FBQzVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMxQix5QkFBeUI7WUFDekIsTUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFbEMsSUFBSSxPQUFPLElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQzNCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN2QixDQUFDO2lCQUFNLElBQUksT0FBTyxJQUFJLFNBQVMsRUFBRSxDQUFDO2dCQUNoQyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxTQUFTLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkIsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0QyxDQUFDO0lBQ0gsQ0FBQztJQUVELGFBQWE7UUFDWCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDNUIsTUFBTSxVQUFVLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVyRCxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDO1lBQzVCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtZQUNyQixDQUFDO1FBRUgsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLElBQUksRUFBRSxFQUFFLENBQUM7WUFDdEUsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3BELENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDdEIsQ0FBQztJQUNILENBQUM7SUFFRCxhQUFhO1FBQ1gsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzVCLE1BQU0sVUFBVSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQztZQUM1QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUE7WUFDckIsQ0FBQztRQUNILENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ2xFLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNsRCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLENBQUM7SUFDSCxDQUFDO0lBRU0sU0FBUztRQUNkLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMxQixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkcsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEcsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzlGLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztZQUVuRyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztZQUNqRyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO1lBQ3RHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBQzdGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO1FBQ3BHLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzNFLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRWhGLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO1lBQ2pHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7UUFDeEcsQ0FBQztRQUVELDZDQUE2QztRQUM3QyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztJQUNqQyxDQUFDO0lBRUQsK0RBQStEO0lBQ3hELFlBQVk7UUFDakIsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUUvRCxJQUFJLGFBQWEsRUFBRSxDQUFDO1lBQ2xCLGFBQWEsQ0FBQyxRQUFRLENBQUM7Z0JBQ3JCLElBQUksRUFBRSxDQUFDLEVBQUssMEJBQTBCO2dCQUN0QyxRQUFRLEVBQUUsUUFBUSxDQUFFLDZCQUE2QjthQUNsRCxDQUFDLENBQUM7WUFFSCxvRUFBb0U7WUFDcEUsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDZCxrQ0FBa0M7Z0JBQ2xDLElBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ3pDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFFLG1EQUFtRDtRQUMvRCxDQUFDO2FBQU0sQ0FBQztZQUNOLHdEQUF3RDtZQUN4RCxrQ0FBa0M7WUFDbEMsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDekMsQ0FBQztJQUNILENBQUM7SUFFTyx1QkFBdUI7UUFDN0IsK0JBQStCO1FBQy9CLGlHQUFpRztRQUVqRyxnQ0FBZ0M7UUFDaEMsc0NBQXNDO1FBQ3RDLFdBQVc7UUFDWCxpREFBaUQ7UUFDakQsc0RBQXNEO1FBQ3RELElBQUk7UUFFSixzQ0FBc0M7UUFDdEMsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7SUFDM0IsQ0FBQztJQUNTLGFBQWE7UUFDckIsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7SUFDNUIsQ0FBQztJQUVNLFVBQVUsQ0FBQyxJQUFTO1FBQ3pCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUUxQixJQUFJLElBQUksQ0FBQyxpQkFBaUIsSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNsSSwrQ0FBK0M7Z0JBQy9DLHNDQUFzQztnQkFDdEMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0JBQzNFLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDO2dCQUN4QixJQUFJLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztZQUM3QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sOENBQThDO2dCQUU5QyxxQ0FBcUM7Z0JBQ3JDLElBQUksQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO2dCQUN6QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztnQkFFMUIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO29CQUM3QixzQ0FBc0M7b0JBQ3RDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNqRixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztvQkFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7Z0JBQzdCLENBQUM7cUJBQU0sQ0FBQztvQkFDTixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUM7d0JBQzNCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNqRixDQUFDO3lCQUFNLENBQUM7d0JBQ04sSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksU0FBUyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztvQkFDckQsQ0FBQztvQkFDRCxzQ0FBc0M7Z0JBQ3hDLENBQUM7WUFDSCxDQUFDO1lBQ0QsSUFBRyxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ3hGLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDckMsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDcEMsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsK0NBQStDO1lBQy9DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDMUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7UUFDM0IsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxZQUFZLENBQUMsSUFBWTtRQUM5QixJQUFJLFlBQVksQ0FBQztRQUVqQixJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNFLENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6RSxDQUFDO1FBRUQsSUFBSSxZQUFZLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdEIsWUFBWSxHQUFHLENBQUMsQ0FBQztRQUNuQixDQUFDO2FBQU0sQ0FBQztZQUNOLFlBQVksRUFBRSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDakcsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDL0YsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxZQUFZLENBQUMsSUFBWTtRQUM5QixJQUFJLFlBQVksQ0FBQztRQUVqQixJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNFLENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6RSxDQUFDO1FBRUQsSUFBSSxZQUFZLElBQUksRUFBRSxFQUFFLENBQUM7WUFDdkIsWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUNwQixDQUFDO2FBQU0sQ0FBQztZQUNOLFlBQVksRUFBRSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDakcsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDL0YsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxhQUFhLENBQUMsSUFBWTtRQUMvQixJQUFJLFlBQVksQ0FBQztRQUVqQixJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pFLENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2RSxDQUFDO1FBRUQsSUFBSSxZQUFZLElBQUksRUFBRSxFQUFFLENBQUM7WUFDdkIsWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUNwQixDQUFDO2FBQU0sQ0FBQztZQUNOLFlBQVksRUFBRSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDL0YsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDN0YsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxhQUFhLENBQUMsSUFBWTtRQUMvQixJQUFJLFlBQVksQ0FBQztRQUVqQixJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixZQUFZLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3pFLENBQUM7YUFBTSxDQUFDO1lBQ04sWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2RSxDQUFDO1FBRUQsSUFBSSxZQUFZLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdEIsWUFBWSxHQUFHLENBQUMsQ0FBQztRQUNuQixDQUFDO2FBQU0sQ0FBQztZQUNOLFlBQVksRUFBRSxDQUFDO1FBQ2pCLENBQUM7UUFFRCxJQUFJLElBQUksSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDL0YsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDN0YsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxZQUE2QjtRQUN4RCxJQUFJLGFBQWEsR0FBRyxZQUFZLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDNUMsT0FBTyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUN4QyxDQUFDO0lBRUQsd0VBQXdFO0lBQ2pFLHVCQUF1QjtRQUM1QixJQUFJLEdBQVEsQ0FBQztRQUNiLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUMxQixJQUFJLFFBQVEsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLFNBQVMsQ0FBQztZQUM3QyxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFFakQsUUFBUSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztZQUN6RCxPQUFPLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1lBQzFELFVBQVUsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDN0QsU0FBUyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUU5RCxHQUFHLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUNwRixHQUFHLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztZQUM5RSxHQUFHLENBQUMsV0FBVyxHQUFHLFFBQVEsR0FBRyxNQUFNLEdBQUcsT0FBTyxHQUFHLE1BQU0sQ0FBQztZQUN2RCxHQUFHLENBQUMsYUFBYSxHQUFHLFVBQVUsR0FBRyxNQUFNLEdBQUcsU0FBUyxHQUFHLE1BQU0sQ0FBQztZQUM3RCxHQUFHLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO1FBQ3BDLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxVQUFVLEVBQUUsU0FBUyxDQUFDO1lBRTFCLFVBQVUsR0FBRyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDN0QsU0FBUyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUU5RCxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7WUFFbEQsR0FBRyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ3ZFLEdBQUcsQ0FBQyxhQUFhLEdBQUcsVUFBVSxHQUFHLE1BQU0sR0FBRyxTQUFTLEdBQUcsTUFBTSxDQUFDO1lBQzdELHdCQUF3QjtZQUN4QixHQUFHLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNwQixDQUFDO1FBQ0QsR0FBRyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztRQUN4QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7UUFDakQsR0FBRyxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUd0RyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDaEMsQ0FBQztJQUVELHdFQUF3RTtJQUNqRSxLQUFLO1FBQ1YsSUFBSSxZQUFZLEVBQUUsS0FBSyxDQUFDO1FBQ3hCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQztRQUNuRyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUVwRyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDMUIsSUFBSSxjQUFjLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLGNBQWMsQ0FBQztZQUVuRSxjQUFjLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDNUUsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDaEYsWUFBWSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3hFLGNBQWMsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUU1RSxZQUFZLEdBQUcsSUFBSSxTQUFTLENBQzFCLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsRUFDNUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsWUFBWSxFQUFFLGNBQWMsQ0FBQyxJQUFJLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLElBQUksRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FDdkksQ0FBQztZQUVGLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdEUsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVuRSxLQUFLLEdBQUcsU0FBUyxHQUFHLEtBQUssR0FBRyxPQUFPLENBQUM7UUFDdEMsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLGNBQWMsRUFBRSxnQkFBZ0IsQ0FBQztZQUVyQyxjQUFjLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEosZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7WUFFMUosSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Z0JBQ3RDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ25DLENBQUM7aUJBQU0sQ0FBQztnQkFDTixZQUFZLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsY0FBYyxFQUFFLGdCQUFnQixDQUFDLElBQUksSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksSUFBSSxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFFLENBQUM7WUFDOUosQ0FBQztZQUVELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVoRSxLQUFLLEdBQUcsU0FBUyxDQUFBO1FBQ25CLENBQUM7UUFFRCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNCLElBQUksQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO1FBRTFCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEtBQUssU0FBUyxFQUFFLENBQUM7WUFDaEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdkMsQ0FBQztJQUNILENBQUM7SUFFTSxzQkFBc0IsQ0FBQyxJQUFTLEVBQUUsS0FBYSxFQUFFLE9BQWU7UUFDckUsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsa0JBQWtCO1FBQ2pELE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUMzQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFaEMsT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVELCtEQUErRDtJQUN4RCxNQUFNO1FBQ1gsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDMUIsSUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7UUFFakMsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUN0QyxJQUFJLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbkMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDSCxDQUFDO0lBRUQsbUVBQW1FO0lBQzVELG1CQUFtQixDQUFDLEdBQVE7UUFDakMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELG1GQUFtRjtJQUM1RSwrQkFBK0IsQ0FBQyxLQUFVO1FBQy9DLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFckQsSUFBSSxpQkFBaUIsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5RCxDQUFDO2FBQU0sSUFBSSxpQkFBaUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM1RCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDOUgsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCw4REFBOEQ7SUFDdkQseUJBQXlCLENBQUMsS0FBVTtRQUN6QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDN0ksSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELHFGQUFxRjtJQUM5RSxpQ0FBaUMsQ0FBQyxLQUFVO1FBQ2pELE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdkQsSUFBSSxtQkFBbUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5RCxDQUFDO2FBQU0sSUFBSSxtQkFBbUIsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNyQyxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNoRSxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEksQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCw2REFBNkQ7SUFDdEQsMkJBQTJCLENBQUMsS0FBVTtRQUMzQyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJELElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDL0ksSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELGlGQUFpRjtJQUMxRSw2QkFBNkIsQ0FBQyxLQUFVO1FBQzdDLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFckQsSUFBSSxpQkFBaUIsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM1RCxDQUFDO2FBQU0sSUFBSSxpQkFBaUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUNsQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMxRCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDNUgsQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCw0REFBNEQ7SUFDckQsdUJBQXVCLENBQUMsS0FBVTtRQUN2QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDM0ksSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVELGdGQUFnRjtJQUN6RSwrQkFBK0IsQ0FBQyxLQUFVO1FBQy9DLE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFFdkQsSUFBSSxtQkFBbUIsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM1RCxDQUFDO2FBQU0sSUFBSSxtQkFBbUIsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNyQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5RCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEksQ0FBQztRQUVELElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCwyREFBMkQ7SUFDcEQseUJBQXlCLENBQUMsS0FBVTtRQUN6QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRXJELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDN0ksSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7SUFDakMsQ0FBQztJQUVNLGVBQWU7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQzdCLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFFTSxhQUFhLENBQUMsRUFBTyxFQUFFLFdBQTZCO1FBQ3pELElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUM1QixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDMUIsSUFBSSxLQUFLLEdBQVEsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUM1QixLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLFlBQVksR0FBRyxLQUFLLENBQUM7UUFDMUIsV0FBVyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDN0IsK0NBQStDO1FBQy9DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNwQixDQUFDO0lBRU0sa0JBQWtCLENBQUMsRUFBTyxFQUFFLFdBQTZCO1FBQzlELElBQUksRUFBRSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ2xCLFdBQVcsQ0FBQyxXQUFXLEdBQUcsTUFBTSxDQUFDO1FBQ25DLENBQUM7UUFFRCxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3RCLENBQUM7SUFDRCxJQUFXLFdBQVc7UUFDcEIsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUM3QyxJQUFJLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLElBQUksU0FBUyxFQUFFLENBQUM7Z0JBQ3BELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7WUFDckMsQ0FBQztZQUVELE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN2QyxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQsY0FBYztRQUNaLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsQixJQUFJLENBQUMsWUFBWSxHQUFHLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNyRixJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN2RixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNwRixJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN4RixDQUFDOzhHQTUwQlUscUJBQXFCO2tHQUFyQixxQkFBcUIsa0dBNUJyQixDQUFDLFFBQVE7WUFDbEIsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLDBCQUEwQixFQUFFO1NBQ3BFLHdFQThCVSxZQUFZLGlKQ3hEekIsMHNPQW9LQSw0b0REOUhJLFdBQVcsdTlCQUNYLGFBQWEsNElBQ2IsYUFBYSxtTEFDYixjQUFjLDZpQ0FDZCxnQkFBZ0IsOEJBQ2hCLGtCQUFrQiw4QkFDbEIsbUJBQW1CLDBiQUNuQixtQkFBbUIsK1VBQ25CLG1CQUFtQiwrQkFDbkIsaUJBQWlCLHFJQUNqQixhQUFhLDJyQ0FDYixrQkFBa0I7OzJGQUdULHFCQUFxQjtrQkE5QmpDLFNBQVM7aUNBQ0ksSUFBSSxhQUNMLENBQUMsUUFBUTt3QkFDbEIsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsUUFBUSxFQUFFLDBCQUEwQixFQUFFO3FCQUNwRSxZQUNTLGVBQWUsaUJBQ1YsaUJBQWlCLENBQUMsSUFBSSxXQVM1Qjt3QkFDUCxXQUFXO3dCQUNYLGFBQWE7d0JBQ2IsYUFBYTt3QkFDYixjQUFjO3dCQUNkLGdCQUFnQjt3QkFDaEIsa0JBQWtCO3dCQUNsQixtQkFBbUI7d0JBQ25CLG1CQUFtQjt3QkFDbkIsbUJBQW1CO3dCQUNuQixpQkFBaUI7d0JBQ2pCLGFBQWE7d0JBQ2Isa0JBQWtCO3FCQUNuQjs7MEJBNEdhLFFBQVE7OzBCQUFJLElBQUk7c0pBeEdkLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUlsQixZQUFZO3NCQURsQixTQUFTO3VCQUFDLFlBQVk7Z0JBaUVHLFFBQVE7c0JBQWpDLFlBQVk7dUJBQUMsVUFBVSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgRGF0ZVBpcGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCwgQ2hhbmdlRGV0ZWN0b3JSZWYsIENvbXBvbmVudCwgRWxlbWVudFJlZiwgSW5wdXQsIE9uRGVzdHJveSwgT25Jbml0LCBPcHRpb25hbCwgUXVlcnlMaXN0LFxuICBTZWxmLCBWaWV3Q2hpbGQsIFZpZXdDaGlsZHJlbiwgVmlld0VuY2Fwc3VsYXRpb24sIHNpZ25hbFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBGb3JtQ29udHJvbCwgRm9ybUdyb3VwLCBGb3Jtc01vZHVsZSwgTmdDb250cm9sLCBSZWFjdGl2ZUZvcm1zTW9kdWxlLCBWYWxpZGF0aW9uRXJyb3JzIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgTWF0Q2FyZE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NhcmQnO1xuaW1wb3J0IHsgTWF0TmF0aXZlRGF0ZU1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2NvcmUnO1xuaW1wb3J0IHsgRGF0ZVJhbmdlLCBNYXRDYWxlbmRhciwgTWF0RGF0ZXBpY2tlck1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL2RhdGVwaWNrZXInO1xuaW1wb3J0IHsgTWF0Rm9ybUZpZWxkLCBNYXRGb3JtRmllbGRNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9mb3JtLWZpZWxkJztcbmltcG9ydCB7IE1hdEljb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9tYXRlcmlhbC9pY29uJztcbmltcG9ydCB7IE1hdElucHV0TW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvbWF0ZXJpYWwvaW5wdXQnO1xuaW1wb3J0IHsgTWF0VG9vbHRpcE1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL21hdGVyaWFsL3Rvb2x0aXAnO1xuaW1wb3J0IHsgQ2xCdXR0b25CZWhhdmlvciwgQ2xCdXR0b25Db21wb25lbnQsIENsQnV0dG9uUHJvcGVydGllcywgSUNsQnV0dG9uVHlwZSB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvYmFzaWMnO1xuaW1wb3J0IHsgRGF0ZVBpY2tlclNlcnZpY2UgfSBmcm9tICcuL2RhdGVwaWNrZXIuc2VydmljZSc7XG5pbXBvcnQgeyBEYXRlUGlja2VySGVhZGVyQ29tcG9uZW50IH0gZnJvbSAnLi9kYXRlLXBpY2tlci1oZWFkZXIvZGF0ZS1waWNrZXItaGVhZGVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDbERhdGVQaWNrZXJQcm9wZXJ0aWVzIH0gZnJvbSAnLi9kYXRlLXBpY2tlci5wcm9wZXJ0aWVzJztcbmltcG9ydCB7IENsQmFzZUNvbXBvbmVudCwgQ2xDb21wb25lbnRUeXBlcyB9IGZyb20gJ0BjbGF5L3VpLWNvbXBvbmVudHMvc2hhcmVkJztcbmltcG9ydCB7IENvbm5lY3RlZFBvc2l0aW9uLCBGdWxsc2NyZWVuT3ZlcmxheUNvbnRhaW5lciwgT3ZlcmxheSwgT3ZlcmxheUNvbnRhaW5lciwgT3ZlcmxheU1vZHVsZSwgU2Nyb2xsU3RyYXRlZ3kgfSBmcm9tICdAYW5ndWxhci9jZGsvb3ZlcmxheSc7XG5pbXBvcnQgeyBDbFRvb2x0aXBEaXJlY3RpdmUgfSBmcm9tICdAY2xheS9hcHAtc2hlbGwvc3RydWN0dXJhbCc7XG5cbkBDb21wb25lbnQoe1xuICBzdGFuZGFsb25lOiB0cnVlLFxuICBwcm92aWRlcnM6IFtEYXRlUGlwZSxcbiAgICB7IHByb3ZpZGU6IE92ZXJsYXlDb250YWluZXIsIHVzZUNsYXNzOiBGdWxsc2NyZWVuT3ZlcmxheUNvbnRhaW5lciB9XG4gIF0sXG4gIHNlbGVjdG9yOiAnY2wtZGF0ZXBpY2tlcicsXG4gIGVuY2Fwc3VsYXRpb246IFZpZXdFbmNhcHN1bGF0aW9uLk5vbmUsXG4gIHN0eWxlVXJsOiAnLi9kYXRlLXBpY2tlci5jb21wb25lbnQuc2NzcycsXG4gIHRlbXBsYXRlVXJsOiAnLi9kYXRlLXBpY2tlci5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlczogW2BcbiAgICA6aG9zdCB7XG4gICAgICBkaXNwbGF5OiBmbGV4ICFpbXBvcnRhbnQ7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uICFpbXBvcnRhbnQ7XG4gICAgfVxuICBgXSxcbiAgaW1wb3J0czogW1xuICAgIEZvcm1zTW9kdWxlLFxuICAgIE1hdENhcmRNb2R1bGUsXG4gICAgTWF0SWNvbk1vZHVsZSxcbiAgICBNYXRJbnB1dE1vZHVsZSxcbiAgICBNYXRUb29sdGlwTW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcbiAgICBNYXREYXRlcGlja2VyTW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgTWF0TmF0aXZlRGF0ZU1vZHVsZSxcbiAgICBDbEJ1dHRvbkNvbXBvbmVudCxcbiAgICBPdmVybGF5TW9kdWxlLFxuICAgIENsVG9vbHRpcERpcmVjdGl2ZVxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBDbERhdGVwaWNrZXJDb21wb25lbnQgZXh0ZW5kcyBDbEJhc2VDb21wb25lbnQgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciwgT25Jbml0LCBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KVxuICBwdWJsaWMgb3ZlcnJpZGUgcHJvcGVydGllcyE6IENsRGF0ZVBpY2tlclByb3BlcnRpZXM7XG5cbiAgQFZpZXdDaGlsZChNYXRGb3JtRmllbGQpXG4gIHB1YmxpYyBtYXRGb3JtRmllbGQhOiBNYXRGb3JtRmllbGQ7XG4gIHB1YmxpYyByYW5nZTogYm9vbGVhbiA9IGZhbHNlO1xuXG4gIHB1YmxpYyBzaG93Q2FsZW5kYXI6IGJvb2xlYW4gPSBmYWxzZTtcbiAgcG9zaXRpb25zOiBDb25uZWN0ZWRQb3NpdGlvbltdID0gW1xuICAgIHtcbiAgICAgIG9yaWdpblg6ICdzdGFydCcsXG4gICAgICBvcmlnaW5ZOiAnYm90dG9tJyxcbiAgICAgIG92ZXJsYXlYOiAnc3RhcnQnLFxuICAgICAgb3ZlcmxheVk6ICd0b3AnLFxuICAgIH0sXG4gICAge1xuICAgICAgb3JpZ2luWDogJ3N0YXJ0JyxcbiAgICAgIG9yaWdpblk6ICd0b3AnLFxuICAgICAgb3ZlcmxheVg6ICdzdGFydCcsXG4gICAgICBvdmVybGF5WTogJ2JvdHRvbScsXG4gICAgfSxcbiAgICB7XG4gICAgICBvcmlnaW5YOiAnY2VudGVyJyxcbiAgICAgIG9yaWdpblk6ICdjZW50ZXInLFxuICAgICAgb3ZlcmxheVg6ICdzdGFydCcsXG4gICAgICBvdmVybGF5WTogJ2NlbnRlcicsXG4gICAgfVxuICBdO1xuXG4gIHNjcm9sbFN0cmF0ZWd5OiBTY3JvbGxTdHJhdGVneSA9IHRoaXMub3ZlcmxheS5zY3JvbGxTdHJhdGVnaWVzLnJlcG9zaXRpb24oKTtcbiAgcHVibGljIHN0YXJ0QXQgPSBuZXcgRGF0ZSgpO1xuICBwdWJsaWMgY3VzdG9tSGVhZGVyID0gRGF0ZVBpY2tlckhlYWRlckNvbXBvbmVudDtcblxuICBwdWJsaWMgc2VsZWN0ZWREYXRlUmFuZ2UhOiBEYXRlUmFuZ2U8RGF0ZT47XG5cbiAgcHJpdmF0ZSByZWFkb25seSBzaW5nbGVEYXRlU2VsZWN0aW9uID0geyByYW5nZTogZmFsc2UsIHN0YXJ0RGF0ZTogJycsIHN0YXJ0RGF0ZVRpbWU6ICcnIH07XG4gIHByaXZhdGUgcmVhZG9ubHkgbXVsdGlEYXRlU2VsZWN0aW9uID0geyBlbmREYXRlOiAnJywgcmFuZ2U6IHRydWUsIHN0YXJ0RGF0ZTogJycsIGVuZERhdGVUaW1lOiAnJywgc3RhcnREYXRlVGltZTogJycgfTtcblxuICBwcml2YXRlIHJlYWRvbmx5IGFwcGx5QnV0dG9uRGlzYWJsZSA9IHNpZ25hbDxib29sZWFuPih0cnVlKTtcblxuICBwdWJsaWMgYXBwbHlCdXR0b25Qcm9wZXJ0aWVzOiBDbEJ1dHRvblByb3BlcnRpZXMgPSB7XG4gICAgbGFiZWw6ICdBcHBseScsXG4gICAgZGlzYWJsZWQ6IHRoaXMuYXBwbHlCdXR0b25EaXNhYmxlLFxuICAgIGlkOiAnYnRuRGF0ZVBpY2tlckFwcGx5JyxcbiAgICBidXR0b25UeXBlOiBJQ2xCdXR0b25UeXBlLmJ1dHRvbixcbiAgICBidXR0b25CZWhhdmlvcjogQ2xCdXR0b25CZWhhdmlvci5mbGF0LFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuYnV0dG9uLFxuICAgIG9uU3VibWl0OiB0aGlzLmFwcGx5LmJpbmQodGhpcyksXG4gICAgc3R5bGU6IHtcbiAgICAgIGNzc0NsYXNzZXM6ICdhcHBseS1idG4gYmctcHJpbWFyeScsXG4gICAgICBsYWJlbENzc0NsYXNzZXM6ICd0ZXh0LXdoaXRlIHRleHQtYmFzZSdcbiAgICB9LFxuICB9O1xuXG4gIHB1YmxpYyBjYW5jZWxCdXR0b25Qcm9wZXJ0aWVzOiBDbEJ1dHRvblByb3BlcnRpZXMgPSB7XG4gICAgbGFiZWw6ICdDYW5jZWwnLFxuICAgIGlkOiAnYnRuRGF0ZVBpY2tlckNhbmNlbCcsXG4gICAgYnV0dG9uVHlwZTogSUNsQnV0dG9uVHlwZS5idXR0b24sXG4gICAgYnV0dG9uQmVoYXZpb3I6IENsQnV0dG9uQmVoYXZpb3IuZmxhdCxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmJ1dHRvbixcbiAgICBvblN1Ym1pdDogdGhpcy5jYW5jZWwuYmluZCh0aGlzKSxcbiAgICBzdHlsZToge1xuICAgICAgY3NzQ2xhc3NlczogJ2JnLXRlcnRpYXJ5JyxcbiAgICAgIGxhYmVsQ3NzQ2xhc3NlczogJ3RleHQtYmFzZScsXG4gICAgfSxcbiAgfTtcblxuICAvLyBAVmlld0NoaWxkKCdjdXN0b21EYXRlUGlja2VyJykgY3VzdG9tRGF0ZVBpY2tlciE6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGRyZW4oJ21hdC1pY29uJykgbWF0SWNvbnMhOiBRdWVyeUxpc3Q8RWxlbWVudFJlZj47XG5cbiAgcHVibGljIHN0YXJ0RGF0ZUhvdXJzTWludXRlcyA9IG5ldyBGb3JtR3JvdXAoe1xuICAgIGhvdXJzOiBuZXcgRm9ybUNvbnRyb2woJycpLFxuICAgIG1pbnV0ZXM6IG5ldyBGb3JtQ29udHJvbCgnJylcbiAgfSk7XG5cbiAgcHVibGljIGVuZERhdGVIb3Vyc01pbnV0ZXMgPSBuZXcgRm9ybUdyb3VwKHtcbiAgICBob3VyczogbmV3IEZvcm1Db250cm9sKCcnKSxcbiAgICBtaW51dGVzOiBuZXcgRm9ybUNvbnRyb2woJycpXG4gIH0pO1xuXG4gIHB1YmxpYyBzaG93RW5kVGltZTogYm9vbGVhbiA9IGZhbHNlO1xuICBwdWJsaWMgc2hvd1N0YXJ0VGltZTogYm9vbGVhbiA9IHRydWU7XG5cbiAgcHJpdmF0ZSByZWFkb25seSBkaXNwbGF5Rm9ybWF0V2l0aG91dFRpbWU6IHN0cmluZyA9ICdkIE1NTSwgeSc7XG4gIHByaXZhdGUgcmVhZG9ubHkgZGlzcGxheUZvcm1hdFdpdGhUaW1lOiBzdHJpbmcgPSAnZCBNTU0sIHkgSEg6bW0nO1xuICBwdWJsaWMgc2VsZWN0ZWREYXRlID0gbmV3IERhdGUoKTtcbiAgcHVibGljIHByZXZpb3VzUmFuZ2U6IGJvb2xlYW4gPSBmYWxzZTtcblxuICBwcm90ZWN0ZWQgX3ZhbHVlOiBhbnk7XG4gIG9uQ2hhbmdlID0gKF86IGFueSkgPT4geyB9O1xuICBvblRvdWNoZWQgPSAoXzogYW55KSA9PiB7IH07XG5cbiAgcHJpdmF0ZSBzdWI/OiBTdWJzY3JpcHRpb247XG4gIHByb3RlY3RlZCBlcnJvcj86IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsO1xuXG4gIHByaXZhdGUgcHJldmlvdXNGcm9tRGF0ZTogYW55O1xuICBwcml2YXRlIHByZXZpb3VzVG9EYXRlOiBhbnk7XG5cbiAgcHVibGljIG1pbkRhdGU6IGFueTtcbiAgcHVibGljIG1heERhdGU6IGFueTtcblxuICBwcml2YXRlIHByZXZpb3VzTWluRGF0ZTogYW55O1xuICBwcml2YXRlIHByZXZpb3VzTWF4RGF0ZTogYW55O1xuXG4gIHByaXZhdGUgcHJldmlvdXNTaG93VGltZTogYW55O1xuICBjb25zdHJ1Y3RvciAoQE9wdGlvbmFsKCkgQFNlbGYoKSBwdWJsaWMgbmdDb250cm9sOiBOZ0NvbnRyb2wsXG4gICAgcHJpdmF0ZSByZWFkb25seSBkYXRlUGlwZTogRGF0ZVBpcGUsXG4gICAgcHJpdmF0ZSByZWFkb25seSBjZHI6IENoYW5nZURldGVjdG9yUmVmLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgZGF0ZXBpY2tlclNlcnZpY2U6IERhdGVQaWNrZXJTZXJ2aWNlLFxuICAgIHByaXZhdGUgb3ZlcmxheTogT3ZlcmxheVxuICApIHtcbiAgICBzdXBlcigpO1xuICAgIHN1cGVyLnNldFByb3BlcnRpZXModGhpcy5wcm9wZXJ0aWVzKTtcblxuICAgIGlmICh0aGlzLm5nQ29udHJvbCAhPSBudWxsKSB7XG4gICAgICAvLyBTZXR0aW5nIHRoZSB2YWx1ZSBhY2Nlc3NvciBkaXJlY3RseSAoaW5zdGVhZCBvZiB1c2luZ1xuICAgICAgLy8gdGhlIHByb3ZpZGVycykgdG8gYXZvaWQgcnVubmluZyBpbnRvIGEgY2lyY3VsYXIgaW1wb3J0LlxuICAgICAgdGhpcy5uZ0NvbnRyb2wudmFsdWVBY2Nlc3NvciA9IHRoaXM7XG4gICAgfVxuICB9XG5cbiAgd3JpdGVWYWx1ZSh2YWx1ZTogYW55KTogdm9pZCB7XG4gICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgfVxuXG4gIHJlZ2lzdGVyT25DaGFuZ2UoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcmVnaXN0ZXJPblRvdWNoZWQoZm46IChfOiBhbnkpID0+IHt9KTogdm9pZCB7XG4gICAgdGhpcy5vblRvdWNoZWQgPSBmbjtcbiAgfVxuXG4gIGdldCB2YWx1ZSgpOiBhbnkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgfVxuXG4gIG92ZXJyaWRlIG5nT25Jbml0KCkge1xuICAgIHRoaXMucHJvcGVydGllcyA/Pz0gbmV3IENsRGF0ZVBpY2tlclByb3BlcnRpZXMoKTtcblxuICAgIGNvbnN0IHN0YXJ0RGF0ZUhvdXIgPSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5zdGFydCA/IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2U/LnN0YXJ0LmdldEhvdXJzKCkgOiAwO1xuICAgIGNvbnN0IHN0YXJ0RGF0ZU1pbnV0ZXMgPSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5zdGFydCA/IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2U/LnN0YXJ0LmdldE1pbnV0ZXMoKSA6IDA7XG4gICAgY29uc3QgZW5kRGF0ZUhvdXIgPSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQgPyB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQuZ2V0SG91cnMoKSA6IDIzO1xuICAgIGNvbnN0IGVuZERhdGVNaW51dGVzID0gdGhpcy5zZWxlY3RlZERhdGVSYW5nZT8uZW5kID8gdGhpcy5zZWxlY3RlZERhdGVSYW5nZT8uZW5kLmdldE1pbnV0ZXMoKSA6IDU5O1xuXG4gICAgdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ2hvdXJzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoc3RhcnREYXRlSG91cikpO1xuICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoc3RhcnREYXRlTWludXRlcykpO1xuICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSh0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcihlbmREYXRlSG91cikpO1xuICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGVuZERhdGVNaW51dGVzKSk7XG5cbiAgICAvLyBhc3NpZ24gdGhlIHJhbmdlIHZhbHVlIGZyb20gdGhlIHByb3BlcnRpZXMgb2JqZWN0XG4gICAgLy8gdGhpcy5yYW5nZSA9IHRoaXMucHJvcGVydGllcz8ucmFuZ2UgPyAgOiBmYWxzZTtcblxuICAgIHRoaXMuc2V0VmFsdWVzKCk7XG5cbiAgICB0aGlzLnByb3BlcnRpZXMuc2hvd1RpbWUgPz89IHRydWU7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlIHx8IHRoaXMucHJvcGVydGllcy50b0RhdGUpIHtcbiAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUpIHtcbiAgICAgICAgdGhpcy5zZXRWYWx1ZXNGcm9tRm9ybUdyb3VwU3RhcnQodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlLCAnc3RhcnREYXRlJyk7XG4gICAgICAgIHRoaXMucHJldmlvdXNGcm9tRGF0ZSA9IHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMudG9EYXRlKSB7XG4gICAgICAgIHRoaXMuc2V0VmFsdWVzRnJvbUZvcm1Hcm91cFN0YXJ0KHRoaXMucHJvcGVydGllcy50b0RhdGUsICdlbmREYXRlJyk7XG4gICAgICAgIHRoaXMucHJldmlvdXNUb0RhdGUgPSB0aGlzLnByb3BlcnRpZXMudG9EYXRlO1xuICAgICAgfVxuXG4gICAgICB0aGlzLnNldFZhbHVlcygpO1xuICAgIH1cblxuICAgIHRoaXMubmdDb250cm9sPy52YWx1ZUNoYW5nZXM/LnN1YnNjcmliZSgodmFsdWU6IGFueSkgPT4ge1xuICAgICAgdGhpcy5zZXRWYWx1ZXNGcm9tRm9ybUdyb3VwKHZhbHVlKTtcblxuICAgICAgdGhpcy5zZXRWYWx1ZXMoKTtcbiAgICB9KTtcblxuICAgIHN1cGVyLm5nT25Jbml0KCk7XG4gIH1cblxuXG4gIG5nRG9DaGVjaygpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzPy5yYW5nZSAhPT0gdGhpcy5wcmV2aW91c1JhbmdlKSB7XG4gICAgICBpZiAodGhpcy5wcm9wZXJ0aWVzPy5yYW5nZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMucHJldmlvdXNSYW5nZSA9IHRoaXMucHJvcGVydGllcz8ucmFuZ2U7XG4gICAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUgJiYgdGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlICE9ICcnKSB7XG4gICAgICAgICAgdGhpcy5zZXRWYWx1ZXNGcm9tRm9ybUdyb3VwU3RhcnQodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlLCAnc3RhcnREYXRlJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMucHJvcGVydGllcy50b0RhdGUgJiYgdGhpcy5wcm9wZXJ0aWVzLnRvRGF0ZSAhPSAnJykge1xuICAgICAgICAgIHRoaXMuc2V0VmFsdWVzRnJvbUZvcm1Hcm91cFN0YXJ0KHRoaXMucHJvcGVydGllcy50b0RhdGUsICdlbmREYXRlJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zZXRWYWx1ZXMoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gaWYgKHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZSB8fCB0aGlzLnByb3BlcnRpZXMudG9EYXRlKSB7XG5cbiAgICB0aGlzLnVwZGF0ZUZyb21BbmRUb0RhdGUoKTtcblxuICAgIGlmICh0aGlzLnByZXZpb3VzU2hvd1RpbWUgIT0gdGhpcy5wcm9wZXJ0aWVzLnNob3dUaW1lKSB7XG4gICAgICB0aGlzLnByZXBhcmVIZWFkZXJEYXRlT2JqZWN0KCk7XG4gICAgICB0aGlzLnByZXZpb3VzU2hvd1RpbWUgPSB0aGlzLnByb3BlcnRpZXMuc2hvd1RpbWUhO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMubWluRGF0ZSAhPSB0aGlzLnByZXZpb3VzTWluRGF0ZSkge1xuICAgICAgdGhpcy51cGRhdGVNaW5EYXRlKCk7XG4gICAgICB0aGlzLnByZXZpb3VzTWluRGF0ZSA9IHRoaXMucHJvcGVydGllcy5taW5EYXRlO1xuICAgIH1cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm1heERhdGUgIT0gdGhpcy5wcmV2aW91c01heERhdGUpIHtcbiAgICAgIHRoaXMudXBkYXRlTWF4RGF0ZSgpO1xuICAgICAgdGhpcy5wcmV2aW91c01heERhdGUgPSB0aGlzLnByb3BlcnRpZXMubWF4RGF0ZTtcbiAgICB9XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgLy8gc2V0dGluZyB0aGUgcmVmZXJlbmNlcyBvZiBOYXRpdmUgRWxlbWVudHMsIHdoaWNoIHdpbGwgYmUgdXNlZCBpbiBzZXRFcnJvclRleHQoKSBhbmQgc2V0SGludFRleHQoKVxuICAgIC8vIHRoaXMuZXJyb3JPckhpbnREaXZFbGVtZW50ID0gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnRSZWYubmF0aXZlRWxlbWVudDtcbiAgICAvLyB0aGlzLm1hdFRleHRGaWVsZERpdkVsZW1lbnQgPSB0aGlzLm1hdEZvcm1GaWVsZC5fZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJy5tYXQtbWRjLXRleHQtZmllbGQtd3JhcHBlci5tZGMtdGV4dC1maWVsZCcpO1xuXG4gICAgLy8gY2FsbGluZyBzZXQgaGludCB0ZXh0IGZ1bmN0aW9uXG4gICAgdGhpcy5zZXRIaW50VGV4dCgpO1xuXG4gICAgLy8gcmVtb3ZlIGFsbCB0aGUgZXJyb3JzIHdoZW4gdGhlIHN0YXR1cyBpcyB2YWxpZFxuICAgIHRoaXMuc3ViID0gdGhpcy5uZ0NvbnRyb2w/LnN0YXR1c0NoYW5nZXMhLnN1YnNjcmliZSgoY2hhbmdlczogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAoY2hhbmdlcyA9PT0gJ1ZBTElEJykge1xuICAgICAgICB0aGlzLmVycm9yID0gbnVsbDtcblxuICAgICAgICAvLyBjYWxsaW5nIHNldCBoaW50IHRleHQgZnVuY3Rpb25cbiAgICAgICAgdGhpcy5zZXRIaW50VGV4dCgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgdXBkYXRlRnJvbUFuZFRvRGF0ZSgpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlICYmIHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZSAhPSAnJyAmJiB0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUgIT0gdGhpcy5wcmV2aW91c0Zyb21EYXRlKSB7XG4gICAgICB0aGlzLnNldFZhbHVlc0Zyb21Gb3JtR3JvdXBTdGFydCh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUsICdzdGFydERhdGUnKTtcbiAgICAgIHRoaXMucHJldmlvdXNGcm9tRGF0ZSA9IHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZTtcbiAgICAgIHRoaXMuc2V0VmFsdWVzKCk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUgPT0gJycgJiYgdGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlICE9IHRoaXMucHJldmlvdXNGcm9tRGF0ZSkge1xuICAgICAgdGhpcy51cGRhdGVNaW5EYXRlKCk7XG4gICAgICB0aGlzLnByZXZpb3VzRnJvbURhdGUgPSB0aGlzLnByb3BlcnRpZXMuZnJvbURhdGU7XG4gICAgfVxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMudG9EYXRlICYmIHRoaXMucHJvcGVydGllcy50b0RhdGUgIT0gJycgJiYgdGhpcy5wcm9wZXJ0aWVzLnRvRGF0ZSAhPSB0aGlzLnByZXZpb3VzVG9EYXRlKSB7XG4gICAgICB0aGlzLnNldFZhbHVlc0Zyb21Gb3JtR3JvdXBTdGFydCh0aGlzLnByb3BlcnRpZXMudG9EYXRlLCAnZW5kRGF0ZScpO1xuICAgICAgdGhpcy5wcmV2aW91c1RvRGF0ZSA9IHRoaXMucHJvcGVydGllcy50b0RhdGU7XG4gICAgICB0aGlzLnNldFZhbHVlcygpO1xuICAgIH0gZWxzZSBpZiAodGhpcy5wcm9wZXJ0aWVzLnRvRGF0ZSA9PSAnJyAmJiB0aGlzLnByb3BlcnRpZXMudG9EYXRlICE9IHRoaXMucHJldmlvdXNUb0RhdGUpIHtcbiAgICAgIHRoaXMudXBkYXRlTWF4RGF0ZSgpO1xuICAgICAgdGhpcy5wcmV2aW91c1RvRGF0ZSA9IHRoaXMucHJvcGVydGllcy50b0RhdGU7XG4gICAgfVxuICB9XG5cbiAgbmdBZnRlckNvbnRlbnRDaGVja2VkKCk6IHZvaWQge1xuICAgIC8vIGJlbG93IGlzIHRvIGF2b2lkIGRpc3BsYXlpbmcgJ3VuZGVmaW5lZCcgb24gc2NyZWVuIHdoZW4gbW9kZWwgaXMgbm90IGRlZmluZWQgLi4geWV0LlxuICAgIHRoaXMuc2V0RW1wdHlWYWx1ZSgpO1xuXG4gICAgLy8gdHJpZ2dlciB0aGUgZXJyb3IgcGF0dGVybiBvbmNlIHRoZSBjb250ZW50IGlzIGNoZWNrZWRcbiAgICBpZiAodGhpcy5uZ0NvbnRyb2wgIT0gbnVsbCAmJiB0aGlzLm5nQ29udHJvbC50b3VjaGVkID09PSB0cnVlICYmIHRoaXMubmdDb250cm9sLmVycm9ycykge1xuICAgICAgdGhpcy5lcnJvciA9IHRoaXMubmdDb250cm9sLmVycm9ycyA/IHRoaXMubmdDb250cm9sLmVycm9yc1snZXJyb3InXSA6IG51bGw7XG5cbiAgICAgIC8vIGNhbGxpbmcgc2V0IGVycm9yIHRleHQgZnVuY3Rpb25cbiAgICAgIHRoaXMuc2V0RXJyb3JUZXh0KHRoaXMuZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0SGludFRleHQoKSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gdGhpcy5wcm9wZXJ0aWVzLmhpbnRUZXh0ID8/ICcnO1xuXG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnbWF0LW1kYy1mb3JtLWZpZWxkLWhpbnQnKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcblxuICAgIC8vIHRoaXMubWF0VGV4dEZpZWxkRGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtZGMtdGV4dC1maWVsZC0taW52YWxpZCcpO1xuICAgIHRoaXMubWF0Rm9ybUZpZWxkLl9lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnbWF0LWZvcm0tZmllbGQtaW52YWxpZCcpO1xuICB9XG5cbiAgcHVibGljIHNldEVycm9yVGV4dChlcnJvcjogYW55KSB7XG4gICAgLy8gdGhpcy5lcnJvck9ySGludERpdkVsZW1lbnQuaW5uZXJUZXh0ID0gZXJyb3I7XG5cbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtbWRjLWZvcm0tZmllbGQtZXJyb3InKTtcbiAgICAvLyB0aGlzLmVycm9yT3JIaW50RGl2RWxlbWVudC5jbGFzc0xpc3QucmVtb3ZlKCdtYXQtbWRjLWZvcm0tZmllbGQtaGludCcpO1xuXG4gICAgdGhpcy5tYXRGb3JtRmllbGQuX2VsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdtYXQtZm9ybS1maWVsZC1pbnZhbGlkJyk7XG4gICAgLy8gdGhpcy5tYXRUZXh0RmllbGREaXZFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ21kYy10ZXh0LWZpZWxkLS1pbnZhbGlkJyk7XG4gIH1cblxuICBwcml2YXRlIHNldEVtcHR5VmFsdWUoKSB7XG4gICAgaWYgKHRoaXMuX3ZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMuX3ZhbHVlID0gJydcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICAvKipcbiAgICAqICEhIFdhcm5pbmcgISFcbiAgICAqIFRoZSBiZWxvdyBzdXBlciBjYWxscyBhcmUgYWx3YXlzIHRvIGJlIGltcGxlbWVudGVkIGZvciBhbnkgY29tcG9uZW50LiBPdGhlcndpc2Ugbm90aGluZyB3aWxsIHdvcmsuXG4gICAgKi9cblxuICAgIHRoaXMuc3ViPy51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICB9XG5cbiAgcHVibGljIHNldFZhbHVlc0Zyb21Gb3JtR3JvdXAodmFsdWU6IGFueSkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMucmFuZ2UpIHtcbiAgICAgIC8vc3BsaXQgdGhlIGRhdGUgd2l0aCAnLSdcbiAgICAgIGlmICh2YWx1ZSAhPSB1bmRlZmluZWQpIHtcbiAgICAgICAgbGV0IHNlbGVjdGVkRGF0ZXMgPSB2YWx1ZS5zcGxpdCgnLScpO1xuICAgICAgICBjb25zdCBzdGFydERhdGUgPSBuZXcgRGF0ZShzZWxlY3RlZERhdGVzWzBdKTtcbiAgICAgICAgY29uc3QgZW5kRGF0ZSA9IG5ldyBEYXRlKHNlbGVjdGVkRGF0ZXNbMV0pO1xuICAgICAgICB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlID0gbmV3IERhdGVSYW5nZShzdGFydERhdGUsIGVuZERhdGUpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNlbGVjdGVkRGF0ZSA9IG5ldyBEYXRlKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBwcm90ZWN0ZWQgZGlzYWJsZUZyb21EYXRlID0gKGQ6IERhdGUpOiBzdHJpbmcgPT4ge1xuICAgIGNvbnN0IGRhdGUgPSBkIHx8IG5ldyBEYXRlKCk7XG4gICAgY29uc3QgZnJvbURhdGUgPSB0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUgPyBuZXcgRGF0ZSh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUpIDogbnVsbDtcblxuICAgIGlmICghZnJvbURhdGUpIHtcbiAgICAgIHJldHVybiAnJzsgLy8gSWYgZnJvbURhdGUgaXMgdW5kZWZpbmVkLCByZXR1cm4gYW4gZW1wdHkgc3RyaW5nLCBubyBkYXRlIHdpbGwgYmUgZGlzYWJsZWRcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5mb3JtYXREYXRlVG9ZeXl5TW1EZChkYXRlKSA9PT0gdGhpcy5mb3JtYXREYXRlVG9ZeXl5TW1EZChmcm9tRGF0ZSkgPyAnZGlzYWJsZWQtZGF0ZScgOiAnJztcbiAgfVxuXG4gIHByaXZhdGUgZm9ybWF0RGF0ZVRvWXl5eU1tRGQoZGF0ZTogRGF0ZSk6IHN0cmluZyB7XG4gICAgaWYgKCFkYXRlKSByZXR1cm4gJyc7XG5cbiAgICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsICcwJyk7IC8vIE1vbnRocyBhcmUgemVyby1pbmRleGVkXG4gICAgY29uc3QgZGF5ID0gU3RyaW5nKGRhdGUuZ2V0RGF0ZSgpKS5wYWRTdGFydCgyLCAnMCcpO1xuXG4gICAgcmV0dXJuIGAkeyB5ZWFyIH0tJHsgbW9udGggfS0keyBkYXkgfWA7XG4gIH1cblxuICBwdWJsaWMgc2V0VmFsdWVzRnJvbUZvcm1Hcm91cFN0YXJ0KHZhbHVlOiBhbnksIGRhdGVLZXk6IHN0cmluZykge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMucmFuZ2UpIHtcbiAgICAgIC8vc3BsaXQgdGhlIGRhdGUgd2l0aCAnLSdcbiAgICAgIGNvbnN0IGRhdGVWYWx1ZSA9IG5ldyBEYXRlKHZhbHVlKTtcblxuICAgICAgaWYgKGRhdGVLZXkgPT0gJ3N0YXJ0RGF0ZScpIHtcbiAgICAgICAgdGhpcy5zZWxlY3RlZERhdGVSYW5nZSA9IG5ldyBEYXRlUmFuZ2UoZGF0ZVZhbHVlLCBudWxsKTtcbiAgICAgICAgdGhpcy51cGRhdGVNaW5EYXRlKCk7XG4gICAgICB9IGVsc2UgaWYgKGRhdGVLZXkgPT0gJ2VuZERhdGUnKSB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2UgPSBuZXcgRGF0ZVJhbmdlKG51bGwsIGRhdGVWYWx1ZSk7XG4gICAgICAgIHRoaXMudXBkYXRlTWF4RGF0ZSgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnNlbGVjdGVkRGF0ZSA9IG5ldyBEYXRlKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICB1cGRhdGVNaW5EYXRlKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMubWluRGF0ZSkge1xuICAgICAgY29uc3QgcGFyc2VkRGF0ZSA9IG5ldyBEYXRlKHRoaXMucHJvcGVydGllcy5taW5EYXRlKTtcblxuICAgICAgaWYgKCFpc05hTihwYXJzZWREYXRlLmdldFRpbWUoKSkpIHtcbiAgICAgICAgdGhpcy5taW5EYXRlID0gcGFyc2VkRGF0ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubWluRGF0ZSA9IG51bGxcbiAgICAgIH1cblxuICAgIH0gZWxzZSBpZiAodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlICYmIHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZSAhPSAnJykge1xuICAgICAgdGhpcy5taW5EYXRlID0gbmV3IERhdGUodGhpcy5wcm9wZXJ0aWVzLmZyb21EYXRlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5taW5EYXRlID0gbnVsbDtcbiAgICB9XG4gIH1cblxuICB1cGRhdGVNYXhEYXRlKCkge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMubWF4RGF0ZSkge1xuICAgICAgY29uc3QgcGFyc2VkRGF0ZSA9IG5ldyBEYXRlKHRoaXMucHJvcGVydGllcy5tYXhEYXRlKTtcbiAgICAgIGlmICghaXNOYU4ocGFyc2VkRGF0ZS5nZXRUaW1lKCkpKSB7XG4gICAgICAgIHRoaXMubWF4RGF0ZSA9IHBhcnNlZERhdGU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLm1heERhdGUgPSBudWxsXG4gICAgICB9XG4gICAgfSBlbHNlIGlmICh0aGlzLnByb3BlcnRpZXMudG9EYXRlICYmIHRoaXMucHJvcGVydGllcy50b0RhdGUgIT0gJycpIHtcbiAgICAgIHRoaXMubWF4RGF0ZSA9IG5ldyBEYXRlKHRoaXMucHJvcGVydGllcy50b0RhdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm1heERhdGUgPSBudWxsO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBzZXRWYWx1ZXMoKSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5yYW5nZSkge1xuICAgICAgY29uc3Qgc3RhcnREYXRlSG91ciA9IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2U/LnN0YXJ0ID8gdGhpcy5zZWxlY3RlZERhdGVSYW5nZT8uc3RhcnQuZ2V0SG91cnMoKSA6IDA7XG4gICAgICBjb25zdCBzdGFydERhdGVNaW51dGVzID0gdGhpcy5zZWxlY3RlZERhdGVSYW5nZT8uc3RhcnQgPyB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5zdGFydC5nZXRNaW51dGVzKCkgOiAwO1xuICAgICAgY29uc3QgZW5kRGF0ZUhvdXIgPSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQgPyB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQuZ2V0SG91cnMoKSA6IDIzO1xuICAgICAgY29uc3QgZW5kRGF0ZU1pbnV0ZXMgPSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQgPyB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlPy5lbmQuZ2V0TWludXRlcygpIDogNTk7XG5cbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKHN0YXJ0RGF0ZUhvdXIpKTtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoc3RhcnREYXRlTWludXRlcykpO1xuICAgICAgdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGVuZERhdGVIb3VyKSk7XG4gICAgICB0aGlzLmVuZERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ21pbnV0ZXMnXS5zZXRWYWx1ZSh0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcihlbmREYXRlTWludXRlcykpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBzdGFydERhdGVIb3VyID0gdGhpcy5zZWxlY3RlZERhdGUgPyB0aGlzLnNlbGVjdGVkRGF0ZS5nZXRIb3VycygpIDogMDtcbiAgICAgIGNvbnN0IHN0YXJ0RGF0ZU1pbnV0ZXMgPSB0aGlzLnNlbGVjdGVkRGF0ZSA/IHRoaXMuc2VsZWN0ZWREYXRlLmdldE1pbnV0ZXMoKSA6IDA7XG5cbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKHN0YXJ0RGF0ZUhvdXIpKTtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoc3RhcnREYXRlTWludXRlcykpO1xuICAgIH1cblxuICAgIC8vc2VuZGluZyB0aGUgaGVhZGVyIG9iaiB0byBkYXRlcGlja2VyIGhlYWRlclxuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIG9uIHRoZSBvcGVuaW5nIHRoZSBjYWxlbmRhciBwYW5lbFxuICBwdWJsaWMgb3BlbkNhbGVuZGFyKCkge1xuICAgIGNvbnN0IHNjcm9sbGFibGVEaXYgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2Nyb2xsYWJsZURpdicpO1xuXG4gICAgaWYgKHNjcm9sbGFibGVEaXYpIHtcbiAgICAgIHNjcm9sbGFibGVEaXYuc2Nyb2xsVG8oe1xuICAgICAgICBsZWZ0OiAwLCAgICAvLyBTY3JvbGwgdG8gdGhlIHZlcnkgbGVmdFxuICAgICAgICBiZWhhdmlvcjogJ3Ntb290aCcgIC8vIFNtb290aCBzY3JvbGxpbmcgYW5pbWF0aW9uXG4gICAgICB9KTtcblxuICAgICAgLy8gRGVsYXkgb3BlbmluZyB0aGUgY2FsZW5kYXIgc2xpZ2h0bHkgdG8gZW5zdXJlIHNjcm9sbGluZyBjb21wbGV0ZXNcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAvLyB0aGlzLm9wZW5DYWxlbmRhckFmdGVyU2Nyb2xsKCk7XG4gICAgICAgIHRoaXMuc2hvd0NhbGVuZGFyID0gIXRoaXMuc2hvd0NhbGVuZGFyO1xuICAgICAgfSwgMzAwKTsgIC8vIEFkanVzdCB0aW1lb3V0IGJhc2VkIG9uIGV4cGVjdGVkIHNjcm9sbCBkdXJhdGlvblxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBJZiBubyBzY3JvbGxpbmcgaXMgbmVlZGVkLCBkaXJlY3RseSBvcGVuIHRoZSBjYWxlbmRhclxuICAgICAgLy8gdGhpcy5vcGVuQ2FsZW5kYXJBZnRlclNjcm9sbCgpO1xuICAgICAgdGhpcy5zaG93Q2FsZW5kYXIgPSAhdGhpcy5zaG93Q2FsZW5kYXI7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBvcGVuQ2FsZW5kYXJBZnRlclNjcm9sbCgpIHtcbiAgICAvLyBpZiAodGhpcy5jdXN0b21EYXRlUGlja2VyKSB7XG4gICAgLy8gICBjb25zdCB7IGxlZnQsIHJpZ2h0LCBib3R0b20gfSA9IHRoaXMuY3VzdG9tRGF0ZVBpY2tlci5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXG4gICAgLy8gICB0aGlzLmRhdGVQaWNrZXJMZWZ0ID0gbGVmdDtcbiAgICAvLyAgIHRoaXMuZGF0ZVBpY2tlclRvcCA9IGJvdHRvbSAtIDIwO1xuICAgIC8vIH0gZWxzZSB7XG4gICAgLy8gICB0aGlzLmRhdGVQaWNrZXJMZWZ0ID0gc2NyZWVuLmF2YWlsV2lkdGggLyAyO1xuICAgIC8vICAgdGhpcy5kYXRlUGlja2VyVG9wID0gc2NyZWVuLmF2YWlsSGVpZ2h0IC8gMiAtIDIwO1xuICAgIC8vIH1cblxuICAgIC8vIFNob3cgdGhlIGNhbGVuZGFyIGFmdGVyIHBvc2l0aW9uaW5nXG4gICAgdGhpcy5zaG93Q2FsZW5kYXIgPSB0cnVlO1xuICB9XG4gIHByb3RlY3RlZCBjbG9zZUNhbGVuZGFyKCkge1xuICAgIHRoaXMuc2hvd0NhbGVuZGFyID0gZmFsc2U7XG4gIH1cblxuICBwdWJsaWMgZGF0ZUNoYW5nZShkYXRlOiBhbnkpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnJhbmdlKSB7XG5cbiAgICAgIGlmICh0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlICYmIHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2Uuc3RhcnQgJiYgZGF0ZSA+PSB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlLnN0YXJ0ICYmICF0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlLmVuZCkge1xuICAgICAgICAvLyB0aGlzLmFwcGx5QnV0dG9uUHJvcGVydGllcy5kaXNhYmxlZCA9IGZhbHNlO1xuICAgICAgICAvLyB0aGlzLmFwcGx5QnV0dG9uRGlzYWJsZS5zZXQoZmFsc2UpO1xuICAgICAgICB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlID0gbmV3IERhdGVSYW5nZSh0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlLnN0YXJ0LCBkYXRlKTtcbiAgICAgICAgdGhpcy5zaG93RW5kVGltZSA9IHRydWU7XG4gICAgICAgIHRoaXMuc2hvd1N0YXJ0VGltZSA9IGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gdGhpcy5hcHBseUJ1dHRvblByb3BlcnRpZXMuZGlzYWJsZWQgPSB0cnVlO1xuXG4gICAgICAgIC8vIHRoaXMuYXBwbHlCdXR0b25EaXNhYmxlLnNldCh0cnVlKTtcbiAgICAgICAgdGhpcy5zaG93RW5kVGltZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNob3dTdGFydFRpbWUgPSB0cnVlO1xuXG4gICAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMuZnJvbURhdGUpIHtcbiAgICAgICAgICAvLyB0aGlzLmFwcGx5QnV0dG9uRGlzYWJsZS5zZXQoZmFsc2UpO1xuICAgICAgICAgIHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2UgPSBuZXcgRGF0ZVJhbmdlKG5ldyBEYXRlKHRoaXMucHJvcGVydGllcy5mcm9tRGF0ZSksIGRhdGUpO1xuICAgICAgICAgIHRoaXMuc2hvd0VuZFRpbWUgPSB0cnVlO1xuICAgICAgICAgIHRoaXMuc2hvd1N0YXJ0VGltZSA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmICh0aGlzLnByb3BlcnRpZXMudG9EYXRlKSB7XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlID0gbmV3IERhdGVSYW5nZShkYXRlLCBuZXcgRGF0ZSh0aGlzLnByb3BlcnRpZXMudG9EYXRlKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2UgPSBuZXcgRGF0ZVJhbmdlKGRhdGUsIG51bGwpO1xuICAgICAgICAgIH1cbiAgICAgICAgICAvLyB0aGlzLmFwcGx5QnV0dG9uRGlzYWJsZS5zZXQoZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZih0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlICYmIHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2Uuc3RhcnQgJiYgdGhpcy5zZWxlY3RlZERhdGVSYW5nZS5lbmQpIHtcbiAgICAgICAgdGhpcy5hcHBseUJ1dHRvbkRpc2FibGUuc2V0KGZhbHNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuYXBwbHlCdXR0b25EaXNhYmxlLnNldCh0cnVlKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zZWxlY3RlZERhdGUgPSBkYXRlO1xuICAgICAgLy8gdGhpcy5hcHBseUJ1dHRvblByb3BlcnRpZXMuZGlzYWJsZWQgPSBmYWxzZTtcbiAgICAgIHRoaXMuYXBwbHlCdXR0b25EaXNhYmxlLnNldChmYWxzZSk7XG4gICAgICB0aGlzLnNob3dTdGFydFRpbWUgPSB0cnVlO1xuICAgICAgdGhpcy5zaG93RW5kVGltZSA9IGZhbHNlO1xuICAgIH1cblxuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIHB1YmxpYyBkZWNyZWFzZU1pbnModHlwZTogc3RyaW5nKSB7XG4gICAgbGV0IGN1cnJlbnRWYWx1ZTtcblxuICAgIGlmICh0eXBlID09ICdzdGFydCcpIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IE51bWJlcih0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3VycmVudFZhbHVlID0gTnVtYmVyKHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnZhbHVlKTtcbiAgICB9XG5cbiAgICBpZiAoY3VycmVudFZhbHVlIDw9IDApIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1cnJlbnRWYWx1ZS0tO1xuICAgIH1cblxuICAgIGlmICh0eXBlID09ICdzdGFydCcpIHtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLm1pbnV0ZXMuc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoY3VycmVudFZhbHVlKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGN1cnJlbnRWYWx1ZSkpO1xuICAgIH1cblxuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIHB1YmxpYyBpbmNyZWFzZU1pbnModHlwZTogc3RyaW5nKSB7XG4gICAgbGV0IGN1cnJlbnRWYWx1ZTtcblxuICAgIGlmICh0eXBlID09ICdzdGFydCcpIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IE51bWJlcih0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3VycmVudFZhbHVlID0gTnVtYmVyKHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnZhbHVlKTtcbiAgICB9XG5cbiAgICBpZiAoY3VycmVudFZhbHVlID49IDU5KSB7XG4gICAgICBjdXJyZW50VmFsdWUgPSA1OTtcbiAgICB9IGVsc2Uge1xuICAgICAgY3VycmVudFZhbHVlKys7XG4gICAgfVxuXG4gICAgaWYgKHR5cGUgPT0gJ3N0YXJ0Jykge1xuICAgICAgdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMubWludXRlcy5zZXRWYWx1ZSh0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcihjdXJyZW50VmFsdWUpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLm1pbnV0ZXMuc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoY3VycmVudFZhbHVlKSk7XG4gICAgfVxuXG4gICAgdGhpcy5wcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpO1xuICB9XG5cbiAgcHVibGljIGluY3JlYXNlSG91cnModHlwZTogc3RyaW5nKSB7XG4gICAgbGV0IGN1cnJlbnRWYWx1ZTtcblxuICAgIGlmICh0eXBlID09ICdzdGFydCcpIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IE51bWJlcih0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5ob3Vycy52YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IE51bWJlcih0aGlzLmVuZERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMuaG91cnMudmFsdWUpO1xuICAgIH1cblxuICAgIGlmIChjdXJyZW50VmFsdWUgPj0gMjMpIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IDIzO1xuICAgIH0gZWxzZSB7XG4gICAgICBjdXJyZW50VmFsdWUrKztcbiAgICB9XG5cbiAgICBpZiAodHlwZSA9PSAnc3RhcnQnKSB7XG4gICAgICB0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5ob3Vycy5zZXRWYWx1ZSh0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcihjdXJyZW50VmFsdWUpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGN1cnJlbnRWYWx1ZSkpO1xuICAgIH1cblxuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIHB1YmxpYyBkZWNyZWFzZUhvdXJzKHR5cGU6IHN0cmluZykge1xuICAgIGxldCBjdXJyZW50VmFsdWU7XG5cbiAgICBpZiAodHlwZSA9PSAnc3RhcnQnKSB7XG4gICAgICBjdXJyZW50VmFsdWUgPSBOdW1iZXIodGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMuaG91cnMudmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjdXJyZW50VmFsdWUgPSBOdW1iZXIodGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnZhbHVlKTtcbiAgICB9XG5cbiAgICBpZiAoY3VycmVudFZhbHVlIDw9IDApIHtcbiAgICAgIGN1cnJlbnRWYWx1ZSA9IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1cnJlbnRWYWx1ZS0tO1xuICAgIH1cblxuICAgIGlmICh0eXBlID09ICdzdGFydCcpIHtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGN1cnJlbnRWYWx1ZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmVuZERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMuaG91cnMuc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoY3VycmVudFZhbHVlKSk7XG4gICAgfVxuXG4gICAgdGhpcy5wcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpO1xuICB9XG5cbiAgcHVibGljIGNvbnZlcnRUd29EaWdpdE51bWJlcihjdXJyZW50VmFsdWU6IHN0cmluZyB8IG51bWJlcik6IHN0cmluZyB7XG4gICAgbGV0IGNvbnZlcnRTdHJpbmcgPSBjdXJyZW50VmFsdWUudG9TdHJpbmcoKTtcbiAgICByZXR1cm4gY29udmVydFN0cmluZy5wYWRTdGFydCgyLCAnMCcpO1xuICB9XG5cbiAgLy8gZnVuY3Rpb24gdG8gcHJlcGFyZSB0aGUgaGVhZGVyIG9iamVjdCB0byBzZW5kIHRvIHRoZSBoZWFkZXIgY29tcG9uZW50XG4gIHB1YmxpYyBwcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpIHtcbiAgICBsZXQgb2JqOiBhbnk7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5yYW5nZSkge1xuICAgICAgbGV0IGVuZEhvdXJzLCBlbmRNaW5zLCBzdGFydEhvdXJzLCBzdGFydE1pbnM7XG4gICAgICBvYmogPSBPYmplY3QuYXNzaWduKHt9LCB0aGlzLm11bHRpRGF0ZVNlbGVjdGlvbik7XG5cbiAgICAgIGVuZEhvdXJzID0gdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnZhbHVlO1xuICAgICAgZW5kTWlucyA9IHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9scy5taW51dGVzLnZhbHVlO1xuICAgICAgc3RhcnRIb3VycyA9IHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnZhbHVlO1xuICAgICAgc3RhcnRNaW5zID0gdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMubWludXRlcy52YWx1ZTtcblxuICAgICAgb2JqLnN0YXJ0RGF0ZSA9IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2U/LnN0YXJ0ID8gdGhpcy5zZWxlY3RlZERhdGVSYW5nZS5zdGFydCA6IG51bGw7XG4gICAgICBvYmouZW5kRGF0ZSA9IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2U/LmVuZCA/IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2UuZW5kIDogbnVsbDtcbiAgICAgIG9iai5lbmREYXRlVGltZSA9IGVuZEhvdXJzICsgJyBocjonICsgZW5kTWlucyArICcgbWluJztcbiAgICAgIG9iai5zdGFydERhdGVUaW1lID0gc3RhcnRIb3VycyArICcgaHI6JyArIHN0YXJ0TWlucyArICcgbWluJztcbiAgICAgIG9iai5yYW5nZSA9IHRoaXMucHJvcGVydGllcy5yYW5nZTtcbiAgICB9IGVsc2Uge1xuICAgICAgbGV0IHN0YXJ0SG91cnMsIHN0YXJ0TWlucztcblxuICAgICAgc3RhcnRIb3VycyA9IHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzLmhvdXJzLnZhbHVlO1xuICAgICAgc3RhcnRNaW5zID0gdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHMubWludXRlcy52YWx1ZTtcblxuICAgICAgb2JqID0gT2JqZWN0LmFzc2lnbih7fSwgdGhpcy5zaW5nbGVEYXRlU2VsZWN0aW9uKTtcblxuICAgICAgb2JqLnN0YXJ0RGF0ZSA9IHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2UgPyB0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlIDogbnVsbDtcbiAgICAgIG9iai5zdGFydERhdGVUaW1lID0gc3RhcnRIb3VycyArICcgaHI6JyArIHN0YXJ0TWlucyArICcgbWluJztcbiAgICAgIC8vIHJhbmdlIHNob3VsZCBiZSBmYWxzZVxuICAgICAgb2JqLnJhbmdlID0gZmFsc2U7XG4gICAgfVxuICAgIG9iai5zaG93VGltZSA9IHRoaXMucHJvcGVydGllcy5zaG93VGltZTtcbiAgICB0aGlzLnByZXZpb3VzU2hvd1RpbWUgPSB0aGlzLnByb3BlcnRpZXMuc2hvd1RpbWU7XG4gICAgb2JqLnNob3dPbmx5TW9udGhZZWFyID0gdGhpcy5wcm9wZXJ0aWVzLnNob3dPbmx5TW9udGhZZWFyID8gdGhpcy5wcm9wZXJ0aWVzLnNob3dPbmx5TW9udGhZZWFyIDogZmFsc2U7XG5cblxuICAgIHRoaXMuc2VuZENoYW5nZXNUb0hlYWRlcihvYmopO1xuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBnZXRzIHRyaWdnZXJlZCB3aGVuIHRoZSB1c2VyIGNsaWNrcyBvbiB0aGUgYXBwbHkgYnV0dG9uXG4gIHB1YmxpYyBhcHBseSgpIHtcbiAgICBsZXQgc2VsZWN0ZWREYXRlLCB2YWx1ZTtcbiAgICBsZXQgZm9ybWF0ID0gdGhpcy5wcm9wZXJ0aWVzLnNob3dUaW1lID8gdGhpcy5kaXNwbGF5Rm9ybWF0V2l0aFRpbWUgOiB0aGlzLmRpc3BsYXlGb3JtYXRXaXRob3V0VGltZTtcbiAgICBmb3JtYXQgPSAodGhpcy5wcm9wZXJ0aWVzLmZvcm1hdCAmJiB0aGlzLnByb3BlcnRpZXMuZm9ybWF0ICE9ICcnKSA/IHRoaXMucHJvcGVydGllcy5mb3JtYXQgOiBmb3JtYXQ7XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnJhbmdlKSB7XG4gICAgICBsZXQgc3RhcnRUaW1lSG91cnMsIHN0YXJ0VGltZU1pbnV0ZXMsIGVuZFRpbWVIb3VycywgZW5kVGltZU1pbnV0ZXM7XG5cbiAgICAgIHN0YXJ0VGltZUhvdXJzID0gTnVtYmVyKHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnZhbHVlKTtcbiAgICAgIHN0YXJ0VGltZU1pbnV0ZXMgPSBOdW1iZXIodGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ21pbnV0ZXMnXS52YWx1ZSk7XG4gICAgICBlbmRUaW1lSG91cnMgPSBOdW1iZXIodGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnZhbHVlKTtcbiAgICAgIGVuZFRpbWVNaW51dGVzID0gTnVtYmVyKHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnZhbHVlKTtcblxuICAgICAgc2VsZWN0ZWREYXRlID0gbmV3IERhdGVSYW5nZShcbiAgICAgICAgdGhpcy5nZXRTZWxlY3RlZERhdGVBbmRUaW1lKHRoaXMuc2VsZWN0ZWREYXRlUmFuZ2Uuc3RhcnQsIHN0YXJ0VGltZUhvdXJzLCBzdGFydFRpbWVNaW51dGVzKSA/PyB0aGlzLmdldFNlbGVjdGVkRGF0ZUFuZFRpbWUobmV3IERhdGUoKSwgMCwgMCksXG4gICAgICAgIHRoaXMuZ2V0U2VsZWN0ZWREYXRlQW5kVGltZSh0aGlzLnNlbGVjdGVkRGF0ZVJhbmdlLmVuZCwgZW5kVGltZUhvdXJzLCBlbmRUaW1lTWludXRlcykgPz8gdGhpcy5nZXRTZWxlY3RlZERhdGVBbmRUaW1lKG5ldyBEYXRlKCksIDAsIDApXG4gICAgICApO1xuXG4gICAgICBjb25zdCBzdGFydERhdGUgPSB0aGlzLmRhdGVQaXBlLnRyYW5zZm9ybShzZWxlY3RlZERhdGUuc3RhcnQsIGZvcm1hdCk7XG4gICAgICBjb25zdCBlbmREYXRlID0gdGhpcy5kYXRlUGlwZS50cmFuc2Zvcm0oc2VsZWN0ZWREYXRlPy5lbmQsIGZvcm1hdCk7XG5cbiAgICAgIHZhbHVlID0gc3RhcnREYXRlICsgJyAtICcgKyBlbmREYXRlO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgc3RhcnRUaW1lSG91cnMsIHN0YXJ0VGltZU1pbnV0ZXM7XG5cbiAgICAgIHN0YXJ0VGltZUhvdXJzID0gaXNOYU4oTnVtYmVyKHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnZhbHVlKSkgPyAwIDogTnVtYmVyKHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnZhbHVlKTtcbiAgICAgIHN0YXJ0VGltZU1pbnV0ZXMgPSBpc05hTihOdW1iZXIodGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ21pbnV0ZXMnXS52YWx1ZSkpID8gMCA6IE51bWJlcih0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnZhbHVlKTtcblxuICAgICAgaWYgKHRoaXMucHJvcGVydGllcy5zaG93T25seU1vbnRoWWVhcikge1xuICAgICAgICBzZWxlY3RlZERhdGUgPSB0aGlzLnNlbGVjdGVkRGF0ZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNlbGVjdGVkRGF0ZSA9IG5ldyBEYXRlKHRoaXMuZ2V0U2VsZWN0ZWREYXRlQW5kVGltZSh0aGlzLnNlbGVjdGVkRGF0ZSwgc3RhcnRUaW1lSG91cnMsIHN0YXJ0VGltZU1pbnV0ZXMpID8/IHRoaXMuZ2V0U2VsZWN0ZWREYXRlQW5kVGltZShuZXcgRGF0ZSgpLCAwLCAwKSwpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzdGFydERhdGUgPSB0aGlzLmRhdGVQaXBlLnRyYW5zZm9ybShzZWxlY3RlZERhdGUsIGZvcm1hdCk7XG5cbiAgICAgIHZhbHVlID0gc3RhcnREYXRlXG4gICAgfVxuXG4gICAgdGhpcy53cml0ZVZhbHVlKHZhbHVlKTtcbiAgICB0aGlzLm9uQ2hhbmdlKHRoaXMuX3ZhbHVlKTtcbiAgICB0aGlzLnNob3dDYWxlbmRhciA9IGZhbHNlO1xuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMucHJvcGVydGllcy5vblZhbHVlQ2hhbmdlKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZ2V0U2VsZWN0ZWREYXRlQW5kVGltZShkYXRlOiBhbnksIGhvdXJzOiBudW1iZXIsIG1pbnV0ZXM6IG51bWJlcik6IGFueSB7XG4gICAgY29uc3QgbW9udGggPSBkYXRlLmdldE1vbnRoKCk7IC8vbW9udGhzIGZyb20gMS0xMlxuICAgIGNvbnN0IGRheSA9IGRhdGUuZ2V0RGF0ZSgpO1xuICAgIGNvbnN0IHllYXIgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XG5cbiAgICByZXR1cm4gbmV3IERhdGUoeWVhciwgbW9udGgsIGRheSwgaG91cnMsIG1pbnV0ZXMpO1xuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgb24gdGhlIGNsaWNrIG9mIHRoZSBjYW5jZWwgYnV0dG9uXG4gIHB1YmxpYyBjYW5jZWwoKSB7XG4gICAgdGhpcy5zaG93Q2FsZW5kYXIgPSBmYWxzZTtcbiAgICBsZXQgdmFsdWUgPSB0aGlzLm5nQ29udHJvbC52YWx1ZTtcblxuICAgIGlmICh2YWx1ZSAhPSB1bmRlZmluZWQgJiYgdmFsdWUgIT0gJycpIHtcbiAgICAgIHRoaXMuc2V0VmFsdWVzRnJvbUZvcm1Hcm91cCh2YWx1ZSk7XG4gICAgICB0aGlzLnNldFZhbHVlcygpO1xuICAgIH1cbiAgfVxuXG4gIC8vIGZ1bmN0aW9uIHRvIHNlbmQgdGhlIGNoYW5nZXMgdG8gdGhlIGRhdGUgcGlja2VyIGhlYWRlciBjb21wb25lbnRcbiAgcHVibGljIHNlbmRDaGFuZ2VzVG9IZWFkZXIob2JqOiBhbnkpIHtcbiAgICB0aGlzLmRhdGVwaWNrZXJTZXJ2aWNlLmRhdGFTdWJqZWN0Lm5leHQob2JqKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlcmUgaXMgYW55IGNoYW5nZSBpbiB0aGUgc3RhcnRUaW1lIGhvdXJzIElucHV0XG4gIHB1YmxpYyBzdGFydFRpbWVIb3Vyc0lucHV0VmFsdWVDaGFuZ2VzKGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCBjdXJyZW50SG91cnNWYWx1ZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xuXG4gICAgaWYgKGN1cnJlbnRIb3Vyc1ZhbHVlID49IDIzKSB7XG4gICAgICB0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSgnMjMnKTtcbiAgICB9IGVsc2UgaWYgKGN1cnJlbnRIb3Vyc1ZhbHVlIDw9IDApIHtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydob3VycyddLnNldFZhbHVlKCcnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ2hvdXJzJ10uc2V0VmFsdWUoIU51bWJlci5pc05hTihjdXJyZW50SG91cnNWYWx1ZSkgPyBjdXJyZW50SG91cnNWYWx1ZS50b1N0cmluZygpIDogJycpO1xuICAgIH1cblxuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIG9uIGJsdXIgb2Ygc3RhcnRUaW1lIGhvdXJzIElucHV0XG4gIHB1YmxpYyBzdGFydFRpbWVIb3Vyc0lucHV0T25CbHVyKGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCBjdXJyZW50SG91cnNWYWx1ZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xuXG4gICAgdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ2hvdXJzJ10uc2V0VmFsdWUoIU51bWJlci5pc05hTihjdXJyZW50SG91cnNWYWx1ZSkgPyB0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcihjdXJyZW50SG91cnNWYWx1ZSkgOiAnJyk7XG4gICAgdGhpcy5wcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpO1xuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgd2hlbiB0aGVyZSBpcyBhbnkgY2hhbmdlIGluIHRoZSBzdGFydFRpbWUgbWludXRlcyBJbnB1dFxuICBwdWJsaWMgc3RhcnRUaW1lTWludXRlc0lucHV0VmFsdWVDaGFuZ2VzKGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCBjdXJyZW50TWludXRlc1ZhbHVlID0gTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XG5cbiAgICBpZiAoY3VycmVudE1pbnV0ZXNWYWx1ZSA8PSAwKSB7XG4gICAgICB0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnNldFZhbHVlKCcnKTtcbiAgICB9IGVsc2UgaWYgKGN1cnJlbnRNaW51dGVzVmFsdWUgPj0gNTkpIHtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUoJzU5Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUoIU51bWJlci5pc05hTihjdXJyZW50TWludXRlc1ZhbHVlKSA/IGN1cnJlbnRNaW51dGVzVmFsdWUudG9TdHJpbmcoKSA6ICcnKTtcbiAgICB9XG5cbiAgICB0aGlzLnByZXBhcmVIZWFkZXJEYXRlT2JqZWN0KCk7XG4gIH1cblxuICAvLyB0aGlzIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCBvbiBibHVyIG9mIHN0YXJ0VGltZSBtaW5zIElucHV0XG4gIHB1YmxpYyBzdGFydFRpbWVNaW51dGVzSW5wdXRPbkJsdXIoZXZlbnQ6IGFueSkge1xuICAgIGNvbnN0IGN1cnJlbnRIb3Vyc1ZhbHVlID0gTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XG5cbiAgICB0aGlzLnN0YXJ0RGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnNldFZhbHVlKCFOdW1iZXIuaXNOYU4oY3VycmVudEhvdXJzVmFsdWUpID8gdGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoY3VycmVudEhvdXJzVmFsdWUpIDogJycpO1xuICAgIHRoaXMucHJlcGFyZUhlYWRlckRhdGVPYmplY3QoKTtcbiAgfVxuXG4gIC8vIHRoaXMgZnVuY3Rpb24gaXMgdHJpZ2dlcmVkIHdoZW4gdGhlcmUgaXMgYW55IGNoYW5nZSBpbiB0aGUgZW5kVGltZSBob3VycyBJbnB1dFxuICBwdWJsaWMgZW5kVGltZUhvdXJzSW5wdXRWYWx1ZUNoYW5nZXMoZXZlbnQ6IGFueSkge1xuICAgIGNvbnN0IGN1cnJlbnRIb3Vyc1ZhbHVlID0gTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XG5cbiAgICBpZiAoY3VycmVudEhvdXJzVmFsdWUgPj0gMjMpIHtcbiAgICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSgnMjMnKTtcbiAgICB9IGVsc2UgaWYgKGN1cnJlbnRIb3Vyc1ZhbHVlIDw9IDApIHtcbiAgICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSgnJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSghTnVtYmVyLmlzTmFOKGN1cnJlbnRIb3Vyc1ZhbHVlKSA/IGN1cnJlbnRIb3Vyc1ZhbHVlLnRvU3RyaW5nKCkgOiAnJyk7XG4gICAgfVxuXG4gICAgdGhpcy5wcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpO1xuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgb24gYmx1ciBvZiBlbmRUaW1lIEhvdXJzIElucHV0XG4gIHB1YmxpYyBlbmRUaW1lSG91cnNJbnB1dE9uQmx1cihldmVudDogYW55KSB7XG4gICAgY29uc3QgY3VycmVudEhvdXJzVmFsdWUgPSBOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKTtcblxuICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSghTnVtYmVyLmlzTmFOKGN1cnJlbnRIb3Vyc1ZhbHVlKSA/IHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGN1cnJlbnRIb3Vyc1ZhbHVlKSA6ICcnKTtcbiAgICB0aGlzLnByZXBhcmVIZWFkZXJEYXRlT2JqZWN0KCk7XG4gIH1cblxuICAvLyB0aGlzIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCB3aGVuIHRoZXJlIGlzIGFueSBjaGFuZ2UgaW4gdGhlIGVuZFRpbWUgbWlucyBJbnB1dFxuICBwdWJsaWMgZW5kVGltZU1pbnV0ZXNJbnB1dFZhbHVlQ2hhbmdlcyhldmVudDogYW55KSB7XG4gICAgY29uc3QgY3VycmVudE1pbnV0ZXNWYWx1ZSA9IE51bWJlcihldmVudC50YXJnZXQudmFsdWUpO1xuXG4gICAgaWYgKGN1cnJlbnRNaW51dGVzVmFsdWUgPD0gMCkge1xuICAgICAgdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUoJycpO1xuICAgIH0gZWxzZSBpZiAoY3VycmVudE1pbnV0ZXNWYWx1ZSA+PSA1OSkge1xuICAgICAgdGhpcy5lbmREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUoJzU5Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnNldFZhbHVlKCFOdW1iZXIuaXNOYU4oY3VycmVudE1pbnV0ZXNWYWx1ZSkgPyBjdXJyZW50TWludXRlc1ZhbHVlLnRvU3RyaW5nKCkgOiAnJyk7XG4gICAgfVxuXG4gICAgdGhpcy5wcmVwYXJlSGVhZGVyRGF0ZU9iamVjdCgpO1xuICB9XG5cbiAgLy8gdGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgb24gYmx1ciBvZiBlbmRUaW1lIG1pbnMgSW5wdXRcbiAgcHVibGljIGVuZFRpbWVNaW51dGVzSW5wdXRPbkJsdXIoZXZlbnQ6IGFueSkge1xuICAgIGNvbnN0IGN1cnJlbnRIb3Vyc1ZhbHVlID0gTnVtYmVyKGV2ZW50LnRhcmdldC52YWx1ZSk7XG5cbiAgICB0aGlzLmVuZERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ21pbnV0ZXMnXS5zZXRWYWx1ZSghTnVtYmVyLmlzTmFOKGN1cnJlbnRIb3Vyc1ZhbHVlKSA/IHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKGN1cnJlbnRIb3Vyc1ZhbHVlKSA6ICcnKTtcbiAgICB0aGlzLnByZXBhcmVIZWFkZXJEYXRlT2JqZWN0KCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0RXJyb3JNZXNzYWdlKCk6IGFueSB7XG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vcHRpb25hbCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG1vbnRoU2VsZWN0ZWQoZXY6IGFueSwgbWF0Q2FsZW5kYXI6IE1hdENhbGVuZGFyPGFueT4pIHtcbiAgICBsZXQgeWVhciA9IGV2LmdldEZ1bGxZZWFyKCk7XG4gICAgbGV0IG1vbnRoID0gZXYuZ2V0TW9udGgoKTtcbiAgICBsZXQgdmFsdWU6IGFueSA9IG5ldyBEYXRlKCk7XG4gICAgdmFsdWUuc2V0RnVsbFllYXIoeWVhcik7XG4gICAgdmFsdWUuc2V0TW9udGgobW9udGgpO1xuICAgIHRoaXMuc2VsZWN0ZWREYXRlID0gdmFsdWU7XG4gICAgbWF0Q2FsZW5kYXIuc2VsZWN0ZWQgPSB2YWx1ZTtcbiAgICAvLyB0aGlzLmFwcGx5QnV0dG9uUHJvcGVydGllcy5kaXNhYmxlZCA9IGZhbHNlO1xuICAgIHRoaXMuYXBwbHlCdXR0b25EaXNhYmxlLnNldChmYWxzZSk7XG4gICAgdGhpcy5jZHIuZGV0YWNoKCk7XG4gIH1cblxuICBwdWJsaWMgdmlld0NoYW5nZWRIYW5kbGVyKGV2OiBhbnksIG1hdENhbGVuZGFyOiBNYXRDYWxlbmRhcjxhbnk+KSB7XG4gICAgaWYgKGV2ID09ICdtb250aCcpIHtcbiAgICAgIG1hdENhbGVuZGFyLmN1cnJlbnRWaWV3ID0gJ3llYXInO1xuICAgIH1cblxuICAgIHRoaXMuY2RyLnJlYXR0YWNoKCk7XG4gIH1cbiAgcHVibGljIGdldCBzaG93SW5mb01zZygpIHtcbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLnNob3dJbmZvTXNnICE9IHVuZGVmaW5lZCkge1xuICAgICAgaWYgKHR5cGVvZiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2cgPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2c7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB0aGlzLnByb3BlcnRpZXMuc2hvd0luZm9Nc2coKTtcbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBjbGVhclNlbGVjdGlvbigpIHtcbiAgICB0aGlzLndyaXRlVmFsdWUoJycpO1xuICAgIHRoaXMub25DaGFuZ2UoJycpO1xuICAgIHRoaXMuc2hvd0NhbGVuZGFyID0gZmFsc2U7XG4gICAgdGhpcy5zdGFydERhdGVIb3Vyc01pbnV0ZXMuY29udHJvbHNbJ2hvdXJzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoMCkpO1xuICAgIHRoaXMuc3RhcnREYXRlSG91cnNNaW51dGVzLmNvbnRyb2xzWydtaW51dGVzJ10uc2V0VmFsdWUodGhpcy5jb252ZXJ0VHdvRGlnaXROdW1iZXIoMCkpO1xuICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snaG91cnMnXS5zZXRWYWx1ZSh0aGlzLmNvbnZlcnRUd29EaWdpdE51bWJlcigyMykpO1xuICAgIHRoaXMuZW5kRGF0ZUhvdXJzTWludXRlcy5jb250cm9sc1snbWludXRlcyddLnNldFZhbHVlKHRoaXMuY29udmVydFR3b0RpZ2l0TnVtYmVyKDU5KSk7XG4gIH1cbn1cbiIsIjxkaXYgW2lkXT1cInByb3BlcnRpZXMuaWRcIj5cbiAgPG1hdC1mb3JtLWZpZWxkIFthcHBlYXJhbmNlXT1cInByb3BlcnRpZXMuYXBwZWFyYW5jZSFcIiBbZmxvYXRMYWJlbF09XCJwcm9wZXJ0aWVzLmZsb2F0TGFiZWwhXCJcbiAgICBjbGFzcz1cInt7IHByb3BlcnRpZXMuc3R5bGU/LmNzc0NsYXNzZXMgfX1cIiBzdWJzY3JpcHRTaXppbmc9XCJkeW5hbWljXCIgY2RrT3ZlcmxheU9yaWdpblxuICAgICNjdXN0b21EYXRlUGlja2VyPVwiY2RrT3ZlcmxheU9yaWdpblwiPlxuXG4gICAgQGlmIChwcm9wZXJ0aWVzLmxhYmVsICE9IG51bGwgJiYgcHJvcGVydGllcy5sYWJlbCAhPSAnJyAmJiBwcm9wZXJ0aWVzLmxhYmVsICE9IHVuZGVmaW5lZCkge1xuICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgPHNwYW4+e3sgcHJvcGVydGllcy5sYWJlbCB9fTwvc3Bhbj5cblxuICAgICAgQGlmIChwcm9wZXJ0aWVzLm9wdGlvbmFsKSB7XG4gICAgICA8c3BhbiBjbGFzcz1cIm9wdGlvbmFsLXRleHRcIj4oT3B0aW9uYWwpPC9zcGFuPlxuICAgICAgfVxuXG4gICAgICBAaWYgKHByb3BlcnRpZXMuaW5mb01zZyAmJiBzaG93SW5mb01zZykge1xuICAgICAgPG1hdC1pY29uIFt0b29sdGlwXT1cInByb3BlcnRpZXMuaW5mb01zZyFcIlxuICAgICAgICBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6aW5mb3JtYXRpb24tY2lyY2xlJ1wiIGNsYXNzPVwibWwtMSBpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlciB0ZXh0LW5ldXRyYWwtNjAwXCI+XG4gICAgICA8L21hdC1pY29uPlxuICAgICAgfVxuICAgIDwvbWF0LWxhYmVsPlxuICAgIH1cblxuICAgIDxpbnB1dCBtYXRJbnB1dCBbdmFsdWVdPVwidmFsdWVcIiBbcGxhY2Vob2xkZXJdPVwicHJvcGVydGllcy5wbGFjZWhvbGRlciFcIlxuICAgICAgKGlucHV0KT1cIm9uQ2hhbmdlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCIgKGJsdXIpPVwib25Ub3VjaGVkKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCJcbiAgICAgIChrZXl1cCk9XCJ3cml0ZVZhbHVlKCRhbnkoJGV2ZW50LnRhcmdldCkudmFsdWUpXCIgW3JlYWRvbmx5XT1cInRydWVcIj5cblxuICAgIEBpZiAocHJvcGVydGllcy5wcmVmaXhJY29uKSB7XG4gICAgPG1hdC1pY29uIG1hdFByZWZpeCBjbGFzcz1cImN1cnNvci1wb2ludGVyXCIgW3N2Z0ljb25dPVwicHJvcGVydGllcy5wcmVmaXhJY29uXCI+XG4gICAgPC9tYXQtaWNvbj5cbiAgICB9XG5cbiAgICBAaWYgKHByb3BlcnRpZXMub3B0aW9uYWwgJiYgdmFsdWUgIT0gJycpIHtcbiAgICAgIDxtYXQtaWNvbiBjbGFzcz1cImNsLWRhdGVwaWNrZXItY2xlYXItaWNvblwiIChjbGljayk9XCJjbGVhclNlbGVjdGlvbigpXCI+Y2xvc2U8L21hdC1pY29uPlxuICAgIH1cblxuICAgIDxtYXQtaWNvbiBtYXRTdWZmaXggKGNsaWNrKT1cIm9wZW5DYWxlbmRhcigpXCIgY2xhc3M9XCJjdXJzb3ItcG9pbnRlclwiXG4gICAgICBbc3ZnSWNvbl09XCJwcm9wZXJ0aWVzLnN1ZmZpeEljb24gPz8gJ2hlcm9pY29uc19vdXRsaW5lOmNhbGVuZGFyJ1wiPlxuICAgIDwvbWF0LWljb24+XG4gIDwvbWF0LWZvcm0tZmllbGQ+XG5cbiAgQGlmIChlcnJvcikge1xuICA8bWF0LWVycm9yIGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgICB7eyBlcnJvciB9fVxuICA8L21hdC1lcnJvcj5cbiAgfVxuICBAaWYgKHByb3BlcnRpZXMuaGludFRleHQpIHtcbiAgPG1hdC1oaW50IGNsYXNzPVwie3sgcHJvcGVydGllcy5zdWJzY3JpcHRTaXppbmcgPT09ICdmaXhlZCcgPyAnaC01JzogJycgfX1cIj5cbiAgICB7eyBwcm9wZXJ0aWVzLmhpbnRUZXh0IH19XG4gIDwvbWF0LWhpbnQ+XG4gIH1cbjwvZGl2PlxuXG48bmctdGVtcGxhdGUgY2RrQ29ubmVjdGVkT3ZlcmxheVxuICBbY2RrQ29ubmVjdGVkT3ZlcmxheU9yaWdpbl09XCJjdXN0b21EYXRlUGlja2VyXCJcbiAgW2Nka0Nvbm5lY3RlZE92ZXJsYXlPcGVuXT1cInNob3dDYWxlbmRhclwiXG4gIFtjZGtDb25uZWN0ZWRPdmVybGF5UG9zaXRpb25zXT1cInBvc2l0aW9uc1wiXG4gIFtjZGtDb25uZWN0ZWRPdmVybGF5U2Nyb2xsU3RyYXRlZ3ldPVwic2Nyb2xsU3RyYXRlZ3lcIlxuICAoYmFja2Ryb3BDbGljayk9XCJjbG9zZUNhbGVuZGFyKClcIlxuICBbY2RrQ29ubmVjdGVkT3ZlcmxheUhhc0JhY2tkcm9wXT1cInRydWVcIj5cblxuICA8bWF0LWNhcmQgY2xhc3M9XCJvdmVybGF5LWNvbnRlbnRcIj5cbiAgICA8bWF0LWNhbGVuZGFyICNtYXRDYWxlbmRhciBbaGVhZGVyQ29tcG9uZW50XT1cImN1c3RvbUhlYWRlclwiIFtzdGFydEF0XT1cInNlbGVjdGVkRGF0ZVwiIFttaW5EYXRlXT1cIm1pbkRhdGUgfHwgbnVsbFwiXG4gICAgICBbbWF4RGF0ZV09XCJtYXhEYXRlIHx8IG51bGxcIiAoc2VsZWN0ZWRDaGFuZ2UpPVwiZGF0ZUNoYW5nZSgkZXZlbnQpXCJcbiAgICAgIFtzdGFydFZpZXddPVwicHJvcGVydGllcy5zdGFydFZpZXcgPyBwcm9wZXJ0aWVzLnN0YXJ0VmlldyA6ICdtb250aCdcIlxuICAgICAgW3NlbGVjdGVkXT1cInByb3BlcnRpZXMucmFuZ2UgPyBzZWxlY3RlZERhdGVSYW5nZTogc2VsZWN0ZWREYXRlXCIgW2RhdGVDbGFzc109XCJkaXNhYmxlRnJvbURhdGVcIlxuICAgICAgKG1vbnRoU2VsZWN0ZWQpPVwicHJvcGVydGllcy5zaG93T25seU1vbnRoWWVhciA/IG1vbnRoU2VsZWN0ZWQoJGV2ZW50LCBtYXRDYWxlbmRhcikgOiBudWxsXCJcbiAgICAgICh2aWV3Q2hhbmdlZCk9XCJwcm9wZXJ0aWVzLnNob3dPbmx5TW9udGhZZWFyID8gdmlld0NoYW5nZWRIYW5kbGVyKCRldmVudCwgbWF0Q2FsZW5kYXIpIDogbnVsbFwiPlxuICAgIDwvbWF0LWNhbGVuZGFyPlxuXG4gICAgPGRpdiBjbGFzcz1cInRpbWUtY29udGFpbmVyIHB4LTQgcGItNCBwdC0zXCI+XG4gICAgICBAaWYgKHNob3dTdGFydFRpbWUgJiYgcHJvcGVydGllcy5zaG93VGltZSkge1xuICAgICAgPGZvcm0gW2Zvcm1Hcm91cF09XCJzdGFydERhdGVIb3Vyc01pbnV0ZXNcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGJnLXdoaXRlIHBiLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgaG91cnMtY29udGFpbmVyIGp1c3RpZnktY2VudGVyIGJnLW5ldXRyYWwtNTBcIj5cblxuICAgICAgICAgICAgPG1hdC1sYWJlbCBjbGFzcz1cInRleHQtbWQgdGV4dC1uZXV0cmFsLTcwMFwiPkhvdXJzPC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICAgIDxpbnB1dCBtYXRJbnB1dCBjbGFzcz1cImhvdXJzSW5wdXQgcGwtMi41XCIgZm9ybUNvbnRyb2xOYW1lPVwiaG91cnNcIiB0eXBlPVwidGV4dFwiIG1heGxlbmd0aD1cIjJcIlxuICAgICAgICAgICAgICBwYXR0ZXJuPVwiWzAtOV17Mn1cIiBtaW49XCIwXCIgbWF4PVwiMjNcIiBwbGFjZWhvbGRlcj1cIjAwXCIgKGtleXVwKT1cInN0YXJ0VGltZUhvdXJzSW5wdXRWYWx1ZUNoYW5nZXMoJGV2ZW50KVwiXG4gICAgICAgICAgICAgIChibHVyKT1cInN0YXJ0VGltZUhvdXJzSW5wdXRPbkJsdXIoJGV2ZW50KVwiPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICA8bWF0LWljb24gKGNsaWNrKT1cImluY3JlYXNlSG91cnMoJ3N0YXJ0JylcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6Y2hldnJvbi11cCdcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgPC9tYXQtaWNvbj5cblxuICAgICAgICAgICAgICA8bWF0LWljb24gKGNsaWNrKT1cImRlY3JlYXNlSG91cnMoJ3N0YXJ0JylcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6Y2hldnJvbi1kb3duJ1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICA8L21hdC1pY29uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGhvdXJzLWNvbnRhaW5lciBqdXN0aWZ5LWNlbnRlciBiZy1uZXV0cmFsLTUwXCI+XG5cbiAgICAgICAgICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJ0ZXh0LW1kIHRleHQtbmV1dHJhbC03MDBcIj5NaW51dGVzPC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImhvdXJzSW5wdXQgcGwtMi41XCIgZm9ybUNvbnRyb2xOYW1lPVwibWludXRlc1wiIHR5cGU9XCJ0ZXh0XCIgbWF0SW5wdXQgbWF4bGVuZ3RoPVwiMlwiXG4gICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XXsyfVwiIG1pbj1cIjBcIiBtYXg9XCI1OVwiIHBsYWNlaG9sZGVyPVwiMDBcIiAoa2V5dXApPVwic3RhcnRUaW1lTWludXRlc0lucHV0VmFsdWVDaGFuZ2VzKCRldmVudClcIlxuICAgICAgICAgICAgICAoYmx1cik9XCJzdGFydFRpbWVNaW51dGVzSW5wdXRPbkJsdXIoJGV2ZW50KVwiPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICAgICAgICA8bWF0LWljb24gKGNsaWNrKT1cImluY3JlYXNlTWlucygnc3RhcnQnKVwiIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTpjaGV2cm9uLXVwJ1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICA8L21hdC1pY29uPlxuXG4gICAgICAgICAgICAgIDxtYXQtaWNvbiAoY2xpY2spPVwiZGVjcmVhc2VNaW5zKCdzdGFydCcpXCIgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmNoZXZyb24tZG93bidcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZm9ybT5cbiAgICAgIH1cblxuICAgICAgQGlmIChzaG93RW5kVGltZSAmJiBwcm9wZXJ0aWVzLnNob3dUaW1lKSB7XG4gICAgICA8Zm9ybSBbZm9ybUdyb3VwXT1cImVuZERhdGVIb3Vyc01pbnV0ZXNcIj5cbiAgICAgICAgPGRpdiBjbGFzcz1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGJnLXdoaXRlIHBiLTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgaG91cnMtY29udGFpbmVyIGp1c3RpZnktY2VudGVyIGJnLW5ldXRyYWwtNTBcIj5cblxuICAgICAgICAgICAgPG1hdC1sYWJlbCBjbGFzcz1cInRleHQtbWQgdGV4dC1uZXV0cmFsLTcwMFwiPkhvdXJzPC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImhvdXJzSW5wdXQgcGwtMi41XCIgZm9ybUNvbnRyb2xOYW1lPVwiaG91cnNcIiB0eXBlPVwidGV4dFwiIG1hdElucHV0IG1heGxlbmd0aD1cIjJcIlxuICAgICAgICAgICAgICBwYXR0ZXJuPVwiWzAtOV17Mn1cIiBtaW49XCIwXCIgbWF4PVwiMjNcIiBwbGFjZWhvbGRlcj1cIjAwXCIgKGtleXVwKT1cImVuZFRpbWVIb3Vyc0lucHV0VmFsdWVDaGFuZ2VzKCRldmVudClcIlxuICAgICAgICAgICAgICAoYmx1cik9XCJlbmRUaW1lSG91cnNJbnB1dE9uQmx1cigkZXZlbnQpXCI+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxtYXQtaWNvbiAoY2xpY2spPVwiaW5jcmVhc2VIb3VycygnZW5kJylcIiBbc3ZnSWNvbl09XCInaGVyb2ljb25zX291dGxpbmU6Y2hldnJvbi11cCdcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgPC9tYXQtaWNvbj5cblxuICAgICAgICAgICAgICA8bWF0LWljb24gKGNsaWNrKT1cImRlY3JlYXNlSG91cnMoJ2VuZCcpXCIgW3N2Z0ljb25dPVwiJ2hlcm9pY29uc19vdXRsaW5lOmNoZXZyb24tZG93bidcIlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiaWNvbi1zaXplLTQgY3Vyc29yLXBvaW50ZXJcIj5cbiAgICAgICAgICAgICAgPC9tYXQtaWNvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzcz1cImZsZXggaXRlbXMtY2VudGVyIGhvdXJzLWNvbnRhaW5lciBqdXN0aWZ5LWNlbnRlciBiZy1uZXV0cmFsLTUwXCI+XG5cbiAgICAgICAgICAgIDxtYXQtbGFiZWwgY2xhc3M9XCJ0ZXh0LW1kIHRleHQtbmV1dHJhbC03MDBcIj5NaW51dGVzPC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzcz1cImhvdXJzSW5wdXQgcGwtMi41XCIgZm9ybUNvbnRyb2xOYW1lPVwibWludXRlc1wiIHR5cGU9XCJ0ZXh0XCIgbWF0SW5wdXQgbWF4bGVuZ3RoPVwiMlwiXG4gICAgICAgICAgICAgIHBhdHRlcm49XCJbMC05XXsyfVwiIG1pbj1cIjBcIiBtYXg9XCI1OVwiIHBsYWNlaG9sZGVyPVwiMDBcIiAoa2V5dXApPVwiZW5kVGltZU1pbnV0ZXNJbnB1dFZhbHVlQ2hhbmdlcygkZXZlbnQpXCJcbiAgICAgICAgICAgICAgKGJsdXIpPVwiZW5kVGltZU1pbnV0ZXNJbnB1dE9uQmx1cigkZXZlbnQpXCI+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgICAgICAgIDxtYXQtaWNvbiAoY2xpY2spPVwiaW5jcmVhc2VNaW5zKCdlbmQnKVwiIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTpjaGV2cm9uLXVwJ1wiXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJpY29uLXNpemUtNCBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgICAgICA8L21hdC1pY29uPlxuXG4gICAgICAgICAgICAgIDxtYXQtaWNvbiAoY2xpY2spPVwiZGVjcmVhc2VNaW5zKCdlbmQnKVwiIFtzdmdJY29uXT1cIidoZXJvaWNvbnNfb3V0bGluZTpjaGV2cm9uLWRvd24nXCJcbiAgICAgICAgICAgICAgICBjbGFzcz1cImljb24tc2l6ZS00IGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgIDwvbWF0LWljb24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Zvcm0+XG4gICAgICB9XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBkYXRlcGlja2VyLWJ1dHRvbnNkaXYgcHQtMyBib3JkZXItbmV1dHJhbC0yMDBcIj5cbiAgICAgICAgPGNsLWJ1dHRvbiBbcHJvcGVydGllc109XCJjYW5jZWxCdXR0b25Qcm9wZXJ0aWVzXCI+PC9jbC1idXR0b24+XG4gICAgICAgIDxjbC1idXR0b24gW3Byb3BlcnRpZXNdPVwiYXBwbHlCdXR0b25Qcm9wZXJ0aWVzXCI+PC9jbC1idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICA8L21hdC1jYXJkPlxuPC9uZy10ZW1wbGF0ZT5cbiJdfQ==