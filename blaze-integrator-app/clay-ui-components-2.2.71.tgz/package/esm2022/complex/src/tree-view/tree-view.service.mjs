import { Subject } from "rxjs";
import { Injectable } from "@angular/core";
import * as i0 from "@angular/core";
export class ClTreeViewService {
    constructor() {
        this.treeNodeToExpandedCollapse = new Subject();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJlZS12aWV3LnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9jbGF5L3VpLWNvbXBvbmVudHMvY29tcGxleC9zcmMvdHJlZS12aWV3L3RyZWUtdmlldy5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDL0IsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFNM0MsTUFBTSxPQUFPLGlCQUFpQjtJQUY5QjtRQUdTLCtCQUEwQixHQUF1QyxJQUFJLE9BQU8sRUFBNkIsQ0FBQztLQUNsSDs4R0FGWSxpQkFBaUI7a0hBQWpCLGlCQUFpQixjQUZKLE1BQU07OzJGQUVuQixpQkFBaUI7a0JBRjdCLFVBQVU7bUJBQUMsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3ViamVjdCB9IGZyb20gXCJyeGpzXCI7XG5pbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcblxuaW1wb3J0IHsgQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllcyB9IGZyb20gXCIuL3RyZWUtdmlldy5wcm9wZXJ0aWVzXCI7XG5cbkBJbmplY3RhYmxlKHsgcHJvdmlkZWRJbjogJ3Jvb3QnIH0pXG5cbmV4cG9ydCBjbGFzcyBDbFRyZWVWaWV3U2VydmljZSB7XG4gIHB1YmxpYyB0cmVlTm9kZVRvRXhwYW5kZWRDb2xsYXBzZTogU3ViamVjdDxDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzPiA9IG5ldyBTdWJqZWN0PENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXM+KCk7XG59XG4iXX0=