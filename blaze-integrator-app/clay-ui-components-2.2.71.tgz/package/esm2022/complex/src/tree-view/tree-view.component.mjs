import { NgClass } from "@angular/common";
import { MatMenuModule } from "@angular/material/menu";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { Input, inject, Component } from "@angular/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { ClTreeViewService } from "./tree-view.service";
import { ClChildTreeViewComponent } from "./child-tree-view/child-tree-view.component";
import { ClComponentTypes, ClBaseContainerComponent } from "@clay/ui-components/shared";
import { ClIconComponent, ClChipComponent } from "@clay/ui-components/basic";
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/menu";
import * as i2 from "@angular/material/checkbox";
import * as i3 from "@angular/material/form-field";
export class ClTreeViewComponent extends ClBaseContainerComponent {
    constructor() {
        super(...arguments);
        this.treeViewService = inject(ClTreeViewService);
        this.addIconProperties = {
            id: 'treeViewIconAdd',
            type: ClComponentTypes.icon,
            iconName: 'heroicons_outline:plus-circle',
            style: { cssClasses: 'icon-size-5 text-primary-600' },
        };
        this.editIconProperties = {
            id: 'treeViewIconEdit',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:edit-filled',
            style: { cssClasses: 'icon-size-4 text-primary-600' },
        };
        this.deleteIconProperties = {
            id: 'treeViewIconDelete',
            iconName: 'fss_icons:trash',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-4' },
        };
        this.actionIconProperties = {
            id: 'treeViewIcon',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:dotted-ellipsis',
            style: { cssClasses: 'icon-size-4' },
        };
        this.viewOnIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:eye-open-filled',
            style: { cssClasses: 'icon-size-5' },
        };
        this.viewOffIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            iconName: 'fss_icons:eye-closed',
            style: { cssClasses: 'icon-size-5' },
        };
        this.upArrowIconProperties = {
            id: 'treeViewIconUp',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:chevron-circle-up-filled',
        };
        this.downArrowIconProperties = {
            id: 'treeViewIconDown',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:chevron-circle-down',
        };
        this.partialViewIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:partial-eye-filled',
        };
        this.disableViewIconProperties = {
            id: 'treeViewIconEye',
            type: ClComponentTypes.icon,
            style: { cssClasses: 'icon-size-5' },
            iconName: 'fss_icons:disable-eye-filled',
        };
    }
    ngOnInit() {
        // calling set default properties function
        this.setDefaultProperties();
        // calling add depth function
        this.addDepth(this.properties.treeViewChildren);
        // calling subscribe to tree view service function
        this.subscribeToTreeViewService();
        super.ngOnInit();
    }
    subscribeToTreeViewService() {
        this.treeViewSubscription = this.treeViewService.treeNodeToExpandedCollapse
            .subscribe((selectedTreeNode) => {
            // calling expand collapse tree function
            this.expandCollapseTree(selectedTreeNode);
            // calling add depth function
            this.addDepth(this.properties.treeViewChildren);
        });
    }
    /**
     * this function will set the default values to the property of the tree view
     */
    setDefaultProperties() {
        // this property is used to always show the icons
        // and has higher precedence over other properties
        this.properties.alwaysShowActionButtons ??= true;
        this.properties.addIconProperties ??= this.addIconProperties;
        this.properties.editIconProperties ??= this.editIconProperties;
        this.properties.deleteIconProperties ??= this.deleteIconProperties;
        this.properties.actionIconProperties ??= this.actionIconProperties;
        this.properties.viewOnIconProperties ??= this.viewOnIconProperties;
        this.properties.viewOffIconProperties ??= this.viewOffIconProperties;
        this.properties.upArrowIconProperties ??= this.upArrowIconProperties;
        this.properties.downArrowIconProperties ??= this.downArrowIconProperties;
        this.properties.partialViewIconProperties ??= this.partialViewIconProperties;
        this.properties.disableViewIconProperties ??= this.disableViewIconProperties;
    }
    /**
     * this function is used to add depth to the tree view for managing the width of the children
     *
     * @param treeNode - array of objects
     *
     * @param depth - depth of the tree node
     */
    addDepth(treeNode, depth = 0) {
        treeNode.forEach((childTreeNode) => {
            childTreeNode.depth = depth;
            childTreeNode.viewOn ??= false;
            childTreeNode.partialView ??= false;
            childTreeNode.showArrowIcons ??= false;
            childTreeNode.showActionButtons ??= false;
            if (childTreeNode.children && childTreeNode.children.length > 0) {
                // calling add depth function
                this.addDepth(childTreeNode.children, depth + 1);
            }
        });
    }
    /**
     * this function will expand or collapse the tree view
     * this function will also call another function to collapse the tree nodes children
     *
     * @param treeNode - tree node which needs to be expanded or collapsed
     */
    expandCollapseTree(treeNode) {
        if (treeNode.children && treeNode.children.length > 0) {
            treeNode.expanded = !treeNode.expanded;
            // calling expand collapse child tree function
            this.expandCollapseChildTree(treeNode.children);
        }
    }
    /**
     * this function will expand or collapse the child tree of a tree node
     *
     * @param treeNode - tree node children which needs to be collapsed
     */
    expandCollapseChildTree(treeNode) {
        treeNode?.forEach((treeNode) => {
            treeNode.expanded = false;
            // calling expand collapse child tree function
            this.expandCollapseChildTree(treeNode.children);
        });
    }
    /**
     * this function will change all the tree node's viewOn property to true or false based on the result
     *
     * @param treeNode - tree node of the tree view
     *
     * @param result - result is based on view on or off
     *                 result should be true to show view on
     *                 result should be true to show view off
     */
    changeViewForAllChildTreeNode(treeNode, result) {
        treeNode.viewOn = result;
        treeNode.partialView = false;
        treeNode.children?.forEach((childTreeNode) => {
            // calling change all view for tree node function
            this.changeViewForAllChildTreeNode(childTreeNode, result);
        });
    }
    /**
     * this function will find the parent and grand parent and so on for the tree node
     * on which view button/icon was clicked
     *
     * @param treeArr - array of tree nodes
     *
     * @param treeId - the id of the tree node where view button/icon was clicked
     *
     * @returns - either return empty array if parent is clicked
     *          - or returns false if id not found
     *          - or returns array of parent and grand parent and so on
     */
    findParentOfTreeNode(treeArr, treeId) {
        for (const treeNode of treeArr) {
            if (treeNode.id === treeId) {
                return [];
            }
            else if (treeNode.children?.length) {
                const parentTreeNodes = this.findParentOfTreeNode(treeNode.children, treeId);
                if (parentTreeNodes !== false) {
                    // this will only add immediate parent of tree node
                    // if (parentTreeNodes.length == 0) parentTreeNodes.push(treeNode);
                    // this will add parent and parent of tree node
                    parentTreeNodes.push(treeNode);
                    return parentTreeNodes;
                }
            }
        }
        return false;
    }
    /**
     * this function will change the view of parent and grand parents and so on
     * based on the combination of it's child's view status
     *
     * in this function we will check the view permission of all the child nodes of each parent
     * if all the child nodes view permission is true then parent's view permission will also be true
     * if all the child nodes view permission is false then parent's view permission will also be false
     * if any of the child's view permission is false and rest of the child's view permission is true
     * then the parent will have partial view permission
     *
     * @param parentTreeNodes - array of tree nodes to change the view
     */
    changeViewForAllParentTreeNode(parentTreeNodes) {
        for (const childTreeNode of parentTreeNodes) {
            const childTreeNodesViewPermission = [];
            childTreeNode.children?.forEach((subChildTreeNode) => {
                childTreeNodesViewPermission.push(subChildTreeNode.viewOn);
            });
            // here we are checking if the tree node has combination of true and false to consider parent as partial view
            if (childTreeNodesViewPermission.indexOf(true) > -1 && childTreeNodesViewPermission.indexOf(false) > -1) {
                childTreeNode.viewOn = true;
                childTreeNode.partialView = true;
            }
            // here we are checking if the tree node has true and does not have false to consider parent as full view
            if (childTreeNodesViewPermission.indexOf(true) > -1 && childTreeNodesViewPermission.indexOf(false) == -1) {
                childTreeNode.viewOn = true;
                childTreeNode.partialView = false;
            }
            // here we are checking if the tree node has false and does not have true to consider parent as no view
            if (childTreeNodesViewPermission.indexOf(true) == -1 && childTreeNodesViewPermission.indexOf(false) > -1) {
                childTreeNode.viewOn = false;
                childTreeNode.partialView = false;
            }
        }
    }
    /**
     * this function will be triggered when the tree node was clicked
     * this function also calls expand collapse tree function
     *
     * @param treeNode - tree node where clicked and needs to be expanded or collapsed
     */
    onTreeNodeClicked(treeNode) {
        let result = true;
        if (treeNode.onTreeNodeClicked != undefined) {
            // calling on tree node clicked callback function
            result = treeNode.onTreeNodeClicked(treeNode);
        }
        if (result) {
            // calling expand collapse tree function
            this.expandCollapseTree(treeNode);
            // calling add depth function
            this.addDepth(this.properties.treeViewChildren);
        }
    }
    /**
     * this function will generate the object for sending it to the client
     *
     * @param treeNode - selected tree node
     *
     * @returns - generated tree node object
     */
    generateReturnObjectForCallback(treeNode) {
        return {
            id: treeNode.id,
            data: treeNode.data,
            text: treeNode.text,
            depth: treeNode.depth,
            viewOn: treeNode.viewOn,
            expanded: treeNode.expanded,
            parentId: treeNode.parentId,
            children: treeNode.children,
            actionList: treeNode.actionList,
            chipsList: treeNode.chipsList,
            partialView: treeNode.partialView,
            showActionButtons: treeNode.showActionButtons,
        };
    }
    /**
     * this function is the call back function for add button
     *
     * @param treeNode - tree node where clicked
     */
    onAddClicked(treeNode) {
        if (treeNode.disableAddIcon) {
            return;
        }
        if (this.properties.onAddClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for add button
            this.properties.onAddClicked(returnObjForCallback);
        }
    }
    /**
     * this function is the call back function for edit button
     *
     * @param treeNode - tree node where clicked
     */
    onEditClicked(treeNode) {
        if (treeNode.disableEditIcon) {
            return;
        }
        if (this.properties.onEditClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for edit button
            this.properties.onEditClicked(returnObjForCallback);
        }
    }
    /**
     * this function is the call back function for delete button
     *
     * @param treeNode - tree node where clicked
     */
    onDeleteClicked(treeNode) {
        if (treeNode.disableDeleteIcon) {
            return;
        }
        if (this.properties.onDeleteClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for delete button
            this.properties.onDeleteClicked(returnObjForCallback);
        }
    }
    onActionIconClicked(treeNode, selectedAction, actionIndex) {
        if (treeNode.disableActionIcon) {
            return;
        }
        if (this.properties.onActionIconClicked != undefined) {
            // toggling checkbox of treeNode
            treeNode.actionList[actionIndex].checked = !treeNode.actionList[actionIndex].checked;
            treeNode.actionList[actionIndex].indeterminate = false;
            // Find parent
            const parentTreeNodes = this.findParentOfTreeNode(this.properties.treeViewChildren, treeNode.id);
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for action button
            this.properties.onActionIconClicked(returnObjForCallback, selectedAction, parentTreeNodes);
        }
    }
    /**
     * this function is the callback function for view button
     *
     * @param treeNode - tree node where clicked
     */
    onViewClicked(treeNode) {
        if (treeNode.disableViewIcon) {
            return;
        }
        if (this.properties.onViewClicked != undefined) {
            // calling generate return object for call back function
            const returnObjForCallback = this.generateReturnObjectForCallback(treeNode);
            // this is the callback function for view button
            const result = this.properties.onViewClicked(returnObjForCallback);
            // calling check if parent is present function
            const parentTreeNodes = this.findParentOfTreeNode(this.properties.treeViewChildren, treeNode.id);
            // calling change all view for tree node function
            this.changeViewForAllChildTreeNode(treeNode, result);
            // calling mark tree node as partial view function
            this.changeViewForAllParentTreeNode(parentTreeNodes);
        }
    }
    onMouseHoverFunction(tree) {
        if (this.properties.alwaysShowActionButtons) {
            tree.showActionButtons = true;
        }
    }
    ngOnDestroy() {
        this.treeViewSubscription.unsubscribe();
        super.ngOnDestroy();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "18.2.8", type: ClTreeViewComponent, isStandalone: true, selector: "cl-tree-view", inputs: { properties: "properties" }, usesInheritance: true, ngImport: i0, template: "@if (properties.treeViewChildren && properties.treeViewChildren.length > 0) {\n  <div class=\"flex w-full flex-col rounded-md border border-solid border-primary-100\">\n    @for (tree of properties.treeViewChildren; track tree; let index = $index) {\n      <div class=\"{{tree.depth == 0 && tree.expanded ? 'bg-neutral-50' : ''}}\n        {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n        {{ index == properties.treeViewChildren.length - 1 ? 'rounded-bl-md rounded-br-md' : '' }}\">\n\n        <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n          (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 flex w-full items-center justify-between\n            {{ (tree.depth == 0 && tree.expanded) ? 'mb-4 bg-neutral-100' : '' }}\n            {{ (index &lt; properties.treeViewChildren.length - 1 && !tree.expanded) ? 'border-b border-solid border-primary-100' : '' }}\n            {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n            {{ (index == properties.treeViewChildren.length - 1 && !tree.expanded) ? 'rounded-bl-md rounded-br-md' : '' }}\n            {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\n            hover:border hover:border-solid hover:border-primary-300\">\n\n          <mat-label class=\"py-2 text-base font-bold leading-6 text-primary-700\">{{ tree.text }}</mat-label>\n\n          <div class=\"flex gap-3 items-center\">\n            <div class=\"flex gap-1 items-center\">\n              @for (chip of tree.chipsList; track chip) {\n                <cl-chip [properties]=\"chip\"></cl-chip>\n              }\n            </div>\n\n            @if (properties.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n              <div\n                [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : tree.expanded ? 'bg-white px-2 py-1 flex gap-2 rounded-md items-center' : 'bg-neutral-50 px-2 py-1 flex gap-2 rounded-md items-center'\">\n\n                @if (!tree.hideViewIcon && properties.viewOnIconProperties && properties.viewOffIconProperties && properties.partialViewIconProperties && properties.disableViewIconProperties) {\n                  <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                    [properties]=\"tree.partialView ? properties.partialViewIconProperties : tree.viewOn ? properties.viewOnIconProperties : tree.disableViewIcon ? properties.disableViewIconProperties! : properties.viewOffIconProperties\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideAddIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.addIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideEditIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.editIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideDeleteIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.deleteIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                  </cl-icon>\n                }\n              </div>\n            }\n\n            @if (properties.showActionIcon) {\n              <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n                (click)=\"$event.stopPropagation();\" [properties]=\"properties.actionIconProperties!\">\n              </cl-icon>\n\n              <mat-menu #actionPropertiesMenu=\"matMenu\">\n                @for (action of tree.actionList; track action; let actionIndex = $index) {\n                  <div class=\"\">\n                    <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                      [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                      (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                      {{ action.label }}\n                    </mat-checkbox>\n                  </div>\n                }\n              </mat-menu>\n            }\n\n            @if (tree.expanded && tree.children && tree.children.length > 0) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.upArrowIconProperties!\">\n              </cl-icon>\n            }\n\n            @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.downArrowIconProperties!\">\n              </cl-icon>\n            }\n          </div>\n        </div>\n\n        @if (tree.children && tree.children.length > 0 && tree.expanded) {\n          <div>\n            <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"properties\" (addClicked)=\"onAddClicked($event)\"\n              (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n              (deleteClicked)=\"onDeleteClicked($event)\"\n              (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n              (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n            </cl-child-tree-view>\n          </div>\n        }\n      </div>\n    }\n  </div>\n}\n", dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i1.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i1.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "directive", type: i3.MatLabel, selector: "mat-label" }, { kind: "component", type: ClIconComponent, selector: "cl-icon", inputs: ["properties"] }, { kind: "component", type: ClChipComponent, selector: "cl-chip", inputs: ["properties"] }, { kind: "component", type: ClChildTreeViewComponent, selector: "cl-child-tree-view", inputs: ["treeViewConfig", "properties"], outputs: ["addClicked", "editClicked", "viewClicked", "deleteClicked", "actionClicked", "treeNodeClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: ClTreeViewComponent, decorators: [{
            type: Component,
            args: [{ standalone: true, selector: 'cl-tree-view', imports: [
                        NgClass,
                        MatMenuModule,
                        MatCheckboxModule,
                        MatFormFieldModule,
                        ClIconComponent,
                        ClChipComponent,
                        ClChildTreeViewComponent
                    ], template: "@if (properties.treeViewChildren && properties.treeViewChildren.length > 0) {\n  <div class=\"flex w-full flex-col rounded-md border border-solid border-primary-100\">\n    @for (tree of properties.treeViewChildren; track tree; let index = $index) {\n      <div class=\"{{tree.depth == 0 && tree.expanded ? 'bg-neutral-50' : ''}}\n        {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n        {{ index == properties.treeViewChildren.length - 1 ? 'rounded-bl-md rounded-br-md' : '' }}\">\n\n        <div (click)=\"onTreeNodeClicked(tree)\" (mouseover)=\"onMouseHoverFunction(tree)\"\n          (mouseleave)=\"tree.showActionButtons = false\" class=\"px-4 py-2 flex w-full items-center justify-between\n            {{ (tree.depth == 0 && tree.expanded) ? 'mb-4 bg-neutral-100' : '' }}\n            {{ (index &lt; properties.treeViewChildren.length - 1 && !tree.expanded) ? 'border-b border-solid border-primary-100' : '' }}\n            {{ index == 0 ? 'rounded-tl-md rounded-tr-md' : '' }}\n            {{ (index == properties.treeViewChildren.length - 1 && !tree.expanded) ? 'rounded-bl-md rounded-br-md' : '' }}\n            {{ (tree.showArrowIcons || tree.children && tree.children.length > 0) ? 'cursor-pointer' : '' }}\n            hover:border hover:border-solid hover:border-primary-300\">\n\n          <mat-label class=\"py-2 text-base font-bold leading-6 text-primary-700\">{{ tree.text }}</mat-label>\n\n          <div class=\"flex gap-3 items-center\">\n            <div class=\"flex gap-1 items-center\">\n              @for (chip of tree.chipsList; track chip) {\n                <cl-chip [properties]=\"chip\"></cl-chip>\n              }\n            </div>\n\n            @if (properties.alwaysShowActionButtons || tree.showActionButtons || tree.expanded && !(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon)) {\n              <div\n                [ngClass]=\"(tree.hideViewIcon && tree.hideAddIcon && tree.hideEditIcon && tree.hideDeleteIcon) ? '' : tree.expanded ? 'bg-white px-2 py-1 flex gap-2 rounded-md items-center' : 'bg-neutral-50 px-2 py-1 flex gap-2 rounded-md items-center'\">\n\n                @if (!tree.hideViewIcon && properties.viewOnIconProperties && properties.viewOffIconProperties && properties.partialViewIconProperties && properties.disableViewIconProperties) {\n                  <cl-icon class=\"p-1 cursor-pointer\" (click)=\"$event.stopPropagation(); onViewClicked(tree)\"\n                    [properties]=\"tree.partialView ? properties.partialViewIconProperties : tree.viewOn ? properties.viewOnIconProperties : tree.disableViewIcon ? properties.disableViewIconProperties! : properties.viewOffIconProperties\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideAddIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.addIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onAddClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideEditIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.editIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onEditClicked(tree)\">\n                  </cl-icon>\n                }\n\n                @if (!tree.hideDeleteIcon) {\n                  <cl-icon class=\"p-1 cursor-pointer\" [properties]=\"properties.deleteIconProperties!\"\n                    (click)=\"$event.stopPropagation(); onDeleteClicked(tree)\">\n                  </cl-icon>\n                }\n              </div>\n            }\n\n            @if (properties.showActionIcon) {\n              <cl-icon class=\"py-2 cursor-pointer\" [matMenuTriggerFor]=\"actionPropertiesMenu\"\n                (click)=\"$event.stopPropagation();\" [properties]=\"properties.actionIconProperties!\">\n              </cl-icon>\n\n              <mat-menu #actionPropertiesMenu=\"matMenu\">\n                @for (action of tree.actionList; track action; let actionIndex = $index) {\n                  <div class=\"\">\n                    <mat-checkbox [checked]=\"action.checked\" [indeterminate]=\"action.indeterminate\"\n                      [disabled]=\"action.disabled\" [color]=\"action.indeterminate ? 'warn' : 'primary'\"\n                      (click)=\"$event.stopPropagation(); onActionIconClicked(tree, action.label, actionIndex)\">\n                      {{ action.label }}\n                    </mat-checkbox>\n                  </div>\n                }\n              </mat-menu>\n            }\n\n            @if (tree.expanded && tree.children && tree.children.length > 0) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.upArrowIconProperties!\">\n              </cl-icon>\n            }\n\n            @if (!tree.expanded && (tree.showArrowIcons || tree.children && tree.children.length > 0)) {\n              <cl-icon class=\"py-2\" [properties]=\"properties.downArrowIconProperties!\">\n              </cl-icon>\n            }\n          </div>\n        </div>\n\n        @if (tree.children && tree.children.length > 0 && tree.expanded) {\n          <div>\n            <cl-child-tree-view [properties]=\"tree.children\" [treeViewConfig]=\"properties\" (addClicked)=\"onAddClicked($event)\"\n              (editClicked)=\"onEditClicked($event)\" (viewClicked)=\"onViewClicked($event)\"\n              (deleteClicked)=\"onDeleteClicked($event)\"\n              (actionClicked)=\"onActionIconClicked($event.treeNode, $event.selectedAction, $event.index)\"\n              (treeNodeClicked)=\"onTreeNodeClicked($event)\">\n            </cl-child-tree-view>\n          </div>\n        }\n      </div>\n    }\n  </div>\n}\n" }]
        }], propDecorators: { properties: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJlZS12aWV3LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb21wbGV4L3NyYy90cmVlLXZpZXcvdHJlZS12aWV3LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2NsYXkvdWktY29tcG9uZW50cy9jb21wbGV4L3NyYy90cmVlLXZpZXcvdHJlZS12aWV3LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMxQyxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFFdkQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDL0QsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQVUsU0FBUyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ2pFLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBRWxFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLHFCQUFxQixDQUFDO0FBQ3hELE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDZDQUE2QyxDQUFDO0FBQ3ZGLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBRXhGLE9BQU8sRUFBRSxlQUFlLEVBQUUsZUFBZSxFQUFvQixNQUFNLDJCQUEyQixDQUFDOzs7OztBQW1CL0YsTUFBTSxPQUFPLG1CQUFvQixTQUFRLHdCQUF3QjtJQWpCakU7O1FBc0JtQixvQkFBZSxHQUFzQixNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUUvRCxzQkFBaUIsR0FBcUI7WUFDckQsRUFBRSxFQUFFLGlCQUFpQjtZQUNyQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixRQUFRLEVBQUUsK0JBQStCO1lBQ3pDLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSw4QkFBOEIsRUFBRTtTQUN0RCxDQUFDO1FBRWUsdUJBQWtCLEdBQXFCO1lBQ3RELEVBQUUsRUFBRSxrQkFBa0I7WUFDdEIsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsUUFBUSxFQUFFLHVCQUF1QjtZQUNqQyxLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsOEJBQThCLEVBQUU7U0FDdEQsQ0FBQztRQUVlLHlCQUFvQixHQUFxQjtZQUN4RCxFQUFFLEVBQUUsb0JBQW9CO1lBQ3hCLFFBQVEsRUFBRSxpQkFBaUI7WUFDM0IsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRTtTQUNyQyxDQUFDO1FBRUsseUJBQW9CLEdBQXFCO1lBQzlDLEVBQUUsRUFBRSxjQUFjO1lBQ2xCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLFFBQVEsRUFBRSwyQkFBMkI7WUFDckMsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRTtTQUNyQyxDQUFDO1FBRWUseUJBQW9CLEdBQXFCO1lBQ3hELEVBQUUsRUFBRSxpQkFBaUI7WUFDckIsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsUUFBUSxFQUFFLDJCQUEyQjtZQUNyQyxLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsYUFBYSxFQUFFO1NBQ3JDLENBQUM7UUFFZSwwQkFBcUIsR0FBcUI7WUFDekQsRUFBRSxFQUFFLGlCQUFpQjtZQUNyQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixRQUFRLEVBQUUsc0JBQXNCO1lBQ2hDLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxhQUFhLEVBQUU7U0FDckMsQ0FBQztRQUVlLDBCQUFxQixHQUFxQjtZQUN6RCxFQUFFLEVBQUUsZ0JBQWdCO1lBQ3BCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxhQUFhLEVBQUU7WUFDcEMsUUFBUSxFQUFFLG9DQUFvQztTQUMvQyxDQUFDO1FBRWUsNEJBQXVCLEdBQXFCO1lBQzNELEVBQUUsRUFBRSxrQkFBa0I7WUFDdEIsSUFBSSxFQUFFLGdCQUFnQixDQUFDLElBQUk7WUFDM0IsS0FBSyxFQUFFLEVBQUUsVUFBVSxFQUFFLGFBQWEsRUFBRTtZQUNwQyxRQUFRLEVBQUUsK0JBQStCO1NBQzFDLENBQUM7UUFFZSw4QkFBeUIsR0FBcUI7WUFDN0QsRUFBRSxFQUFFLGlCQUFpQjtZQUNyQixJQUFJLEVBQUUsZ0JBQWdCLENBQUMsSUFBSTtZQUMzQixLQUFLLEVBQUUsRUFBRSxVQUFVLEVBQUUsYUFBYSxFQUFFO1lBQ3BDLFFBQVEsRUFBRSw4QkFBOEI7U0FDekMsQ0FBQztRQUVlLDhCQUF5QixHQUFxQjtZQUM3RCxFQUFFLEVBQUUsaUJBQWlCO1lBQ3JCLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxJQUFJO1lBQzNCLEtBQUssRUFBRSxFQUFFLFVBQVUsRUFBRSxhQUFhLEVBQUU7WUFDcEMsUUFBUSxFQUFFLDhCQUE4QjtTQUN6QyxDQUFDO0tBaVdIO0lBL1ZVLFFBQVE7UUFDZiwwQ0FBMEM7UUFDMUMsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFFNUIsNkJBQTZCO1FBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBaUIsQ0FBQyxDQUFDO1FBRWpELGtEQUFrRDtRQUNsRCxJQUFJLENBQUMsMEJBQTBCLEVBQUUsQ0FBQztRQUVsQyxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbkIsQ0FBQztJQUVPLDBCQUEwQjtRQUNoQyxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQywwQkFBMEI7YUFDeEUsU0FBUyxDQUFDLENBQUMsZ0JBQTJDLEVBQUUsRUFBRTtZQUN6RCx3Q0FBd0M7WUFDeEMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLGdCQUFnQixDQUFDLENBQUM7WUFFMUMsNkJBQTZCO1lBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBaUIsQ0FBQyxDQUFDO1FBQ25ELENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVEOztPQUVHO0lBQ0ssb0JBQW9CO1FBQzFCLGlEQUFpRDtRQUNqRCxrREFBa0Q7UUFDbEQsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsS0FBSyxJQUFJLENBQUM7UUFFakQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsS0FBSyxJQUFJLENBQUMsaUJBQWlCLENBQUM7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUM7UUFDL0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsS0FBSyxJQUFJLENBQUMsb0JBQW9CLENBQUM7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsS0FBSyxJQUFJLENBQUMsb0JBQW9CLENBQUM7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsS0FBSyxJQUFJLENBQUMsb0JBQW9CLENBQUM7UUFDbkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsS0FBSyxJQUFJLENBQUMscUJBQXFCLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxxQkFBcUIsS0FBSyxJQUFJLENBQUMscUJBQXFCLENBQUM7UUFDckUsSUFBSSxDQUFDLFVBQVUsQ0FBQyx1QkFBdUIsS0FBSyxJQUFJLENBQUMsdUJBQXVCLENBQUM7UUFDekUsSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLENBQUMseUJBQXlCLENBQUM7UUFDN0UsSUFBSSxDQUFDLFVBQVUsQ0FBQyx5QkFBeUIsS0FBSyxJQUFJLENBQUMseUJBQXlCLENBQUM7SUFDL0UsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNLLFFBQVEsQ0FBQyxRQUFxQyxFQUFFLEtBQUssR0FBRyxDQUFDO1FBQy9ELFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxhQUF3QyxFQUFFLEVBQUU7WUFDNUQsYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7WUFDNUIsYUFBYSxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUM7WUFDL0IsYUFBYSxDQUFDLFdBQVcsS0FBSyxLQUFLLENBQUM7WUFDcEMsYUFBYSxDQUFDLGNBQWMsS0FBSyxLQUFLLENBQUM7WUFDdkMsYUFBYSxDQUFDLGlCQUFpQixLQUFLLEtBQUssQ0FBQztZQUUxQyxJQUFJLGFBQWEsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hFLDZCQUE2QjtnQkFDN0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNuRCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSSxrQkFBa0IsQ0FBQyxRQUFtQztRQUMzRCxJQUFJLFFBQVEsQ0FBQyxRQUFRLElBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDdEQsUUFBUSxDQUFDLFFBQVEsR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUM7WUFFdkMsOENBQThDO1lBQzlDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbEQsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksdUJBQXVCLENBQUMsUUFBc0M7UUFDbkUsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLFFBQW1DLEVBQUUsRUFBRTtZQUN4RCxRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztZQUUxQiw4Q0FBOEM7WUFDOUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7T0FRRztJQUNLLDZCQUE2QixDQUFDLFFBQW1DLEVBQUUsTUFBZTtRQUN4RixRQUFRLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUN6QixRQUFRLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztRQUU3QixRQUFRLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLGFBQXdDLEVBQUUsRUFBRTtZQUN0RSxpREFBaUQ7WUFDakQsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM1RCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7Ozs7Ozs7Ozs7T0FXRztJQUNLLG9CQUFvQixDQUFDLE9BQW9DLEVBQUUsTUFBVztRQUM1RSxLQUFLLE1BQU0sUUFBUSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQy9CLElBQUksUUFBUSxDQUFDLEVBQUUsS0FBSyxNQUFNLEVBQUUsQ0FBQztnQkFDM0IsT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDO2lCQUFNLElBQUksUUFBUSxDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUUsQ0FBQztnQkFDckMsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBRTdFLElBQUksZUFBZSxLQUFLLEtBQUssRUFBRSxDQUFDO29CQUM5QixtREFBbUQ7b0JBQ25ELG1FQUFtRTtvQkFFbkUsK0NBQStDO29CQUMvQyxlQUFlLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUUvQixPQUFPLGVBQWUsQ0FBQztnQkFDekIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBRUQsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRUQ7Ozs7Ozs7Ozs7O09BV0c7SUFDSyw4QkFBOEIsQ0FBQyxlQUE0QztRQUNqRixLQUFLLE1BQU0sYUFBYSxJQUFJLGVBQWUsRUFBRSxDQUFDO1lBQzVDLE1BQU0sNEJBQTRCLEdBQWMsRUFBRSxDQUFDO1lBRW5ELGFBQWEsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsZ0JBQTJDLEVBQUUsRUFBRTtnQkFDOUUsNEJBQTRCLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU8sQ0FBQyxDQUFDO1lBQzlELENBQUMsQ0FBQyxDQUFDO1lBRUgsNkdBQTZHO1lBQzdHLElBQUksNEJBQTRCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUN4RyxhQUFhLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQztnQkFDNUIsYUFBYSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7WUFDbkMsQ0FBQztZQUVELHlHQUF5RztZQUN6RyxJQUFJLDRCQUE0QixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDekcsYUFBYSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7Z0JBQzVCLGFBQWEsQ0FBQyxXQUFXLEdBQUcsS0FBSyxDQUFDO1lBQ3BDLENBQUM7WUFFRCx1R0FBdUc7WUFDdkcsSUFBSSw0QkFBNEIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksNEJBQTRCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ3pHLGFBQWEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO2dCQUM3QixhQUFhLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztZQUNwQyxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRDs7Ozs7T0FLRztJQUNJLGlCQUFpQixDQUFDLFFBQW1DO1FBQzFELElBQUksTUFBTSxHQUFZLElBQUksQ0FBQztRQUUzQixJQUFJLFFBQVEsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUM1QyxpREFBaUQ7WUFDakQsTUFBTSxHQUFHLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBRUQsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLHdDQUF3QztZQUN4QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFbEMsNkJBQTZCO1lBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxnQkFBaUIsQ0FBQyxDQUFDO1FBQ25ELENBQUM7SUFDSCxDQUFDO0lBRUQ7Ozs7OztPQU1HO0lBQ0ssK0JBQStCLENBQUMsUUFBbUM7UUFDekUsT0FBTztZQUNMLEVBQUUsRUFBRSxRQUFRLENBQUMsRUFBRTtZQUNmLElBQUksRUFBRSxRQUFRLENBQUMsSUFBSTtZQUNuQixJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUk7WUFDbkIsS0FBSyxFQUFFLFFBQVEsQ0FBQyxLQUFLO1lBQ3JCLE1BQU0sRUFBRSxRQUFRLENBQUMsTUFBTTtZQUN2QixRQUFRLEVBQUUsUUFBUSxDQUFDLFFBQVE7WUFDM0IsUUFBUSxFQUFFLFFBQVEsQ0FBQyxRQUFRO1lBQzNCLFFBQVEsRUFBRSxRQUFRLENBQUMsUUFBUTtZQUMzQixVQUFVLEVBQUUsUUFBUSxDQUFDLFVBQVU7WUFDL0IsU0FBUyxFQUFFLFFBQVEsQ0FBQyxTQUFTO1lBQzdCLFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVztZQUNqQyxpQkFBaUIsRUFBRSxRQUFRLENBQUMsaUJBQWlCO1NBQzlDLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNJLFlBQVksQ0FBQyxRQUFtQztRQUNyRCxJQUFJLFFBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM1QixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLElBQUksU0FBUyxFQUFFLENBQUM7WUFDOUMsd0RBQXdEO1lBQ3hELE1BQU0sb0JBQW9CLEdBQThCLElBQUksQ0FBQywrQkFBK0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUV2RywrQ0FBK0M7WUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNyRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxhQUFhLENBQUMsUUFBbUM7UUFDdEQsSUFBSSxRQUFRLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDN0IsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQy9DLHdEQUF3RDtZQUN4RCxNQUFNLG9CQUFvQixHQUE4QixJQUFJLENBQUMsK0JBQStCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFdkcsZ0RBQWdEO1lBQ2hELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDdEQsQ0FBQztJQUNILENBQUM7SUFFRDs7OztPQUlHO0lBQ0ksZUFBZSxDQUFDLFFBQW1DO1FBQ3hELElBQUksUUFBUSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDL0IsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2pELHdEQUF3RDtZQUN4RCxNQUFNLG9CQUFvQixHQUE4QixJQUFJLENBQUMsK0JBQStCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFdkcsa0RBQWtEO1lBQ2xELElBQUksQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDeEQsQ0FBQztJQUNILENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxRQUFtQyxFQUFFLGNBQXNCLEVBQUUsV0FBbUI7UUFDekcsSUFBSSxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUMvQixPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNyRCxnQ0FBZ0M7WUFDaEMsUUFBUSxDQUFDLFVBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsVUFBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQztZQUN2RixRQUFRLENBQUMsVUFBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUM7WUFFeEQsY0FBYztZQUNkLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFpQixFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUVsRyx3REFBd0Q7WUFDeEQsTUFBTSxvQkFBb0IsR0FBOEIsSUFBSSxDQUFDLCtCQUErQixDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBRXZHLGtEQUFrRDtZQUNsRCxJQUFJLENBQUMsVUFBVSxDQUFDLG1CQUFtQixDQUFDLG9CQUFvQixFQUFFLGNBQWMsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUM3RixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7O09BSUc7SUFDSSxhQUFhLENBQUMsUUFBbUM7UUFDdEQsSUFBSSxRQUFRLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDN0IsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQy9DLHdEQUF3RDtZQUN4RCxNQUFNLG9CQUFvQixHQUE4QixJQUFJLENBQUMsK0JBQStCLENBQUMsUUFBUSxDQUFDLENBQUM7WUFFdkcsZ0RBQWdEO1lBQ2hELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFFbkUsOENBQThDO1lBQzlDLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGdCQUFpQixFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUVsRyxpREFBaUQ7WUFDakQsSUFBSSxDQUFDLDZCQUE2QixDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUVyRCxrREFBa0Q7WUFDbEQsSUFBSSxDQUFDLDhCQUE4QixDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3ZELENBQUM7SUFDSCxDQUFDO0lBRUQsb0JBQW9CLENBQUMsSUFBK0I7UUFDbEQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLHVCQUF1QixFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQTtRQUMvQixDQUFDO0lBQ0gsQ0FBQztJQUVRLFdBQVc7UUFDbEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3hDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QixDQUFDOzhHQTNhVSxtQkFBbUI7a0dBQW5CLG1CQUFtQixxSUM5QmhDLDRtTEFtR0EsNENEakZJLE9BQU8sbUZBRVAsYUFBYSx5bUJBQ2IsaUJBQWlCLG9ZQUNqQixrQkFBa0IsZ0dBRWxCLGVBQWUsNEVBQ2YsZUFBZSw0RUFDZix3QkFBd0I7OzJGQUlmLG1CQUFtQjtrQkFqQi9CLFNBQVM7aUNBQ0ksSUFBSSxZQUNOLGNBQWMsV0FFZjt3QkFDUCxPQUFPO3dCQUVQLGFBQWE7d0JBQ2IsaUJBQWlCO3dCQUNqQixrQkFBa0I7d0JBRWxCLGVBQWU7d0JBQ2YsZUFBZTt3QkFDZix3QkFBd0I7cUJBQ3pCOzhCQUtlLFVBQVU7c0JBRHpCLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdDbGFzcyB9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7IE1hdE1lbnVNb2R1bGUgfSBmcm9tIFwiQGFuZ3VsYXIvbWF0ZXJpYWwvbWVudVwiO1xuaW1wb3J0IHsgU3Vic2NyaXB0aW9uIH0gZnJvbSBcInJ4anMvaW50ZXJuYWwvU3Vic2NyaXB0aW9uXCI7XG5pbXBvcnQgeyBNYXRDaGVja2JveE1vZHVsZSB9IGZyb20gXCJAYW5ndWxhci9tYXRlcmlhbC9jaGVja2JveFwiO1xuaW1wb3J0IHsgSW5wdXQsIGluamVjdCwgT25Jbml0LCBDb21wb25lbnQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xuaW1wb3J0IHsgTWF0Rm9ybUZpZWxkTW9kdWxlIH0gZnJvbSBcIkBhbmd1bGFyL21hdGVyaWFsL2Zvcm0tZmllbGRcIjtcblxuaW1wb3J0IHsgQ2xUcmVlVmlld1NlcnZpY2UgfSBmcm9tIFwiLi90cmVlLXZpZXcuc2VydmljZVwiO1xuaW1wb3J0IHsgQ2xDaGlsZFRyZWVWaWV3Q29tcG9uZW50IH0gZnJvbSBcIi4vY2hpbGQtdHJlZS12aWV3L2NoaWxkLXRyZWUtdmlldy5jb21wb25lbnRcIjtcbmltcG9ydCB7IENsQ29tcG9uZW50VHlwZXMsIENsQmFzZUNvbnRhaW5lckNvbXBvbmVudCB9IGZyb20gXCJAY2xheS91aS1jb21wb25lbnRzL3NoYXJlZFwiO1xuaW1wb3J0IHsgQ2xUcmVlVmlld1Byb3BlcnRpZXMsIENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMgfSBmcm9tIFwiLi90cmVlLXZpZXcucHJvcGVydGllc1wiO1xuaW1wb3J0IHsgQ2xJY29uQ29tcG9uZW50LCBDbENoaXBDb21wb25lbnQsIENsSWNvblByb3BlcnRpZXMgfSBmcm9tIFwiQGNsYXkvdWktY29tcG9uZW50cy9iYXNpY1wiO1xuXG5AQ29tcG9uZW50KHtcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc2VsZWN0b3I6ICdjbC10cmVlLXZpZXcnLFxuICB0ZW1wbGF0ZVVybDogJy4vdHJlZS12aWV3LmNvbXBvbmVudC5odG1sJyxcbiAgaW1wb3J0czogW1xuICAgIE5nQ2xhc3MsXG5cbiAgICBNYXRNZW51TW9kdWxlLFxuICAgIE1hdENoZWNrYm94TW9kdWxlLFxuICAgIE1hdEZvcm1GaWVsZE1vZHVsZSxcblxuICAgIENsSWNvbkNvbXBvbmVudCxcbiAgICBDbENoaXBDb21wb25lbnQsXG4gICAgQ2xDaGlsZFRyZWVWaWV3Q29tcG9uZW50XG4gIF1cbn0pXG5cbmV4cG9ydCBjbGFzcyBDbFRyZWVWaWV3Q29tcG9uZW50IGV4dGVuZHMgQ2xCYXNlQ29udGFpbmVyQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSlcbiAgcHVibGljIG92ZXJyaWRlIHByb3BlcnRpZXMhOiBDbFRyZWVWaWV3UHJvcGVydGllcztcblxuICBwcml2YXRlIHRyZWVWaWV3U3Vic2NyaXB0aW9uITogU3Vic2NyaXB0aW9uO1xuICBwcml2YXRlIHJlYWRvbmx5IHRyZWVWaWV3U2VydmljZTogQ2xUcmVlVmlld1NlcnZpY2UgPSBpbmplY3QoQ2xUcmVlVmlld1NlcnZpY2UpO1xuXG4gIHByaXZhdGUgcmVhZG9ubHkgYWRkSWNvblByb3BlcnRpZXM6IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICd0cmVlVmlld0ljb25BZGQnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBpY29uTmFtZTogJ2hlcm9pY29uc19vdXRsaW5lOnBsdXMtY2lyY2xlJyxcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTUgdGV4dC1wcmltYXJ5LTYwMCcgfSxcbiAgfTtcblxuICBwcml2YXRlIHJlYWRvbmx5IGVkaXRJY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ3RyZWVWaWV3SWNvbkVkaXQnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBpY29uTmFtZTogJ2Zzc19pY29uczplZGl0LWZpbGxlZCcsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS00IHRleHQtcHJpbWFyeS02MDAnIH0sXG4gIH07XG5cbiAgcHJpdmF0ZSByZWFkb25seSBkZWxldGVJY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ3RyZWVWaWV3SWNvbkRlbGV0ZScsXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6dHJhc2gnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTQnIH0sXG4gIH07XG5cbiAgcHVibGljIGFjdGlvbkljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAndHJlZVZpZXdJY29uJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmljb24sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6ZG90dGVkLWVsbGlwc2lzJyxcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTQnIH0sXG4gIH07XG5cbiAgcHJpdmF0ZSByZWFkb25seSB2aWV3T25JY29uUHJvcGVydGllczogQ2xJY29uUHJvcGVydGllcyA9IHtcbiAgICBpZDogJ3RyZWVWaWV3SWNvbkV5ZScsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIGljb25OYW1lOiAnZnNzX2ljb25zOmV5ZS1vcGVuLWZpbGxlZCcsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS01JyB9LFxuICB9O1xuXG4gIHByaXZhdGUgcmVhZG9ubHkgdmlld09mZkljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAndHJlZVZpZXdJY29uRXllJyxcbiAgICB0eXBlOiBDbENvbXBvbmVudFR5cGVzLmljb24sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6ZXllLWNsb3NlZCcsXG4gICAgc3R5bGU6IHsgY3NzQ2xhc3NlczogJ2ljb24tc2l6ZS01JyB9LFxuICB9O1xuXG4gIHByaXZhdGUgcmVhZG9ubHkgdXBBcnJvd0ljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAndHJlZVZpZXdJY29uVXAnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTUnIH0sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6Y2hldnJvbi1jaXJjbGUtdXAtZmlsbGVkJyxcbiAgfTtcblxuICBwcml2YXRlIHJlYWRvbmx5IGRvd25BcnJvd0ljb25Qcm9wZXJ0aWVzOiBDbEljb25Qcm9wZXJ0aWVzID0ge1xuICAgIGlkOiAndHJlZVZpZXdJY29uRG93bicsXG4gICAgdHlwZTogQ2xDb21wb25lbnRUeXBlcy5pY29uLFxuICAgIHN0eWxlOiB7IGNzc0NsYXNzZXM6ICdpY29uLXNpemUtNScgfSxcbiAgICBpY29uTmFtZTogJ2Zzc19pY29uczpjaGV2cm9uLWNpcmNsZS1kb3duJyxcbiAgfTtcblxuICBwcml2YXRlIHJlYWRvbmx5IHBhcnRpYWxWaWV3SWNvblByb3BlcnRpZXM6IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICd0cmVlVmlld0ljb25FeWUnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTUnIH0sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6cGFydGlhbC1leWUtZmlsbGVkJyxcbiAgfTtcblxuICBwcml2YXRlIHJlYWRvbmx5IGRpc2FibGVWaWV3SWNvblByb3BlcnRpZXM6IENsSWNvblByb3BlcnRpZXMgPSB7XG4gICAgaWQ6ICd0cmVlVmlld0ljb25FeWUnLFxuICAgIHR5cGU6IENsQ29tcG9uZW50VHlwZXMuaWNvbixcbiAgICBzdHlsZTogeyBjc3NDbGFzc2VzOiAnaWNvbi1zaXplLTUnIH0sXG4gICAgaWNvbk5hbWU6ICdmc3NfaWNvbnM6ZGlzYWJsZS1leWUtZmlsbGVkJyxcbiAgfTtcblxuICBvdmVycmlkZSBuZ09uSW5pdCgpOiB2b2lkIHtcbiAgICAvLyBjYWxsaW5nIHNldCBkZWZhdWx0IHByb3BlcnRpZXMgZnVuY3Rpb25cbiAgICB0aGlzLnNldERlZmF1bHRQcm9wZXJ0aWVzKCk7XG5cbiAgICAvLyBjYWxsaW5nIGFkZCBkZXB0aCBmdW5jdGlvblxuICAgIHRoaXMuYWRkRGVwdGgodGhpcy5wcm9wZXJ0aWVzLnRyZWVWaWV3Q2hpbGRyZW4hKTtcblxuICAgIC8vIGNhbGxpbmcgc3Vic2NyaWJlIHRvIHRyZWUgdmlldyBzZXJ2aWNlIGZ1bmN0aW9uXG4gICAgdGhpcy5zdWJzY3JpYmVUb1RyZWVWaWV3U2VydmljZSgpO1xuXG4gICAgc3VwZXIubmdPbkluaXQoKTtcbiAgfVxuXG4gIHByaXZhdGUgc3Vic2NyaWJlVG9UcmVlVmlld1NlcnZpY2UoKSB7XG4gICAgdGhpcy50cmVlVmlld1N1YnNjcmlwdGlvbiA9IHRoaXMudHJlZVZpZXdTZXJ2aWNlLnRyZWVOb2RlVG9FeHBhbmRlZENvbGxhcHNlXG4gICAgICAuc3Vic2NyaWJlKChzZWxlY3RlZFRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSA9PiB7XG4gICAgICAgIC8vIGNhbGxpbmcgZXhwYW5kIGNvbGxhcHNlIHRyZWUgZnVuY3Rpb25cbiAgICAgICAgdGhpcy5leHBhbmRDb2xsYXBzZVRyZWUoc2VsZWN0ZWRUcmVlTm9kZSk7XG5cbiAgICAgICAgLy8gY2FsbGluZyBhZGQgZGVwdGggZnVuY3Rpb25cbiAgICAgICAgdGhpcy5hZGREZXB0aCh0aGlzLnByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbiEpO1xuICAgICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIHNldCB0aGUgZGVmYXVsdCB2YWx1ZXMgdG8gdGhlIHByb3BlcnR5IG9mIHRoZSB0cmVlIHZpZXdcbiAgICovXG4gIHByaXZhdGUgc2V0RGVmYXVsdFByb3BlcnRpZXMoKSB7XG4gICAgLy8gdGhpcyBwcm9wZXJ0eSBpcyB1c2VkIHRvIGFsd2F5cyBzaG93IHRoZSBpY29uc1xuICAgIC8vIGFuZCBoYXMgaGlnaGVyIHByZWNlZGVuY2Ugb3ZlciBvdGhlciBwcm9wZXJ0aWVzXG4gICAgdGhpcy5wcm9wZXJ0aWVzLmFsd2F5c1Nob3dBY3Rpb25CdXR0b25zID8/PSB0cnVlO1xuXG4gICAgdGhpcy5wcm9wZXJ0aWVzLmFkZEljb25Qcm9wZXJ0aWVzID8/PSB0aGlzLmFkZEljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy5lZGl0SWNvblByb3BlcnRpZXMgPz89IHRoaXMuZWRpdEljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy5kZWxldGVJY29uUHJvcGVydGllcyA/Pz0gdGhpcy5kZWxldGVJY29uUHJvcGVydGllcztcbiAgICB0aGlzLnByb3BlcnRpZXMuYWN0aW9uSWNvblByb3BlcnRpZXMgPz89IHRoaXMuYWN0aW9uSWNvblByb3BlcnRpZXM7XG4gICAgdGhpcy5wcm9wZXJ0aWVzLnZpZXdPbkljb25Qcm9wZXJ0aWVzID8/PSB0aGlzLnZpZXdPbkljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy52aWV3T2ZmSWNvblByb3BlcnRpZXMgPz89IHRoaXMudmlld09mZkljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy51cEFycm93SWNvblByb3BlcnRpZXMgPz89IHRoaXMudXBBcnJvd0ljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy5kb3duQXJyb3dJY29uUHJvcGVydGllcyA/Pz0gdGhpcy5kb3duQXJyb3dJY29uUHJvcGVydGllcztcbiAgICB0aGlzLnByb3BlcnRpZXMucGFydGlhbFZpZXdJY29uUHJvcGVydGllcyA/Pz0gdGhpcy5wYXJ0aWFsVmlld0ljb25Qcm9wZXJ0aWVzO1xuICAgIHRoaXMucHJvcGVydGllcy5kaXNhYmxlVmlld0ljb25Qcm9wZXJ0aWVzID8/PSB0aGlzLmRpc2FibGVWaWV3SWNvblByb3BlcnRpZXM7XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiBpcyB1c2VkIHRvIGFkZCBkZXB0aCB0byB0aGUgdHJlZSB2aWV3IGZvciBtYW5hZ2luZyB0aGUgd2lkdGggb2YgdGhlIGNoaWxkcmVuXG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIGFycmF5IG9mIG9iamVjdHNcbiAgICpcbiAgICogQHBhcmFtIGRlcHRoIC0gZGVwdGggb2YgdGhlIHRyZWUgbm9kZVxuICAgKi9cbiAgcHJpdmF0ZSBhZGREZXB0aCh0cmVlTm9kZTogQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllc1tdLCBkZXB0aCA9IDApIHtcbiAgICB0cmVlTm9kZS5mb3JFYWNoKChjaGlsZFRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSA9PiB7XG4gICAgICBjaGlsZFRyZWVOb2RlLmRlcHRoID0gZGVwdGg7XG4gICAgICBjaGlsZFRyZWVOb2RlLnZpZXdPbiA/Pz0gZmFsc2U7XG4gICAgICBjaGlsZFRyZWVOb2RlLnBhcnRpYWxWaWV3ID8/PSBmYWxzZTtcbiAgICAgIGNoaWxkVHJlZU5vZGUuc2hvd0Fycm93SWNvbnMgPz89IGZhbHNlO1xuICAgICAgY2hpbGRUcmVlTm9kZS5zaG93QWN0aW9uQnV0dG9ucyA/Pz0gZmFsc2U7XG5cbiAgICAgIGlmIChjaGlsZFRyZWVOb2RlLmNoaWxkcmVuICYmIGNoaWxkVHJlZU5vZGUuY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgICAvLyBjYWxsaW5nIGFkZCBkZXB0aCBmdW5jdGlvblxuICAgICAgICB0aGlzLmFkZERlcHRoKGNoaWxkVHJlZU5vZGUuY2hpbGRyZW4sIGRlcHRoICsgMSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIGV4cGFuZCBvciBjb2xsYXBzZSB0aGUgdHJlZSB2aWV3XG4gICAqIHRoaXMgZnVuY3Rpb24gd2lsbCBhbHNvIGNhbGwgYW5vdGhlciBmdW5jdGlvbiB0byBjb2xsYXBzZSB0aGUgdHJlZSBub2RlcyBjaGlsZHJlblxuICAgKlxuICAgKiBAcGFyYW0gdHJlZU5vZGUgLSB0cmVlIG5vZGUgd2hpY2ggbmVlZHMgdG8gYmUgZXhwYW5kZWQgb3IgY29sbGFwc2VkXG4gICAqL1xuICBwdWJsaWMgZXhwYW5kQ29sbGFwc2VUcmVlKHRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSB7XG4gICAgaWYgKHRyZWVOb2RlLmNoaWxkcmVuICYmIHRyZWVOb2RlLmNoaWxkcmVuLmxlbmd0aCA+IDApIHtcbiAgICAgIHRyZWVOb2RlLmV4cGFuZGVkID0gIXRyZWVOb2RlLmV4cGFuZGVkO1xuXG4gICAgICAvLyBjYWxsaW5nIGV4cGFuZCBjb2xsYXBzZSBjaGlsZCB0cmVlIGZ1bmN0aW9uXG4gICAgICB0aGlzLmV4cGFuZENvbGxhcHNlQ2hpbGRUcmVlKHRyZWVOb2RlLmNoaWxkcmVuKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIGV4cGFuZCBvciBjb2xsYXBzZSB0aGUgY2hpbGQgdHJlZSBvZiBhIHRyZWUgbm9kZVxuICAgKlxuICAgKiBAcGFyYW0gdHJlZU5vZGUgLSB0cmVlIG5vZGUgY2hpbGRyZW4gd2hpY2ggbmVlZHMgdG8gYmUgY29sbGFwc2VkXG4gICAqL1xuICBwdWJsaWMgZXhwYW5kQ29sbGFwc2VDaGlsZFRyZWUodHJlZU5vZGU/OiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzW10pIHtcbiAgICB0cmVlTm9kZT8uZm9yRWFjaCgodHJlZU5vZGU6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMpID0+IHtcbiAgICAgIHRyZWVOb2RlLmV4cGFuZGVkID0gZmFsc2U7XG5cbiAgICAgIC8vIGNhbGxpbmcgZXhwYW5kIGNvbGxhcHNlIGNoaWxkIHRyZWUgZnVuY3Rpb25cbiAgICAgIHRoaXMuZXhwYW5kQ29sbGFwc2VDaGlsZFRyZWUodHJlZU5vZGUuY2hpbGRyZW4pO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIHRoaXMgZnVuY3Rpb24gd2lsbCBjaGFuZ2UgYWxsIHRoZSB0cmVlIG5vZGUncyB2aWV3T24gcHJvcGVydHkgdG8gdHJ1ZSBvciBmYWxzZSBiYXNlZCBvbiB0aGUgcmVzdWx0XG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIHRyZWUgbm9kZSBvZiB0aGUgdHJlZSB2aWV3XG4gICAqXG4gICAqIEBwYXJhbSByZXN1bHQgLSByZXN1bHQgaXMgYmFzZWQgb24gdmlldyBvbiBvciBvZmZcbiAgICogICAgICAgICAgICAgICAgIHJlc3VsdCBzaG91bGQgYmUgdHJ1ZSB0byBzaG93IHZpZXcgb25cbiAgICogICAgICAgICAgICAgICAgIHJlc3VsdCBzaG91bGQgYmUgdHJ1ZSB0byBzaG93IHZpZXcgb2ZmXG4gICAqL1xuICBwcml2YXRlIGNoYW5nZVZpZXdGb3JBbGxDaGlsZFRyZWVOb2RlKHRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzLCByZXN1bHQ6IGJvb2xlYW4pIHtcbiAgICB0cmVlTm9kZS52aWV3T24gPSByZXN1bHQ7XG4gICAgdHJlZU5vZGUucGFydGlhbFZpZXcgPSBmYWxzZTtcblxuICAgIHRyZWVOb2RlLmNoaWxkcmVuPy5mb3JFYWNoKChjaGlsZFRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSA9PiB7XG4gICAgICAvLyBjYWxsaW5nIGNoYW5nZSBhbGwgdmlldyBmb3IgdHJlZSBub2RlIGZ1bmN0aW9uXG4gICAgICB0aGlzLmNoYW5nZVZpZXdGb3JBbGxDaGlsZFRyZWVOb2RlKGNoaWxkVHJlZU5vZGUsIHJlc3VsdCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIGZpbmQgdGhlIHBhcmVudCBhbmQgZ3JhbmQgcGFyZW50IGFuZCBzbyBvbiBmb3IgdGhlIHRyZWUgbm9kZVxuICAgKiBvbiB3aGljaCB2aWV3IGJ1dHRvbi9pY29uIHdhcyBjbGlja2VkXG4gICAqXG4gICAqIEBwYXJhbSB0cmVlQXJyIC0gYXJyYXkgb2YgdHJlZSBub2Rlc1xuICAgKlxuICAgKiBAcGFyYW0gdHJlZUlkIC0gdGhlIGlkIG9mIHRoZSB0cmVlIG5vZGUgd2hlcmUgdmlldyBidXR0b24vaWNvbiB3YXMgY2xpY2tlZFxuICAgKlxuICAgKiBAcmV0dXJucyAtIGVpdGhlciByZXR1cm4gZW1wdHkgYXJyYXkgaWYgcGFyZW50IGlzIGNsaWNrZWRcbiAgICogICAgICAgICAgLSBvciByZXR1cm5zIGZhbHNlIGlmIGlkIG5vdCBmb3VuZFxuICAgKiAgICAgICAgICAtIG9yIHJldHVybnMgYXJyYXkgb2YgcGFyZW50IGFuZCBncmFuZCBwYXJlbnQgYW5kIHNvIG9uXG4gICAqL1xuICBwcml2YXRlIGZpbmRQYXJlbnRPZlRyZWVOb2RlKHRyZWVBcnI6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXNbXSwgdHJlZUlkOiBhbnkpOiBhbnkge1xuICAgIGZvciAoY29uc3QgdHJlZU5vZGUgb2YgdHJlZUFycikge1xuICAgICAgaWYgKHRyZWVOb2RlLmlkID09PSB0cmVlSWQpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgfSBlbHNlIGlmICh0cmVlTm9kZS5jaGlsZHJlbj8ubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IHBhcmVudFRyZWVOb2RlcyA9IHRoaXMuZmluZFBhcmVudE9mVHJlZU5vZGUodHJlZU5vZGUuY2hpbGRyZW4sIHRyZWVJZCk7XG5cbiAgICAgICAgaWYgKHBhcmVudFRyZWVOb2RlcyAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAvLyB0aGlzIHdpbGwgb25seSBhZGQgaW1tZWRpYXRlIHBhcmVudCBvZiB0cmVlIG5vZGVcbiAgICAgICAgICAvLyBpZiAocGFyZW50VHJlZU5vZGVzLmxlbmd0aCA9PSAwKSBwYXJlbnRUcmVlTm9kZXMucHVzaCh0cmVlTm9kZSk7XG5cbiAgICAgICAgICAvLyB0aGlzIHdpbGwgYWRkIHBhcmVudCBhbmQgcGFyZW50IG9mIHRyZWUgbm9kZVxuICAgICAgICAgIHBhcmVudFRyZWVOb2Rlcy5wdXNoKHRyZWVOb2RlKTtcblxuICAgICAgICAgIHJldHVybiBwYXJlbnRUcmVlTm9kZXM7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiB3aWxsIGNoYW5nZSB0aGUgdmlldyBvZiBwYXJlbnQgYW5kIGdyYW5kIHBhcmVudHMgYW5kIHNvIG9uXG4gICAqIGJhc2VkIG9uIHRoZSBjb21iaW5hdGlvbiBvZiBpdCdzIGNoaWxkJ3MgdmlldyBzdGF0dXNcbiAgICpcbiAgICogaW4gdGhpcyBmdW5jdGlvbiB3ZSB3aWxsIGNoZWNrIHRoZSB2aWV3IHBlcm1pc3Npb24gb2YgYWxsIHRoZSBjaGlsZCBub2RlcyBvZiBlYWNoIHBhcmVudFxuICAgKiBpZiBhbGwgdGhlIGNoaWxkIG5vZGVzIHZpZXcgcGVybWlzc2lvbiBpcyB0cnVlIHRoZW4gcGFyZW50J3MgdmlldyBwZXJtaXNzaW9uIHdpbGwgYWxzbyBiZSB0cnVlXG4gICAqIGlmIGFsbCB0aGUgY2hpbGQgbm9kZXMgdmlldyBwZXJtaXNzaW9uIGlzIGZhbHNlIHRoZW4gcGFyZW50J3MgdmlldyBwZXJtaXNzaW9uIHdpbGwgYWxzbyBiZSBmYWxzZVxuICAgKiBpZiBhbnkgb2YgdGhlIGNoaWxkJ3MgdmlldyBwZXJtaXNzaW9uIGlzIGZhbHNlIGFuZCByZXN0IG9mIHRoZSBjaGlsZCdzIHZpZXcgcGVybWlzc2lvbiBpcyB0cnVlXG4gICAqIHRoZW4gdGhlIHBhcmVudCB3aWxsIGhhdmUgcGFydGlhbCB2aWV3IHBlcm1pc3Npb25cbiAgICpcbiAgICogQHBhcmFtIHBhcmVudFRyZWVOb2RlcyAtIGFycmF5IG9mIHRyZWUgbm9kZXMgdG8gY2hhbmdlIHRoZSB2aWV3XG4gICAqL1xuICBwcml2YXRlIGNoYW5nZVZpZXdGb3JBbGxQYXJlbnRUcmVlTm9kZShwYXJlbnRUcmVlTm9kZXM6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXNbXSkge1xuICAgIGZvciAoY29uc3QgY2hpbGRUcmVlTm9kZSBvZiBwYXJlbnRUcmVlTm9kZXMpIHtcbiAgICAgIGNvbnN0IGNoaWxkVHJlZU5vZGVzVmlld1Blcm1pc3Npb246IGJvb2xlYW5bXSA9IFtdO1xuXG4gICAgICBjaGlsZFRyZWVOb2RlLmNoaWxkcmVuPy5mb3JFYWNoKChzdWJDaGlsZFRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSA9PiB7XG4gICAgICAgIGNoaWxkVHJlZU5vZGVzVmlld1Blcm1pc3Npb24ucHVzaChzdWJDaGlsZFRyZWVOb2RlLnZpZXdPbiEpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIGhlcmUgd2UgYXJlIGNoZWNraW5nIGlmIHRoZSB0cmVlIG5vZGUgaGFzIGNvbWJpbmF0aW9uIG9mIHRydWUgYW5kIGZhbHNlIHRvIGNvbnNpZGVyIHBhcmVudCBhcyBwYXJ0aWFsIHZpZXdcbiAgICAgIGlmIChjaGlsZFRyZWVOb2Rlc1ZpZXdQZXJtaXNzaW9uLmluZGV4T2YodHJ1ZSkgPiAtMSAmJiBjaGlsZFRyZWVOb2Rlc1ZpZXdQZXJtaXNzaW9uLmluZGV4T2YoZmFsc2UpID4gLTEpIHtcbiAgICAgICAgY2hpbGRUcmVlTm9kZS52aWV3T24gPSB0cnVlO1xuICAgICAgICBjaGlsZFRyZWVOb2RlLnBhcnRpYWxWaWV3ID0gdHJ1ZTtcbiAgICAgIH1cblxuICAgICAgLy8gaGVyZSB3ZSBhcmUgY2hlY2tpbmcgaWYgdGhlIHRyZWUgbm9kZSBoYXMgdHJ1ZSBhbmQgZG9lcyBub3QgaGF2ZSBmYWxzZSB0byBjb25zaWRlciBwYXJlbnQgYXMgZnVsbCB2aWV3XG4gICAgICBpZiAoY2hpbGRUcmVlTm9kZXNWaWV3UGVybWlzc2lvbi5pbmRleE9mKHRydWUpID4gLTEgJiYgY2hpbGRUcmVlTm9kZXNWaWV3UGVybWlzc2lvbi5pbmRleE9mKGZhbHNlKSA9PSAtMSkge1xuICAgICAgICBjaGlsZFRyZWVOb2RlLnZpZXdPbiA9IHRydWU7XG4gICAgICAgIGNoaWxkVHJlZU5vZGUucGFydGlhbFZpZXcgPSBmYWxzZTtcbiAgICAgIH1cblxuICAgICAgLy8gaGVyZSB3ZSBhcmUgY2hlY2tpbmcgaWYgdGhlIHRyZWUgbm9kZSBoYXMgZmFsc2UgYW5kIGRvZXMgbm90IGhhdmUgdHJ1ZSB0byBjb25zaWRlciBwYXJlbnQgYXMgbm8gdmlld1xuICAgICAgaWYgKGNoaWxkVHJlZU5vZGVzVmlld1Blcm1pc3Npb24uaW5kZXhPZih0cnVlKSA9PSAtMSAmJiBjaGlsZFRyZWVOb2Rlc1ZpZXdQZXJtaXNzaW9uLmluZGV4T2YoZmFsc2UpID4gLTEpIHtcbiAgICAgICAgY2hpbGRUcmVlTm9kZS52aWV3T24gPSBmYWxzZTtcbiAgICAgICAgY2hpbGRUcmVlTm9kZS5wYXJ0aWFsVmlldyA9IGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgYmUgdHJpZ2dlcmVkIHdoZW4gdGhlIHRyZWUgbm9kZSB3YXMgY2xpY2tlZFxuICAgKiB0aGlzIGZ1bmN0aW9uIGFsc28gY2FsbHMgZXhwYW5kIGNvbGxhcHNlIHRyZWUgZnVuY3Rpb25cbiAgICpcbiAgICogQHBhcmFtIHRyZWVOb2RlIC0gdHJlZSBub2RlIHdoZXJlIGNsaWNrZWQgYW5kIG5lZWRzIHRvIGJlIGV4cGFuZGVkIG9yIGNvbGxhcHNlZFxuICAgKi9cbiAgcHVibGljIG9uVHJlZU5vZGVDbGlja2VkKHRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSB7XG4gICAgbGV0IHJlc3VsdDogYm9vbGVhbiA9IHRydWU7XG5cbiAgICBpZiAodHJlZU5vZGUub25UcmVlTm9kZUNsaWNrZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBjYWxsaW5nIG9uIHRyZWUgbm9kZSBjbGlja2VkIGNhbGxiYWNrIGZ1bmN0aW9uXG4gICAgICByZXN1bHQgPSB0cmVlTm9kZS5vblRyZWVOb2RlQ2xpY2tlZCh0cmVlTm9kZSk7XG4gICAgfVxuXG4gICAgaWYgKHJlc3VsdCkge1xuICAgICAgLy8gY2FsbGluZyBleHBhbmQgY29sbGFwc2UgdHJlZSBmdW5jdGlvblxuICAgICAgdGhpcy5leHBhbmRDb2xsYXBzZVRyZWUodHJlZU5vZGUpO1xuXG4gICAgICAvLyBjYWxsaW5nIGFkZCBkZXB0aCBmdW5jdGlvblxuICAgICAgdGhpcy5hZGREZXB0aCh0aGlzLnByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbiEpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIHdpbGwgZ2VuZXJhdGUgdGhlIG9iamVjdCBmb3Igc2VuZGluZyBpdCB0byB0aGUgY2xpZW50XG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIHNlbGVjdGVkIHRyZWUgbm9kZVxuICAgKlxuICAgKiBAcmV0dXJucyAtIGdlbmVyYXRlZCB0cmVlIG5vZGUgb2JqZWN0XG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlUmV0dXJuT2JqZWN0Rm9yQ2FsbGJhY2sodHJlZU5vZGU6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMpOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzIHtcbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IHRyZWVOb2RlLmlkLFxuICAgICAgZGF0YTogdHJlZU5vZGUuZGF0YSxcbiAgICAgIHRleHQ6IHRyZWVOb2RlLnRleHQsXG4gICAgICBkZXB0aDogdHJlZU5vZGUuZGVwdGgsXG4gICAgICB2aWV3T246IHRyZWVOb2RlLnZpZXdPbixcbiAgICAgIGV4cGFuZGVkOiB0cmVlTm9kZS5leHBhbmRlZCxcbiAgICAgIHBhcmVudElkOiB0cmVlTm9kZS5wYXJlbnRJZCxcbiAgICAgIGNoaWxkcmVuOiB0cmVlTm9kZS5jaGlsZHJlbixcbiAgICAgIGFjdGlvbkxpc3Q6IHRyZWVOb2RlLmFjdGlvbkxpc3QsXG4gICAgICBjaGlwc0xpc3Q6IHRyZWVOb2RlLmNoaXBzTGlzdCxcbiAgICAgIHBhcnRpYWxWaWV3OiB0cmVlTm9kZS5wYXJ0aWFsVmlldyxcbiAgICAgIHNob3dBY3Rpb25CdXR0b25zOiB0cmVlTm9kZS5zaG93QWN0aW9uQnV0dG9ucyxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIHRoaXMgZnVuY3Rpb24gaXMgdGhlIGNhbGwgYmFjayBmdW5jdGlvbiBmb3IgYWRkIGJ1dHRvblxuICAgKlxuICAgKiBAcGFyYW0gdHJlZU5vZGUgLSB0cmVlIG5vZGUgd2hlcmUgY2xpY2tlZFxuICAgKi9cbiAgcHVibGljIG9uQWRkQ2xpY2tlZCh0cmVlTm9kZTogQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllcykge1xuICAgIGlmICh0cmVlTm9kZS5kaXNhYmxlQWRkSWNvbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnByb3BlcnRpZXMub25BZGRDbGlja2VkICE9IHVuZGVmaW5lZCkge1xuICAgICAgLy8gY2FsbGluZyBnZW5lcmF0ZSByZXR1cm4gb2JqZWN0IGZvciBjYWxsIGJhY2sgZnVuY3Rpb25cbiAgICAgIGNvbnN0IHJldHVybk9iakZvckNhbGxiYWNrOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzID0gdGhpcy5nZW5lcmF0ZVJldHVybk9iamVjdEZvckNhbGxiYWNrKHRyZWVOb2RlKTtcblxuICAgICAgLy8gdGhpcyBpcyB0aGUgY2FsbGJhY2sgZnVuY3Rpb24gZm9yIGFkZCBidXR0b25cbiAgICAgIHRoaXMucHJvcGVydGllcy5vbkFkZENsaWNrZWQocmV0dXJuT2JqRm9yQ2FsbGJhY2spO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiB0aGlzIGZ1bmN0aW9uIGlzIHRoZSBjYWxsIGJhY2sgZnVuY3Rpb24gZm9yIGVkaXQgYnV0dG9uXG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIHRyZWUgbm9kZSB3aGVyZSBjbGlja2VkXG4gICAqL1xuICBwdWJsaWMgb25FZGl0Q2xpY2tlZCh0cmVlTm9kZTogQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllcykge1xuICAgIGlmICh0cmVlTm9kZS5kaXNhYmxlRWRpdEljb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uRWRpdENsaWNrZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBjYWxsaW5nIGdlbmVyYXRlIHJldHVybiBvYmplY3QgZm9yIGNhbGwgYmFjayBmdW5jdGlvblxuICAgICAgY29uc3QgcmV0dXJuT2JqRm9yQ2FsbGJhY2s6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMgPSB0aGlzLmdlbmVyYXRlUmV0dXJuT2JqZWN0Rm9yQ2FsbGJhY2sodHJlZU5vZGUpO1xuXG4gICAgICAvLyB0aGlzIGlzIHRoZSBjYWxsYmFjayBmdW5jdGlvbiBmb3IgZWRpdCBidXR0b25cbiAgICAgIHRoaXMucHJvcGVydGllcy5vbkVkaXRDbGlja2VkKHJldHVybk9iakZvckNhbGxiYWNrKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiBpcyB0aGUgY2FsbCBiYWNrIGZ1bmN0aW9uIGZvciBkZWxldGUgYnV0dG9uXG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIHRyZWUgbm9kZSB3aGVyZSBjbGlja2VkXG4gICAqL1xuICBwdWJsaWMgb25EZWxldGVDbGlja2VkKHRyZWVOb2RlOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzKSB7XG4gICAgaWYgKHRyZWVOb2RlLmRpc2FibGVEZWxldGVJY29uKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHRoaXMucHJvcGVydGllcy5vbkRlbGV0ZUNsaWNrZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBjYWxsaW5nIGdlbmVyYXRlIHJldHVybiBvYmplY3QgZm9yIGNhbGwgYmFjayBmdW5jdGlvblxuICAgICAgY29uc3QgcmV0dXJuT2JqRm9yQ2FsbGJhY2s6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMgPSB0aGlzLmdlbmVyYXRlUmV0dXJuT2JqZWN0Rm9yQ2FsbGJhY2sodHJlZU5vZGUpO1xuXG4gICAgICAvLyB0aGlzIGlzIHRoZSBjYWxsYmFjayBmdW5jdGlvbiBmb3IgZGVsZXRlIGJ1dHRvblxuICAgICAgdGhpcy5wcm9wZXJ0aWVzLm9uRGVsZXRlQ2xpY2tlZChyZXR1cm5PYmpGb3JDYWxsYmFjayk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uQWN0aW9uSWNvbkNsaWNrZWQodHJlZU5vZGU6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMsIHNlbGVjdGVkQWN0aW9uOiBzdHJpbmcsIGFjdGlvbkluZGV4OiBudW1iZXIpIHtcbiAgICBpZiAodHJlZU5vZGUuZGlzYWJsZUFjdGlvbkljb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uQWN0aW9uSWNvbkNsaWNrZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyB0b2dnbGluZyBjaGVja2JveCBvZiB0cmVlTm9kZVxuICAgICAgdHJlZU5vZGUuYWN0aW9uTGlzdCFbYWN0aW9uSW5kZXhdLmNoZWNrZWQgPSAhdHJlZU5vZGUuYWN0aW9uTGlzdCFbYWN0aW9uSW5kZXhdLmNoZWNrZWQ7XG4gICAgICB0cmVlTm9kZS5hY3Rpb25MaXN0IVthY3Rpb25JbmRleF0uaW5kZXRlcm1pbmF0ZSA9IGZhbHNlO1xuXG4gICAgICAvLyBGaW5kIHBhcmVudFxuICAgICAgY29uc3QgcGFyZW50VHJlZU5vZGVzID0gdGhpcy5maW5kUGFyZW50T2ZUcmVlTm9kZSh0aGlzLnByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbiEsIHRyZWVOb2RlLmlkKTtcblxuICAgICAgLy8gY2FsbGluZyBnZW5lcmF0ZSByZXR1cm4gb2JqZWN0IGZvciBjYWxsIGJhY2sgZnVuY3Rpb25cbiAgICAgIGNvbnN0IHJldHVybk9iakZvckNhbGxiYWNrOiBDbFRyZWVWaWV3Q2hpbGRQcm9wZXJ0aWVzID0gdGhpcy5nZW5lcmF0ZVJldHVybk9iamVjdEZvckNhbGxiYWNrKHRyZWVOb2RlKTtcblxuICAgICAgLy8gdGhpcyBpcyB0aGUgY2FsbGJhY2sgZnVuY3Rpb24gZm9yIGFjdGlvbiBidXR0b25cbiAgICAgIHRoaXMucHJvcGVydGllcy5vbkFjdGlvbkljb25DbGlja2VkKHJldHVybk9iakZvckNhbGxiYWNrLCBzZWxlY3RlZEFjdGlvbiwgcGFyZW50VHJlZU5vZGVzKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogdGhpcyBmdW5jdGlvbiBpcyB0aGUgY2FsbGJhY2sgZnVuY3Rpb24gZm9yIHZpZXcgYnV0dG9uXG4gICAqXG4gICAqIEBwYXJhbSB0cmVlTm9kZSAtIHRyZWUgbm9kZSB3aGVyZSBjbGlja2VkXG4gICAqL1xuICBwdWJsaWMgb25WaWV3Q2xpY2tlZCh0cmVlTm9kZTogQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllcykge1xuICAgIGlmICh0cmVlTm9kZS5kaXNhYmxlVmlld0ljb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5wcm9wZXJ0aWVzLm9uVmlld0NsaWNrZWQgIT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBjYWxsaW5nIGdlbmVyYXRlIHJldHVybiBvYmplY3QgZm9yIGNhbGwgYmFjayBmdW5jdGlvblxuICAgICAgY29uc3QgcmV0dXJuT2JqRm9yQ2FsbGJhY2s6IENsVHJlZVZpZXdDaGlsZFByb3BlcnRpZXMgPSB0aGlzLmdlbmVyYXRlUmV0dXJuT2JqZWN0Rm9yQ2FsbGJhY2sodHJlZU5vZGUpO1xuXG4gICAgICAvLyB0aGlzIGlzIHRoZSBjYWxsYmFjayBmdW5jdGlvbiBmb3IgdmlldyBidXR0b25cbiAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMucHJvcGVydGllcy5vblZpZXdDbGlja2VkKHJldHVybk9iakZvckNhbGxiYWNrKTtcblxuICAgICAgLy8gY2FsbGluZyBjaGVjayBpZiBwYXJlbnQgaXMgcHJlc2VudCBmdW5jdGlvblxuICAgICAgY29uc3QgcGFyZW50VHJlZU5vZGVzID0gdGhpcy5maW5kUGFyZW50T2ZUcmVlTm9kZSh0aGlzLnByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbiEsIHRyZWVOb2RlLmlkKTtcblxuICAgICAgLy8gY2FsbGluZyBjaGFuZ2UgYWxsIHZpZXcgZm9yIHRyZWUgbm9kZSBmdW5jdGlvblxuICAgICAgdGhpcy5jaGFuZ2VWaWV3Rm9yQWxsQ2hpbGRUcmVlTm9kZSh0cmVlTm9kZSwgcmVzdWx0KTtcblxuICAgICAgLy8gY2FsbGluZyBtYXJrIHRyZWUgbm9kZSBhcyBwYXJ0aWFsIHZpZXcgZnVuY3Rpb25cbiAgICAgIHRoaXMuY2hhbmdlVmlld0ZvckFsbFBhcmVudFRyZWVOb2RlKHBhcmVudFRyZWVOb2Rlcyk7XG4gICAgfVxuICB9XG5cbiAgb25Nb3VzZUhvdmVyRnVuY3Rpb24odHJlZTogQ2xUcmVlVmlld0NoaWxkUHJvcGVydGllcykge1xuICAgIGlmICh0aGlzLnByb3BlcnRpZXMuYWx3YXlzU2hvd0FjdGlvbkJ1dHRvbnMpIHtcbiAgICAgIHRyZWUuc2hvd0FjdGlvbkJ1dHRvbnMgPSB0cnVlXG4gICAgfVxuICB9XG5cbiAgb3ZlcnJpZGUgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgdGhpcy50cmVlVmlld1N1YnNjcmlwdGlvbi51bnN1YnNjcmliZSgpO1xuICAgIHN1cGVyLm5nT25EZXN0cm95KCk7XG4gIH1cbn1cbiIsIkBpZiAocHJvcGVydGllcy50cmVlVmlld0NoaWxkcmVuICYmIHByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbi5sZW5ndGggPiAwKSB7XG4gIDxkaXYgY2xhc3M9XCJmbGV4IHctZnVsbCBmbGV4LWNvbCByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItc29saWQgYm9yZGVyLXByaW1hcnktMTAwXCI+XG4gICAgQGZvciAodHJlZSBvZiBwcm9wZXJ0aWVzLnRyZWVWaWV3Q2hpbGRyZW47IHRyYWNrIHRyZWU7IGxldCBpbmRleCA9ICRpbmRleCkge1xuICAgICAgPGRpdiBjbGFzcz1cInt7dHJlZS5kZXB0aCA9PSAwICYmIHRyZWUuZXhwYW5kZWQgPyAnYmctbmV1dHJhbC01MCcgOiAnJ319XG4gICAgICAgIHt7IGluZGV4ID09IDAgPyAncm91bmRlZC10bC1tZCByb3VuZGVkLXRyLW1kJyA6ICcnIH19XG4gICAgICAgIHt7IGluZGV4ID09IHByb3BlcnRpZXMudHJlZVZpZXdDaGlsZHJlbi5sZW5ndGggLSAxID8gJ3JvdW5kZWQtYmwtbWQgcm91bmRlZC1ici1tZCcgOiAnJyB9fVwiPlxuXG4gICAgICAgIDxkaXYgKGNsaWNrKT1cIm9uVHJlZU5vZGVDbGlja2VkKHRyZWUpXCIgKG1vdXNlb3Zlcik9XCJvbk1vdXNlSG92ZXJGdW5jdGlvbih0cmVlKVwiXG4gICAgICAgICAgKG1vdXNlbGVhdmUpPVwidHJlZS5zaG93QWN0aW9uQnV0dG9ucyA9IGZhbHNlXCIgY2xhc3M9XCJweC00IHB5LTIgZmxleCB3LWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblxuICAgICAgICAgICAge3sgKHRyZWUuZGVwdGggPT0gMCAmJiB0cmVlLmV4cGFuZGVkKSA/ICdtYi00IGJnLW5ldXRyYWwtMTAwJyA6ICcnIH19XG4gICAgICAgICAgICB7eyAoaW5kZXggJmx0OyBwcm9wZXJ0aWVzLnRyZWVWaWV3Q2hpbGRyZW4ubGVuZ3RoIC0gMSAmJiAhdHJlZS5leHBhbmRlZCkgPyAnYm9yZGVyLWIgYm9yZGVyLXNvbGlkIGJvcmRlci1wcmltYXJ5LTEwMCcgOiAnJyB9fVxuICAgICAgICAgICAge3sgaW5kZXggPT0gMCA/ICdyb3VuZGVkLXRsLW1kIHJvdW5kZWQtdHItbWQnIDogJycgfX1cbiAgICAgICAgICAgIHt7IChpbmRleCA9PSBwcm9wZXJ0aWVzLnRyZWVWaWV3Q2hpbGRyZW4ubGVuZ3RoIC0gMSAmJiAhdHJlZS5leHBhbmRlZCkgPyAncm91bmRlZC1ibC1tZCByb3VuZGVkLWJyLW1kJyA6ICcnIH19XG4gICAgICAgICAgICB7eyAodHJlZS5zaG93QXJyb3dJY29ucyB8fCB0cmVlLmNoaWxkcmVuICYmIHRyZWUuY2hpbGRyZW4ubGVuZ3RoID4gMCkgPyAnY3Vyc29yLXBvaW50ZXInIDogJycgfX1cbiAgICAgICAgICAgIGhvdmVyOmJvcmRlciBob3Zlcjpib3JkZXItc29saWQgaG92ZXI6Ym9yZGVyLXByaW1hcnktMzAwXCI+XG5cbiAgICAgICAgICA8bWF0LWxhYmVsIGNsYXNzPVwicHktMiB0ZXh0LWJhc2UgZm9udC1ib2xkIGxlYWRpbmctNiB0ZXh0LXByaW1hcnktNzAwXCI+e3sgdHJlZS50ZXh0IH19PC9tYXQtbGFiZWw+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBnYXAtMyBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGdhcC0xIGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgICAgICBAZm9yIChjaGlwIG9mIHRyZWUuY2hpcHNMaXN0OyB0cmFjayBjaGlwKSB7XG4gICAgICAgICAgICAgICAgPGNsLWNoaXAgW3Byb3BlcnRpZXNdPVwiY2hpcFwiPjwvY2wtY2hpcD5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIEBpZiAocHJvcGVydGllcy5hbHdheXNTaG93QWN0aW9uQnV0dG9ucyB8fCB0cmVlLnNob3dBY3Rpb25CdXR0b25zIHx8IHRyZWUuZXhwYW5kZWQgJiYgISh0cmVlLmhpZGVWaWV3SWNvbiAmJiB0cmVlLmhpZGVBZGRJY29uICYmIHRyZWUuaGlkZUVkaXRJY29uICYmIHRyZWUuaGlkZURlbGV0ZUljb24pKSB7XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBbbmdDbGFzc109XCIodHJlZS5oaWRlVmlld0ljb24gJiYgdHJlZS5oaWRlQWRkSWNvbiAmJiB0cmVlLmhpZGVFZGl0SWNvbiAmJiB0cmVlLmhpZGVEZWxldGVJY29uKSA/ICcnIDogdHJlZS5leHBhbmRlZCA/ICdiZy13aGl0ZSBweC0yIHB5LTEgZmxleCBnYXAtMiByb3VuZGVkLW1kIGl0ZW1zLWNlbnRlcicgOiAnYmctbmV1dHJhbC01MCBweC0yIHB5LTEgZmxleCBnYXAtMiByb3VuZGVkLW1kIGl0ZW1zLWNlbnRlcidcIj5cblxuICAgICAgICAgICAgICAgIEBpZiAoIXRyZWUuaGlkZVZpZXdJY29uICYmIHByb3BlcnRpZXMudmlld09uSWNvblByb3BlcnRpZXMgJiYgcHJvcGVydGllcy52aWV3T2ZmSWNvblByb3BlcnRpZXMgJiYgcHJvcGVydGllcy5wYXJ0aWFsVmlld0ljb25Qcm9wZXJ0aWVzICYmIHByb3BlcnRpZXMuZGlzYWJsZVZpZXdJY29uUHJvcGVydGllcykge1xuICAgICAgICAgICAgICAgICAgPGNsLWljb24gY2xhc3M9XCJwLTEgY3Vyc29yLXBvaW50ZXJcIiAoY2xpY2spPVwiJGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpOyBvblZpZXdDbGlja2VkKHRyZWUpXCJcbiAgICAgICAgICAgICAgICAgICAgW3Byb3BlcnRpZXNdPVwidHJlZS5wYXJ0aWFsVmlldyA/IHByb3BlcnRpZXMucGFydGlhbFZpZXdJY29uUHJvcGVydGllcyA6IHRyZWUudmlld09uID8gcHJvcGVydGllcy52aWV3T25JY29uUHJvcGVydGllcyA6IHRyZWUuZGlzYWJsZVZpZXdJY29uID8gcHJvcGVydGllcy5kaXNhYmxlVmlld0ljb25Qcm9wZXJ0aWVzISA6IHByb3BlcnRpZXMudmlld09mZkljb25Qcm9wZXJ0aWVzXCI+XG4gICAgICAgICAgICAgICAgICA8L2NsLWljb24+XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgQGlmICghdHJlZS5oaWRlQWRkSWNvbikge1xuICAgICAgICAgICAgICAgICAgPGNsLWljb24gY2xhc3M9XCJwLTEgY3Vyc29yLXBvaW50ZXJcIiBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLmFkZEljb25Qcm9wZXJ0aWVzIVwiXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7IG9uQWRkQ2xpY2tlZCh0cmVlKVwiPlxuICAgICAgICAgICAgICAgICAgPC9jbC1pY29uPlxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIEBpZiAoIXRyZWUuaGlkZUVkaXRJY29uKSB7XG4gICAgICAgICAgICAgICAgICA8Y2wtaWNvbiBjbGFzcz1cInAtMSBjdXJzb3ItcG9pbnRlclwiIFtwcm9wZXJ0aWVzXT1cInByb3BlcnRpZXMuZWRpdEljb25Qcm9wZXJ0aWVzIVwiXG4gICAgICAgICAgICAgICAgICAgIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7IG9uRWRpdENsaWNrZWQodHJlZSlcIj5cbiAgICAgICAgICAgICAgICAgIDwvY2wtaWNvbj5cbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBAaWYgKCF0cmVlLmhpZGVEZWxldGVJY29uKSB7XG4gICAgICAgICAgICAgICAgICA8Y2wtaWNvbiBjbGFzcz1cInAtMSBjdXJzb3ItcG9pbnRlclwiIFtwcm9wZXJ0aWVzXT1cInByb3BlcnRpZXMuZGVsZXRlSWNvblByb3BlcnRpZXMhXCJcbiAgICAgICAgICAgICAgICAgICAgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKTsgb25EZWxldGVDbGlja2VkKHRyZWUpXCI+XG4gICAgICAgICAgICAgICAgICA8L2NsLWljb24+XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgQGlmIChwcm9wZXJ0aWVzLnNob3dBY3Rpb25JY29uKSB7XG4gICAgICAgICAgICAgIDxjbC1pY29uIGNsYXNzPVwicHktMiBjdXJzb3ItcG9pbnRlclwiIFttYXRNZW51VHJpZ2dlckZvcl09XCJhY3Rpb25Qcm9wZXJ0aWVzTWVudVwiXG4gICAgICAgICAgICAgICAgKGNsaWNrKT1cIiRldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcIiBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLmFjdGlvbkljb25Qcm9wZXJ0aWVzIVwiPlxuICAgICAgICAgICAgICA8L2NsLWljb24+XG5cbiAgICAgICAgICAgICAgPG1hdC1tZW51ICNhY3Rpb25Qcm9wZXJ0aWVzTWVudT1cIm1hdE1lbnVcIj5cbiAgICAgICAgICAgICAgICBAZm9yIChhY3Rpb24gb2YgdHJlZS5hY3Rpb25MaXN0OyB0cmFjayBhY3Rpb247IGxldCBhY3Rpb25JbmRleCA9ICRpbmRleCkge1xuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cIlwiPlxuICAgICAgICAgICAgICAgICAgICA8bWF0LWNoZWNrYm94IFtjaGVja2VkXT1cImFjdGlvbi5jaGVja2VkXCIgW2luZGV0ZXJtaW5hdGVdPVwiYWN0aW9uLmluZGV0ZXJtaW5hdGVcIlxuICAgICAgICAgICAgICAgICAgICAgIFtkaXNhYmxlZF09XCJhY3Rpb24uZGlzYWJsZWRcIiBbY29sb3JdPVwiYWN0aW9uLmluZGV0ZXJtaW5hdGUgPyAnd2FybicgOiAncHJpbWFyeSdcIlxuICAgICAgICAgICAgICAgICAgICAgIChjbGljayk9XCIkZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7IG9uQWN0aW9uSWNvbkNsaWNrZWQodHJlZSwgYWN0aW9uLmxhYmVsLCBhY3Rpb25JbmRleClcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7eyBhY3Rpb24ubGFiZWwgfX1cbiAgICAgICAgICAgICAgICAgICAgPC9tYXQtY2hlY2tib3g+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIDwvbWF0LW1lbnU+XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIEBpZiAodHJlZS5leHBhbmRlZCAmJiB0cmVlLmNoaWxkcmVuICYmIHRyZWUuY2hpbGRyZW4ubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgICA8Y2wtaWNvbiBjbGFzcz1cInB5LTJcIiBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLnVwQXJyb3dJY29uUHJvcGVydGllcyFcIj5cbiAgICAgICAgICAgICAgPC9jbC1pY29uPlxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBAaWYgKCF0cmVlLmV4cGFuZGVkICYmICh0cmVlLnNob3dBcnJvd0ljb25zIHx8IHRyZWUuY2hpbGRyZW4gJiYgdHJlZS5jaGlsZHJlbi5sZW5ndGggPiAwKSkge1xuICAgICAgICAgICAgICA8Y2wtaWNvbiBjbGFzcz1cInB5LTJcIiBbcHJvcGVydGllc109XCJwcm9wZXJ0aWVzLmRvd25BcnJvd0ljb25Qcm9wZXJ0aWVzIVwiPlxuICAgICAgICAgICAgICA8L2NsLWljb24+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIEBpZiAodHJlZS5jaGlsZHJlbiAmJiB0cmVlLmNoaWxkcmVuLmxlbmd0aCA+IDAgJiYgdHJlZS5leHBhbmRlZCkge1xuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8Y2wtY2hpbGQtdHJlZS12aWV3IFtwcm9wZXJ0aWVzXT1cInRyZWUuY2hpbGRyZW5cIiBbdHJlZVZpZXdDb25maWddPVwicHJvcGVydGllc1wiIChhZGRDbGlja2VkKT1cIm9uQWRkQ2xpY2tlZCgkZXZlbnQpXCJcbiAgICAgICAgICAgICAgKGVkaXRDbGlja2VkKT1cIm9uRWRpdENsaWNrZWQoJGV2ZW50KVwiICh2aWV3Q2xpY2tlZCk9XCJvblZpZXdDbGlja2VkKCRldmVudClcIlxuICAgICAgICAgICAgICAoZGVsZXRlQ2xpY2tlZCk9XCJvbkRlbGV0ZUNsaWNrZWQoJGV2ZW50KVwiXG4gICAgICAgICAgICAgIChhY3Rpb25DbGlja2VkKT1cIm9uQWN0aW9uSWNvbkNsaWNrZWQoJGV2ZW50LnRyZWVOb2RlLCAkZXZlbnQuc2VsZWN0ZWRBY3Rpb24sICRldmVudC5pbmRleClcIlxuICAgICAgICAgICAgICAodHJlZU5vZGVDbGlja2VkKT1cIm9uVHJlZU5vZGVDbGlja2VkKCRldmVudClcIj5cbiAgICAgICAgICAgIDwvY2wtY2hpbGQtdHJlZS12aWV3PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gIDwvZGl2PlxufVxuIl19